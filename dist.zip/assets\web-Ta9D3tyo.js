import{W as n}from"./index-Co3NGl_e.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
