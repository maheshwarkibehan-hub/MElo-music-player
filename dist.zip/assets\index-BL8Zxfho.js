(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))r(i);new MutationObserver(i=>{for(const s of i)if(s.type==="childList")for(const w of s.addedNodes)w.tagName==="LINK"&&w.rel==="modulepreload"&&r(w)}).observe(document,{childList:!0,subtree:!0});function a(i){const s={};return i.integrity&&(s.integrity=i.integrity),i.referrerPolicy&&(s.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?s.credentials="include":i.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function r(i){if(i.ep)return;i.ep=!0;const s=a(i);fetch(i.href,s)}})();const Jt=new Map;let Pe=null;const Y={register(e,t){Jt.set(e,t)},init(e){Pe=e,window.addEventListener("hashchange",()=>this._navigate()),this._navigate()},navigate(e){window.location.hash=e},getCurrentRoute(){return(window.location.hash.slice(1)||"home").split("?")[0]},getParams(){const t=(window.location.hash.slice(1)||"").split("?")[1];return new URLSearchParams(t||"")},_navigate(){const e=this.getCurrentRoute(),t=Jt.get(e);if(t&&Pe){Pe.innerHTML="";const a=t();typeof a=="string"?Pe.innerHTML=a:a instanceof HTMLElement&&Pe.appendChild(a),window.dispatchEvent(new CustomEvent("routechange",{detail:{route:e}}))}}},t0="melo_state",r0={interests:[],onboarded:!1,recentlyPlayed:[],likedSongs:[],playlists:[],trackMetadata:{},currentTrackId:null,queue:[],queueIndex:0,shuffle:!1,repeat:"off",volume:1,downloads:{}};let q={...r0};function R0(){try{const e=localStorage.getItem(t0);e&&(q={...r0,...JSON.parse(e)})}catch(e){console.warn("Failed to load state:",e)}}function N0(){try{localStorage.setItem(t0,JSON.stringify(q))}catch(e){console.warn("Failed to save state:",e)}}const $t=new Set;function M0(e){return $t.add(e),()=>$t.delete(e)}function X(e){$t.forEach(t=>t(e,q)),N0()}const M={get:()=>q,subscribe:M0,setInterests(e){q.interests=e,q.onboarded=!0,X("interests")},addRecentlyPlayed(e){!e||!e.id||(q.trackMetadata[e.id]=e,q.recentlyPlayed=[e.id,...q.recentlyPlayed.filter(t=>t!==e.id)].slice(0,20),X("recentlyPlayed"))},toggleLike(e){if(!e||!e.id)return;q.trackMetadata[e.id]=e;const t=e.id,a=q.likedSongs.indexOf(t);a===-1?q.likedSongs.push(t):q.likedSongs.splice(a,1),X("likedSongs")},isLiked(e){return q.likedSongs.includes(e)},setQueue(e,t=0){q.queue=[...e],q.queueIndex=t,q.currentTrackId=e[t]||null,X("queue")},nextInQueue(){if(q.repeat==="one")return X("queue"),q.currentTrackId;if(q.shuffle){const e=q.queue.filter(t=>t!==q.currentTrackId);if(e.length>0){const t=e[Math.floor(Math.random()*e.length)];q.queueIndex=q.queue.indexOf(t),q.currentTrackId=t}}else{if(q.queueIndex++,q.queueIndex>=q.queue.length)if(q.repeat==="all")q.queueIndex=0;else return q.queueIndex=q.queue.length-1,X("queue"),null;q.currentTrackId=q.queue[q.queueIndex]}return X("queue"),q.currentTrackId},prevInQueue(){if(q.shuffle){const e=q.queue.filter(t=>t!==q.currentTrackId);if(e.length>0){const t=e[Math.floor(Math.random()*e.length)];q.queueIndex=q.queue.indexOf(t),q.currentTrackId=t}}else q.queueIndex--,q.queueIndex<0&&(q.queueIndex=q.repeat==="all"?q.queue.length-1:0),q.currentTrackId=q.queue[q.queueIndex];return X("queue"),q.currentTrackId},toggleShuffle(){q.shuffle=!q.shuffle,X("shuffle")},cycleRepeat(){const e=["off","all","one"],t=e.indexOf(q.repeat);q.repeat=e[(t+1)%e.length],X("repeat")},setVolume(e){q.volume=Math.max(0,Math.min(1,e)),X("volume")},createPlaylist(e){const t=Date.now().toString();return q.playlists.push({id:t,name:e,trackIds:[]}),X("playlists"),t},addToPlaylist(e,t){if(!t||!t.id)return;q.trackMetadata[t.id]=t;const a=q.playlists.find(r=>r.id===e);a&&!a.trackIds.includes(t.id)&&(a.trackIds.push(t.id),X("playlists"))},removeFromPlaylist(e,t){const a=q.playlists.find(r=>r.id===e);a&&(a.trackIds=a.trackIds.filter(r=>r!==t),X("playlists"))},deletePlaylist(e){q.playlists=q.playlists.filter(t=>t.id!==e),X("playlists")},updateDownload(e,t){q.downloads[e]={...q.downloads[e],...t},t.track&&(q.trackMetadata[e]=t.track),X("downloads")},removeDownload(e){delete q.downloads[e],X("downloads")},isDownloadComplete(e){var t;return((t=q.downloads[e])==null?void 0:t.status)==="complete"},getDownloads(){return Object.entries(q.downloads).filter(([,e])=>e.status==="complete").map(([e,t])=>({id:e,...t}))}};R0();function I0(){const e=document.createElement("nav");e.className="navbar",e.innerHTML=`
    <button class="nav-item active" data-route="home" id="nav-home">
      <span class="material-symbols-rounded">home</span>
      <span class="nav-label">Home</span>
    </button>
    <button class="nav-item" data-route="search" id="nav-search">
      <span class="material-symbols-rounded">search</span>
      <span class="nav-label">Search</span>
    </button>
    <button class="nav-item" data-route="library" id="nav-library">
      <span class="material-symbols-rounded">library_music</span>
      <span class="nav-label">Library</span>
    </button>
  `;const t=e.querySelectorAll(".nav-item");return t.forEach(a=>{a.addEventListener("click",()=>{Y.navigate(a.dataset.route)})}),window.addEventListener("routechange",a=>{t.forEach(r=>{r.classList.toggle("active",r.dataset.route===a.detail.route)})}),e}const a0=document.createElement("style");a0.textContent=`
  .navbar {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 100;
    display: flex;
    align-items: center;
    justify-content: space-around;
    height: var(--nav-height);
    background: linear-gradient(to top, var(--bg-primary) 60%, transparent);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    padding-bottom: var(--safe-bottom);
    border-top: 1px solid var(--surface-border);
  }

  .nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2px;
    padding: var(--space-sm) var(--space-xl);
    border: none;
    background: transparent;
    color: var(--text-tertiary);
    cursor: pointer;
    transition: color var(--transition-fast), transform var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
    font-family: var(--font-family);
    border-radius: var(--radius-lg);
  }

  .nav-item:active {
    transform: scale(0.9);
  }

  .nav-item .material-symbols-rounded {
    font-size: 26px;
    transition: font-variation-settings var(--transition-fast);
  }

  .nav-item.active {
    color: var(--text-primary);
  }

  .nav-item.active .material-symbols-rounded {
    font-variation-settings: 'FILL' 1, 'wght' 600, 'GRAD' 0, 'opsz' 24;
  }

  .nav-label {
    font-size: 10px;
    font-weight: 500;
    letter-spacing: 0.02em;
  }
`;document.head.appendChild(a0);const O0="modulepreload",j0=function(e){return"/"+e},er={},ve=function(t,a,r){let i=Promise.resolve();if(a&&a.length>0){let w=function(n){return Promise.all(n.map(d=>Promise.resolve(d).then(b=>({status:"fulfilled",value:b}),b=>({status:"rejected",reason:b}))))};document.getElementsByTagName("link");const c=document.querySelector("meta[property=csp-nonce]"),h=(c==null?void 0:c.nonce)||(c==null?void 0:c.getAttribute("nonce"));i=w(a.map(n=>{if(n=j0(n),n in er)return;er[n]=!0;const d=n.endsWith(".css"),b=d?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${n}"]${b}`))return;const o=document.createElement("link");if(o.rel=d?"stylesheet":O0,d||(o.as="script"),o.crossOrigin="",o.href=n,h&&o.setAttribute("nonce",h),document.head.appendChild(o),d)return new Promise((x,f)=>{o.addEventListener("load",x),o.addEventListener("error",()=>f(new Error(`Unable to preload CSS for ${n}`)))})}))}function s(w){const c=new Event("vite:preloadError",{cancelable:!0});if(c.payload=w,window.dispatchEvent(c),!c.defaultPrevented)throw w}return i.then(w=>{for(const c of w||[])c.status==="rejected"&&s(c.reason);return t().catch(s)})};/*! Capacitor: https://capacitorjs.com/ - MIT License */var Be;(function(e){e.Unimplemented="UNIMPLEMENTED",e.Unavailable="UNAVAILABLE"})(Be||(Be={}));class Dt extends Error{constructor(t,a,r){super(t),this.message=t,this.code=a,this.data=r}}const U0=e=>{var t,a;return e!=null&&e.androidBridge?"android":!((a=(t=e==null?void 0:e.webkit)===null||t===void 0?void 0:t.messageHandlers)===null||a===void 0)&&a.bridge?"ios":"web"},W0=e=>{const t=e.CapacitorCustomPlatform||null,a=e.Capacitor||{},r=a.Plugins=a.Plugins||{},i=()=>t!==null?t.name:U0(e),s=()=>i()!=="web",w=b=>{const o=n.get(b);return!!(o!=null&&o.platforms.has(i())||c(b))},c=b=>{var o;return(o=a.PluginHeaders)===null||o===void 0?void 0:o.find(x=>x.name===b)},h=b=>e.console.error(b),n=new Map,d=(b,o={})=>{const x=n.get(b);if(x)return console.warn(`Capacitor plugin "${b}" already registered. Cannot register plugins twice.`),x.proxy;const f=i(),y=c(b);let m;const u=async()=>(!m&&f in o?m=typeof o[f]=="function"?m=await o[f]():m=o[f]:t!==null&&!m&&"web"in o&&(m=typeof o.web=="function"?m=await o.web():m=o.web),m),l=(B,D)=>{var A,_;if(y){const k=y==null?void 0:y.methods.find(F=>D===F.name);if(k)return k.rtype==="promise"?F=>a.nativePromise(b,D.toString(),F):(F,T)=>a.nativeCallback(b,D.toString(),F,T);if(B)return(A=B[D])===null||A===void 0?void 0:A.bind(B)}else{if(B)return(_=B[D])===null||_===void 0?void 0:_.bind(B);throw new Dt(`"${b}" plugin is not implemented on ${f}`,Be.Unimplemented)}},p=B=>{let D;const A=(..._)=>{const k=u().then(F=>{const T=l(F,B);if(T){const H=T(..._);return D=H==null?void 0:H.remove,H}else throw new Dt(`"${b}.${B}()" is not implemented on ${f}`,Be.Unimplemented)});return B==="addListener"&&(k.remove=async()=>D()),k};return A.toString=()=>`${B.toString()}() { [capacitor code] }`,Object.defineProperty(A,"name",{value:B,writable:!1,configurable:!1}),A},g=p("addListener"),v=p("removeListener"),E=(B,D)=>{const A=g({eventName:B},D),_=async()=>{const F=await A;v({eventName:B,callbackId:F},D)},k=new Promise(F=>A.then(()=>F({remove:_})));return k.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await _()},k},C=new Proxy({},{get(B,D){switch(D){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return y?E:g;case"removeListener":return v;default:return p(D)}}});return r[b]=C,n.set(b,{name:b,proxy:C,platforms:new Set([...Object.keys(o),...y?[f]:[]])}),C};return a.convertFileSrc||(a.convertFileSrc=b=>b),a.getPlatform=i,a.handleError=h,a.isNativePlatform=s,a.isPluginAvailable=w,a.registerPlugin=d,a.Exception=Dt,a.DEBUG=!!a.DEBUG,a.isLoggingEnabled=!!a.isLoggingEnabled,a},K0=e=>e.Capacitor=W0(e),wt=K0(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),le=wt.registerPlugin;class zt{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(t,a){let r=!1;this.listeners[t]||(this.listeners[t]=[],r=!0),this.listeners[t].push(a);const s=this.windowListeners[t];s&&!s.registered&&this.addWindowListener(s),r&&this.sendRetainedArgumentsForEvent(t);const w=async()=>this.removeListener(t,a);return Promise.resolve({remove:w})}async removeAllListeners(){this.listeners={};for(const t in this.windowListeners)this.removeWindowListener(this.windowListeners[t]);this.windowListeners={}}notifyListeners(t,a,r){const i=this.listeners[t];if(!i){if(r){let s=this.retainedEventArguments[t];s||(s=[]),s.push(a),this.retainedEventArguments[t]=s}return}i.forEach(s=>s(a))}hasListeners(t){var a;return!!(!((a=this.listeners[t])===null||a===void 0)&&a.length)}registerWindowListener(t,a){this.windowListeners[a]={registered:!1,windowEventName:t,pluginEventName:a,handler:r=>{this.notifyListeners(a,r)}}}unimplemented(t="not implemented"){return new wt.Exception(t,Be.Unimplemented)}unavailable(t="not available"){return new wt.Exception(t,Be.Unavailable)}async removeListener(t,a){const r=this.listeners[t];if(!r)return;const i=r.indexOf(a);this.listeners[t].splice(i,1),this.listeners[t].length||this.removeWindowListener(this.windowListeners[t])}addWindowListener(t){window.addEventListener(t.windowEventName,t.handler),t.registered=!0}removeWindowListener(t){t&&(window.removeEventListener(t.windowEventName,t.handler),t.registered=!1)}sendRetainedArgumentsForEvent(t){const a=this.retainedEventArguments[t];a&&(delete this.retainedEventArguments[t],a.forEach(r=>{this.notifyListeners(t,r)}))}}const tr=e=>encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),rr=e=>e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class G0 extends zt{async getCookies(){const t=document.cookie,a={};return t.split(";").forEach(r=>{if(r.length<=0)return;let[i,s]=r.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");i=rr(i).trim(),s=rr(s).trim(),a[i]=s}),a}async setCookie(t){try{const a=tr(t.key),r=tr(t.value),i=t.expires?`; expires=${t.expires.replace("expires=","")}`:"",s=(t.path||"/").replace("path=",""),w=t.url!=null&&t.url.length>0?`domain=${t.url}`:"";document.cookie=`${a}=${r||""}${i}; path=${s}; ${w};`}catch(a){return Promise.reject(a)}}async deleteCookie(t){try{document.cookie=`${t.key}=; Max-Age=0`}catch(a){return Promise.reject(a)}}async clearCookies(){try{const t=document.cookie.split(";")||[];for(const a of t)document.cookie=a.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(t){return Promise.reject(t)}}async clearAllCookies(){try{await this.clearCookies()}catch(t){return Promise.reject(t)}}}le("CapacitorCookies",{web:()=>new G0});const V0=async e=>new Promise((t,a)=>{const r=new FileReader;r.onload=()=>{const i=r.result;t(i.indexOf(",")>=0?i.split(",")[1]:i)},r.onerror=i=>a(i),r.readAsDataURL(e)}),X0=(e={})=>{const t=Object.keys(e);return Object.keys(e).map(i=>i.toLocaleLowerCase()).reduce((i,s,w)=>(i[s]=e[t[w]],i),{})},Y0=(e,t=!0)=>e?Object.entries(e).reduce((r,i)=>{const[s,w]=i;let c,h;return Array.isArray(w)?(h="",w.forEach(n=>{c=t?encodeURIComponent(n):n,h+=`${s}=${c}&`}),h.slice(0,-1)):(c=t?encodeURIComponent(w):w,h=`${s}=${c}`),`${r}&${h}`},"").substr(1):null,Q0=(e,t={})=>{const a=Object.assign({method:e.method||"GET",headers:e.headers},t),i=X0(e.headers)["content-type"]||"";if(typeof e.data=="string")a.body=e.data;else if(i.includes("application/x-www-form-urlencoded")){const s=new URLSearchParams;for(const[w,c]of Object.entries(e.data||{}))s.set(w,c);a.body=s.toString()}else if(i.includes("multipart/form-data")||e.data instanceof FormData){const s=new FormData;if(e.data instanceof FormData)e.data.forEach((c,h)=>{s.append(h,c)});else for(const c of Object.keys(e.data))s.append(c,e.data[c]);a.body=s;const w=new Headers(a.headers);w.delete("content-type"),a.headers=w}else(i.includes("application/json")||typeof e.data=="object")&&(a.body=JSON.stringify(e.data));return a};class Z0 extends zt{async request(t){const a=Q0(t,t.webFetchExtra),r=Y0(t.params,t.shouldEncodeUrlParams),i=r?`${t.url}?${r}`:t.url,s=await fetch(i,a),w=s.headers.get("content-type")||"";let{responseType:c="text"}=s.ok?t:{};w.includes("application/json")&&(c="json");let h,n;switch(c){case"arraybuffer":case"blob":n=await s.blob(),h=await V0(n);break;case"json":h=await s.json();break;case"document":case"text":default:h=await s.text()}const d={};return s.headers.forEach((b,o)=>{d[o]=b}),{data:h,headers:d,status:s.status,url:s.url}}async get(t){return this.request(Object.assign(Object.assign({},t),{method:"GET"}))}async post(t){return this.request(Object.assign(Object.assign({},t),{method:"POST"}))}async put(t){return this.request(Object.assign(Object.assign({},t),{method:"PUT"}))}async patch(t){return this.request(Object.assign(Object.assign({},t),{method:"PATCH"}))}async delete(t){return this.request(Object.assign(Object.assign({},t),{method:"DELETE"}))}}const J0=le("CapacitorHttp",{web:()=>new Z0});var ar;(function(e){e.Dark="DARK",e.Light="LIGHT",e.Default="DEFAULT"})(ar||(ar={}));var nr;(function(e){e.StatusBar="StatusBar",e.NavigationBar="NavigationBar"})(nr||(nr={}));class ea extends zt{async setStyle(){this.unavailable("not available for web")}async setAnimation(){this.unavailable("not available for web")}async show(){this.unavailable("not available for web")}async hide(){this.unavailable("not available for web")}}le("SystemBars",{web:()=>new ea});var Ct;(function(e){e.Heavy="HEAVY",e.Medium="MEDIUM",e.Light="LIGHT"})(Ct||(Ct={}));var ir;(function(e){e.Success="SUCCESS",e.Warning="WARNING",e.Error="ERROR"})(ir||(ir={}));const n0=le("Haptics",{web:()=>ve(()=>import("./web-D239cdEH.js"),[]).then(e=>new e.HapticsWeb)}),ta="melo_downloads",ra=1,Z="tracks";let He=null;const qt=new Set;function we(){return new Promise((e,t)=>{if(He)return e(He);const a=indexedDB.open(ta,ra);a.onupgradeneeded=r=>{const i=r.target.result;i.objectStoreNames.contains(Z)||i.createObjectStore(Z,{keyPath:"id"})},a.onsuccess=r=>{He=r.target.result,e(He)},a.onerror=r=>t(r.target.error)})}function ze(e,t){qt.forEach(a=>a(e,t))}async function sr(e){const t=await fetch(e);if(!t.ok)throw new Error(`Download failed: ${t.status}`);return await t.blob()}const he={on(e){return qt.add(e),()=>qt.delete(e)},async downloadTrack(e){if(!e||!e.url||!e.id)return!1;try{if(await this.isDownloaded(e.id))return console.log("Already downloaded:",e.title),!0;ze("start",{trackId:e.id,title:e.title}),M.updateDownload(e.id,{status:"downloading",track:e});const t=await sr(e.url);let a=null;try{const c=e.coverSmall||e.cover;c&&(a=await sr(c))}catch(c){console.warn("Cover download failed:",c)}const s=(await we()).transaction(Z,"readwrite").objectStore(Z),w={id:e.id,title:e.title,artist:e.artist,album:e.album||"",duration:e.duration||0,cover:e.cover||"",coverSmall:e.coverSmall||"",originalUrl:e.url,audioBlob:t,coverBlob:a,downloadedAt:Date.now(),size:t.size};return await new Promise((c,h)=>{const n=s.put(w);n.onsuccess=()=>c(),n.onerror=d=>h(d.target.error)}),M.updateDownload(e.id,{status:"complete",track:e}),ze("complete",{trackId:e.id,title:e.title}),console.log(`Downloaded: ${e.title} (${(t.size/1024/1024).toFixed(1)}MB)`),!0}catch(t){return console.error("Download failed:",t),M.updateDownload(e.id,{status:"error",track:e}),ze("error",{trackId:e.id,error:t.message}),!1}},async isDownloaded(e){try{const r=(await we()).transaction(Z,"readonly").objectStore(Z);return new Promise(i=>{const s=r.get(e);s.onsuccess=()=>i(!!s.result),s.onerror=()=>i(!1)})}catch{return!1}},async getPlaybackUrl(e){try{const r=(await we()).transaction(Z,"readonly").objectStore(Z);return new Promise((i,s)=>{const w=r.get(e);w.onsuccess=()=>{w.result&&w.result.audioBlob?i(URL.createObjectURL(w.result.audioBlob)):i(null)},w.onerror=()=>i(null)})}catch{return null}},async getCoverUrl(e){try{const r=(await we()).transaction(Z,"readonly").objectStore(Z);return new Promise(i=>{const s=r.get(e);s.onsuccess=()=>{s.result&&s.result.coverBlob?i(URL.createObjectURL(s.result.coverBlob)):i(null)},s.onerror=()=>i(null)})}catch{return null}},async getAllDownloads(){try{const a=(await we()).transaction(Z,"readonly").objectStore(Z);return new Promise(r=>{const i=a.getAll();i.onsuccess=()=>{const s=(i.result||[]).map(w=>({id:w.id,title:w.title,artist:w.artist,album:w.album,duration:w.duration,cover:w.cover,coverSmall:w.coverSmall,url:w.originalUrl,downloadedAt:w.downloadedAt,size:w.size}));s.sort((w,c)=>c.downloadedAt-w.downloadedAt),r(s)},i.onerror=()=>r([])})}catch{return[]}},async deleteDownload(e){try{const r=(await we()).transaction(Z,"readwrite").objectStore(Z);return await new Promise((i,s)=>{const w=r.delete(e);w.onsuccess=()=>i(),w.onerror=c=>s(c.target.error)}),M.removeDownload(e),ze("deleted",{trackId:e}),!0}catch(t){return console.error("Delete failed:",t),!1}},async getTotalSize(){return(await this.getAllDownloads()).reduce((t,a)=>t+(a.size||0),0)}},de=le("MediaPlugin"),kt=async()=>{try{await n0.impact({style:Ct.Light})}catch{}};class aa{constructor(){this.audio=new Audio,this.audio.preload="none",this.isPlaying=!1,this.currentTrack=null,this._listeners=new Map,this._trackCache=new Map,this._useNative=!1,this._detectNative(),this.audio.addEventListener("ended",()=>this._onEnded()),this.audio.addEventListener("timeupdate",()=>{this._emit("timeupdate",{currentTime:this.audio.currentTime,duration:this.audio.duration||0})}),this.audio.addEventListener("loadedmetadata",()=>this._emit("loaded",{duration:this.audio.duration})),this.audio.addEventListener("play",()=>{this.isPlaying=!0,this._emit("statechange",{isPlaying:!0})}),this.audio.addEventListener("pause",()=>{this.isPlaying=!1,this._emit("statechange",{isPlaying:!1})}),this.audio.addEventListener("error",t=>{console.warn("Audio error:",t),this._emit("error",t),setTimeout(()=>this.next(),1e3)}),this._setupMediaSession()}async _detectNative(){try{window.Capacitor&&window.Capacitor.isNativePlatform()&&(this._useNative=!0,console.log("[Melo] Native Media3 bridge active"),de.addListener("mediaNext",()=>{console.log("[Melo] Notification: next"),this.next()}),de.addListener("mediaPrev",()=>{console.log("[Melo] Notification: prev"),this.prev()}),de.addListener("mediaEnded",()=>{console.log("[Melo] Native playback ended. Triggering auto-play/queue..."),this._onEnded()}),de.addListener("timeupdate",t=>{this._emit("timeupdate",{currentTime:t.position,duration:t.duration||(this.currentTrack?this.currentTrack.duration:0)})}))}catch{console.log("[Melo] Web fallback mode")}}on(t,a){return this._listeners.has(t)||this._listeners.set(t,new Set),this._listeners.get(t).add(a),()=>{var r;return(r=this._listeners.get(t))==null?void 0:r.delete(a)}}_emit(t,a){var r;(r=this._listeners.get(t))==null||r.forEach(i=>i(a))}cacheTrack(t){t&&t.id&&this._trackCache.set(t.id,t)}cacheTracks(t){t.forEach(a=>this.cacheTrack(a))}getCachedTrack(t){return this._trackCache.get(t)||M.get().trackMetadata[t]||null}async playTrack(t){if(!t||!t.url)return;this.currentTrack=t,this.cacheTrack(t);const r=await he.getPlaybackUrl(t.id)||t.url;if(this._useNative)try{const i=(t.cover||"").replace(/^http:\/\//i,"https://");await de.play({url:r,title:t.title||"Melo Music",artist:t.artist||"Melo",cover:i}),this.isPlaying=!0,this._emit("statechange",{isPlaying:!0})}catch(i){console.warn("[Melo] Native play failed, falling back to web:",i),this._playWeb(r)}else this._playWeb(r);M.addRecentlyPlayed(t),this._emit("trackchange",t)}_playWeb(t){this.audio.src=t,this.audio.play().catch(a=>console.warn("Play failed:",a)),this._updateMediaSession()}playTrackById(t){const a=this.getCachedTrack(t);a&&this.playTrack(a)}playAll(t,a){this.cacheTracks(t);const r=t.map(s=>s.id),i=a?r.indexOf(a.id):0;M.setQueue(r,Math.max(0,i)),this.playTrack(t[Math.max(0,i)])}async play(){if(this._useNative)try{await de.resume(),this.isPlaying=!0,this._emit("statechange",{isPlaying:!0})}catch{this.audio.src&&this.audio.play().catch(()=>{})}else this.audio.src&&this.audio.play().catch(t=>console.warn("Play failed:",t))}async pause(){if(this._useNative)try{await de.pause()}catch{}this.audio.pause(),this.isPlaying=!1,this._emit("statechange",{isPlaying:!1})}togglePlay(){kt(),this.isPlaying?this.pause():this.play()}next(){kt();const t=M.nextInQueue();if(t){const a=this.getCachedTrack(t);a&&this.playTrack(a)}else this.pause(),this.audio.currentTime=0}prev(){if(kt(),this.audio.currentTime>3){this.audio.currentTime=0,this._useNative&&de.seek({position:0}).catch(()=>{});return}const t=M.prevInQueue();if(t){const a=this.getCachedTrack(t);a&&this.playTrack(a)}}seek(t){isFinite(t)&&(this.audio.currentTime=t,this._useNative&&de.seek({position:Math.round(t*1e3)}).catch(()=>{}))}seekPercent(t){this.currentTrack&&isFinite(this.currentTrack.duration)&&this.currentTrack.duration>0?this.seek(this.currentTrack.duration*t):this.audio.duration&&isFinite(this.audio.duration)&&this.seek(this.audio.duration*t)}setVolume(t){this.audio.volume=Math.max(0,Math.min(1,t)),M.setVolume(t)}_detectMood(t){if(!t)return"hindi songs";const a=`${t.title||""} ${t.artist||""} ${t.album||""}`.toLowerCase(),r=[{keywords:["sad","dard","dil","tanha","alvida","bewafa","rona","aansu","judai","broken","heartbreak","emotional"],query:"sad emotional hindi songs"},{keywords:["romantic","love","pyar","ishq","mohabbat","prem","valentine","couple"],query:"romantic love hindi songs"},{keywords:["party","dance","club","dj","remix","bass","beat","drop","edm"],query:"party dance hindi songs"},{keywords:["lofi","lo-fi","chill","relax","sleep","calm","acoustic","unplugged","slowed"],query:"lofi chill hindi songs"},{keywords:["motivat","inspire","workout","gym","energy","power","pump"],query:"motivational workout hindi songs"},{keywords:["sufi","qawwali","devotion","bhajan","spiritual"],query:"sufi devotional songs"},{keywords:["rap","hip hop","hiphop","rapper","bars"],query:"hindi rap hip hop songs"},{keywords:["old","classic","90s","80s","70s","retro","purana"],query:"old classic bollywood hits"},{keywords:["punjabi","bhangra","jatt"],query:"punjabi latest songs"}];for(const i of r)if(i.keywords.some(s=>a.includes(s)))return i.query;return t.artist?`${t.artist.split(",")[0].trim()} best songs`:"trending hindi songs 2025"}async _onEnded(){const t=M.nextInQueue();if(t){const a=this.getCachedTrack(t);if(a){this.playTrack(a);return}}if(this.currentTrack){if(this.currentTrack.type==="podcast_episode"){console.log("[Melo] Podcast ended, auto-play disabled for podcasts."),this.pause(),this.audio.currentTime=0;return}try{const{searchSongs:a}=await ve(async()=>{const{searchSongs:s}=await Promise.resolve().then(()=>m0);return{searchSongs:s}},void 0),r=this._detectMood(this.currentTrack);console.log("[Melo] Auto-play mood query:",r);const i=await a(r);if(i.length>0){const s=new Set(M.get().queue),w=i.filter(n=>!s.has(n.id)),c=w.length>0?w:i;this.cacheTracks(c);const h=c.map(n=>n.id);M.setQueue(h,0),this.playTrack(c[0]);return}}catch(a){console.warn("Auto-play fetch failed:",a)}}this.pause(),this.audio.currentTime=0}_setupMediaSession(){"mediaSession"in navigator&&(navigator.mediaSession.setActionHandler("play",()=>this.play()),navigator.mediaSession.setActionHandler("pause",()=>this.pause()),navigator.mediaSession.setActionHandler("previoustrack",()=>this.prev()),navigator.mediaSession.setActionHandler("nexttrack",()=>this.next()),navigator.mediaSession.setActionHandler("seekto",t=>{t.seekTime!=null&&this.seek(t.seekTime)}),navigator.mediaSession.setActionHandler("stop",()=>{this.pause(),this.audio.currentTime=0}))}_updateMediaSession(){if(!this.currentTrack||!("mediaSession"in navigator))return;const t=(this.currentTrack.cover||"").replace(/^http:\/\//i,"https://");try{navigator.mediaSession.metadata=new MediaMetadata({title:this.currentTrack.title||"Melo Music",artist:this.currentTrack.artist||"Melo",album:this.currentTrack.album||"Melo Music",artwork:[{src:t,sizes:"512x512",type:"image/jpeg"}]})}catch{}}}const z=new aa;function na(){const e=document.createElement("div");e.className="miniplayer glass",e.innerHTML=`
    <div class="mini-progress-bg">
      <div class="mini-progress-fill" id="mini-progress"></div>
    </div>
    <div class="mini-content">
      <div class="mini-info" id="mini-open">
        <img class="mini-art" id="mini-art" src="" alt="" />
        <div class="mini-text">
          <div class="mini-title" id="mini-title">Not Playing</div>
          <div class="mini-artist" id="mini-artist">Select a song</div>
        </div>
      </div>
      <div class="mini-controls">
        <button class="btn-icon" id="mini-prev">
          <span class="material-symbols-rounded">skip_previous</span>
        </button>
        <button class="btn-play" id="mini-play" style="width: 40px; height: 40px;">
          <span class="material-symbols-rounded" style="font-size: 24px;">play_arrow</span>
        </button>
        <button class="btn-icon" id="mini-next">
          <span class="material-symbols-rounded">skip_next</span>
        </button>
      </div>
    </div>
  `;const t=i=>{e.querySelector("#mini-art").src=i.coverSmall||i.cover,e.querySelector("#mini-title").textContent=i.title,e.querySelector("#mini-artist").textContent=i.artist,e.classList.add("active");const s=Y.getCurrentRoute();["nowplaying","onboarding"].includes(s)||(e.style.display="block")},a=i=>{const s=e.querySelector("#mini-play .material-symbols-rounded");s.textContent=i?"pause":"play_arrow"},r=(i,s)=>{const w=i/s*100;e.querySelector("#mini-progress").style.width=`${w}%`};return e.querySelector("#mini-open").addEventListener("click",()=>{Y.navigate("nowplaying")}),e.querySelector("#mini-play").addEventListener("click",i=>{i.stopPropagation(),z.togglePlay()}),e.querySelector("#mini-prev").addEventListener("click",i=>{i.stopPropagation(),z.prev()}),e.querySelector("#mini-next").addEventListener("click",i=>{i.stopPropagation(),z.next()}),z.on("trackchange",t),z.on("statechange",({isPlaying:i})=>a(i)),z.on("timeupdate",({currentTime:i,duration:s})=>r(i,s)),window.addEventListener("routechange",i=>{const s=["nowplaying","onboarding"].includes(i.detail.route);e.style.display=s?"none":z.currentTrack?"block":"none"}),z.currentTrack?(t(z.currentTrack),a(z.isPlaying),e.style.display="block"):e.style.display="none",e}const i0=document.createElement("style");i0.textContent=`
  .miniplayer {
    position: fixed;
    bottom: calc(var(--nav-height) + var(--safe-bottom) + var(--space-md));
    left: var(--space-md);
    right: var(--space-md);
    height: var(--miniplayer-height);
    border-radius: var(--radius-lg);
    z-index: 101;
    overflow: hidden;
    box-shadow: var(--shadow-lg);
    transition: transform var(--transition-normal), opacity var(--transition-normal);
  }

  .miniplayer:not(.active) {
    display: none;
  }

  .mini-progress-bg {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 2px;
    background: rgba(255,255,255,0.05);
  }

  .mini-progress-fill {
    height: 100%;
    background: var(--accent);
    width: 0;
  }

  .mini-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 100%;
    padding: 0 var(--space-md);
  }

  .mini-info {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    flex: 1;
    min-width: 0;
    cursor: pointer;
  }

  .mini-art {
    width: 40px;
    height: 40px;
    border-radius: var(--radius-sm);
    object-fit: cover;
    box-shadow: var(--shadow-sm);
  }

  .mini-text {
    flex: 1;
    min-width: 0;
  }

  .mini-title {
    font-size: var(--font-sm);
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .mini-artist {
    font-size: var(--font-xs);
    color: var(--text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .mini-controls {
    display: flex;
    align-items: center;
    gap: var(--space-xs);
  }

  .miniplayer .btn-icon {
    width: 36px;
    height: 36px;
  }
`;document.head.appendChild(i0);const Tt=[{id:"pop",name:"Pop",gradient:"linear-gradient(135deg, #e040fb, #7c4dff)",icon:"star"},{id:"hiphop",name:"Hip Hop",gradient:"linear-gradient(135deg, #ff6d00, #ff3d00)",icon:"mic"},{id:"rock",name:"Rock",gradient:"linear-gradient(135deg, #d50000, #ff1744)",icon:"electric_bolt"},{id:"lofi",name:"Lo-Fi",gradient:"linear-gradient(135deg, #00695c, #26a69a)",icon:"headphones"},{id:"electronic",name:"Electronic",gradient:"linear-gradient(135deg, #2979ff, #00b0ff)",icon:"equalizer"},{id:"rnb",name:"R&B",gradient:"linear-gradient(135deg, #6a1b9a, #ab47bc)",icon:"music_note"},{id:"jazz",name:"Jazz",gradient:"linear-gradient(135deg, #f57f17, #fdd835)",icon:"piano"},{id:"classical",name:"Classical",gradient:"linear-gradient(135deg, #1565c0, #42a5f5)",icon:"library_music"},{id:"indie",name:"Indie",gradient:"linear-gradient(135deg, #00897b, #4db6ac)",icon:"forest"},{id:"kpop",name:"K-Pop",gradient:"linear-gradient(135deg, #f06292, #ec407a)",icon:"favorite"},{id:"bollywood",name:"Bollywood",gradient:"linear-gradient(135deg, #ff8f00, #ffca28)",icon:"movie"},{id:"ambient",name:"Ambient",gradient:"linear-gradient(135deg, #37474f, #78909c)",icon:"spa"}],ia=[{id:"arijit-singh",name:"Arijit Singh",query:"Arijit Singh songs",gradient:"linear-gradient(135deg, #1a1a2e, #16213e)",image:"https://c.saavncdn.com/artists/Arijit_Singh_002_20230801131019_150x150.jpg"},{id:"udit-narayan",name:"Udit Narayan",query:"Udit Narayan best songs",gradient:"linear-gradient(135deg, #2d1b69, #11998e)",image:"https://c.saavncdn.com/artists/Udit_Narayan_150x150.jpg"},{id:"shreya-ghoshal",name:"Shreya Ghoshal",query:"Shreya Ghoshal hits",gradient:"linear-gradient(135deg, #7b2ff7, #c471f5)",image:"https://c.saavncdn.com/artists/Shreya_Ghoshal_006_20200711073954_150x150.jpg"},{id:"atif-aslam",name:"Atif Aslam",query:"Atif Aslam songs",gradient:"linear-gradient(135deg, #134e5e, #71b280)",image:"https://c.saavncdn.com/artists/Atif_Aslam_150x150.jpg"},{id:"neha-kakkar",name:"Neha Kakkar",query:"Neha Kakkar latest",gradient:"linear-gradient(135deg, #e91e63, #ff6f00)",image:"https://c.saavncdn.com/artists/Neha_Kakkar_006_20200822042626_150x150.jpg"},{id:"kishore-kumar",name:"Kishore Kumar",query:"Kishore Kumar classics",gradient:"linear-gradient(135deg, #3a1c71, #d76d77)",image:"https://c.saavncdn.com/artists/Kishore_Kumar_150x150.jpg"},{id:"lata-mangeshkar",name:"Lata Mangeshkar",query:"Lata Mangeshkar best",gradient:"linear-gradient(135deg, #c04848, #480048)",image:"https://c.saavncdn.com/artists/Lata_Mangeshkar_004_20230804105030_150x150.jpg"},{id:"kumar-sanu",name:"Kumar Sanu",query:"Kumar Sanu romantic songs",gradient:"linear-gradient(135deg, #0f0c29, #302b63)",image:"https://c.saavncdn.com/artists/Kumar_Sanu_150x150.jpg"},{id:"ap-dhillon",name:"AP Dhillon",query:"AP Dhillon songs",gradient:"linear-gradient(135deg, #000000, #434343)",image:"https://c.saavncdn.com/artists/AP_Dhillon_001_20221012113605_150x150.jpg"},{id:"honey-singh",name:"Yo Yo Honey Singh",query:"Honey Singh party songs",gradient:"linear-gradient(135deg, #f7971e, #ffd200)",image:"https://c.saavncdn.com/artists/Yo_Yo_Honey_Singh_150x150.jpg"},{id:"jubin-nautiyal",name:"Jubin Nautiyal",query:"Jubin Nautiyal songs",gradient:"linear-gradient(135deg, #0052d4, #6fb1fc)",image:"https://c.saavncdn.com/artists/Jubin_Nautiyal_003_20221012112730_150x150.jpg"},{id:"sunidhi-chauhan",name:"Sunidhi Chauhan",query:"Sunidhi Chauhan hits",gradient:"linear-gradient(135deg, #ee0979, #ff6a00)",image:"https://c.saavncdn.com/artists/Sunidhi_Chauhan_150x150.jpg"}],te={show(e,t="info",a=3e3){let r=document.getElementById("toast-container");if(!r){r=document.createElement("div"),r.id="toast-container",document.body.appendChild(r);const w=document.createElement("style");w.textContent=`
                #toast-container {
                    position: fixed;
                    top: var(--space-xl);
                    right: var(--space-xl);
                    z-index: 9999;
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-sm);
                    pointer-events: none;
                }
                .toast {
                    padding: var(--space-md) var(--space-xl);
                    border-radius: var(--radius-md);
                    background: var(--bg-elevated);
                    color: var(--text-primary);
                    font-size: var(--font-sm);
                    font-weight: 500;
                    box-shadow: var(--shadow-lg);
                    border: 1px solid var(--surface-border);
                    backdrop-filter: blur(20px);
                    animation: toastIn 0.4s cubic-bezier(0.16, 1, 0.3, 1);
                    display: flex;
                    align-items: center;
                    gap: var(--space-sm);
                    pointer-events: auto;
                }
                .toast-success { border-left: 4px solid var(--accent); }
                .toast-error { border-left: 4px solid #ff4d4d; }
                .toast-info { border-left: 4px solid #4d94ff; }
                .toast-exit {
                    animation: toastOut 0.3s forwards;
                }
                @keyframes toastOut {
                    to { opacity: 0; transform: translateX(20px); }
                }
            `,document.head.appendChild(w)}const i=document.createElement("div");i.className=`toast toast-${t}`;let s="info";t==="success"&&(s="check_circle"),t==="error"&&(s="error"),i.innerHTML=`
            <span class="material-symbols-rounded" style="font-size: 18px;">${s}</span>
            <span>${e}</span>
        `,r.appendChild(i),setTimeout(()=>{i.classList.add("toast-exit"),setTimeout(()=>i.remove(),300)},a)}};function ue(e,t,a="vertical"){const r=document.createElement("div");r.className=`track-card ${a}`;const i=M.isLiked(e.id),s=M.isDownloadComplete(e.id);r.innerHTML=`
    <div class="track-card-art-wrapper">
      <img class="track-card-art" src="${e.cover||e.coverSmall||""}" alt="${e.title}" loading="lazy" />
      <button class="track-card-play-btn" aria-label="Play ${e.title}">
        <span class="material-symbols-rounded">play_arrow</span>
      </button>
      <button class="track-card-download-btn ${s?"downloaded":""}" aria-label="Download ${e.title}">
        <span class="material-symbols-rounded">${s?"download_done":"download"}</span>
      </button>
      <button class="track-card-like-btn ${i?"liked":""}" aria-label="Favorite ${e.title}">
        <span class="material-symbols-rounded">${i?"favorite":"favorite_border"}</span>
      </button>
      <button class="track-card-add-btn" aria-label="Add to Playlist">
        <span class="material-symbols-rounded">playlist_add</span>
      </button>
    </div>
    <div class="track-card-title">${e.title}</div>
    <div class="track-card-artist" style="pointer-events: auto;">${e.artist}</div>
  `;const w=r.querySelector(".track-card-artist");return w&&w.addEventListener("click",c=>{c.stopPropagation();const h=e.artist.split(",")[0].trim();window.location.hash=`artist?name=${encodeURIComponent(h)}`}),r.addEventListener("click",c=>{if(c.target.closest(".track-card-download-btn")){c.stopPropagation();const h=c.target.closest(".track-card-download-btn");if(M.isDownloadComplete(e.id)){te.show("Already downloaded!","info");return}te.show(`Downloading: ${e.title}...`,"info"),h.querySelector(".material-symbols-rounded").textContent="hourglass_top",he.downloadTrack(e).then(n=>{n?(h.classList.add("downloaded"),h.querySelector(".material-symbols-rounded").textContent="download_done",te.show(`Downloaded: ${e.title}`,"success")):(h.querySelector(".material-symbols-rounded").textContent="download",te.show("Download failed","error"))});return}if(c.target.closest(".track-card-like-btn")){c.stopPropagation(),M.toggleLike(e);const h=M.isLiked(e.id),n=c.target.closest(".track-card-like-btn");n.classList.toggle("liked",h),n.querySelector(".material-symbols-rounded").textContent=h?"favorite":"favorite_border",te.show(h?"Added to Liked Songs":"Removed from Liked Songs","success"),h&&z.cacheTrack(e);return}if(c.target.closest(".track-card-add-btn")){c.stopPropagation();const h=M.get();if(h.playlists.length===0){te.show("Create a playlist first in Library","error");return}const n=h.playlists.map(b=>b.name).join(", "),d=prompt(`Add to playlist?
Available: ${n}`);if(d){const b=h.playlists.find(o=>o.name.toLowerCase()===d.toLowerCase());b?(M.addToPlaylist(b.id,e),te.show(`Added to ${b.name}`,"success")):te.show("Playlist not found","error")}return}z.playAll(t,e)}),r}const s0=document.createElement("style");s0.textContent=`
  .track-card {
    cursor: pointer;
    transition: transform var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
  }
  .track-card:active {
    transform: scale(0.97);
  }

  .track-card.vertical {
    width: 130px;
  }

  .track-card.horizontal {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    padding: var(--space-sm);
    border-radius: var(--radius-md);
    width: 100%;
  }

  .track-card-art-wrapper {
    position: relative;
    border-radius: var(--radius-md);
    overflow: hidden;
    aspect-ratio: 1;
    background: var(--bg-tertiary);
  }

  .track-card.horizontal .track-card-art-wrapper {
    width: 56px;
    height: 56px;
    flex-shrink: 0;
    border-radius: var(--radius-sm);
  }

  .track-card-art {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform var(--transition-normal);
  }

  .track-card:hover .track-card-art {
    transform: scale(1.05);
  }

  .track-card-play-btn {
    position: absolute;
    bottom: var(--space-sm);
    right: var(--space-sm);
    width: 40px;
    height: 40px;
    border-radius: var(--radius-full);
    border: none;
    background: var(--accent);
    color: var(--text-on-accent);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: translateY(8px);
    transition: opacity var(--transition-normal), transform var(--transition-normal), box-shadow var(--transition-normal);
    box-shadow: var(--shadow-md);
    z-index: 2;
  }

  .track-card-download-btn {
    position: absolute;
    top: var(--space-sm);
    right: var(--space-sm);
    width: 32px;
    height: 32px;
    border-radius: var(--radius-full);
    border: none;
    background: var(--surface-glass-thick);
    backdrop-filter: blur(10px);
    color: var(--text-primary);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: translateY(-8px);
    transition: opacity var(--transition-normal), transform var(--transition-normal), background var(--transition-fast);
  }

  .track-card-download-btn.downloaded {
    color: var(--accent);
    opacity: 1;
    transform: translateY(0);
  }

  .track-card-like-btn {
    position: absolute;
    bottom: var(--space-sm);
    left: var(--space-sm);
    width: 32px;
    height: 32px;
    border-radius: var(--radius-full);
    border: none;
    background: var(--surface-glass-thick);
    backdrop-filter: blur(10px);
    color: var(--text-primary);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: translateY(8px);
    transition: opacity var(--transition-normal), transform var(--transition-normal), background var(--transition-fast), color var(--transition-fast);
  }

  .track-card-like-btn.liked {
    color: #ff4d4d;
  }

  .track-card-add-btn {
    position: absolute;
    top: var(--space-sm);
    left: var(--space-sm);
    width: 32px;
    height: 32px;
    border-radius: var(--radius-full);
    border: none;
    background: var(--surface-glass-thick);
    backdrop-filter: blur(10px);
    color: var(--text-primary);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: translateY(-8px);
    transition: opacity var(--transition-normal), transform var(--transition-normal), background var(--transition-fast);
  }

  .track-card-download-btn:hover,
  .track-card-like-btn:hover,
  .track-card-add-btn:hover {
    background: var(--accent);
    color: var(--text-on-accent);
  }

  .track-card:hover .track-card-play-btn,
  .track-card:active .track-card-play-btn,
  .track-card:hover .track-card-download-btn,
  .track-card:active .track-card-download-btn,
  .track-card:hover .track-card-add-btn,
  .track-card:active .track-card-add-btn,
  .track-card:hover .track-card-like-btn,
  .track-card:active .track-card-like-btn {
    opacity: 1;
    transform: translateY(0);
  }

  /* Removed hover:none block to keep UI clean on mobile */

  .track-card-play-btn .material-symbols-rounded {
    font-size: 22px;
  }
  .track-card-download-btn .material-symbols-rounded,
  .track-card-add-btn .material-symbols-rounded,
  .track-card-like-btn .material-symbols-rounded {
    font-size: 18px;
  }

  .track-card-title {
    margin-top: var(--space-sm);
    font-size: var(--font-sm);
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: var(--text-primary);
  }

  .track-card.horizontal .track-card-title {
    margin-top: 0;
  }

  .track-card-artist {
    font-size: var(--font-xs);
    color: var(--text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
`;document.head.appendChild(s0);var Ft=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function sa(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function oa(e){if(Object.prototype.hasOwnProperty.call(e,"__esModule"))return e;var t=e.default;if(typeof t=="function"){var a=function r(){return this instanceof r?Reflect.construct(t,arguments,this.constructor):t.apply(this,arguments)};a.prototype=t.prototype}else a={};return Object.defineProperty(a,"__esModule",{value:!0}),Object.keys(e).forEach(function(r){var i=Object.getOwnPropertyDescriptor(e,r);Object.defineProperty(a,r,i.get?i:{enumerable:!0,get:function(){return e[r]}})}),a}var Ne={exports:{}};function ca(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Me={exports:{}};const la={},da=Object.freeze(Object.defineProperty({__proto__:null,default:la},Symbol.toStringTag,{value:"Module"})),xa=oa(da);var pa=Me.exports,or;function I(){return or||(or=1,(function(e,t){(function(a,r){e.exports=r()})(pa,function(){var a=a||(function(r,i){var s;if(typeof window<"u"&&window.crypto&&(s=window.crypto),typeof self<"u"&&self.crypto&&(s=self.crypto),typeof globalThis<"u"&&globalThis.crypto&&(s=globalThis.crypto),!s&&typeof window<"u"&&window.msCrypto&&(s=window.msCrypto),!s&&typeof Ft<"u"&&Ft.crypto&&(s=Ft.crypto),!s&&typeof ca=="function")try{s=xa}catch{}var w=function(){if(s){if(typeof s.getRandomValues=="function")try{return s.getRandomValues(new Uint32Array(1))[0]}catch{}if(typeof s.randomBytes=="function")try{return s.randomBytes(4).readInt32LE()}catch{}}throw new Error("Native crypto module could not be used to get secure random number.")},c=Object.create||(function(){function l(){}return function(p){var g;return l.prototype=p,g=new l,l.prototype=null,g}})(),h={},n=h.lib={},d=n.Base=(function(){return{extend:function(l){var p=c(this);return l&&p.mixIn(l),(!p.hasOwnProperty("init")||this.init===p.init)&&(p.init=function(){p.$super.init.apply(this,arguments)}),p.init.prototype=p,p.$super=this,p},create:function(){var l=this.extend();return l.init.apply(l,arguments),l},init:function(){},mixIn:function(l){for(var p in l)l.hasOwnProperty(p)&&(this[p]=l[p]);l.hasOwnProperty("toString")&&(this.toString=l.toString)},clone:function(){return this.init.prototype.extend(this)}}})(),b=n.WordArray=d.extend({init:function(l,p){l=this.words=l||[],p!=i?this.sigBytes=p:this.sigBytes=l.length*4},toString:function(l){return(l||x).stringify(this)},concat:function(l){var p=this.words,g=l.words,v=this.sigBytes,E=l.sigBytes;if(this.clamp(),v%4)for(var C=0;C<E;C++){var B=g[C>>>2]>>>24-C%4*8&255;p[v+C>>>2]|=B<<24-(v+C)%4*8}else for(var D=0;D<E;D+=4)p[v+D>>>2]=g[D>>>2];return this.sigBytes+=E,this},clamp:function(){var l=this.words,p=this.sigBytes;l[p>>>2]&=4294967295<<32-p%4*8,l.length=r.ceil(p/4)},clone:function(){var l=d.clone.call(this);return l.words=this.words.slice(0),l},random:function(l){for(var p=[],g=0;g<l;g+=4)p.push(w());return new b.init(p,l)}}),o=h.enc={},x=o.Hex={stringify:function(l){for(var p=l.words,g=l.sigBytes,v=[],E=0;E<g;E++){var C=p[E>>>2]>>>24-E%4*8&255;v.push((C>>>4).toString(16)),v.push((C&15).toString(16))}return v.join("")},parse:function(l){for(var p=l.length,g=[],v=0;v<p;v+=2)g[v>>>3]|=parseInt(l.substr(v,2),16)<<24-v%8*4;return new b.init(g,p/2)}},f=o.Latin1={stringify:function(l){for(var p=l.words,g=l.sigBytes,v=[],E=0;E<g;E++){var C=p[E>>>2]>>>24-E%4*8&255;v.push(String.fromCharCode(C))}return v.join("")},parse:function(l){for(var p=l.length,g=[],v=0;v<p;v++)g[v>>>2]|=(l.charCodeAt(v)&255)<<24-v%4*8;return new b.init(g,p)}},y=o.Utf8={stringify:function(l){try{return decodeURIComponent(escape(f.stringify(l)))}catch{throw new Error("Malformed UTF-8 data")}},parse:function(l){return f.parse(unescape(encodeURIComponent(l)))}},m=n.BufferedBlockAlgorithm=d.extend({reset:function(){this._data=new b.init,this._nDataBytes=0},_append:function(l){typeof l=="string"&&(l=y.parse(l)),this._data.concat(l),this._nDataBytes+=l.sigBytes},_process:function(l){var p,g=this._data,v=g.words,E=g.sigBytes,C=this.blockSize,B=C*4,D=E/B;l?D=r.ceil(D):D=r.max((D|0)-this._minBufferSize,0);var A=D*C,_=r.min(A*4,E);if(A){for(var k=0;k<A;k+=C)this._doProcessBlock(v,k);p=v.splice(0,A),g.sigBytes-=_}return new b.init(p,_)},clone:function(){var l=d.clone.call(this);return l._data=this._data.clone(),l},_minBufferSize:0});n.Hasher=m.extend({cfg:d.extend(),init:function(l){this.cfg=this.cfg.extend(l),this.reset()},reset:function(){m.reset.call(this),this._doReset()},update:function(l){return this._append(l),this._process(),this},finalize:function(l){l&&this._append(l);var p=this._doFinalize();return p},blockSize:16,_createHelper:function(l){return function(p,g){return new l.init(g).finalize(p)}},_createHmacHelper:function(l){return function(p,g){return new u.HMAC.init(l,g).finalize(p)}}});var u=h.algo={};return h})(Math);return a})})(Me)),Me.exports}var Ie={exports:{}},ua=Ie.exports,cr;function Bt(){return cr||(cr=1,(function(e,t){(function(a,r){e.exports=r(I())})(ua,function(a){return(function(r){var i=a,s=i.lib,w=s.Base,c=s.WordArray,h=i.x64={};h.Word=w.extend({init:function(n,d){this.high=n,this.low=d}}),h.WordArray=w.extend({init:function(n,d){n=this.words=n||[],d!=r?this.sigBytes=d:this.sigBytes=n.length*8},toX32:function(){for(var n=this.words,d=n.length,b=[],o=0;o<d;o++){var x=n[o];b.push(x.high),b.push(x.low)}return c.create(b,this.sigBytes)},clone:function(){for(var n=w.clone.call(this),d=n.words=this.words.slice(0),b=d.length,o=0;o<b;o++)d[o]=d[o].clone();return n}})})(),a})})(Ie)),Ie.exports}var Oe={exports:{}},fa=Oe.exports,lr;function ha(){return lr||(lr=1,(function(e,t){(function(a,r){e.exports=r(I())})(fa,function(a){return(function(){if(typeof ArrayBuffer=="function"){var r=a,i=r.lib,s=i.WordArray,w=s.init,c=s.init=function(h){if(h instanceof ArrayBuffer&&(h=new Uint8Array(h)),(h instanceof Int8Array||typeof Uint8ClampedArray<"u"&&h instanceof Uint8ClampedArray||h instanceof Int16Array||h instanceof Uint16Array||h instanceof Int32Array||h instanceof Uint32Array||h instanceof Float32Array||h instanceof Float64Array)&&(h=new Uint8Array(h.buffer,h.byteOffset,h.byteLength)),h instanceof Uint8Array){for(var n=h.byteLength,d=[],b=0;b<n;b++)d[b>>>2]|=h[b]<<24-b%4*8;w.call(this,d,n)}else w.apply(this,arguments)};c.prototype=s}})(),a.lib.WordArray})})(Oe)),Oe.exports}var je={exports:{}},va=je.exports,dr;function ma(){return dr||(dr=1,(function(e,t){(function(a,r){e.exports=r(I())})(va,function(a){return(function(){var r=a,i=r.lib,s=i.WordArray,w=r.enc;w.Utf16=w.Utf16BE={stringify:function(h){for(var n=h.words,d=h.sigBytes,b=[],o=0;o<d;o+=2){var x=n[o>>>2]>>>16-o%4*8&65535;b.push(String.fromCharCode(x))}return b.join("")},parse:function(h){for(var n=h.length,d=[],b=0;b<n;b++)d[b>>>1]|=h.charCodeAt(b)<<16-b%2*16;return s.create(d,n*2)}},w.Utf16LE={stringify:function(h){for(var n=h.words,d=h.sigBytes,b=[],o=0;o<d;o+=2){var x=c(n[o>>>2]>>>16-o%4*8&65535);b.push(String.fromCharCode(x))}return b.join("")},parse:function(h){for(var n=h.length,d=[],b=0;b<n;b++)d[b>>>1]|=c(h.charCodeAt(b)<<16-b%2*16);return s.create(d,n*2)}};function c(h){return h<<8&4278255360|h>>>8&16711935}})(),a.enc.Utf16})})(je)),je.exports}var Ue={exports:{}},ga=Ue.exports,xr;function me(){return xr||(xr=1,(function(e,t){(function(a,r){e.exports=r(I())})(ga,function(a){return(function(){var r=a,i=r.lib,s=i.WordArray,w=r.enc;w.Base64={stringify:function(h){var n=h.words,d=h.sigBytes,b=this._map;h.clamp();for(var o=[],x=0;x<d;x+=3)for(var f=n[x>>>2]>>>24-x%4*8&255,y=n[x+1>>>2]>>>24-(x+1)%4*8&255,m=n[x+2>>>2]>>>24-(x+2)%4*8&255,u=f<<16|y<<8|m,l=0;l<4&&x+l*.75<d;l++)o.push(b.charAt(u>>>6*(3-l)&63));var p=b.charAt(64);if(p)for(;o.length%4;)o.push(p);return o.join("")},parse:function(h){var n=h.length,d=this._map,b=this._reverseMap;if(!b){b=this._reverseMap=[];for(var o=0;o<d.length;o++)b[d.charCodeAt(o)]=o}var x=d.charAt(64);if(x){var f=h.indexOf(x);f!==-1&&(n=f)}return c(h,n,b)},_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="};function c(h,n,d){for(var b=[],o=0,x=0;x<n;x++)if(x%4){var f=d[h.charCodeAt(x-1)]<<x%4*2,y=d[h.charCodeAt(x)]>>>6-x%4*2,m=f|y;b[o>>>2]|=m<<24-o%4*8,o++}return s.create(b,o)}})(),a.enc.Base64})})(Ue)),Ue.exports}var We={exports:{}},ya=We.exports,pr;function ba(){return pr||(pr=1,(function(e,t){(function(a,r){e.exports=r(I())})(ya,function(a){return(function(){var r=a,i=r.lib,s=i.WordArray,w=r.enc;w.Base64url={stringify:function(h,n){n===void 0&&(n=!0);var d=h.words,b=h.sigBytes,o=n?this._safe_map:this._map;h.clamp();for(var x=[],f=0;f<b;f+=3)for(var y=d[f>>>2]>>>24-f%4*8&255,m=d[f+1>>>2]>>>24-(f+1)%4*8&255,u=d[f+2>>>2]>>>24-(f+2)%4*8&255,l=y<<16|m<<8|u,p=0;p<4&&f+p*.75<b;p++)x.push(o.charAt(l>>>6*(3-p)&63));var g=o.charAt(64);if(g)for(;x.length%4;)x.push(g);return x.join("")},parse:function(h,n){n===void 0&&(n=!0);var d=h.length,b=n?this._safe_map:this._map,o=this._reverseMap;if(!o){o=this._reverseMap=[];for(var x=0;x<b.length;x++)o[b.charCodeAt(x)]=x}var f=b.charAt(64);if(f){var y=h.indexOf(f);y!==-1&&(d=y)}return c(h,d,o)},_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",_safe_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"};function c(h,n,d){for(var b=[],o=0,x=0;x<n;x++)if(x%4){var f=d[h.charCodeAt(x-1)]<<x%4*2,y=d[h.charCodeAt(x)]>>>6-x%4*2,m=f|y;b[o>>>2]|=m<<24-o%4*8,o++}return s.create(b,o)}})(),a.enc.Base64url})})(We)),We.exports}var Ke={exports:{}},Ea=Ke.exports,ur;function ge(){return ur||(ur=1,(function(e,t){(function(a,r){e.exports=r(I())})(Ea,function(a){return(function(r){var i=a,s=i.lib,w=s.WordArray,c=s.Hasher,h=i.algo,n=[];(function(){for(var y=0;y<64;y++)n[y]=r.abs(r.sin(y+1))*4294967296|0})();var d=h.MD5=c.extend({_doReset:function(){this._hash=new w.init([1732584193,4023233417,2562383102,271733878])},_doProcessBlock:function(y,m){for(var u=0;u<16;u++){var l=m+u,p=y[l];y[l]=(p<<8|p>>>24)&16711935|(p<<24|p>>>8)&4278255360}var g=this._hash.words,v=y[m+0],E=y[m+1],C=y[m+2],B=y[m+3],D=y[m+4],A=y[m+5],_=y[m+6],k=y[m+7],F=y[m+8],T=y[m+9],H=y[m+10],R=y[m+11],K=y[m+12],O=y[m+13],U=y[m+14],j=y[m+15],S=g[0],P=g[1],$=g[2],L=g[3];S=b(S,P,$,L,v,7,n[0]),L=b(L,S,P,$,E,12,n[1]),$=b($,L,S,P,C,17,n[2]),P=b(P,$,L,S,B,22,n[3]),S=b(S,P,$,L,D,7,n[4]),L=b(L,S,P,$,A,12,n[5]),$=b($,L,S,P,_,17,n[6]),P=b(P,$,L,S,k,22,n[7]),S=b(S,P,$,L,F,7,n[8]),L=b(L,S,P,$,T,12,n[9]),$=b($,L,S,P,H,17,n[10]),P=b(P,$,L,S,R,22,n[11]),S=b(S,P,$,L,K,7,n[12]),L=b(L,S,P,$,O,12,n[13]),$=b($,L,S,P,U,17,n[14]),P=b(P,$,L,S,j,22,n[15]),S=o(S,P,$,L,E,5,n[16]),L=o(L,S,P,$,_,9,n[17]),$=o($,L,S,P,R,14,n[18]),P=o(P,$,L,S,v,20,n[19]),S=o(S,P,$,L,A,5,n[20]),L=o(L,S,P,$,H,9,n[21]),$=o($,L,S,P,j,14,n[22]),P=o(P,$,L,S,D,20,n[23]),S=o(S,P,$,L,T,5,n[24]),L=o(L,S,P,$,U,9,n[25]),$=o($,L,S,P,B,14,n[26]),P=o(P,$,L,S,F,20,n[27]),S=o(S,P,$,L,O,5,n[28]),L=o(L,S,P,$,C,9,n[29]),$=o($,L,S,P,k,14,n[30]),P=o(P,$,L,S,K,20,n[31]),S=x(S,P,$,L,A,4,n[32]),L=x(L,S,P,$,F,11,n[33]),$=x($,L,S,P,R,16,n[34]),P=x(P,$,L,S,U,23,n[35]),S=x(S,P,$,L,E,4,n[36]),L=x(L,S,P,$,D,11,n[37]),$=x($,L,S,P,k,16,n[38]),P=x(P,$,L,S,H,23,n[39]),S=x(S,P,$,L,O,4,n[40]),L=x(L,S,P,$,v,11,n[41]),$=x($,L,S,P,B,16,n[42]),P=x(P,$,L,S,_,23,n[43]),S=x(S,P,$,L,T,4,n[44]),L=x(L,S,P,$,K,11,n[45]),$=x($,L,S,P,j,16,n[46]),P=x(P,$,L,S,C,23,n[47]),S=f(S,P,$,L,v,6,n[48]),L=f(L,S,P,$,k,10,n[49]),$=f($,L,S,P,U,15,n[50]),P=f(P,$,L,S,A,21,n[51]),S=f(S,P,$,L,K,6,n[52]),L=f(L,S,P,$,B,10,n[53]),$=f($,L,S,P,H,15,n[54]),P=f(P,$,L,S,E,21,n[55]),S=f(S,P,$,L,F,6,n[56]),L=f(L,S,P,$,j,10,n[57]),$=f($,L,S,P,_,15,n[58]),P=f(P,$,L,S,O,21,n[59]),S=f(S,P,$,L,D,6,n[60]),L=f(L,S,P,$,R,10,n[61]),$=f($,L,S,P,C,15,n[62]),P=f(P,$,L,S,T,21,n[63]),g[0]=g[0]+S|0,g[1]=g[1]+P|0,g[2]=g[2]+$|0,g[3]=g[3]+L|0},_doFinalize:function(){var y=this._data,m=y.words,u=this._nDataBytes*8,l=y.sigBytes*8;m[l>>>5]|=128<<24-l%32;var p=r.floor(u/4294967296),g=u;m[(l+64>>>9<<4)+15]=(p<<8|p>>>24)&16711935|(p<<24|p>>>8)&4278255360,m[(l+64>>>9<<4)+14]=(g<<8|g>>>24)&16711935|(g<<24|g>>>8)&4278255360,y.sigBytes=(m.length+1)*4,this._process();for(var v=this._hash,E=v.words,C=0;C<4;C++){var B=E[C];E[C]=(B<<8|B>>>24)&16711935|(B<<24|B>>>8)&4278255360}return v},clone:function(){var y=c.clone.call(this);return y._hash=this._hash.clone(),y}});function b(y,m,u,l,p,g,v){var E=y+(m&u|~m&l)+p+v;return(E<<g|E>>>32-g)+m}function o(y,m,u,l,p,g,v){var E=y+(m&l|u&~l)+p+v;return(E<<g|E>>>32-g)+m}function x(y,m,u,l,p,g,v){var E=y+(m^u^l)+p+v;return(E<<g|E>>>32-g)+m}function f(y,m,u,l,p,g,v){var E=y+(u^(m|~l))+p+v;return(E<<g|E>>>32-g)+m}i.MD5=c._createHelper(d),i.HmacMD5=c._createHmacHelper(d)})(Math),a.MD5})})(Ke)),Ke.exports}var Ge={exports:{}},wa=Ge.exports,fr;function o0(){return fr||(fr=1,(function(e,t){(function(a,r){e.exports=r(I())})(wa,function(a){return(function(){var r=a,i=r.lib,s=i.WordArray,w=i.Hasher,c=r.algo,h=[],n=c.SHA1=w.extend({_doReset:function(){this._hash=new s.init([1732584193,4023233417,2562383102,271733878,3285377520])},_doProcessBlock:function(d,b){for(var o=this._hash.words,x=o[0],f=o[1],y=o[2],m=o[3],u=o[4],l=0;l<80;l++){if(l<16)h[l]=d[b+l]|0;else{var p=h[l-3]^h[l-8]^h[l-14]^h[l-16];h[l]=p<<1|p>>>31}var g=(x<<5|x>>>27)+u+h[l];l<20?g+=(f&y|~f&m)+1518500249:l<40?g+=(f^y^m)+1859775393:l<60?g+=(f&y|f&m|y&m)-1894007588:g+=(f^y^m)-899497514,u=m,m=y,y=f<<30|f>>>2,f=x,x=g}o[0]=o[0]+x|0,o[1]=o[1]+f|0,o[2]=o[2]+y|0,o[3]=o[3]+m|0,o[4]=o[4]+u|0},_doFinalize:function(){var d=this._data,b=d.words,o=this._nDataBytes*8,x=d.sigBytes*8;return b[x>>>5]|=128<<24-x%32,b[(x+64>>>9<<4)+14]=Math.floor(o/4294967296),b[(x+64>>>9<<4)+15]=o,d.sigBytes=b.length*4,this._process(),this._hash},clone:function(){var d=w.clone.call(this);return d._hash=this._hash.clone(),d}});r.SHA1=w._createHelper(n),r.HmacSHA1=w._createHmacHelper(n)})(),a.SHA1})})(Ge)),Ge.exports}var Ve={exports:{}},Ca=Ve.exports,hr;function Rt(){return hr||(hr=1,(function(e,t){(function(a,r){e.exports=r(I())})(Ca,function(a){return(function(r){var i=a,s=i.lib,w=s.WordArray,c=s.Hasher,h=i.algo,n=[],d=[];(function(){function x(u){for(var l=r.sqrt(u),p=2;p<=l;p++)if(!(u%p))return!1;return!0}function f(u){return(u-(u|0))*4294967296|0}for(var y=2,m=0;m<64;)x(y)&&(m<8&&(n[m]=f(r.pow(y,1/2))),d[m]=f(r.pow(y,1/3)),m++),y++})();var b=[],o=h.SHA256=c.extend({_doReset:function(){this._hash=new w.init(n.slice(0))},_doProcessBlock:function(x,f){for(var y=this._hash.words,m=y[0],u=y[1],l=y[2],p=y[3],g=y[4],v=y[5],E=y[6],C=y[7],B=0;B<64;B++){if(B<16)b[B]=x[f+B]|0;else{var D=b[B-15],A=(D<<25|D>>>7)^(D<<14|D>>>18)^D>>>3,_=b[B-2],k=(_<<15|_>>>17)^(_<<13|_>>>19)^_>>>10;b[B]=A+b[B-7]+k+b[B-16]}var F=g&v^~g&E,T=m&u^m&l^u&l,H=(m<<30|m>>>2)^(m<<19|m>>>13)^(m<<10|m>>>22),R=(g<<26|g>>>6)^(g<<21|g>>>11)^(g<<7|g>>>25),K=C+R+F+d[B]+b[B],O=H+T;C=E,E=v,v=g,g=p+K|0,p=l,l=u,u=m,m=K+O|0}y[0]=y[0]+m|0,y[1]=y[1]+u|0,y[2]=y[2]+l|0,y[3]=y[3]+p|0,y[4]=y[4]+g|0,y[5]=y[5]+v|0,y[6]=y[6]+E|0,y[7]=y[7]+C|0},_doFinalize:function(){var x=this._data,f=x.words,y=this._nDataBytes*8,m=x.sigBytes*8;return f[m>>>5]|=128<<24-m%32,f[(m+64>>>9<<4)+14]=r.floor(y/4294967296),f[(m+64>>>9<<4)+15]=y,x.sigBytes=f.length*4,this._process(),this._hash},clone:function(){var x=c.clone.call(this);return x._hash=this._hash.clone(),x}});i.SHA256=c._createHelper(o),i.HmacSHA256=c._createHmacHelper(o)})(Math),a.SHA256})})(Ve)),Ve.exports}var Xe={exports:{}},Ba=Xe.exports,vr;function Aa(){return vr||(vr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),Rt())})(Ba,function(a){return(function(){var r=a,i=r.lib,s=i.WordArray,w=r.algo,c=w.SHA256,h=w.SHA224=c.extend({_doReset:function(){this._hash=new s.init([3238371032,914150663,812702999,4144912697,4290775857,1750603025,1694076839,3204075428])},_doFinalize:function(){var n=c._doFinalize.call(this);return n.sigBytes-=4,n}});r.SHA224=c._createHelper(h),r.HmacSHA224=c._createHmacHelper(h)})(),a.SHA224})})(Xe)),Xe.exports}var Ye={exports:{}},_a=Ye.exports,mr;function c0(){return mr||(mr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),Bt())})(_a,function(a){return(function(){var r=a,i=r.lib,s=i.Hasher,w=r.x64,c=w.Word,h=w.WordArray,n=r.algo;function d(){return c.create.apply(c,arguments)}var b=[d(1116352408,3609767458),d(1899447441,602891725),d(3049323471,3964484399),d(3921009573,2173295548),d(961987163,4081628472),d(1508970993,3053834265),d(2453635748,2937671579),d(2870763221,3664609560),d(3624381080,2734883394),d(310598401,1164996542),d(607225278,1323610764),d(1426881987,3590304994),d(1925078388,4068182383),d(2162078206,991336113),d(2614888103,633803317),d(3248222580,3479774868),d(3835390401,2666613458),d(4022224774,944711139),d(264347078,2341262773),d(604807628,2007800933),d(770255983,1495990901),d(1249150122,1856431235),d(1555081692,3175218132),d(1996064986,2198950837),d(2554220882,3999719339),d(2821834349,766784016),d(2952996808,2566594879),d(3210313671,3203337956),d(3336571891,1034457026),d(3584528711,2466948901),d(113926993,3758326383),d(338241895,168717936),d(666307205,1188179964),d(773529912,1546045734),d(1294757372,1522805485),d(1396182291,2643833823),d(1695183700,2343527390),d(1986661051,1014477480),d(2177026350,1206759142),d(2456956037,344077627),d(2730485921,1290863460),d(2820302411,3158454273),d(3259730800,3505952657),d(3345764771,106217008),d(3516065817,3606008344),d(3600352804,1432725776),d(4094571909,1467031594),d(275423344,851169720),d(430227734,3100823752),d(506948616,1363258195),d(659060556,3750685593),d(883997877,3785050280),d(958139571,3318307427),d(1322822218,3812723403),d(1537002063,2003034995),d(1747873779,3602036899),d(1955562222,1575990012),d(2024104815,1125592928),d(2227730452,2716904306),d(2361852424,442776044),d(2428436474,593698344),d(2756734187,3733110249),d(3204031479,2999351573),d(3329325298,3815920427),d(3391569614,3928383900),d(3515267271,566280711),d(3940187606,3454069534),d(4118630271,4000239992),d(116418474,1914138554),d(174292421,2731055270),d(289380356,3203993006),d(460393269,320620315),d(685471733,587496836),d(852142971,1086792851),d(1017036298,365543100),d(1126000580,2618297676),d(1288033470,3409855158),d(1501505948,4234509866),d(1607167915,987167468),d(1816402316,1246189591)],o=[];(function(){for(var f=0;f<80;f++)o[f]=d()})();var x=n.SHA512=s.extend({_doReset:function(){this._hash=new h.init([new c.init(1779033703,4089235720),new c.init(3144134277,2227873595),new c.init(1013904242,4271175723),new c.init(2773480762,1595750129),new c.init(1359893119,2917565137),new c.init(2600822924,725511199),new c.init(528734635,4215389547),new c.init(1541459225,327033209)])},_doProcessBlock:function(f,y){for(var m=this._hash.words,u=m[0],l=m[1],p=m[2],g=m[3],v=m[4],E=m[5],C=m[6],B=m[7],D=u.high,A=u.low,_=l.high,k=l.low,F=p.high,T=p.low,H=g.high,R=g.low,K=v.high,O=v.low,U=E.high,j=E.low,S=C.high,P=C.low,$=B.high,L=B.low,G=D,W=A,Q=_,N=k,Ae=F,ye=T,At=H,_e=R,ie=K,J=O,$e=U,De=j,qe=S,ke=P,_t=$,Fe=L,se=0;se<80;se++){var re,xe,Te=o[se];if(se<16)xe=Te.high=f[y+se*2]|0,re=Te.low=f[y+se*2+1]|0;else{var It=o[se-15],be=It.high,Se=It.low,A0=(be>>>1|Se<<31)^(be>>>8|Se<<24)^be>>>7,Ot=(Se>>>1|be<<31)^(Se>>>8|be<<24)^(Se>>>7|be<<25),jt=o[se-2],Ee=jt.high,Le=jt.low,_0=(Ee>>>19|Le<<13)^(Ee<<3|Le>>>29)^Ee>>>6,Ut=(Le>>>19|Ee<<13)^(Le<<3|Ee>>>29)^(Le>>>6|Ee<<26),Wt=o[se-7],D0=Wt.high,k0=Wt.low,Kt=o[se-16],F0=Kt.high,Gt=Kt.low;re=Ot+k0,xe=A0+D0+(re>>>0<Ot>>>0?1:0),re=re+Ut,xe=xe+_0+(re>>>0<Ut>>>0?1:0),re=re+Gt,xe=xe+F0+(re>>>0<Gt>>>0?1:0),Te.high=xe,Te.low=re}var S0=ie&$e^~ie&qe,Vt=J&De^~J&ke,L0=G&Q^G&Ae^Q&Ae,P0=W&N^W&ye^N&ye,$0=(G>>>28|W<<4)^(G<<30|W>>>2)^(G<<25|W>>>7),Xt=(W>>>28|G<<4)^(W<<30|G>>>2)^(W<<25|G>>>7),q0=(ie>>>14|J<<18)^(ie>>>18|J<<14)^(ie<<23|J>>>9),T0=(J>>>14|ie<<18)^(J>>>18|ie<<14)^(J<<23|ie>>>9),Yt=b[se],H0=Yt.high,Qt=Yt.low,ee=Fe+T0,pe=_t+q0+(ee>>>0<Fe>>>0?1:0),ee=ee+Vt,pe=pe+S0+(ee>>>0<Vt>>>0?1:0),ee=ee+Qt,pe=pe+H0+(ee>>>0<Qt>>>0?1:0),ee=ee+re,pe=pe+xe+(ee>>>0<re>>>0?1:0),Zt=Xt+P0,z0=$0+L0+(Zt>>>0<Xt>>>0?1:0);_t=qe,Fe=ke,qe=$e,ke=De,$e=ie,De=J,J=_e+ee|0,ie=At+pe+(J>>>0<_e>>>0?1:0)|0,At=Ae,_e=ye,Ae=Q,ye=N,Q=G,N=W,W=ee+Zt|0,G=pe+z0+(W>>>0<ee>>>0?1:0)|0}A=u.low=A+W,u.high=D+G+(A>>>0<W>>>0?1:0),k=l.low=k+N,l.high=_+Q+(k>>>0<N>>>0?1:0),T=p.low=T+ye,p.high=F+Ae+(T>>>0<ye>>>0?1:0),R=g.low=R+_e,g.high=H+At+(R>>>0<_e>>>0?1:0),O=v.low=O+J,v.high=K+ie+(O>>>0<J>>>0?1:0),j=E.low=j+De,E.high=U+$e+(j>>>0<De>>>0?1:0),P=C.low=P+ke,C.high=S+qe+(P>>>0<ke>>>0?1:0),L=B.low=L+Fe,B.high=$+_t+(L>>>0<Fe>>>0?1:0)},_doFinalize:function(){var f=this._data,y=f.words,m=this._nDataBytes*8,u=f.sigBytes*8;y[u>>>5]|=128<<24-u%32,y[(u+128>>>10<<5)+30]=Math.floor(m/4294967296),y[(u+128>>>10<<5)+31]=m,f.sigBytes=y.length*4,this._process();var l=this._hash.toX32();return l},clone:function(){var f=s.clone.call(this);return f._hash=this._hash.clone(),f},blockSize:1024/32});r.SHA512=s._createHelper(x),r.HmacSHA512=s._createHmacHelper(x)})(),a.SHA512})})(Ye)),Ye.exports}var Qe={exports:{}},Da=Qe.exports,gr;function ka(){return gr||(gr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),Bt(),c0())})(Da,function(a){return(function(){var r=a,i=r.x64,s=i.Word,w=i.WordArray,c=r.algo,h=c.SHA512,n=c.SHA384=h.extend({_doReset:function(){this._hash=new w.init([new s.init(3418070365,3238371032),new s.init(1654270250,914150663),new s.init(2438529370,812702999),new s.init(355462360,4144912697),new s.init(1731405415,4290775857),new s.init(2394180231,1750603025),new s.init(3675008525,1694076839),new s.init(1203062813,3204075428)])},_doFinalize:function(){var d=h._doFinalize.call(this);return d.sigBytes-=16,d}});r.SHA384=h._createHelper(n),r.HmacSHA384=h._createHmacHelper(n)})(),a.SHA384})})(Qe)),Qe.exports}var Ze={exports:{}},Fa=Ze.exports,yr;function Sa(){return yr||(yr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),Bt())})(Fa,function(a){return(function(r){var i=a,s=i.lib,w=s.WordArray,c=s.Hasher,h=i.x64,n=h.Word,d=i.algo,b=[],o=[],x=[];(function(){for(var m=1,u=0,l=0;l<24;l++){b[m+5*u]=(l+1)*(l+2)/2%64;var p=u%5,g=(2*m+3*u)%5;m=p,u=g}for(var m=0;m<5;m++)for(var u=0;u<5;u++)o[m+5*u]=u+(2*m+3*u)%5*5;for(var v=1,E=0;E<24;E++){for(var C=0,B=0,D=0;D<7;D++){if(v&1){var A=(1<<D)-1;A<32?B^=1<<A:C^=1<<A-32}v&128?v=v<<1^113:v<<=1}x[E]=n.create(C,B)}})();var f=[];(function(){for(var m=0;m<25;m++)f[m]=n.create()})();var y=d.SHA3=c.extend({cfg:c.cfg.extend({outputLength:512}),_doReset:function(){for(var m=this._state=[],u=0;u<25;u++)m[u]=new n.init;this.blockSize=(1600-2*this.cfg.outputLength)/32},_doProcessBlock:function(m,u){for(var l=this._state,p=this.blockSize/2,g=0;g<p;g++){var v=m[u+2*g],E=m[u+2*g+1];v=(v<<8|v>>>24)&16711935|(v<<24|v>>>8)&4278255360,E=(E<<8|E>>>24)&16711935|(E<<24|E>>>8)&4278255360;var C=l[g];C.high^=E,C.low^=v}for(var B=0;B<24;B++){for(var D=0;D<5;D++){for(var A=0,_=0,k=0;k<5;k++){var C=l[D+5*k];A^=C.high,_^=C.low}var F=f[D];F.high=A,F.low=_}for(var D=0;D<5;D++)for(var T=f[(D+4)%5],H=f[(D+1)%5],R=H.high,K=H.low,A=T.high^(R<<1|K>>>31),_=T.low^(K<<1|R>>>31),k=0;k<5;k++){var C=l[D+5*k];C.high^=A,C.low^=_}for(var O=1;O<25;O++){var A,_,C=l[O],U=C.high,j=C.low,S=b[O];S<32?(A=U<<S|j>>>32-S,_=j<<S|U>>>32-S):(A=j<<S-32|U>>>64-S,_=U<<S-32|j>>>64-S);var P=f[o[O]];P.high=A,P.low=_}var $=f[0],L=l[0];$.high=L.high,$.low=L.low;for(var D=0;D<5;D++)for(var k=0;k<5;k++){var O=D+5*k,C=l[O],G=f[O],W=f[(D+1)%5+5*k],Q=f[(D+2)%5+5*k];C.high=G.high^~W.high&Q.high,C.low=G.low^~W.low&Q.low}var C=l[0],N=x[B];C.high^=N.high,C.low^=N.low}},_doFinalize:function(){var m=this._data,u=m.words;this._nDataBytes*8;var l=m.sigBytes*8,p=this.blockSize*32;u[l>>>5]|=1<<24-l%32,u[(r.ceil((l+1)/p)*p>>>5)-1]|=128,m.sigBytes=u.length*4,this._process();for(var g=this._state,v=this.cfg.outputLength/8,E=v/8,C=[],B=0;B<E;B++){var D=g[B],A=D.high,_=D.low;A=(A<<8|A>>>24)&16711935|(A<<24|A>>>8)&4278255360,_=(_<<8|_>>>24)&16711935|(_<<24|_>>>8)&4278255360,C.push(_),C.push(A)}return new w.init(C,v)},clone:function(){for(var m=c.clone.call(this),u=m._state=this._state.slice(0),l=0;l<25;l++)u[l]=u[l].clone();return m}});i.SHA3=c._createHelper(y),i.HmacSHA3=c._createHmacHelper(y)})(Math),a.SHA3})})(Ze)),Ze.exports}var Je={exports:{}},La=Je.exports,br;function Pa(){return br||(br=1,(function(e,t){(function(a,r){e.exports=r(I())})(La,function(a){/** @preserve
			(c) 2012 by Cédric Mesnil. All rights reserved.

			Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

			    - Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
			    - Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

			THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
			*/return(function(r){var i=a,s=i.lib,w=s.WordArray,c=s.Hasher,h=i.algo,n=w.create([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,7,4,13,1,10,6,15,3,12,0,9,5,2,14,11,8,3,10,14,4,9,15,8,1,2,7,0,6,13,11,5,12,1,9,11,10,0,8,12,4,13,3,7,15,14,5,6,2,4,0,5,9,7,12,2,10,14,1,3,8,11,6,15,13]),d=w.create([5,14,7,0,9,2,11,4,13,6,15,8,1,10,3,12,6,11,3,7,0,13,5,10,14,15,8,12,4,9,1,2,15,5,1,3,7,14,6,9,11,8,12,2,10,0,4,13,8,6,4,1,3,11,15,0,5,12,2,13,9,7,10,14,12,15,10,4,1,5,8,7,6,2,13,14,0,3,9,11]),b=w.create([11,14,15,12,5,8,7,9,11,13,14,15,6,7,9,8,7,6,8,13,11,9,7,15,7,12,15,9,11,7,13,12,11,13,6,7,14,9,13,15,14,8,13,6,5,12,7,5,11,12,14,15,14,15,9,8,9,14,5,6,8,6,5,12,9,15,5,11,6,8,13,12,5,12,13,14,11,8,5,6]),o=w.create([8,9,9,11,13,15,15,5,7,7,8,11,14,14,12,6,9,13,15,7,12,8,9,11,7,7,12,7,6,15,13,11,9,7,15,11,8,6,6,14,12,13,5,14,13,13,7,5,15,5,8,11,14,14,6,14,6,9,12,9,12,5,15,8,8,5,12,9,12,5,14,6,8,13,6,5,15,13,11,11]),x=w.create([0,1518500249,1859775393,2400959708,2840853838]),f=w.create([1352829926,1548603684,1836072691,2053994217,0]),y=h.RIPEMD160=c.extend({_doReset:function(){this._hash=w.create([1732584193,4023233417,2562383102,271733878,3285377520])},_doProcessBlock:function(E,C){for(var B=0;B<16;B++){var D=C+B,A=E[D];E[D]=(A<<8|A>>>24)&16711935|(A<<24|A>>>8)&4278255360}var _=this._hash.words,k=x.words,F=f.words,T=n.words,H=d.words,R=b.words,K=o.words,O,U,j,S,P,$,L,G,W,Q;$=O=_[0],L=U=_[1],G=j=_[2],W=S=_[3],Q=P=_[4];for(var N,B=0;B<80;B+=1)N=O+E[C+T[B]]|0,B<16?N+=m(U,j,S)+k[0]:B<32?N+=u(U,j,S)+k[1]:B<48?N+=l(U,j,S)+k[2]:B<64?N+=p(U,j,S)+k[3]:N+=g(U,j,S)+k[4],N=N|0,N=v(N,R[B]),N=N+P|0,O=P,P=S,S=v(j,10),j=U,U=N,N=$+E[C+H[B]]|0,B<16?N+=g(L,G,W)+F[0]:B<32?N+=p(L,G,W)+F[1]:B<48?N+=l(L,G,W)+F[2]:B<64?N+=u(L,G,W)+F[3]:N+=m(L,G,W)+F[4],N=N|0,N=v(N,K[B]),N=N+Q|0,$=Q,Q=W,W=v(G,10),G=L,L=N;N=_[1]+j+W|0,_[1]=_[2]+S+Q|0,_[2]=_[3]+P+$|0,_[3]=_[4]+O+L|0,_[4]=_[0]+U+G|0,_[0]=N},_doFinalize:function(){var E=this._data,C=E.words,B=this._nDataBytes*8,D=E.sigBytes*8;C[D>>>5]|=128<<24-D%32,C[(D+64>>>9<<4)+14]=(B<<8|B>>>24)&16711935|(B<<24|B>>>8)&4278255360,E.sigBytes=(C.length+1)*4,this._process();for(var A=this._hash,_=A.words,k=0;k<5;k++){var F=_[k];_[k]=(F<<8|F>>>24)&16711935|(F<<24|F>>>8)&4278255360}return A},clone:function(){var E=c.clone.call(this);return E._hash=this._hash.clone(),E}});function m(E,C,B){return E^C^B}function u(E,C,B){return E&C|~E&B}function l(E,C,B){return(E|~C)^B}function p(E,C,B){return E&B|C&~B}function g(E,C,B){return E^(C|~B)}function v(E,C){return E<<C|E>>>32-C}i.RIPEMD160=c._createHelper(y),i.HmacRIPEMD160=c._createHmacHelper(y)})(),a.RIPEMD160})})(Je)),Je.exports}var et={exports:{}},$a=et.exports,Er;function Nt(){return Er||(Er=1,(function(e,t){(function(a,r){e.exports=r(I())})($a,function(a){(function(){var r=a,i=r.lib,s=i.Base,w=r.enc,c=w.Utf8,h=r.algo;h.HMAC=s.extend({init:function(n,d){n=this._hasher=new n.init,typeof d=="string"&&(d=c.parse(d));var b=n.blockSize,o=b*4;d.sigBytes>o&&(d=n.finalize(d)),d.clamp();for(var x=this._oKey=d.clone(),f=this._iKey=d.clone(),y=x.words,m=f.words,u=0;u<b;u++)y[u]^=1549556828,m[u]^=909522486;x.sigBytes=f.sigBytes=o,this.reset()},reset:function(){var n=this._hasher;n.reset(),n.update(this._iKey)},update:function(n){return this._hasher.update(n),this},finalize:function(n){var d=this._hasher,b=d.finalize(n);d.reset();var o=d.finalize(this._oKey.clone().concat(b));return o}})})()})})(et)),et.exports}var tt={exports:{}},qa=tt.exports,wr;function Ta(){return wr||(wr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),Rt(),Nt())})(qa,function(a){return(function(){var r=a,i=r.lib,s=i.Base,w=i.WordArray,c=r.algo,h=c.SHA256,n=c.HMAC,d=c.PBKDF2=s.extend({cfg:s.extend({keySize:128/32,hasher:h,iterations:25e4}),init:function(b){this.cfg=this.cfg.extend(b)},compute:function(b,o){for(var x=this.cfg,f=n.create(x.hasher,b),y=w.create(),m=w.create([1]),u=y.words,l=m.words,p=x.keySize,g=x.iterations;u.length<p;){var v=f.update(o).finalize(m);f.reset();for(var E=v.words,C=E.length,B=v,D=1;D<g;D++){B=f.finalize(B),f.reset();for(var A=B.words,_=0;_<C;_++)E[_]^=A[_]}y.concat(v),l[0]++}return y.sigBytes=p*4,y}});r.PBKDF2=function(b,o,x){return d.create(x).compute(b,o)}})(),a.PBKDF2})})(tt)),tt.exports}var rt={exports:{}},Ha=rt.exports,Cr;function fe(){return Cr||(Cr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),o0(),Nt())})(Ha,function(a){return(function(){var r=a,i=r.lib,s=i.Base,w=i.WordArray,c=r.algo,h=c.MD5,n=c.EvpKDF=s.extend({cfg:s.extend({keySize:128/32,hasher:h,iterations:1}),init:function(d){this.cfg=this.cfg.extend(d)},compute:function(d,b){for(var o,x=this.cfg,f=x.hasher.create(),y=w.create(),m=y.words,u=x.keySize,l=x.iterations;m.length<u;){o&&f.update(o),o=f.update(d).finalize(b),f.reset();for(var p=1;p<l;p++)o=f.finalize(o),f.reset();y.concat(o)}return y.sigBytes=u*4,y}});r.EvpKDF=function(d,b,o){return n.create(o).compute(d,b)}})(),a.EvpKDF})})(rt)),rt.exports}var at={exports:{}},za=at.exports,Br;function V(){return Br||(Br=1,(function(e,t){(function(a,r,i){e.exports=r(I(),fe())})(za,function(a){a.lib.Cipher||(function(r){var i=a,s=i.lib,w=s.Base,c=s.WordArray,h=s.BufferedBlockAlgorithm,n=i.enc;n.Utf8;var d=n.Base64,b=i.algo,o=b.EvpKDF,x=s.Cipher=h.extend({cfg:w.extend(),createEncryptor:function(A,_){return this.create(this._ENC_XFORM_MODE,A,_)},createDecryptor:function(A,_){return this.create(this._DEC_XFORM_MODE,A,_)},init:function(A,_,k){this.cfg=this.cfg.extend(k),this._xformMode=A,this._key=_,this.reset()},reset:function(){h.reset.call(this),this._doReset()},process:function(A){return this._append(A),this._process()},finalize:function(A){A&&this._append(A);var _=this._doFinalize();return _},keySize:128/32,ivSize:128/32,_ENC_XFORM_MODE:1,_DEC_XFORM_MODE:2,_createHelper:(function(){function A(_){return typeof _=="string"?D:E}return function(_){return{encrypt:function(k,F,T){return A(F).encrypt(_,k,F,T)},decrypt:function(k,F,T){return A(F).decrypt(_,k,F,T)}}}})()});s.StreamCipher=x.extend({_doFinalize:function(){var A=this._process(!0);return A},blockSize:1});var f=i.mode={},y=s.BlockCipherMode=w.extend({createEncryptor:function(A,_){return this.Encryptor.create(A,_)},createDecryptor:function(A,_){return this.Decryptor.create(A,_)},init:function(A,_){this._cipher=A,this._iv=_}}),m=f.CBC=(function(){var A=y.extend();A.Encryptor=A.extend({processBlock:function(k,F){var T=this._cipher,H=T.blockSize;_.call(this,k,F,H),T.encryptBlock(k,F),this._prevBlock=k.slice(F,F+H)}}),A.Decryptor=A.extend({processBlock:function(k,F){var T=this._cipher,H=T.blockSize,R=k.slice(F,F+H);T.decryptBlock(k,F),_.call(this,k,F,H),this._prevBlock=R}});function _(k,F,T){var H,R=this._iv;R?(H=R,this._iv=r):H=this._prevBlock;for(var K=0;K<T;K++)k[F+K]^=H[K]}return A})(),u=i.pad={},l=u.Pkcs7={pad:function(A,_){for(var k=_*4,F=k-A.sigBytes%k,T=F<<24|F<<16|F<<8|F,H=[],R=0;R<F;R+=4)H.push(T);var K=c.create(H,F);A.concat(K)},unpad:function(A){var _=A.words[A.sigBytes-1>>>2]&255;A.sigBytes-=_}};s.BlockCipher=x.extend({cfg:x.cfg.extend({mode:m,padding:l}),reset:function(){var A;x.reset.call(this);var _=this.cfg,k=_.iv,F=_.mode;this._xformMode==this._ENC_XFORM_MODE?A=F.createEncryptor:(A=F.createDecryptor,this._minBufferSize=1),this._mode&&this._mode.__creator==A?this._mode.init(this,k&&k.words):(this._mode=A.call(F,this,k&&k.words),this._mode.__creator=A)},_doProcessBlock:function(A,_){this._mode.processBlock(A,_)},_doFinalize:function(){var A,_=this.cfg.padding;return this._xformMode==this._ENC_XFORM_MODE?(_.pad(this._data,this.blockSize),A=this._process(!0)):(A=this._process(!0),_.unpad(A)),A},blockSize:128/32});var p=s.CipherParams=w.extend({init:function(A){this.mixIn(A)},toString:function(A){return(A||this.formatter).stringify(this)}}),g=i.format={},v=g.OpenSSL={stringify:function(A){var _,k=A.ciphertext,F=A.salt;return F?_=c.create([1398893684,1701076831]).concat(F).concat(k):_=k,_.toString(d)},parse:function(A){var _,k=d.parse(A),F=k.words;return F[0]==1398893684&&F[1]==1701076831&&(_=c.create(F.slice(2,4)),F.splice(0,4),k.sigBytes-=16),p.create({ciphertext:k,salt:_})}},E=s.SerializableCipher=w.extend({cfg:w.extend({format:v}),encrypt:function(A,_,k,F){F=this.cfg.extend(F);var T=A.createEncryptor(k,F),H=T.finalize(_),R=T.cfg;return p.create({ciphertext:H,key:k,iv:R.iv,algorithm:A,mode:R.mode,padding:R.padding,blockSize:A.blockSize,formatter:F.format})},decrypt:function(A,_,k,F){F=this.cfg.extend(F),_=this._parse(_,F.format);var T=A.createDecryptor(k,F).finalize(_.ciphertext);return T},_parse:function(A,_){return typeof A=="string"?_.parse(A,this):A}}),C=i.kdf={},B=C.OpenSSL={execute:function(A,_,k,F,T){if(F||(F=c.random(64/8)),T)var H=o.create({keySize:_+k,hasher:T}).compute(A,F);else var H=o.create({keySize:_+k}).compute(A,F);var R=c.create(H.words.slice(_),k*4);return H.sigBytes=_*4,p.create({key:H,iv:R,salt:F})}},D=s.PasswordBasedCipher=E.extend({cfg:E.cfg.extend({kdf:B}),encrypt:function(A,_,k,F){F=this.cfg.extend(F);var T=F.kdf.execute(k,A.keySize,A.ivSize,F.salt,F.hasher);F.iv=T.iv;var H=E.encrypt.call(this,A,_,T.key,F);return H.mixIn(T),H},decrypt:function(A,_,k,F){F=this.cfg.extend(F),_=this._parse(_,F.format);var T=F.kdf.execute(k,A.keySize,A.ivSize,_.salt,F.hasher);F.iv=T.iv;var H=E.decrypt.call(this,A,_,T.key,F);return H}})})()})})(at)),at.exports}var nt={exports:{}},Ra=nt.exports,Ar;function Na(){return Ar||(Ar=1,(function(e,t){(function(a,r,i){e.exports=r(I(),V())})(Ra,function(a){return a.mode.CFB=(function(){var r=a.lib.BlockCipherMode.extend();r.Encryptor=r.extend({processBlock:function(s,w){var c=this._cipher,h=c.blockSize;i.call(this,s,w,h,c),this._prevBlock=s.slice(w,w+h)}}),r.Decryptor=r.extend({processBlock:function(s,w){var c=this._cipher,h=c.blockSize,n=s.slice(w,w+h);i.call(this,s,w,h,c),this._prevBlock=n}});function i(s,w,c,h){var n,d=this._iv;d?(n=d.slice(0),this._iv=void 0):n=this._prevBlock,h.encryptBlock(n,0);for(var b=0;b<c;b++)s[w+b]^=n[b]}return r})(),a.mode.CFB})})(nt)),nt.exports}var it={exports:{}},Ma=it.exports,_r;function Ia(){return _r||(_r=1,(function(e,t){(function(a,r,i){e.exports=r(I(),V())})(Ma,function(a){return a.mode.CTR=(function(){var r=a.lib.BlockCipherMode.extend(),i=r.Encryptor=r.extend({processBlock:function(s,w){var c=this._cipher,h=c.blockSize,n=this._iv,d=this._counter;n&&(d=this._counter=n.slice(0),this._iv=void 0);var b=d.slice(0);c.encryptBlock(b,0),d[h-1]=d[h-1]+1|0;for(var o=0;o<h;o++)s[w+o]^=b[o]}});return r.Decryptor=i,r})(),a.mode.CTR})})(it)),it.exports}var st={exports:{}},Oa=st.exports,Dr;function ja(){return Dr||(Dr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),V())})(Oa,function(a){/** @preserve
 * Counter block mode compatible with  Dr Brian Gladman fileenc.c
 * derived from CryptoJS.mode.CTR
 * Jan Hruby jhruby.web@gmail.com
 */return a.mode.CTRGladman=(function(){var r=a.lib.BlockCipherMode.extend();function i(c){if((c>>24&255)===255){var h=c>>16&255,n=c>>8&255,d=c&255;h===255?(h=0,n===255?(n=0,d===255?d=0:++d):++n):++h,c=0,c+=h<<16,c+=n<<8,c+=d}else c+=1<<24;return c}function s(c){return(c[0]=i(c[0]))===0&&(c[1]=i(c[1])),c}var w=r.Encryptor=r.extend({processBlock:function(c,h){var n=this._cipher,d=n.blockSize,b=this._iv,o=this._counter;b&&(o=this._counter=b.slice(0),this._iv=void 0),s(o);var x=o.slice(0);n.encryptBlock(x,0);for(var f=0;f<d;f++)c[h+f]^=x[f]}});return r.Decryptor=w,r})(),a.mode.CTRGladman})})(st)),st.exports}var ot={exports:{}},Ua=ot.exports,kr;function Wa(){return kr||(kr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),V())})(Ua,function(a){return a.mode.OFB=(function(){var r=a.lib.BlockCipherMode.extend(),i=r.Encryptor=r.extend({processBlock:function(s,w){var c=this._cipher,h=c.blockSize,n=this._iv,d=this._keystream;n&&(d=this._keystream=n.slice(0),this._iv=void 0),c.encryptBlock(d,0);for(var b=0;b<h;b++)s[w+b]^=d[b]}});return r.Decryptor=i,r})(),a.mode.OFB})})(ot)),ot.exports}var ct={exports:{}},Ka=ct.exports,Fr;function Ga(){return Fr||(Fr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),V())})(Ka,function(a){return a.mode.ECB=(function(){var r=a.lib.BlockCipherMode.extend();return r.Encryptor=r.extend({processBlock:function(i,s){this._cipher.encryptBlock(i,s)}}),r.Decryptor=r.extend({processBlock:function(i,s){this._cipher.decryptBlock(i,s)}}),r})(),a.mode.ECB})})(ct)),ct.exports}var lt={exports:{}},Va=lt.exports,Sr;function Xa(){return Sr||(Sr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),V())})(Va,function(a){return a.pad.AnsiX923={pad:function(r,i){var s=r.sigBytes,w=i*4,c=w-s%w,h=s+c-1;r.clamp(),r.words[h>>>2]|=c<<24-h%4*8,r.sigBytes+=c},unpad:function(r){var i=r.words[r.sigBytes-1>>>2]&255;r.sigBytes-=i}},a.pad.Ansix923})})(lt)),lt.exports}var dt={exports:{}},Ya=dt.exports,Lr;function Qa(){return Lr||(Lr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),V())})(Ya,function(a){return a.pad.Iso10126={pad:function(r,i){var s=i*4,w=s-r.sigBytes%s;r.concat(a.lib.WordArray.random(w-1)).concat(a.lib.WordArray.create([w<<24],1))},unpad:function(r){var i=r.words[r.sigBytes-1>>>2]&255;r.sigBytes-=i}},a.pad.Iso10126})})(dt)),dt.exports}var xt={exports:{}},Za=xt.exports,Pr;function Ja(){return Pr||(Pr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),V())})(Za,function(a){return a.pad.Iso97971={pad:function(r,i){r.concat(a.lib.WordArray.create([2147483648],1)),a.pad.ZeroPadding.pad(r,i)},unpad:function(r){a.pad.ZeroPadding.unpad(r),r.sigBytes--}},a.pad.Iso97971})})(xt)),xt.exports}var pt={exports:{}},en=pt.exports,$r;function tn(){return $r||($r=1,(function(e,t){(function(a,r,i){e.exports=r(I(),V())})(en,function(a){return a.pad.ZeroPadding={pad:function(r,i){var s=i*4;r.clamp(),r.sigBytes+=s-(r.sigBytes%s||s)},unpad:function(r){for(var i=r.words,s=r.sigBytes-1,s=r.sigBytes-1;s>=0;s--)if(i[s>>>2]>>>24-s%4*8&255){r.sigBytes=s+1;break}}},a.pad.ZeroPadding})})(pt)),pt.exports}var ut={exports:{}},rn=ut.exports,qr;function an(){return qr||(qr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),V())})(rn,function(a){return a.pad.NoPadding={pad:function(){},unpad:function(){}},a.pad.NoPadding})})(ut)),ut.exports}var ft={exports:{}},nn=ft.exports,Tr;function sn(){return Tr||(Tr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),V())})(nn,function(a){return(function(r){var i=a,s=i.lib,w=s.CipherParams,c=i.enc,h=c.Hex,n=i.format;n.Hex={stringify:function(d){return d.ciphertext.toString(h)},parse:function(d){var b=h.parse(d);return w.create({ciphertext:b})}}})(),a.format.Hex})})(ft)),ft.exports}var ht={exports:{}},on=ht.exports,Hr;function cn(){return Hr||(Hr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),me(),ge(),fe(),V())})(on,function(a){return(function(){var r=a,i=r.lib,s=i.BlockCipher,w=r.algo,c=[],h=[],n=[],d=[],b=[],o=[],x=[],f=[],y=[],m=[];(function(){for(var p=[],g=0;g<256;g++)g<128?p[g]=g<<1:p[g]=g<<1^283;for(var v=0,E=0,g=0;g<256;g++){var C=E^E<<1^E<<2^E<<3^E<<4;C=C>>>8^C&255^99,c[v]=C,h[C]=v;var B=p[v],D=p[B],A=p[D],_=p[C]*257^C*16843008;n[v]=_<<24|_>>>8,d[v]=_<<16|_>>>16,b[v]=_<<8|_>>>24,o[v]=_;var _=A*16843009^D*65537^B*257^v*16843008;x[C]=_<<24|_>>>8,f[C]=_<<16|_>>>16,y[C]=_<<8|_>>>24,m[C]=_,v?(v=B^p[p[p[A^B]]],E^=p[p[E]]):v=E=1}})();var u=[0,1,2,4,8,16,32,64,128,27,54],l=w.AES=s.extend({_doReset:function(){var p;if(!(this._nRounds&&this._keyPriorReset===this._key)){for(var g=this._keyPriorReset=this._key,v=g.words,E=g.sigBytes/4,C=this._nRounds=E+6,B=(C+1)*4,D=this._keySchedule=[],A=0;A<B;A++)A<E?D[A]=v[A]:(p=D[A-1],A%E?E>6&&A%E==4&&(p=c[p>>>24]<<24|c[p>>>16&255]<<16|c[p>>>8&255]<<8|c[p&255]):(p=p<<8|p>>>24,p=c[p>>>24]<<24|c[p>>>16&255]<<16|c[p>>>8&255]<<8|c[p&255],p^=u[A/E|0]<<24),D[A]=D[A-E]^p);for(var _=this._invKeySchedule=[],k=0;k<B;k++){var A=B-k;if(k%4)var p=D[A];else var p=D[A-4];k<4||A<=4?_[k]=p:_[k]=x[c[p>>>24]]^f[c[p>>>16&255]]^y[c[p>>>8&255]]^m[c[p&255]]}}},encryptBlock:function(p,g){this._doCryptBlock(p,g,this._keySchedule,n,d,b,o,c)},decryptBlock:function(p,g){var v=p[g+1];p[g+1]=p[g+3],p[g+3]=v,this._doCryptBlock(p,g,this._invKeySchedule,x,f,y,m,h);var v=p[g+1];p[g+1]=p[g+3],p[g+3]=v},_doCryptBlock:function(p,g,v,E,C,B,D,A){for(var _=this._nRounds,k=p[g]^v[0],F=p[g+1]^v[1],T=p[g+2]^v[2],H=p[g+3]^v[3],R=4,K=1;K<_;K++){var O=E[k>>>24]^C[F>>>16&255]^B[T>>>8&255]^D[H&255]^v[R++],U=E[F>>>24]^C[T>>>16&255]^B[H>>>8&255]^D[k&255]^v[R++],j=E[T>>>24]^C[H>>>16&255]^B[k>>>8&255]^D[F&255]^v[R++],S=E[H>>>24]^C[k>>>16&255]^B[F>>>8&255]^D[T&255]^v[R++];k=O,F=U,T=j,H=S}var O=(A[k>>>24]<<24|A[F>>>16&255]<<16|A[T>>>8&255]<<8|A[H&255])^v[R++],U=(A[F>>>24]<<24|A[T>>>16&255]<<16|A[H>>>8&255]<<8|A[k&255])^v[R++],j=(A[T>>>24]<<24|A[H>>>16&255]<<16|A[k>>>8&255]<<8|A[F&255])^v[R++],S=(A[H>>>24]<<24|A[k>>>16&255]<<16|A[F>>>8&255]<<8|A[T&255])^v[R++];p[g]=O,p[g+1]=U,p[g+2]=j,p[g+3]=S},keySize:256/32});r.AES=s._createHelper(l)})(),a.AES})})(ht)),ht.exports}var vt={exports:{}},ln=vt.exports,zr;function dn(){return zr||(zr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),me(),ge(),fe(),V())})(ln,function(a){return(function(){var r=a,i=r.lib,s=i.WordArray,w=i.BlockCipher,c=r.algo,h=[57,49,41,33,25,17,9,1,58,50,42,34,26,18,10,2,59,51,43,35,27,19,11,3,60,52,44,36,63,55,47,39,31,23,15,7,62,54,46,38,30,22,14,6,61,53,45,37,29,21,13,5,28,20,12,4],n=[14,17,11,24,1,5,3,28,15,6,21,10,23,19,12,4,26,8,16,7,27,20,13,2,41,52,31,37,47,55,30,40,51,45,33,48,44,49,39,56,34,53,46,42,50,36,29,32],d=[1,2,4,6,8,10,12,14,15,17,19,21,23,25,27,28],b=[{0:8421888,268435456:32768,536870912:8421378,805306368:2,1073741824:512,1342177280:8421890,1610612736:8389122,1879048192:8388608,2147483648:514,2415919104:8389120,2684354560:33280,2952790016:8421376,3221225472:32770,3489660928:8388610,3758096384:0,4026531840:33282,134217728:0,402653184:8421890,671088640:33282,939524096:32768,1207959552:8421888,1476395008:512,1744830464:8421378,2013265920:2,2281701376:8389120,2550136832:33280,2818572288:8421376,3087007744:8389122,3355443200:8388610,3623878656:32770,3892314112:514,4160749568:8388608,1:32768,268435457:2,536870913:8421888,805306369:8388608,1073741825:8421378,1342177281:33280,1610612737:512,1879048193:8389122,2147483649:8421890,2415919105:8421376,2684354561:8388610,2952790017:33282,3221225473:514,3489660929:8389120,3758096385:32770,4026531841:0,134217729:8421890,402653185:8421376,671088641:8388608,939524097:512,1207959553:32768,1476395009:8388610,1744830465:2,2013265921:33282,2281701377:32770,2550136833:8389122,2818572289:514,3087007745:8421888,3355443201:8389120,3623878657:0,3892314113:33280,4160749569:8421378},{0:1074282512,16777216:16384,33554432:524288,50331648:1074266128,67108864:1073741840,83886080:1074282496,100663296:1073758208,117440512:16,134217728:540672,150994944:1073758224,167772160:1073741824,184549376:540688,201326592:524304,218103808:0,234881024:16400,251658240:1074266112,8388608:1073758208,25165824:540688,41943040:16,58720256:1073758224,75497472:1074282512,92274688:1073741824,109051904:524288,125829120:1074266128,142606336:524304,159383552:0,176160768:16384,192937984:1074266112,209715200:1073741840,226492416:540672,243269632:1074282496,260046848:16400,268435456:0,285212672:1074266128,301989888:1073758224,318767104:1074282496,335544320:1074266112,352321536:16,369098752:540688,385875968:16384,402653184:16400,419430400:524288,436207616:524304,452984832:1073741840,469762048:540672,486539264:1073758208,503316480:1073741824,520093696:1074282512,276824064:540688,293601280:524288,310378496:1074266112,327155712:16384,343932928:1073758208,360710144:1074282512,377487360:16,394264576:1073741824,411041792:1074282496,427819008:1073741840,444596224:1073758224,461373440:524304,478150656:0,494927872:16400,511705088:1074266128,528482304:540672},{0:260,1048576:0,2097152:67109120,3145728:65796,4194304:65540,5242880:67108868,6291456:67174660,7340032:67174400,8388608:67108864,9437184:67174656,10485760:65792,11534336:67174404,12582912:67109124,13631488:65536,14680064:4,15728640:256,524288:67174656,1572864:67174404,2621440:0,3670016:67109120,4718592:67108868,5767168:65536,6815744:65540,7864320:260,8912896:4,9961472:256,11010048:67174400,12058624:65796,13107200:65792,14155776:67109124,15204352:67174660,16252928:67108864,16777216:67174656,17825792:65540,18874368:65536,19922944:67109120,20971520:256,22020096:67174660,23068672:67108868,24117248:0,25165824:67109124,26214400:67108864,27262976:4,28311552:65792,29360128:67174400,30408704:260,31457280:65796,32505856:67174404,17301504:67108864,18350080:260,19398656:67174656,20447232:0,21495808:65540,22544384:67109120,23592960:256,24641536:67174404,25690112:65536,26738688:67174660,27787264:65796,28835840:67108868,29884416:67109124,30932992:67174400,31981568:4,33030144:65792},{0:2151682048,65536:2147487808,131072:4198464,196608:2151677952,262144:0,327680:4198400,393216:2147483712,458752:4194368,524288:2147483648,589824:4194304,655360:64,720896:2147487744,786432:2151678016,851968:4160,917504:4096,983040:2151682112,32768:2147487808,98304:64,163840:2151678016,229376:2147487744,294912:4198400,360448:2151682112,425984:0,491520:2151677952,557056:4096,622592:2151682048,688128:4194304,753664:4160,819200:2147483648,884736:4194368,950272:4198464,1015808:2147483712,1048576:4194368,1114112:4198400,1179648:2147483712,1245184:0,1310720:4160,1376256:2151678016,1441792:2151682048,1507328:2147487808,1572864:2151682112,1638400:2147483648,1703936:2151677952,1769472:4198464,1835008:2147487744,1900544:4194304,1966080:64,2031616:4096,1081344:2151677952,1146880:2151682112,1212416:0,1277952:4198400,1343488:4194368,1409024:2147483648,1474560:2147487808,1540096:64,1605632:2147483712,1671168:4096,1736704:2147487744,1802240:2151678016,1867776:4160,1933312:2151682048,1998848:4194304,2064384:4198464},{0:128,4096:17039360,8192:262144,12288:536870912,16384:537133184,20480:16777344,24576:553648256,28672:262272,32768:16777216,36864:537133056,40960:536871040,45056:553910400,49152:553910272,53248:0,57344:17039488,61440:553648128,2048:17039488,6144:553648256,10240:128,14336:17039360,18432:262144,22528:537133184,26624:553910272,30720:536870912,34816:537133056,38912:0,43008:553910400,47104:16777344,51200:536871040,55296:553648128,59392:16777216,63488:262272,65536:262144,69632:128,73728:536870912,77824:553648256,81920:16777344,86016:553910272,90112:537133184,94208:16777216,98304:553910400,102400:553648128,106496:17039360,110592:537133056,114688:262272,118784:536871040,122880:0,126976:17039488,67584:553648256,71680:16777216,75776:17039360,79872:537133184,83968:536870912,88064:17039488,92160:128,96256:553910272,100352:262272,104448:553910400,108544:0,112640:553648128,116736:16777344,120832:262144,124928:537133056,129024:536871040},{0:268435464,256:8192,512:270532608,768:270540808,1024:268443648,1280:2097152,1536:2097160,1792:268435456,2048:0,2304:268443656,2560:2105344,2816:8,3072:270532616,3328:2105352,3584:8200,3840:270540800,128:270532608,384:270540808,640:8,896:2097152,1152:2105352,1408:268435464,1664:268443648,1920:8200,2176:2097160,2432:8192,2688:268443656,2944:270532616,3200:0,3456:270540800,3712:2105344,3968:268435456,4096:268443648,4352:270532616,4608:270540808,4864:8200,5120:2097152,5376:268435456,5632:268435464,5888:2105344,6144:2105352,6400:0,6656:8,6912:270532608,7168:8192,7424:268443656,7680:270540800,7936:2097160,4224:8,4480:2105344,4736:2097152,4992:268435464,5248:268443648,5504:8200,5760:270540808,6016:270532608,6272:270540800,6528:270532616,6784:8192,7040:2105352,7296:2097160,7552:0,7808:268435456,8064:268443656},{0:1048576,16:33555457,32:1024,48:1049601,64:34604033,80:0,96:1,112:34603009,128:33555456,144:1048577,160:33554433,176:34604032,192:34603008,208:1025,224:1049600,240:33554432,8:34603009,24:0,40:33555457,56:34604032,72:1048576,88:33554433,104:33554432,120:1025,136:1049601,152:33555456,168:34603008,184:1048577,200:1024,216:34604033,232:1,248:1049600,256:33554432,272:1048576,288:33555457,304:34603009,320:1048577,336:33555456,352:34604032,368:1049601,384:1025,400:34604033,416:1049600,432:1,448:0,464:34603008,480:33554433,496:1024,264:1049600,280:33555457,296:34603009,312:1,328:33554432,344:1048576,360:1025,376:34604032,392:33554433,408:34603008,424:0,440:34604033,456:1049601,472:1024,488:33555456,504:1048577},{0:134219808,1:131072,2:134217728,3:32,4:131104,5:134350880,6:134350848,7:2048,8:134348800,9:134219776,10:133120,11:134348832,12:2080,13:0,14:134217760,15:133152,2147483648:2048,2147483649:134350880,2147483650:134219808,2147483651:134217728,2147483652:134348800,2147483653:133120,2147483654:133152,2147483655:32,2147483656:134217760,2147483657:2080,2147483658:131104,2147483659:134350848,2147483660:0,2147483661:134348832,2147483662:134219776,2147483663:131072,16:133152,17:134350848,18:32,19:2048,20:134219776,21:134217760,22:134348832,23:131072,24:0,25:131104,26:134348800,27:134219808,28:134350880,29:133120,30:2080,31:134217728,2147483664:131072,2147483665:2048,2147483666:134348832,2147483667:133152,2147483668:32,2147483669:134348800,2147483670:134217728,2147483671:134219808,2147483672:134350880,2147483673:134217760,2147483674:134219776,2147483675:0,2147483676:133120,2147483677:2080,2147483678:131104,2147483679:134350848}],o=[4160749569,528482304,33030144,2064384,129024,8064,504,2147483679],x=c.DES=w.extend({_doReset:function(){for(var u=this._key,l=u.words,p=[],g=0;g<56;g++){var v=h[g]-1;p[g]=l[v>>>5]>>>31-v%32&1}for(var E=this._subKeys=[],C=0;C<16;C++){for(var B=E[C]=[],D=d[C],g=0;g<24;g++)B[g/6|0]|=p[(n[g]-1+D)%28]<<31-g%6,B[4+(g/6|0)]|=p[28+(n[g+24]-1+D)%28]<<31-g%6;B[0]=B[0]<<1|B[0]>>>31;for(var g=1;g<7;g++)B[g]=B[g]>>>(g-1)*4+3;B[7]=B[7]<<5|B[7]>>>27}for(var A=this._invSubKeys=[],g=0;g<16;g++)A[g]=E[15-g]},encryptBlock:function(u,l){this._doCryptBlock(u,l,this._subKeys)},decryptBlock:function(u,l){this._doCryptBlock(u,l,this._invSubKeys)},_doCryptBlock:function(u,l,p){this._lBlock=u[l],this._rBlock=u[l+1],f.call(this,4,252645135),f.call(this,16,65535),y.call(this,2,858993459),y.call(this,8,16711935),f.call(this,1,1431655765);for(var g=0;g<16;g++){for(var v=p[g],E=this._lBlock,C=this._rBlock,B=0,D=0;D<8;D++)B|=b[D][((C^v[D])&o[D])>>>0];this._lBlock=C,this._rBlock=E^B}var A=this._lBlock;this._lBlock=this._rBlock,this._rBlock=A,f.call(this,1,1431655765),y.call(this,8,16711935),y.call(this,2,858993459),f.call(this,16,65535),f.call(this,4,252645135),u[l]=this._lBlock,u[l+1]=this._rBlock},keySize:64/32,ivSize:64/32,blockSize:64/32});function f(u,l){var p=(this._lBlock>>>u^this._rBlock)&l;this._rBlock^=p,this._lBlock^=p<<u}function y(u,l){var p=(this._rBlock>>>u^this._lBlock)&l;this._lBlock^=p,this._rBlock^=p<<u}r.DES=w._createHelper(x);var m=c.TripleDES=w.extend({_doReset:function(){var u=this._key,l=u.words;if(l.length!==2&&l.length!==4&&l.length<6)throw new Error("Invalid key length - 3DES requires the key length to be 64, 128, 192 or >192.");var p=l.slice(0,2),g=l.length<4?l.slice(0,2):l.slice(2,4),v=l.length<6?l.slice(0,2):l.slice(4,6);this._des1=x.createEncryptor(s.create(p)),this._des2=x.createEncryptor(s.create(g)),this._des3=x.createEncryptor(s.create(v))},encryptBlock:function(u,l){this._des1.encryptBlock(u,l),this._des2.decryptBlock(u,l),this._des3.encryptBlock(u,l)},decryptBlock:function(u,l){this._des3.decryptBlock(u,l),this._des2.encryptBlock(u,l),this._des1.decryptBlock(u,l)},keySize:192/32,ivSize:64/32,blockSize:64/32});r.TripleDES=w._createHelper(m)})(),a.TripleDES})})(vt)),vt.exports}var mt={exports:{}},xn=mt.exports,Rr;function pn(){return Rr||(Rr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),me(),ge(),fe(),V())})(xn,function(a){return(function(){var r=a,i=r.lib,s=i.StreamCipher,w=r.algo,c=w.RC4=s.extend({_doReset:function(){for(var d=this._key,b=d.words,o=d.sigBytes,x=this._S=[],f=0;f<256;f++)x[f]=f;for(var f=0,y=0;f<256;f++){var m=f%o,u=b[m>>>2]>>>24-m%4*8&255;y=(y+x[f]+u)%256;var l=x[f];x[f]=x[y],x[y]=l}this._i=this._j=0},_doProcessBlock:function(d,b){d[b]^=h.call(this)},keySize:256/32,ivSize:0});function h(){for(var d=this._S,b=this._i,o=this._j,x=0,f=0;f<4;f++){b=(b+1)%256,o=(o+d[b])%256;var y=d[b];d[b]=d[o],d[o]=y,x|=d[(d[b]+d[o])%256]<<24-f*8}return this._i=b,this._j=o,x}r.RC4=s._createHelper(c);var n=w.RC4Drop=c.extend({cfg:c.cfg.extend({drop:192}),_doReset:function(){c._doReset.call(this);for(var d=this.cfg.drop;d>0;d--)h.call(this)}});r.RC4Drop=s._createHelper(n)})(),a.RC4})})(mt)),mt.exports}var gt={exports:{}},un=gt.exports,Nr;function fn(){return Nr||(Nr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),me(),ge(),fe(),V())})(un,function(a){return(function(){var r=a,i=r.lib,s=i.StreamCipher,w=r.algo,c=[],h=[],n=[],d=w.Rabbit=s.extend({_doReset:function(){for(var o=this._key.words,x=this.cfg.iv,f=0;f<4;f++)o[f]=(o[f]<<8|o[f]>>>24)&16711935|(o[f]<<24|o[f]>>>8)&4278255360;var y=this._X=[o[0],o[3]<<16|o[2]>>>16,o[1],o[0]<<16|o[3]>>>16,o[2],o[1]<<16|o[0]>>>16,o[3],o[2]<<16|o[1]>>>16],m=this._C=[o[2]<<16|o[2]>>>16,o[0]&4294901760|o[1]&65535,o[3]<<16|o[3]>>>16,o[1]&4294901760|o[2]&65535,o[0]<<16|o[0]>>>16,o[2]&4294901760|o[3]&65535,o[1]<<16|o[1]>>>16,o[3]&4294901760|o[0]&65535];this._b=0;for(var f=0;f<4;f++)b.call(this);for(var f=0;f<8;f++)m[f]^=y[f+4&7];if(x){var u=x.words,l=u[0],p=u[1],g=(l<<8|l>>>24)&16711935|(l<<24|l>>>8)&4278255360,v=(p<<8|p>>>24)&16711935|(p<<24|p>>>8)&4278255360,E=g>>>16|v&4294901760,C=v<<16|g&65535;m[0]^=g,m[1]^=E,m[2]^=v,m[3]^=C,m[4]^=g,m[5]^=E,m[6]^=v,m[7]^=C;for(var f=0;f<4;f++)b.call(this)}},_doProcessBlock:function(o,x){var f=this._X;b.call(this),c[0]=f[0]^f[5]>>>16^f[3]<<16,c[1]=f[2]^f[7]>>>16^f[5]<<16,c[2]=f[4]^f[1]>>>16^f[7]<<16,c[3]=f[6]^f[3]>>>16^f[1]<<16;for(var y=0;y<4;y++)c[y]=(c[y]<<8|c[y]>>>24)&16711935|(c[y]<<24|c[y]>>>8)&4278255360,o[x+y]^=c[y]},blockSize:128/32,ivSize:64/32});function b(){for(var o=this._X,x=this._C,f=0;f<8;f++)h[f]=x[f];x[0]=x[0]+1295307597+this._b|0,x[1]=x[1]+3545052371+(x[0]>>>0<h[0]>>>0?1:0)|0,x[2]=x[2]+886263092+(x[1]>>>0<h[1]>>>0?1:0)|0,x[3]=x[3]+1295307597+(x[2]>>>0<h[2]>>>0?1:0)|0,x[4]=x[4]+3545052371+(x[3]>>>0<h[3]>>>0?1:0)|0,x[5]=x[5]+886263092+(x[4]>>>0<h[4]>>>0?1:0)|0,x[6]=x[6]+1295307597+(x[5]>>>0<h[5]>>>0?1:0)|0,x[7]=x[7]+3545052371+(x[6]>>>0<h[6]>>>0?1:0)|0,this._b=x[7]>>>0<h[7]>>>0?1:0;for(var f=0;f<8;f++){var y=o[f]+x[f],m=y&65535,u=y>>>16,l=((m*m>>>17)+m*u>>>15)+u*u,p=((y&4294901760)*y|0)+((y&65535)*y|0);n[f]=l^p}o[0]=n[0]+(n[7]<<16|n[7]>>>16)+(n[6]<<16|n[6]>>>16)|0,o[1]=n[1]+(n[0]<<8|n[0]>>>24)+n[7]|0,o[2]=n[2]+(n[1]<<16|n[1]>>>16)+(n[0]<<16|n[0]>>>16)|0,o[3]=n[3]+(n[2]<<8|n[2]>>>24)+n[1]|0,o[4]=n[4]+(n[3]<<16|n[3]>>>16)+(n[2]<<16|n[2]>>>16)|0,o[5]=n[5]+(n[4]<<8|n[4]>>>24)+n[3]|0,o[6]=n[6]+(n[5]<<16|n[5]>>>16)+(n[4]<<16|n[4]>>>16)|0,o[7]=n[7]+(n[6]<<8|n[6]>>>24)+n[5]|0}r.Rabbit=s._createHelper(d)})(),a.Rabbit})})(gt)),gt.exports}var yt={exports:{}},hn=yt.exports,Mr;function vn(){return Mr||(Mr=1,(function(e,t){(function(a,r,i){e.exports=r(I(),me(),ge(),fe(),V())})(hn,function(a){return(function(){var r=a,i=r.lib,s=i.StreamCipher,w=r.algo,c=[],h=[],n=[],d=w.RabbitLegacy=s.extend({_doReset:function(){var o=this._key.words,x=this.cfg.iv,f=this._X=[o[0],o[3]<<16|o[2]>>>16,o[1],o[0]<<16|o[3]>>>16,o[2],o[1]<<16|o[0]>>>16,o[3],o[2]<<16|o[1]>>>16],y=this._C=[o[2]<<16|o[2]>>>16,o[0]&4294901760|o[1]&65535,o[3]<<16|o[3]>>>16,o[1]&4294901760|o[2]&65535,o[0]<<16|o[0]>>>16,o[2]&4294901760|o[3]&65535,o[1]<<16|o[1]>>>16,o[3]&4294901760|o[0]&65535];this._b=0;for(var m=0;m<4;m++)b.call(this);for(var m=0;m<8;m++)y[m]^=f[m+4&7];if(x){var u=x.words,l=u[0],p=u[1],g=(l<<8|l>>>24)&16711935|(l<<24|l>>>8)&4278255360,v=(p<<8|p>>>24)&16711935|(p<<24|p>>>8)&4278255360,E=g>>>16|v&4294901760,C=v<<16|g&65535;y[0]^=g,y[1]^=E,y[2]^=v,y[3]^=C,y[4]^=g,y[5]^=E,y[6]^=v,y[7]^=C;for(var m=0;m<4;m++)b.call(this)}},_doProcessBlock:function(o,x){var f=this._X;b.call(this),c[0]=f[0]^f[5]>>>16^f[3]<<16,c[1]=f[2]^f[7]>>>16^f[5]<<16,c[2]=f[4]^f[1]>>>16^f[7]<<16,c[3]=f[6]^f[3]>>>16^f[1]<<16;for(var y=0;y<4;y++)c[y]=(c[y]<<8|c[y]>>>24)&16711935|(c[y]<<24|c[y]>>>8)&4278255360,o[x+y]^=c[y]},blockSize:128/32,ivSize:64/32});function b(){for(var o=this._X,x=this._C,f=0;f<8;f++)h[f]=x[f];x[0]=x[0]+1295307597+this._b|0,x[1]=x[1]+3545052371+(x[0]>>>0<h[0]>>>0?1:0)|0,x[2]=x[2]+886263092+(x[1]>>>0<h[1]>>>0?1:0)|0,x[3]=x[3]+1295307597+(x[2]>>>0<h[2]>>>0?1:0)|0,x[4]=x[4]+3545052371+(x[3]>>>0<h[3]>>>0?1:0)|0,x[5]=x[5]+886263092+(x[4]>>>0<h[4]>>>0?1:0)|0,x[6]=x[6]+1295307597+(x[5]>>>0<h[5]>>>0?1:0)|0,x[7]=x[7]+3545052371+(x[6]>>>0<h[6]>>>0?1:0)|0,this._b=x[7]>>>0<h[7]>>>0?1:0;for(var f=0;f<8;f++){var y=o[f]+x[f],m=y&65535,u=y>>>16,l=((m*m>>>17)+m*u>>>15)+u*u,p=((y&4294901760)*y|0)+((y&65535)*y|0);n[f]=l^p}o[0]=n[0]+(n[7]<<16|n[7]>>>16)+(n[6]<<16|n[6]>>>16)|0,o[1]=n[1]+(n[0]<<8|n[0]>>>24)+n[7]|0,o[2]=n[2]+(n[1]<<16|n[1]>>>16)+(n[0]<<16|n[0]>>>16)|0,o[3]=n[3]+(n[2]<<8|n[2]>>>24)+n[1]|0,o[4]=n[4]+(n[3]<<16|n[3]>>>16)+(n[2]<<16|n[2]>>>16)|0,o[5]=n[5]+(n[4]<<8|n[4]>>>24)+n[3]|0,o[6]=n[6]+(n[5]<<16|n[5]>>>16)+(n[4]<<16|n[4]>>>16)|0,o[7]=n[7]+(n[6]<<8|n[6]>>>24)+n[5]|0}r.RabbitLegacy=s._createHelper(d)})(),a.RabbitLegacy})})(yt)),yt.exports}var bt={exports:{}},mn=bt.exports,Ir;function gn(){return Ir||(Ir=1,(function(e,t){(function(a,r,i){e.exports=r(I(),me(),ge(),fe(),V())})(mn,function(a){return(function(){var r=a,i=r.lib,s=i.BlockCipher,w=r.algo;const c=16,h=[608135816,2242054355,320440878,57701188,2752067618,698298832,137296536,3964562569,1160258022,953160567,3193202383,887688300,3232508343,3380367581,1065670069,3041331479,2450970073,2306472731],n=[[3509652390,2564797868,805139163,3491422135,3101798381,1780907670,3128725573,4046225305,614570311,3012652279,134345442,2240740374,1667834072,1901547113,2757295779,4103290238,227898511,1921955416,1904987480,2182433518,2069144605,3260701109,2620446009,720527379,3318853667,677414384,3393288472,3101374703,2390351024,1614419982,1822297739,2954791486,3608508353,3174124327,2024746970,1432378464,3864339955,2857741204,1464375394,1676153920,1439316330,715854006,3033291828,289532110,2706671279,2087905683,3018724369,1668267050,732546397,1947742710,3462151702,2609353502,2950085171,1814351708,2050118529,680887927,999245976,1800124847,3300911131,1713906067,1641548236,4213287313,1216130144,1575780402,4018429277,3917837745,3693486850,3949271944,596196993,3549867205,258830323,2213823033,772490370,2760122372,1774776394,2652871518,566650946,4142492826,1728879713,2882767088,1783734482,3629395816,2517608232,2874225571,1861159788,326777828,3124490320,2130389656,2716951837,967770486,1724537150,2185432712,2364442137,1164943284,2105845187,998989502,3765401048,2244026483,1075463327,1455516326,1322494562,910128902,469688178,1117454909,936433444,3490320968,3675253459,1240580251,122909385,2157517691,634681816,4142456567,3825094682,3061402683,2540495037,79693498,3249098678,1084186820,1583128258,426386531,1761308591,1047286709,322548459,995290223,1845252383,2603652396,3431023940,2942221577,3202600964,3727903485,1712269319,422464435,3234572375,1170764815,3523960633,3117677531,1434042557,442511882,3600875718,1076654713,1738483198,4213154764,2393238008,3677496056,1014306527,4251020053,793779912,2902807211,842905082,4246964064,1395751752,1040244610,2656851899,3396308128,445077038,3742853595,3577915638,679411651,2892444358,2354009459,1767581616,3150600392,3791627101,3102740896,284835224,4246832056,1258075500,768725851,2589189241,3069724005,3532540348,1274779536,3789419226,2764799539,1660621633,3471099624,4011903706,913787905,3497959166,737222580,2514213453,2928710040,3937242737,1804850592,3499020752,2949064160,2386320175,2390070455,2415321851,4061277028,2290661394,2416832540,1336762016,1754252060,3520065937,3014181293,791618072,3188594551,3933548030,2332172193,3852520463,3043980520,413987798,3465142937,3030929376,4245938359,2093235073,3534596313,375366246,2157278981,2479649556,555357303,3870105701,2008414854,3344188149,4221384143,3956125452,2067696032,3594591187,2921233993,2428461,544322398,577241275,1471733935,610547355,4027169054,1432588573,1507829418,2025931657,3646575487,545086370,48609733,2200306550,1653985193,298326376,1316178497,3007786442,2064951626,458293330,2589141269,3591329599,3164325604,727753846,2179363840,146436021,1461446943,4069977195,705550613,3059967265,3887724982,4281599278,3313849956,1404054877,2845806497,146425753,1854211946],[1266315497,3048417604,3681880366,3289982499,290971e4,1235738493,2632868024,2414719590,3970600049,1771706367,1449415276,3266420449,422970021,1963543593,2690192192,3826793022,1062508698,1531092325,1804592342,2583117782,2714934279,4024971509,1294809318,4028980673,1289560198,2221992742,1669523910,35572830,157838143,1052438473,1016535060,1802137761,1753167236,1386275462,3080475397,2857371447,1040679964,2145300060,2390574316,1461121720,2956646967,4031777805,4028374788,33600511,2920084762,1018524850,629373528,3691585981,3515945977,2091462646,2486323059,586499841,988145025,935516892,3367335476,2599673255,2839830854,265290510,3972581182,2759138881,3795373465,1005194799,847297441,406762289,1314163512,1332590856,1866599683,4127851711,750260880,613907577,1450815602,3165620655,3734664991,3650291728,3012275730,3704569646,1427272223,778793252,1343938022,2676280711,2052605720,1946737175,3164576444,3914038668,3967478842,3682934266,1661551462,3294938066,4011595847,840292616,3712170807,616741398,312560963,711312465,1351876610,322626781,1910503582,271666773,2175563734,1594956187,70604529,3617834859,1007753275,1495573769,4069517037,2549218298,2663038764,504708206,2263041392,3941167025,2249088522,1514023603,1998579484,1312622330,694541497,2582060303,2151582166,1382467621,776784248,2618340202,3323268794,2497899128,2784771155,503983604,4076293799,907881277,423175695,432175456,1378068232,4145222326,3954048622,3938656102,3820766613,2793130115,2977904593,26017576,3274890735,3194772133,1700274565,1756076034,4006520079,3677328699,720338349,1533947780,354530856,688349552,3973924725,1637815568,332179504,3949051286,53804574,2852348879,3044236432,1282449977,3583942155,3416972820,4006381244,1617046695,2628476075,3002303598,1686838959,431878346,2686675385,1700445008,1080580658,1009431731,832498133,3223435511,2605976345,2271191193,2516031870,1648197032,4164389018,2548247927,300782431,375919233,238389289,3353747414,2531188641,2019080857,1475708069,455242339,2609103871,448939670,3451063019,1395535956,2413381860,1841049896,1491858159,885456874,4264095073,4001119347,1565136089,3898914787,1108368660,540939232,1173283510,2745871338,3681308437,4207628240,3343053890,4016749493,1699691293,1103962373,3625875870,2256883143,3830138730,1031889488,3479347698,1535977030,4236805024,3251091107,2132092099,1774941330,1199868427,1452454533,157007616,2904115357,342012276,595725824,1480756522,206960106,497939518,591360097,863170706,2375253569,3596610801,1814182875,2094937945,3421402208,1082520231,3463918190,2785509508,435703966,3908032597,1641649973,2842273706,3305899714,1510255612,2148256476,2655287854,3276092548,4258621189,236887753,3681803219,274041037,1734335097,3815195456,3317970021,1899903192,1026095262,4050517792,356393447,2410691914,3873677099,3682840055],[3913112168,2491498743,4132185628,2489919796,1091903735,1979897079,3170134830,3567386728,3557303409,857797738,1136121015,1342202287,507115054,2535736646,337727348,3213592640,1301675037,2528481711,1895095763,1721773893,3216771564,62756741,2142006736,835421444,2531993523,1442658625,3659876326,2882144922,676362277,1392781812,170690266,3921047035,1759253602,3611846912,1745797284,664899054,1329594018,3901205900,3045908486,2062866102,2865634940,3543621612,3464012697,1080764994,553557557,3656615353,3996768171,991055499,499776247,1265440854,648242737,3940784050,980351604,3713745714,1749149687,3396870395,4211799374,3640570775,1161844396,3125318951,1431517754,545492359,4268468663,3499529547,1437099964,2702547544,3433638243,2581715763,2787789398,1060185593,1593081372,2418618748,4260947970,69676912,2159744348,86519011,2512459080,3838209314,1220612927,3339683548,133810670,1090789135,1078426020,1569222167,845107691,3583754449,4072456591,1091646820,628848692,1613405280,3757631651,526609435,236106946,48312990,2942717905,3402727701,1797494240,859738849,992217954,4005476642,2243076622,3870952857,3732016268,765654824,3490871365,2511836413,1685915746,3888969200,1414112111,2273134842,3281911079,4080962846,172450625,2569994100,980381355,4109958455,2819808352,2716589560,2568741196,3681446669,3329971472,1835478071,660984891,3704678404,4045999559,3422617507,3040415634,1762651403,1719377915,3470491036,2693910283,3642056355,3138596744,1364962596,2073328063,1983633131,926494387,3423689081,2150032023,4096667949,1749200295,3328846651,309677260,2016342300,1779581495,3079819751,111262694,1274766160,443224088,298511866,1025883608,3806446537,1145181785,168956806,3641502830,3584813610,1689216846,3666258015,3200248200,1692713982,2646376535,4042768518,1618508792,1610833997,3523052358,4130873264,2001055236,3610705100,2202168115,4028541809,2961195399,1006657119,2006996926,3186142756,1430667929,3210227297,1314452623,4074634658,4101304120,2273951170,1399257539,3367210612,3027628629,1190975929,2062231137,2333990788,2221543033,2438960610,1181637006,548689776,2362791313,3372408396,3104550113,3145860560,296247880,1970579870,3078560182,3769228297,1714227617,3291629107,3898220290,166772364,1251581989,493813264,448347421,195405023,2709975567,677966185,3703036547,1463355134,2715995803,1338867538,1343315457,2802222074,2684532164,233230375,2599980071,2000651841,3277868038,1638401717,4028070440,3237316320,6314154,819756386,300326615,590932579,1405279636,3267499572,3150704214,2428286686,3959192993,3461946742,1862657033,1266418056,963775037,2089974820,2263052895,1917689273,448879540,3550394620,3981727096,150775221,3627908307,1303187396,508620638,2975983352,2726630617,1817252668,1876281319,1457606340,908771278,3720792119,3617206836,2455994898,1729034894,1080033504],[976866871,3556439503,2881648439,1522871579,1555064734,1336096578,3548522304,2579274686,3574697629,3205460757,3593280638,3338716283,3079412587,564236357,2993598910,1781952180,1464380207,3163844217,3332601554,1699332808,1393555694,1183702653,3581086237,1288719814,691649499,2847557200,2895455976,3193889540,2717570544,1781354906,1676643554,2592534050,3230253752,1126444790,2770207658,2633158820,2210423226,2615765581,2414155088,3127139286,673620729,2805611233,1269405062,4015350505,3341807571,4149409754,1057255273,2012875353,2162469141,2276492801,2601117357,993977747,3918593370,2654263191,753973209,36408145,2530585658,25011837,3520020182,2088578344,530523599,2918365339,1524020338,1518925132,3760827505,3759777254,1202760957,3985898139,3906192525,674977740,4174734889,2031300136,2019492241,3983892565,4153806404,3822280332,352677332,2297720250,60907813,90501309,3286998549,1016092578,2535922412,2839152426,457141659,509813237,4120667899,652014361,1966332200,2975202805,55981186,2327461051,676427537,3255491064,2882294119,3433927263,1307055953,942726286,933058658,2468411793,3933900994,4215176142,1361170020,2001714738,2830558078,3274259782,1222529897,1679025792,2729314320,3714953764,1770335741,151462246,3013232138,1682292957,1483529935,471910574,1539241949,458788160,3436315007,1807016891,3718408830,978976581,1043663428,3165965781,1927990952,4200891579,2372276910,3208408903,3533431907,1412390302,2931980059,4132332400,1947078029,3881505623,4168226417,2941484381,1077988104,1320477388,886195818,18198404,3786409e3,2509781533,112762804,3463356488,1866414978,891333506,18488651,661792760,1628790961,3885187036,3141171499,876946877,2693282273,1372485963,791857591,2686433993,3759982718,3167212022,3472953795,2716379847,445679433,3561995674,3504004811,3574258232,54117162,3331405415,2381918588,3769707343,4154350007,1140177722,4074052095,668550556,3214352940,367459370,261225585,2610173221,4209349473,3468074219,3265815641,314222801,3066103646,3808782860,282218597,3406013506,3773591054,379116347,1285071038,846784868,2669647154,3771962079,3550491691,2305946142,453669953,1268987020,3317592352,3279303384,3744833421,2610507566,3859509063,266596637,3847019092,517658769,3462560207,3443424879,370717030,4247526661,2224018117,4143653529,4112773975,2788324899,2477274417,1456262402,2901442914,1517677493,1846949527,2295493580,3734397586,2176403920,1280348187,1908823572,3871786941,846861322,1172426758,3287448474,3383383037,1655181056,3139813346,901632758,1897031941,2986607138,3066810236,3447102507,1393639104,373351379,950779232,625454576,3124240540,4148612726,2007998917,544563296,2244738638,2330496472,2058025392,1291430526,424198748,50039436,29584100,3605783033,2429876329,2791104160,1057563949,3255363231,3075367218,3463963227,1469046755,985887462]];var d={pbox:[],sbox:[]};function b(m,u){let l=u>>24&255,p=u>>16&255,g=u>>8&255,v=u&255,E=m.sbox[0][l]+m.sbox[1][p];return E=E^m.sbox[2][g],E=E+m.sbox[3][v],E}function o(m,u,l){let p=u,g=l,v;for(let E=0;E<c;++E)p=p^m.pbox[E],g=b(m,p)^g,v=p,p=g,g=v;return v=p,p=g,g=v,g=g^m.pbox[c],p=p^m.pbox[c+1],{left:p,right:g}}function x(m,u,l){let p=u,g=l,v;for(let E=c+1;E>1;--E)p=p^m.pbox[E],g=b(m,p)^g,v=p,p=g,g=v;return v=p,p=g,g=v,g=g^m.pbox[1],p=p^m.pbox[0],{left:p,right:g}}function f(m,u,l){for(let C=0;C<4;C++){m.sbox[C]=[];for(let B=0;B<256;B++)m.sbox[C][B]=n[C][B]}let p=0;for(let C=0;C<c+2;C++)m.pbox[C]=h[C]^u[p],p++,p>=l&&(p=0);let g=0,v=0,E=0;for(let C=0;C<c+2;C+=2)E=o(m,g,v),g=E.left,v=E.right,m.pbox[C]=g,m.pbox[C+1]=v;for(let C=0;C<4;C++)for(let B=0;B<256;B+=2)E=o(m,g,v),g=E.left,v=E.right,m.sbox[C][B]=g,m.sbox[C][B+1]=v;return!0}var y=w.Blowfish=s.extend({_doReset:function(){if(this._keyPriorReset!==this._key){var m=this._keyPriorReset=this._key,u=m.words,l=m.sigBytes/4;f(d,u,l)}},encryptBlock:function(m,u){var l=o(d,m[u],m[u+1]);m[u]=l.left,m[u+1]=l.right},decryptBlock:function(m,u){var l=x(d,m[u],m[u+1]);m[u]=l.left,m[u+1]=l.right},blockSize:64/32,keySize:128/32,ivSize:64/32});r.Blowfish=s._createHelper(y)})(),a.Blowfish})})(bt)),bt.exports}var yn=Ne.exports,Or;function bn(){return Or||(Or=1,(function(e,t){(function(a,r,i){e.exports=r(I(),Bt(),ha(),ma(),me(),ba(),ge(),o0(),Rt(),Aa(),c0(),ka(),Sa(),Pa(),Nt(),Ta(),fe(),V(),Na(),Ia(),ja(),Wa(),Ga(),Xa(),Qa(),Ja(),tn(),an(),sn(),cn(),dn(),pn(),fn(),vn(),gn())})(yn,function(a){return a})})(Ne)),Ne.exports}var En=bn();const Ce=sa(En),ne=wt.isNativePlatform(),wn="38346591",jr={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",Accept:"*/*","Accept-Language":"en-US,en;q=0.9,hi;q=0.8",Referer:"https://www.jiosaavn.com/"};async function ae(e){if(ne){const t=await J0.get({url:e,headers:jr});if(t.status!==200)throw new Error(`HTTP ${t.status}`);return typeof t.data=="string"?t.data:JSON.stringify(t.data)}else{const t=await fetch(e,{headers:jr});if(!t.ok)throw new Error(`HTTP ${t.status}`);return await t.text()}}function Ur(e){if(!e)return"";try{const t=Ce.enc.Utf8.parse(wn),a=Ce.enc.Base64.parse(e.trim());let i=Ce.DES.decrypt({ciphertext:a},t,{mode:Ce.mode.ECB,padding:Ce.pad.Pkcs7}).toString(Ce.enc.Utf8);return i?(i=i.replace("_96.mp4","_320.mp4"),i):""}catch(t){return console.error("Decrypt error:",t),""}}function oe(e){if(!e)return"";const t=document.createElement("textarea");return t.innerHTML=e,t.value}function Mt(e){var t,a,r,i;if(!e)return null;try{let s="";if(e.encrypted_media_url?(s=Ur(e.encrypted_media_url),e["320kbps"]!=="true"&&(s=s.replace("_320.mp4","_160.mp4"))):(t=e.more_info)!=null&&t.encrypted_media_url?(s=Ur(e.more_info.encrypted_media_url),e.more_info["320kbps"]!=="true"&&(s=s.replace("_320.mp4","_160.mp4"))):e.media_preview_url&&(s=e.media_preview_url.replace("preview.saavncdn.com","aac.saavncdn.com"),s=e["320kbps"]==="true"?s.replace("_96_p.mp4","_320.mp4"):s.replace("_96_p.mp4","_160.mp4")),!s)return null;let w=(e.image||"").replace(/150x150/g,"500x500").replace(/50x50/g,"500x500"),c=(e.image||"").replace(/500x500/g,"150x150").replace(/50x50/g,"150x150");return{id:e.id||"",title:oe(e.song||e.title||""),artist:oe(e.primary_artists||((a=e.more_info)==null?void 0:a.primary_artists)||e.singers||e.music||e.subtitle||""),album:oe(e.album||((r=e.more_info)==null?void 0:r.album)||""),duration:parseInt(e.duration||((i=e.more_info)==null?void 0:i.duration)||"0"),cover:w,coverSmall:c,url:s}}catch(s){return console.error("Format error:",s),null}}function Et(e){const t=new Set,a=new Set;return e.filter(r=>{if(!r)return!1;const i=(r.cover||"").replace(/\d+x\d+/g,"SIZE").toLowerCase(),s=(r.title||"").toLowerCase().trim();return i&&t.has(i)&&a.has(s)?!1:(i&&t.add(i),s&&a.add(s),!0)})}const Cn=(e,t,a)=>`https://www.jiosaavn.com/api.php?__call=search.getResults&_format=json&_marker=0&cc=in&p=${t}&n=${a}&q=${encodeURIComponent(e)}`,Bn="https://www.jiosaavn.com/api.php?__call=search.getAll&_format=json&_marker=0&cc=in&query=",An="https://www.jiosaavn.com/api.php?__call=autocomplete.get&_format=json&_marker=0&cc=in&includeMetaTags=1&query=",l0="https://www.jiosaavn.com/api.php?__call=song.getDetails&cc=in&_marker=0&_format=json&pids=",_n="https://www.jiosaavn.com/api.php?__call=playlist.getDetails&_format=json&_marker=0&cc=in&listid=";async function ce(e,t=1,a=10){var r;try{if(console.log(`[${ne?"NATIVE":"WEB"}] Searching for: ${e} (Page ${t})`),ne){try{const b=(await ae(Cn(e,t,a))).replace(/\(From "([^"]+)"\)/g,"(From '$1')"),o=JSON.parse(b),x=(o==null?void 0:o.results)||[];if(console.log(`search.getResults: ${x.length} results`),x.length>0){const f=x.map(y=>y.id).filter(Boolean).join(",");if(f){const y=await ae(l0+f),m=JSON.parse(y),u=Object.values(m).map(l=>Mt(l)).filter(l=>l&&l.url);if(u.length>0)return console.log(`Formatted ${u.length} full songs from IDs`),Et(u)}}}catch(d){console.warn("search.getResults failed, trying autocomplete:",d.message)}const s=(await ae(An+encodeURIComponent(e))).replace(/\(From "([^"]+)"\)/g,"(From '$1')"),w=JSON.parse(s),c=((r=w==null?void 0:w.songs)==null?void 0:r.data)||[];console.log(`Autocomplete fallback: ${c.length} IDs`);const h=c.map(d=>p0(d.id)),n=await Promise.all(h);return Et(n.filter(d=>d&&d.url))}else{const i=await fetch(`/api/search?q=${encodeURIComponent(e)}&page=${t}&limit=${a}`);if(!i.ok)return[];const s=await i.json();return Array.isArray(s)?Et(s):[]}}catch(i){return console.error("Search failed:",i),[]}}async function d0(e){var t,a,r;try{if(!ne)return{songs:await ce(e),playlists:[],albums:[]};const s=(await ae(Bn+encodeURIComponent(e))).replace(/\(From "([^"]+)"\)/g,"(From '$1')"),w=JSON.parse(s);let c=[];const h=((t=w==null?void 0:w.songs)==null?void 0:t.data)||[];h.length>0&&(c=h.map(x=>{var f;return{id:x.id||"",title:oe(x.title||""),artist:oe(x.description||((f=x.more_info)==null?void 0:f.primary_artists)||""),cover:(x.image||"").replace(/150x150/g,"500x500").replace(/50x50/g,"500x500"),coverSmall:(x.image||"").replace(/500x500/g,"150x150"),_needsDetail:!0}}).filter(x=>x.id));let n=[];const d=((a=w==null?void 0:w.playlists)==null?void 0:a.data)||[];d.length>0&&(n=d.map(x=>{var f;return{id:x.id||"",title:oe(x.title||""),description:oe(x.description||x.subtitle||""),cover:(x.image||"").replace(/150x150/g,"500x500").replace(/50x50/g,"500x500"),coverSmall:(x.image||"").replace(/500x500/g,"150x150"),songCount:((f=x.more_info)==null?void 0:f.song_count)||x.count||0,type:"playlist"}}).filter(x=>x.id));let b=[];const o=((r=w==null?void 0:w.albums)==null?void 0:r.data)||[];return o.length>0&&(b=o.map(x=>{var f;return{id:x.id||"",title:oe(x.title||""),artist:oe(x.description||x.music||((f=x.more_info)==null?void 0:f.music)||""),cover:(x.image||"").replace(/150x150/g,"500x500").replace(/50x50/g,"500x500"),coverSmall:(x.image||"").replace(/500x500/g,"150x150"),type:"album"}}).filter(x=>x.id)),{songs:c,playlists:n,albums:b}}catch(i){return console.error("searchAll failed:",i),{songs:[],playlists:[],albums:[]}}}async function x0(e){try{if(!ne)return[];const a=(await ae(_n+e)).replace(/\(From "([^"]+)"\)/g,"(From '$1')"),r=JSON.parse(a),s=((r==null?void 0:r.songs)||(r==null?void 0:r.list)||[]).map(w=>Mt(w)).filter(w=>w&&w.url);return Et(s)}catch(t){return console.error("Playlist fetch failed:",t),[]}}async function p0(e){try{if(ne){const t=await ae(l0+e),r=JSON.parse(t)[e];return Mt(r)}else{const t=await fetch(`/api/song?id=${e}`);return t.ok?await t.json():null}}catch(t){return console.error("Get song failed:",t,e),null}}const Dn="https://api.lyrics.ovh/v1/";async function u0(e,t){if(!e||!t)return null;try{const a=e.split(",")[0].trim(),r=t.replace(/\s*\(.*?\)\s*/g,"").replace(/\s*\[.*?\]\s*/g,"").replace(/\s*-\s*.*$/,"").trim(),i=Dn+encodeURIComponent(a)+"/"+encodeURIComponent(r);let s="";if(ne){const w=await ae(i),c=JSON.parse(w);s=(c==null?void 0:c.lyrics)||""}else{const w=await fetch(i);if(!w.ok)return null;const c=await w.json();s=(c==null?void 0:c.lyrics)||""}return s.trim()||null}catch(a){return console.warn("Lyrics not found:",a.message),null}}const kn="https://www.theaudiodb.com/api/v1/json/2/search.php?s=";async function f0(e){if(!e)return null;const t=e.split(",")[0].trim(),a=kn+encodeURIComponent(t);try{let r;if(ne){const i=await ae(a);r=JSON.parse(i)}else{const i=await fetch(a);if(!i.ok)return null;r=await i.json()}if(r&&r.artists&&r.artists.length>0){const i=r.artists[0];return{name:i.strArtist||t,biography:i.strBiographyEN||"",thumbnail:i.strArtistThumb||"",logo:i.strArtistLogo||"",banner:i.strArtistBanner||i.strArtistThumb||"",genre:i.strGenre||"",country:i.strCountry||"",yearFormed:i.intFormedYear||""}}}catch(r){console.warn("Artist info fetch failed:",r.message)}return null}const Fn="https://itunes.apple.com/search?media=podcast&limit=15&term=";async function h0(e){if(!e)return[];try{const t=Fn+encodeURIComponent(e);let a;if(ne){const r=await ae(t);a=JSON.parse(r)}else{const r=await fetch(t);if(!r.ok)return[];a=await r.json()}if(a&&a.results)return a.results.map(r=>({id:r.collectionId,title:r.collectionName,artist:r.artistName,cover:r.artworkUrl600||r.artworkUrl100,feedUrl:r.feedUrl,genre:r.primaryGenreName,type:"podcast"})).filter(r=>r.feedUrl)}catch(t){console.error("Podcast search failed:",t)}return[]}async function v0(e,t,a){if(!e)return[];try{let r="";if(ne)r=await ae(e);else{const c=await fetch(e);if(!c.ok)return[];r=await c.text()}const s=new DOMParser().parseFromString(r,"text/xml");return Array.from(s.querySelectorAll("item")).slice(0,50).map((c,h)=>{var y,m,u;const n=((y=c.querySelector("title"))==null?void 0:y.textContent)||`Episode ${h+1}`,d=c.querySelector("enclosure"),b=d?d.getAttribute("url"):"",o=((m=c.querySelector("pubDate"))==null?void 0:m.textContent)||"",f=(((u=c.querySelector("description"))==null?void 0:u.textContent)||"").replace(/<[^>]+>/g," ").substring(0,150)+"...";return b?{id:`podcast_${btoa(b).substring(0,10)}_${h}`,title:oe(n),artist:a||"Podcast",cover:t,url:b,duration:0,type:"podcast_episode",date:o,description:f}:null}).filter(Boolean)}catch(r){console.error("Podcast feed fetch failed:",r)}return[]}const Sn="https://musicbrainz.org/ws/2/artist/?fmt=json&query=";async function Ln(e){if(!e)return[];const t=e.split(",")[0].trim(),a=Sn+encodeURIComponent(t);try{const r={"User-Agent":"MeloMusicPlayer/1.0 (mahesh@example.com)"};let i=null;if(ne){const c=await ae(a),h=JSON.parse(c);h.artists&&h.artists.length>0&&(i=h.artists[0].id)}else{const c=await fetch(a,{headers:r});if(!c.ok)return[];const h=await c.json();h.artists&&h.artists.length>0&&(i=h.artists[0].id)}if(!i)return[];const s=`https://musicbrainz.org/ws/2/release-group?artist=${i}&fmt=json&limit=50`;let w;if(ne){const c=await ae(s);w=JSON.parse(c)}else{const c=await fetch(s,{headers:r});if(!c.ok)return[];w=await c.json()}if(w&&w["release-groups"]){const c=w["release-groups"],h=new Map;return c.forEach(n=>{if(!n.title||!n["first-release-date"])return;const d=n["first-release-date"].substring(0,4),b=n.title.toLowerCase().replace(/\\(.*\\)|\[.*\]/g,"").trim();h.has(b)||h.set(b,{id:n.id,title:n.title,type:n["primary-type"]||"Single",year:d,cover:`https://coverartarchive.org/release-group/${n.id}/front-250`})}),Array.from(h.values()).sort((n,d)=>parseInt(d.year)-parseInt(n.year))}}catch(r){console.error("MusicBrainz discography failed:",r)}return[]}const m0=Object.freeze(Object.defineProperty({__proto__:null,getArtistDiscography:Ln,getArtistInfo:f0,getLyrics:u0,getPlaylistSongs:x0,getPodcastEpisodes:v0,getSongById:p0,searchAll:d0,searchPodcasts:h0,searchSongs:ce},Symbol.toStringTag,{value:"Module"})),Pn={pop:"latest pop hits",hiphop:"hip hop trending",rock:"rock hits",lofi:"lofi chill beats",electronic:"electronic dance",rnb:"r&b soul",jazz:"jazz classics",classical:"classical music",indie:"indie music",kpop:"kpop trending",bollywood:"bollywood latest songs",ambient:"ambient relax"};function $n(){const e=document.createElement("div");e.className="page";const t=M.get(),a=new Date().getHours();let r="Good evening";a<12?r="Good morning":a<17&&(r="Good afternoon"),e.innerHTML=`
    <div class="home-header">
      <img src="/icons/icon.svg" class="home-logo" alt="Melo" />
      <h1 class="text-greeting">${r} <span style="font-size: 14px; color: var(--accent); vertical-align: middle; margin-left: 10px;">v1.0.7</span></h1>
    </div>
    <div class="section" style="margin-top: var(--space-xl);">
      <div class="horizontal-scroll" id="home-chips"></div>
    </div>
    <div id="home-sections">
      <div class="home-loading">
        <div class="loading-spinner"></div>
        <p class="text-subtitle">Loading your music...</p>
      </div>
    </div>
  `;const i=e.querySelector("#home-chips"),s=document.createElement("button");s.className="chip active",s.textContent="For You",i.appendChild(s),(t.interests.length>0?t.interests:["bollywood","pop","lofi","hiphop"]).forEach(o=>{const x=Tt.find(f=>f.id===o);if(x){const f=document.createElement("button");f.className="chip",f.textContent=x.name,f.dataset.genre=o,i.appendChild(f)}});let c=null;i.addEventListener("click",o=>{const x=o.target.closest(".chip");x&&(i.querySelectorAll(".chip").forEach(f=>f.classList.remove("active")),x.classList.add("active"),c=x.dataset.genre||null,n())});const h=e.querySelector("#home-sections");async function n(){var o;h.innerHTML=`
      <div class="home-loading">
        <div class="loading-spinner"></div>
        <p class="text-subtitle">Loading...</p>
      </div>
    `;try{if(c){const x=Pn[c]||c,f=await ce(x);if(h.innerHTML="",f.length>0){const y=((o=Tt.find(m=>m.id===c))==null?void 0:o.name)||c;h.appendChild(d(`${y} Hits`,f,x))}else h.innerHTML='<div class="empty-state"><span class="material-symbols-rounded">music_off</span><p>No tracks found</p></div>'}else{if(h.innerHTML="",t.recentlyPlayed.length>0){const C=t.recentlyPlayed.map(B=>z.getCachedTrack(B)).filter(Boolean).slice(0,10);C.length>0&&h.appendChild(d("Recently played",C))}const x=await he.getAllDownloads();x.length>0&&h.appendChild(d("Downloaded · Offline",x.slice(0,20)));const f=[],y={pop:[{title:"Pop Hits 🎵",query:"latest pop songs new 2025"},{title:"International Pop",query:"top english pop songs trending"}],hiphop:[{title:"Hip Hop Fire 🔥",query:"hindi rap songs trending 2025"},{title:"Underground Beats",query:"indian hip hop rapper tracks"}],rock:[{title:"Rock Anthems 🎸",query:"rock songs hindi best"},{title:"Alt Rock Picks",query:"alternative rock band songs"}],lofi:[{title:"Lo-Fi Chill 🌙",query:"lofi hindi chill beats study"},{title:"Late Night Vibes",query:"slowed reverb songs hindi aesthetic"}],electronic:[{title:"EDM Drops ⚡",query:"edm electronic dance songs"},{title:"Bass & Beats",query:"electronic bass music remix"}],rnb:[{title:"R&B Smooth 🎤",query:"rnb soul music smooth"},{title:"Soulful Vibes",query:"soul music relaxing"}],jazz:[{title:"Jazz Sessions 🎷",query:"jazz songs instrumental smooth"},{title:"Jazz Classics",query:"jazz classic legends vocals"}],classical:[{title:"Classical Ragas 🎻",query:"indian classical music raga"},{title:"Timeless Melodies",query:"classical instrumental piano soothing"}],indie:[{title:"Indie Picks 🌿",query:"indie music hindi artist"},{title:"Fresh Indie",query:"independent artist songs new"}],kpop:[{title:"K-Pop Faves 💜",query:"kpop trending songs BTS"},{title:"K-Pop New Releases",query:"kpop latest songs 2025"}],bollywood:[{title:"Bollywood Hits 🎬",query:"bollywood songs latest trending 2025"},{title:"Filmi Favorites",query:"best bollywood movie songs romantic"}],ambient:[{title:"Ambient Escape 🧘",query:"ambient meditation music calm"},{title:"Nature & Peace",query:"relaxing music nature sounds sleep"}]};(t.interests.length>0?t.interests:["bollywood","pop","lofi"]).forEach(C=>{(y[C]||[]).forEach(D=>f.push(D))});const u=new Set;if(t.recentlyPlayed.length>0)for(const C of t.recentlyPlayed.slice(0,10)){const B=z.getCachedTrack(C);if(B!=null&&B.artist){const D=B.artist.split(",")[0].trim();!u.has(D.toLowerCase())&&u.size<2&&(u.add(D.toLowerCase()),f.splice(2+u.size,0,{title:`Because you listened to ${D}`,query:`${D} best songs more`}))}}const l=f.slice(0,8),p=await Promise.allSettled(l.map(C=>ce(C.query).then(B=>({...C,songs:B})))),g=h.querySelector(".home-loading");g&&g.remove();let v=0;async function E(){if(v>=p.length||h.parentElement!==e)return;const C=p[v];C.status==="fulfilled"&&C.value.songs.length>0&&h.appendChild(d(C.value.title,C.value.songs,C.value.query)),v++,setTimeout(E,30)}E().then(()=>{h.parentElement===e&&h.appendChild(b())}),p.length===0&&(h.innerHTML=`
            <div class="empty-state">
              <span class="material-symbols-rounded">wifi_off</span>
              <p>Couldn't load music</p>
              <p class="text-subtitle" style="margin-top: var(--space-sm);">Check your internet and try again</p>
            </div>
          `)}}catch(x){console.error("Failed to load home content:",x),h.innerHTML=`
        <div class="empty-state">
          <span class="material-symbols-rounded">error</span>
          <p>Something went wrong</p>
        </div>
      `}}function d(o,x,f=null){const y=document.createElement("div");y.className="section";let m=1;y.innerHTML=`
      <div class="section-header">
        <h2 class="text-section-title">${o}</h2>
        <span class="text-subtitle">${x.length} songs</span>
      </div>
    `;const u=document.createElement("div");if(u.className="horizontal-scroll",x.slice(0,10).forEach(l=>{u.appendChild(ue(l,x))}),x.length>=10&&f){const l=document.createElement("div");l.className="view-more-card";let p=!1;l.innerHTML=`
        <div class="view-more-inner">
          <span class="material-symbols-rounded">arrow_forward</span>
          <span>Load More</span>
        </div>
      `,l.addEventListener("click",async()=>{if(!p){p=!0,l.innerHTML='<div class="loading-spinner" style="width:24px;height:24px;border-width:2px;"></div>',m++;try{const g=await ce(f,m,10);g&&g.length>0?(g.forEach(v=>{x.push(v),u.insertBefore(ue(v,x),l)}),y.querySelector(".text-subtitle").textContent=`${x.length} songs`,l.innerHTML=`
              <div class="view-more-inner">
                <span class="material-symbols-rounded">arrow_forward</span>
                <span>Load More</span>
              </div>
            `):l.remove()}catch{l.innerHTML='<div class="view-more-inner"><span>Error</span></div>'}p=!1}}),u.appendChild(l)}return y.appendChild(u),y}function b(){const o=document.createElement("div");o.className="section",o.innerHTML=`
      <div class="section-header">
        <h2 class="text-section-title">Popular Artists</h2>
      </div>
    `;const x=document.createElement("div");return x.className="horizontal-scroll artist-scroll",ia.forEach(f=>{const y=document.createElement("div");y.className="artist-card";const m=f.name.split(" ").map(u=>u[0]).join("").slice(0,2);y.innerHTML=`
        <div class="artist-avatar" style="background: ${f.gradient};">
          ${f.image?`<img class="artist-img" src="${f.image}" alt="${f.name}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';" /><span class="artist-initials" style="display:none;">${m}</span>`:`<span class="artist-initials">${m}</span>`}
        </div>
        <div class="artist-name">${f.name}</div>
      `,y.addEventListener("click",async()=>{var p;h.innerHTML=`
          <div class="home-loading">
            <div class="loading-spinner"></div>
            <p class="text-subtitle">Loading ${f.name} songs...</p>
          </div>
        `;const u=await ce(f.query);h.innerHTML="";const l=document.createElement("div");l.style.cssText="display:flex;align-items:center;gap:var(--space-md);margin-bottom:var(--space-xl);",l.innerHTML=`
          <button class="btn-icon" id="artist-back"><span class="material-symbols-rounded">arrow_back</span></button>
          <div class="artist-avatar" style="background:${f.gradient};width:48px;height:48px;"><span class="material-symbols-rounded" style="font-size:24px;">person</span></div>
          <div>
            <h2 class="text-section-title">${f.name}</h2>
            <span class="text-subtitle">${u.length} songs</span>
          </div>
          ${u.length>0?'<button class="btn-play" id="artist-play-all" style="margin-left:auto;width:44px;height:44px;"><span class="material-symbols-rounded" style="font-size:22px;">play_arrow</span></button>':""}
        `,l.querySelector("#artist-back").addEventListener("click",()=>{c=null,n()}),h.appendChild(l),u.length>0?((p=l.querySelector("#artist-play-all"))==null||p.addEventListener("click",()=>{z.playAll(u,u[0])}),h.appendChild(d(`${f.name} Songs`,u,f.query))):h.innerHTML+='<div class="empty-state"><span class="material-symbols-rounded">music_off</span><p>No songs found</p></div>'}),x.appendChild(y)}),o.appendChild(x),o}return n(),e}const g0=document.createElement("style");g0.textContent=`
  .home-header {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    margin-bottom: var(--space-sm);
  }
  .home-logo {
    width: 32px;
    height: 32px;
    filter: drop-shadow(0 0 8px var(--accent-glow));
    cursor: pointer;
    transition: transform var(--transition-fast);
  }
  .home-logo:active {
    transform: scale(0.9);
  }

  .home-loading {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: var(--space-3xl);
    gap: var(--space-lg);
  }

  .loading-spinner {
    width: 36px;
    height: 36px;
    border: 3px solid var(--bg-active);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }

  /* View More card at end of row */
  .view-more-card {
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 100px;
    height: 130px;
    cursor: pointer;
    -webkit-tap-highlight-color: transparent;
    flex-shrink: 0;
  }

  .view-more-inner {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: var(--space-sm);
    color: var(--text-secondary);
    font-size: var(--font-sm);
    font-weight: 500;
    text-align: center;
    transition: color var(--transition-fast), transform var(--transition-fast);
  }

  .view-more-inner .material-symbols-rounded {
    font-size: 32px;
    width: 56px;
    height: 56px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--radius-full);
    background: var(--surface-glass);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid var(--surface-border);
    transition: background var(--transition-fast), transform var(--transition-fast);
  }

  .view-more-card:hover .view-more-inner {
    color: var(--accent);
  }

  .view-more-card:hover .material-symbols-rounded {
    background: var(--accent-dim);
    transform: scale(1.05);
  }

  .view-more-card:active .view-more-inner {
    transform: scale(0.95);
  }

  .view-more-inner small {
    font-size: var(--font-xs);
    color: var(--text-tertiary);
  }

  /* Artist cards */
  .artist-scroll {
    gap: var(--space-xl);
  }

  .artist-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: var(--space-sm);
    cursor: pointer;
    transition: transform var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
    width: 90px;
  }

  .artist-card:active {
    transform: scale(0.95);
  }

  .artist-avatar {
    width: 72px;
    height: 72px;
    border-radius: var(--radius-full);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: var(--shadow-md);
    transition: transform var(--transition-normal), box-shadow var(--transition-normal);
    overflow: hidden;
  }

  .artist-card:hover .artist-avatar {
    transform: scale(1.05);
    box-shadow: var(--shadow-lg);
  }

  .artist-avatar .material-symbols-rounded {
    font-size: 32px;
    opacity: 0.9;
  }

  .artist-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: var(--radius-full);
  }

  .artist-initials {
    font-size: 24px;
    font-weight: 700;
    color: rgba(255,255,255,0.85);
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
  }

  .artist-name {
    font-size: var(--font-xs);
    font-weight: 500;
    color: var(--text-primary);
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
  }

  /* Tablet: bigger artist cards */
  @media (min-width: 768px) {
    .artist-card {
      width: 110px;
    }
    .artist-avatar {
      width: 88px;
      height: 88px;
    }
    .artist-name {
      font-size: var(--font-sm);
    }
    .artist-initials {
      font-size: 30px;
    }
  }

  @media (min-width: 1024px) {
    .artist-card {
      width: 130px;
    }
    .artist-avatar {
      width: 100px;
      height: 100px;
    }
    .artist-avatar .material-symbols-rounded {
      font-size: 40px;
    }
    .artist-initials {
      font-size: 36px;
    }
  }
`;document.head.appendChild(g0);function qn(){const e=document.createElement("div");e.className="page",e.innerHTML=`
    <h1 class="text-greeting">Search</h1>
    <div class="search-input-wrapper" style="margin-top: var(--space-xl);">
      <span class="material-symbols-rounded">search</span>
      <input type="text" class="search-input" placeholder="Search songs, artists, playlists..." id="search-input" autocomplete="off" />
    </div>
    <div id="search-loading" class="home-loading" style="display:none;">
      <div class="loading-spinner"></div>
      <p class="text-subtitle">Searching...</p>
    </div>
    <div id="search-results" style="display: none;"></div>
    <div id="browse-section"></div>
  `;const t=e.querySelector("#search-input"),a=e.querySelector("#search-results"),r=e.querySelector("#search-loading"),i=e.querySelector("#browse-section");function s(){const u=M.get();if(i.innerHTML="",u.recentlyPlayed.length>0){const p=document.createElement("div");p.className="section",p.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Recently Played</h2>
          <span class="text-subtitle">${u.recentlyPlayed.length} songs</span>
        </div>
      `;const g=document.createElement("div");g.className="search-history-list",u.recentlyPlayed.slice(0,10).forEach(v=>{const E=u.trackMetadata[v];E&&g.appendChild(ue(E,u.recentlyPlayed.map(C=>u.trackMetadata[C]).filter(Boolean),"horizontal"))}),p.appendChild(g),i.appendChild(p)}if(u.likedSongs.length>0){const p=document.createElement("div");p.className="section",p.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Your Liked Songs</h2>
          <span class="text-subtitle">${u.likedSongs.length} songs</span>
        </div>
      `;const g=document.createElement("div");g.className="search-history-list",u.likedSongs.slice(0,10).forEach(v=>{const E=u.trackMetadata[v];E&&g.appendChild(ue(E,u.likedSongs.map(C=>u.trackMetadata[C]).filter(Boolean),"horizontal"))}),p.appendChild(g),i.appendChild(p)}const l=w(u);if(l.length>0){const p=document.createElement("div");p.className="section",p.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Try Searching</h2>
        </div>
      `;const g=document.createElement("div");g.className="suggestion-chips",l.forEach(v=>{const E=document.createElement("button");E.className="chip suggestion-chip",E.innerHTML=`<span class="material-symbols-rounded" style="font-size:16px;">${v.icon}</span> ${v.label}`,E.addEventListener("click",()=>{t.value=v.query,y(v.query)}),g.appendChild(E)}),p.appendChild(g),i.appendChild(p)}if(u.recentlyPlayed.length===0&&u.likedSongs.length===0){const p=document.createElement("div");p.className="section",p.innerHTML=`
        <div class="empty-state" style="padding: var(--space-2xl) 0;">
          <span class="material-symbols-rounded" style="font-size:48px;color:var(--text-tertiary);">search</span>
          <p style="margin-top:var(--space-md);color:var(--text-secondary);">Search for any song, artist, or playlist</p>
          <p class="text-subtitle" style="margin-top:var(--space-sm);">Your listening history will appear here</p>
        </div>
      `,i.appendChild(p);const g=document.createElement("div");g.className="section",g.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Popular Searches</h2>
        </div>
      `;const v=document.createElement("div");v.className="suggestion-chips",[{label:"Arijit Singh",icon:"person",query:"Arijit Singh"},{label:"Bollywood Hits",icon:"music_note",query:"bollywood hits 2025"},{label:"Party Songs",icon:"celebration",query:"party songs hindi"},{label:"Romantic",icon:"favorite",query:"romantic hindi songs"},{label:"Punjabi",icon:"queue_music",query:"punjabi hits 2025"},{label:"Sad Songs",icon:"sentiment_sad",query:"sad hindi songs broken heart"},{label:"Lo-fi Chill",icon:"headphones",query:"lofi chill hindi"},{label:"Top Playlists",icon:"playlist_play",query:"top hindi playlist trending"}].forEach(C=>{const B=document.createElement("button");B.className="chip suggestion-chip",B.innerHTML=`<span class="material-symbols-rounded" style="font-size:16px;">${C.icon}</span> ${C.label}`,B.addEventListener("click",()=>{t.value=C.query,y(C.query)}),v.appendChild(B)}),g.appendChild(v),i.appendChild(g)}}function w(u){const l=[],p=new Set;return u.recentlyPlayed.slice(0,15).forEach(v=>{const E=u.trackMetadata[v];if(E&&E.artist){const C=E.artist.split(",")[0].trim();p.has(C.toLowerCase())||(p.add(C.toLowerCase()),l.push({label:C,icon:"person",query:C}))}}),[{label:"New Releases",icon:"new_releases",query:"new hindi songs 2025"},{label:"Trending Now",icon:"trending_up",query:"trending songs india"},{label:"Workout Mix",icon:"fitness_center",query:"workout hindi songs"},{label:"Chill Vibes",icon:"spa",query:"chill hindi lofi"}].forEach(v=>{p.has(v.label.toLowerCase())||(p.add(v.label.toLowerCase()),l.push(v))}),l.slice(0,12)}let c=null,h=0,n="",d=1,b=!1,o=!0,x=[];function f(u,l){new IntersectionObserver(async g=>{if(g[0].isIntersecting&&!b&&o){b=!0,d++,u.innerHTML='<div class="loading-spinner" style="width: 24px; height: 24px; border-width: 2px;"></div>',u.style.display="flex",u.style.justifyContent="center";try{const v=await ce(n,d,10);!v||v.length===0?(o=!1,u.innerHTML=""):(v.forEach(E=>x.push(E)),v.forEach(E=>{l.appendChild(ue(E,x,"horizontal"))}),u.innerHTML="")}catch{u.innerHTML=""}b=!1}},{rootMargin:"150px"}).observe(u)}async function y(u){const l=++h;if(!u.trim()){a.style.display="none",r.style.display="none",i.style.display="block";return}i.style.display="none",a.style.display="none",r.style.display="flex",n=u,d=1,b=!1,o=!0,x=[];try{const[p,g]=await Promise.allSettled([d0(u),h0(u)]),v=p.status==="fulfilled"?p.value:{},E=g.status==="fulfilled"?g.value:[];if(l!==h)return;const C=v.songs||[],B=v.playlists||[];if(C.length>0&&C[0]._needsDetail)try{x=await ce(u,1,10)}catch{x=C}else if(C.length===0)try{x=await ce(u,1,10)}catch{x=[]}else x=C;if(l!==h)return;if(r.style.display="none",a.style.display="block",a.innerHTML="",x.length===0&&B.length===0&&E.length===0){a.innerHTML=`
          <div class="empty-state">
            <span class="material-symbols-rounded">search_off</span>
            <p>No results found for "${u}"</p>
            <p class="text-subtitle" style="margin-top: var(--space-sm);">Try a different search</p>
          </div>
        `;return}if(E.length>0){const D=document.createElement("div");D.className="section",D.innerHTML=`
          <div class="section-header">
            <h2 class="text-section-title">Podcasts</h2>
            <span class="text-subtitle">from Apple Podcasts</span>
          </div>
        `;const A=document.createElement("div");A.className="horizontal-scroll",E.slice(0,10).forEach(_=>{const k=document.createElement("div");k.className="playlist-card",k.style.width="160px",k.innerHTML=`
            <div class="playlist-card-art-wrapper" style="border-radius: var(--radius-lg);">
              <img class="playlist-card-art" src="${_.cover}" alt="${_.title}" loading="lazy" />
              <div class="playlist-card-overlay">
                <span class="material-symbols-rounded">podcasts</span>
              </div>
            </div>
            <div class="playlist-card-title">${_.title}</div>
            <div class="playlist-card-info">${_.artist}</div>
          `,k.addEventListener("click",()=>{window.location.hash=`podcast?feed=${encodeURIComponent(_.feedUrl)}&title=${encodeURIComponent(_.title)}&artist=${encodeURIComponent(_.artist)}&cover=${encodeURIComponent(_.cover)}`}),A.appendChild(k)}),D.appendChild(A),a.appendChild(D)}if(B.length>0){const D=document.createElement("div");D.className="section",D.innerHTML=`
          <div class="section-header">
            <h2 class="text-section-title">Playlists</h2>
            <span class="text-subtitle">${B.length} found</span>
          </div>
        `;const A=document.createElement("div");A.className="horizontal-scroll",B.slice(0,10).forEach(_=>{const k=document.createElement("div");k.className="playlist-card",k.innerHTML=`
            <div class="playlist-card-art-wrapper">
              <img class="playlist-card-art" src="${_.coverSmall||_.cover||""}" alt="${_.title}" loading="lazy" />
              <div class="playlist-card-overlay">
                <span class="material-symbols-rounded">playlist_play</span>
              </div>
            </div>
            <div class="playlist-card-title">${_.title}</div>
            <div class="playlist-card-info">${_.songCount?_.songCount+" songs":_.description||""}</div>
          `,k.addEventListener("click",()=>m(_)),A.appendChild(k)}),D.appendChild(A),a.appendChild(D)}if(x.length>0){const D=document.createElement("div");D.innerHTML=`
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:var(--space-lg);margin-top:var(--space-lg);">
            <span class="text-section-title">Songs</span>
            <button class="chip" id="play-all-results">
              <span class="material-symbols-rounded" style="font-size:16px;">play_arrow</span>
              Play All
            </button>
          </div>
        `,D.querySelector("#play-all-results").addEventListener("click",()=>{z.playAll(x,x[0])});const A=document.createElement("div");A.id="search-song-container",x.forEach(k=>{A.appendChild(ue(k,x,"horizontal"))}),D.appendChild(A);const _=document.createElement("div");_.id="infinite-scroll-trigger",_.style.height="40px",_.style.marginTop="var(--space-md)",D.appendChild(_),a.appendChild(D),f(_,A)}}catch{r.style.display="none",a.style.display="block",a.innerHTML=`
        <div class="empty-state">
          <span class="material-symbols-rounded">error</span>
          <p>Search failed. Check your internet connection.</p>
        </div>
      `}}async function m(u){var g;a.innerHTML=`
      <div class="home-loading">
        <div class="loading-spinner"></div>
        <p class="text-subtitle">Loading playlist...</p>
      </div>
    `;const l=await x0(u.id);a.innerHTML="";const p=document.createElement("div");p.className="playlist-header",p.innerHTML=`
      <button class="btn-icon" id="playlist-back"><span class="material-symbols-rounded">arrow_back</span></button>
      <img class="playlist-header-art" src="${u.cover||u.coverSmall||""}" alt="${u.title}" />
      <div class="playlist-header-info">
        <h2 class="text-section-title">${u.title}</h2>
        <span class="text-subtitle">${l.length} songs</span>
      </div>
      ${l.length>0?'<button class="btn-play" id="playlist-play-all" style="margin-left:auto;"><span class="material-symbols-rounded">play_arrow</span></button>':""}
    `,p.querySelector("#playlist-back").addEventListener("click",()=>{y(t.value)}),a.appendChild(p),l.length>0?((g=p.querySelector("#playlist-play-all"))==null||g.addEventListener("click",()=>{z.playAll(l,l[0])}),l.forEach(v=>{a.appendChild(ue(v,l,"horizontal"))})):a.innerHTML+=`
        <div class="empty-state">
          <span class="material-symbols-rounded">music_off</span>
          <p>No songs found in this playlist</p>
        </div>
      `}return t.addEventListener("input",()=>{clearTimeout(c);const u=t.value;if(!u.trim()){a.style.display="none",r.style.display="none",i.style.display="block";return}c=setTimeout(()=>y(u),400)}),s(),setTimeout(()=>t.focus(),100),e}const y0=document.createElement("style");y0.textContent=`
  .search-history-list {
    display: flex;
    flex-direction: column;
    gap: var(--space-xs);
  }

  .suggestion-chips {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-sm);
  }

  .suggestion-chip {
    animation: fadeInUp 0.3s ease both;
  }

  @keyframes fadeInUp {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }

  /* Playlist cards */
  .playlist-card {
    width: 140px;
    cursor: pointer;
    transition: transform var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
    flex-shrink: 0;
  }

  .playlist-card:active {
    transform: scale(0.97);
  }

  .playlist-card-art-wrapper {
    position: relative;
    border-radius: var(--radius-md);
    overflow: hidden;
    aspect-ratio: 1;
    background: var(--bg-tertiary);
  }

  .playlist-card-art {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .playlist-card-overlay {
    position: absolute;
    inset: 0;
    background: rgba(0,0,0,0.35);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity var(--transition-normal);
  }

  .playlist-card:hover .playlist-card-overlay {
    opacity: 1;
  }

  .playlist-card-overlay .material-symbols-rounded {
    font-size: 36px;
    color: white;
  }

  .playlist-card-title {
    margin-top: var(--space-sm);
    font-size: var(--font-sm);
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: var(--text-primary);
  }

  .playlist-card-info {
    font-size: var(--font-xs);
    color: var(--text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  /* Playlist detail header */
  .playlist-header {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    margin-bottom: var(--space-xl);
    padding: var(--space-md) 0;
  }

  .playlist-header-art {
    width: 56px;
    height: 56px;
    border-radius: var(--radius-md);
    object-fit: cover;
  }
`;document.head.appendChild(y0);function Tn(){const e=document.createElement("div");e.className="page",e.innerHTML=`
    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: var(--space-xl);">
      <h1 class="text-greeting">Your Library</h1>
    </div>
    <div id="library-content"></div>
  `;const t=e.querySelector("#library-content");async function a(){const s=M.get();t.innerHTML="";const w=localStorage.getItem("melo-zoom")||"1.0",c=document.createElement("div");c.className="library-settings-card",c.innerHTML=`
      <div class="settings-header">
        <span class="material-symbols-rounded">zoom_in</span>
        <div class="settings-info">
          <div class="settings-title">Display Scaling</div>
          <div class="settings-subtitle">Adjust text and element sizes</div>
        </div>
        <div class="zoom-value">${Math.round(w*100)}%</div>
      </div>
      <div class="settings-body">
        <input type="range" id="zoom-slider" min="0.8" max="1.5" step="0.05" value="${w}" class="zoom-slider">
        <div class="zoom-labels">
          <span>Small</span>
          <span>Default</span>
          <span>Large</span>
        </div>
      </div>
    `;const h=c.querySelector("#zoom-slider"),n=c.querySelector(".zoom-value");h.addEventListener("input",y=>{const m=y.target.value;n.textContent=Math.round(m*100)+"%",localStorage.setItem("melo-zoom",m),document.documentElement.style.setProperty("--zoom",m),document.body.style.zoom=m}),t.appendChild(c);const d=await he.getAllDownloads(),b=document.createElement("div");b.className="library-playlist-item",b.innerHTML=`
      <div class="library-playlist-art downloads-art">
        <span class="material-symbols-rounded">download_done</span>
      </div>
      <div class="library-playlist-info">
        <div class="library-playlist-name">Downloads</div>
        <div class="library-playlist-meta">${d.length} song${d.length!==1?"s":""}${d.length>0?" · "+Wr(d.reduce((y,m)=>y+(m.size||0),0)):""}</div>
      </div>
    `,b.addEventListener("click",()=>{r(d,t)}),t.appendChild(b);const o=s.likedSongs.length,x=document.createElement("div");if(x.className="library-playlist-item",x.innerHTML=`
      <div class="library-playlist-art liked-art">
        <span class="material-symbols-rounded">favorite</span>
      </div>
      <div class="library-playlist-info">
        <div class="library-playlist-name">Liked Songs</div>
        <div class="library-playlist-meta">${o} song${o!==1?"s":""}</div>
      </div>
    `,x.addEventListener("click",()=>{o>0&&i("Liked Songs",s.likedSongs,t)}),t.appendChild(x),s.recentlyPlayed.length>0){const y=document.createElement("div");y.className="library-playlist-item";const m=z.getCachedTrack(s.recentlyPlayed[0]),u=(m==null?void 0:m.coverSmall)||(m==null?void 0:m.cover)||"";y.innerHTML=`
        <div class="library-playlist-art" style="background: var(--bg-tertiary);">
          ${u?`<img src="${u}" style="width:100%;height:100%;object-fit:cover;border-radius:var(--radius-md);" />`:'<span class="material-symbols-rounded" style="color:var(--text-tertiary);">history</span>'}
        </div>
        <div class="library-playlist-info">
          <div class="library-playlist-name">Recently Played</div>
          <div class="library-playlist-meta">${s.recentlyPlayed.length} song${s.recentlyPlayed.length!==1?"s":""}</div>
        </div>
      `,y.addEventListener("click",()=>{i("Recently Played",s.recentlyPlayed,t)}),t.appendChild(y)}s.playlists.forEach(y=>{const m=document.createElement("div");m.className="library-playlist-item";const u=y.trackIds.length>0?z.getCachedTrack(y.trackIds[0]):null;m.innerHTML=`
        <div class="library-playlist-art" style="background: var(--bg-tertiary);">
          ${u?`<img src="${u.coverSmall||u.cover}" style="width:100%;height:100%;object-fit:cover;border-radius:var(--radius-md);" />`:'<span class="material-symbols-rounded" style="color:var(--text-tertiary);">queue_music</span>'}
        </div>
        <div class="library-playlist-info">
          <div class="library-playlist-name">${y.name}</div>
          <div class="library-playlist-meta">${y.trackIds.length} song${y.trackIds.length!==1?"s":""}</div>
        </div>
      `,m.addEventListener("click",()=>{i(y.name,y.trackIds,t)}),t.appendChild(m)});const f=document.createElement("div");f.className="library-playlist-item create-playlist",f.innerHTML=`
      <div class="library-playlist-art create-art">
        <span class="material-symbols-rounded">add</span>
      </div>
      <div class="library-playlist-info">
        <div class="library-playlist-name">Create Playlist</div>
        <div class="library-playlist-meta">Build your collection</div>
      </div>
    `,f.addEventListener("click",()=>{const y=prompt("Enter playlist name:");y!=null&&y.trim()&&(M.createPlaylist(y.trim()),a())}),t.appendChild(f)}function r(s,w){var h;w.innerHTML="";const c=document.createElement("div");if(c.style.cssText="display:flex;align-items:center;gap:var(--space-md);margin-bottom:var(--space-xl);",c.innerHTML=`
      <button class="btn-icon" id="dl-back"><span class="material-symbols-rounded">arrow_back</span></button>
      <h2 class="text-section-title" style="flex:1;">Downloads</h2>
      <span class="text-subtitle">${s.length} song${s.length!==1?"s":""}</span>
      ${s.length>0?`
        <button class="btn-play" id="dl-play-all" style="width:44px;height:44px;">
          <span class="material-symbols-rounded" style="font-size:22px;">play_arrow</span>
        </button>
      `:""}
    `,c.querySelector("#dl-back").addEventListener("click",()=>a()),w.appendChild(c),s.length>0&&((h=c.querySelector("#dl-play-all"))==null||h.addEventListener("click",()=>{z.playAll(s,s[0])})),s.length===0){w.innerHTML+=`
        <div class="empty-state">
          <span class="material-symbols-rounded">download</span>
          <p>No downloads yet</p>
          <p class="text-subtitle" style="margin-top:var(--space-sm);">Download songs to play them offline</p>
        </div>
      `;return}s.forEach(n=>{const d=document.createElement("div");d.className="track-item",d.innerHTML=`
        <img class="track-item-art" src="${n.coverSmall||n.cover}" alt="" loading="lazy" />
        <div class="track-item-info">
          <div class="track-item-title">${n.title}</div>
          <div class="track-item-artist">${n.artist}</div>
        </div>
        <span class="track-item-duration">${Wr(n.size||0)}</span>
        <button class="btn-icon dl-delete-btn" data-id="${n.id}" title="Delete download">
          <span class="material-symbols-rounded" style="font-size:20px;color:var(--text-tertiary);">delete</span>
        </button>
      `,d.addEventListener("click",b=>{if(b.target.closest(".dl-delete-btn")){b.stopPropagation();const o=b.target.closest(".dl-delete-btn").dataset.id;he.deleteDownload(o).then(()=>{te.show("Download removed","info"),he.getAllDownloads().then(x=>r(x,w))});return}z.playAll(s,n)}),w.appendChild(d)})}function i(s,w,c){c.innerHTML="";const h=document.createElement("div");h.style.cssText="display:flex;align-items:center;gap:var(--space-md);margin-bottom:var(--space-xl);",h.innerHTML=`
      <button class="btn-icon" id="lib-back"><span class="material-symbols-rounded">arrow_back</span></button>
      <h2 class="text-section-title" style="flex:1;">${s}</h2>
      <button class="btn-play" id="lib-play-all" style="width:44px;height:44px;">
        <span class="material-symbols-rounded" style="font-size:22px;">play_arrow</span>
      </button>
    `,h.querySelector("#lib-back").addEventListener("click",()=>a()),c.appendChild(h);const n=w.map(d=>z.getCachedTrack(d)).filter(Boolean);if(h.querySelector("#lib-play-all").addEventListener("click",()=>{n.length>0&&z.playAll(n,n[0])}),n.length===0){c.innerHTML+=`
        <div class="empty-state">
          <span class="material-symbols-rounded">library_music</span>
          <p>No songs yet</p>
          <p class="text-subtitle" style="margin-top:var(--space-sm);">Search and play songs to see them here</p>
        </div>
      `;return}n.forEach(d=>{const b=document.createElement("div");b.className="track-item",b.innerHTML=`
        <img class="track-item-art" src="${d.coverSmall||d.cover}" alt="" loading="lazy" />
        <div class="track-item-info">
          <div class="track-item-title">${d.title}</div>
          <div class="track-item-artist">${d.artist}</div>
        </div>
        <span class="track-item-duration">${Hn(d.duration)}</span>
      `,b.addEventListener("click",()=>{z.playAll(n,d)}),c.appendChild(b)})}return a(),M.subscribe(s=>{["likedSongs","playlists","recentlyPlayed","downloads"].includes(s)&&a()}),e}function Hn(e){if(!e||!isFinite(e))return"";const t=Math.floor(e/60),a=Math.floor(e%60);return`${t}:${a.toString().padStart(2,"0")}`}function Wr(e){return e?e<1024?e+" B":e<1024*1024?(e/1024).toFixed(0)+" KB":(e/1024/1024).toFixed(1)+" MB":"0 B"}const b0=document.createElement("style");b0.textContent=`
  .library-settings-card {
    background: var(--surface-glass);
    border: 1px solid var(--surface-border);
    border-radius: var(--radius-lg);
    padding: var(--space-lg);
    margin-bottom: var(--space-xl);
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
  }
  .settings-header {
    display: flex;
    align-items: center;
    gap: var(--space-md);
  }
  .settings-header .material-symbols-rounded {
    font-size: 24px;
    color: var(--accent);
    background: var(--accent-dim);
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--radius-md);
  }
  .settings-info {
    flex: 1;
  }
  .settings-title {
    font-size: var(--font-md);
    font-weight: 600;
  }
  .settings-subtitle {
    font-size: var(--font-xs);
    color: var(--text-secondary);
  }
  .zoom-value {
    font-size: var(--font-sm);
    font-weight: 700;
    color: var(--accent);
    background: var(--accent-dim);
    padding: 4px 10px;
    border-radius: var(--radius-sm);
  }
  .settings-body {
    display: flex;
    flex-direction: column;
    gap: var(--space-xs);
  }
  .zoom-slider {
    width: 100%;
    accent-color: var(--accent);
    cursor: pointer;
  }
  .zoom-labels {
    display: flex;
    justify-content: space-between;
    font-size: 10px;
    color: var(--text-tertiary);
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }
  .library-playlist-item {
    display: flex;
    align-items: center;
    gap: var(--space-lg);
    padding: var(--space-md);
    border-radius: var(--radius-md);
    cursor: pointer;
    transition: background var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
  }
  .library-playlist-item:hover {
    background: var(--surface-glass-hover);
  }
  .library-playlist-item:active {
    background: var(--bg-active);
  }
  .library-playlist-art {
    width: 56px;
    height: 56px;
    border-radius: var(--radius-md);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    overflow: hidden;
  }
  .liked-art {
    background: linear-gradient(135deg, #7c4dff, #e040fb);
  }
  .liked-art .material-symbols-rounded {
    font-size: 28px;
  }
  .downloads-art {
    background: linear-gradient(135deg, #1ed760, #0ea5e9);
  }
  .downloads-art .material-symbols-rounded {
    font-size: 28px;
  }
  .create-art {
    background: var(--bg-tertiary);
    border: 2px dashed var(--text-tertiary);
  }
  .create-art .material-symbols-rounded {
    font-size: 28px;
    color: var(--text-tertiary);
  }
  .library-playlist-info {
    flex: 1;
    min-width: 0;
  }
  .library-playlist-name {
    font-size: var(--font-md);
    font-weight: 500;
    color: var(--text-primary);
  }
  .library-playlist-meta {
    font-size: var(--font-sm);
    color: var(--text-secondary);
  }
  .dl-delete-btn {
    width: 36px;
    height: 36px;
    flex-shrink: 0;
  }
`;document.head.appendChild(b0);async function zn(e,t){try{return await u0(t,e)}catch(a){console.warn("Lyrics fetch failed:",a)}return null}function Rn(){const e=document.createElement("div");e.className="page nowplaying-page";const t=z.currentTrack;if(!t)return e.innerHTML=`
      <div class="empty-state" style="padding-top: 30vh;">
        <span class="material-symbols-rounded">music_off</span>
        <p>No track playing</p>
        <p class="text-subtitle" style="margin-top: var(--space-sm);">Choose a song to get started</p>
      </div>
    `,e;const a=M.get(),r=M.isLiked(t.id);e.innerHTML=`
    <div class="np-bg" id="np-bg"></div>
    <div class="np-header">
      <button class="btn-icon" id="np-back">
        <span class="material-symbols-rounded">keyboard_arrow_down</span>
      </button>
      <div class="np-header-title">
        <span class="text-tiny" style="text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600;">Now Playing</span>
      </div>
      <button class="btn-icon" id="np-queue">
        <span class="material-symbols-rounded">queue_music</span>
      </button>
    </div>

    <div class="np-body">
      <div class="np-art-container ${z.isPlaying?"playing":""}">
        <img class="np-art" id="np-art" src="${t.cover}" alt="${t.title}" />
      </div>

      <div class="np-info">
        <div class="np-title-row">
          <div class="np-title-wrap">
            <h2 class="np-title" id="np-title">${t.title}</h2>
            <p class="np-artist" id="np-artist" style="pointer-events: auto;">${t.artist}</p>
          </div>
          <button class="btn-icon np-like ${r?"liked":""}" id="np-like">
            <span class="material-symbols-rounded">${r?"favorite":"favorite_border"}</span>
          </button>
        </div>

        <div class="np-progress">
          <div class="np-progress-bar" id="np-progress-bar">
            <div class="np-progress-fill" id="np-progress-fill"></div>
            <div class="np-progress-thumb" id="np-progress-thumb"></div>
          </div>
          <div class="np-time">
            <span id="np-time-current">0:00</span>
            <span id="np-time-total">${Re(t.duration)}</span>
          </div>
        </div>

        <div class="np-controls">
          <button class="btn-icon np-ctrl-btn ${a.shuffle?"active":""}" id="np-shuffle">
            <span class="material-symbols-rounded">shuffle</span>
          </button>
          <button class="btn-icon np-ctrl-btn np-ctrl-lg" id="np-prev">
            <span class="material-symbols-rounded">skip_previous</span>
          </button>
          <button class="btn-play np-play-btn" id="np-play">
            <span class="material-symbols-rounded">${z.isPlaying?"pause":"play_arrow"}</span>
          </button>
          <button class="btn-icon np-ctrl-btn np-ctrl-lg" id="np-next">
            <span class="material-symbols-rounded">skip_next</span>
          </button>
          <button class="btn-icon np-ctrl-btn ${M.isDownloadComplete(t.id)?"active":""}" id="np-download">
             <span class="material-symbols-rounded">${M.isDownloadComplete(t.id)?"download_done":"download"}</span>
          </button>
        </div>

        <!-- Caption / Lyrics Section -->
        <div class="np-caption" id="np-caption">
          <div class="np-caption-toggle" id="np-caption-toggle">
            <span class="material-symbols-rounded" style="font-size:18px;">lyrics</span>
            <span>Lyrics</span>
            <span class="material-symbols-rounded np-caption-arrow" id="np-caption-arrow">expand_more</span>
          </div>
          <div class="np-caption-body" id="np-caption-body" style="display:none;">
            <div class="np-caption-loading" id="np-caption-loading">
              <div class="loading-spinner" style="width:20px;height:20px;border-width:2px;"></div>
              <span>Finding lyrics...</span>
            </div>
            <pre class="np-caption-text" id="np-caption-text" style="display:none;"></pre>
          </div>
        </div>
      </div>
    </div>
  `;const i=e.querySelector("#np-bg");i.style.backgroundImage=`url(${t.cover})`,e.querySelector("#np-back").addEventListener("click",()=>{Y.navigate("home")}),e.querySelector("#np-artist").addEventListener("click",()=>{const u=t.artist.split(",")[0].trim();Y.navigate(`artist?name=${encodeURIComponent(u)}`)}),e.querySelector("#np-download").addEventListener("click",async()=>{const u=e.querySelector("#np-download");if(M.isDownloadComplete(t.id)){te.show("Already downloaded!","info");return}te.show(`Downloading ${t.title}...`,"info"),u.querySelector(".material-symbols-rounded").textContent="hourglass_top",await he.downloadTrack(t)?(u.classList.add("active"),u.querySelector(".material-symbols-rounded").textContent="download_done",te.show(`Downloaded: ${t.title}`,"success")):(u.querySelector(".material-symbols-rounded").textContent="download",te.show("Download failed","error"))}),e.querySelector("#np-play").addEventListener("click",()=>z.togglePlay()),e.querySelector("#np-prev").addEventListener("click",()=>z.prev()),e.querySelector("#np-next").addEventListener("click",()=>z.next()),e.querySelector("#np-shuffle").addEventListener("click",()=>{M.toggleShuffle(),e.querySelector("#np-shuffle").classList.toggle("active")}),e.querySelector("#np-like").addEventListener("click",()=>{M.toggleLike(t);const u=M.isLiked(t.id),l=e.querySelector("#np-like");l.classList.toggle("liked",u),l.querySelector(".material-symbols-rounded").textContent=u?"favorite":"favorite_border"});let s=!1;const w=e.querySelector("#np-caption-toggle"),c=e.querySelector("#np-caption-body"),h=e.querySelector("#np-caption-arrow"),n=e.querySelector("#np-caption-text"),d=e.querySelector("#np-caption-loading");w.addEventListener("click",async()=>{const u=c.style.display!=="none";if(c.style.display=u?"none":"block",h.textContent=u?"expand_more":"expand_less",!u&&!s){s=!0;const l=await zn(t.title,t.artist);d.style.display="none",n.style.display="block",l?n.textContent=l.replace(/\r\n/g,`
`).replace(/\n{3,}/g,`

`).trim():(n.textContent="Lyrics not available for this song.",n.style.textAlign="center",n.style.color="var(--text-tertiary)")}});const b=e.querySelector("#np-progress-bar");let o=!1,x=0;function f(u){const l=b.getBoundingClientRect();let p=l.left;u.touches&&u.touches.length>0?p=u.touches[0].clientX:u.clientX!==void 0?p=u.clientX:u.changedTouches&&u.changedTouches.length>0&&(p=u.changedTouches[0].clientX);const g=p-l.left;x=Math.max(0,Math.min(1,g/l.width));const v=z.currentTrack?z.currentTrack.duration:parseInt(z.audio.duration||0);v&&m(x*v,v)}function y(){if(!o)return;o=!1;const u=z.currentTrack?z.currentTrack.duration:parseInt(z.audio.duration||0);if(!u)return;const l=u*x+.1;z.seek(l)}b.addEventListener("mousedown",u=>{o=!0,f(u)}),b.addEventListener("touchstart",u=>{o=!0,f(u)},{passive:!0}),document.addEventListener("mousemove",u=>{o&&f(u)}),document.addEventListener("touchmove",u=>{o&&f(u)},{passive:!0}),document.addEventListener("mouseup",()=>{o&&y()}),document.addEventListener("touchend",()=>{o&&y()}),z.on("statechange",({isPlaying:u})=>{const l=e.querySelector("#np-play .material-symbols-rounded");l&&(l.textContent=u?"pause":"play_arrow");const p=e.querySelector(".np-art-container");p&&p.classList.toggle("playing",u)}),z.on("timeupdate",({currentTime:u,duration:l})=>{o||m(u,l)}),z.on("trackchange",u=>{const l=e.querySelector("#np-art"),p=e.querySelector("#np-title"),g=e.querySelector("#np-artist"),v=e.querySelector("#np-time-total"),E=e.querySelector("#np-bg");l&&(l.src=u.cover),p&&(p.textContent=u.title),g&&(g.textContent=u.artist),v&&(u.duration?v.textContent=Re(u.duration):v.textContent="Live"),E&&(E.style.backgroundImage=`url(${u.cover})`);const C=M.isLiked(u.id),B=e.querySelector("#np-like");B&&(B.classList.toggle("liked",C),B.querySelector(".material-symbols-rounded").textContent=C?"favorite":"favorite_border"),s=!1,c.style.display="none",h.textContent="expand_more",d.style.display="flex",n.style.display="none",n.textContent=""});function m(u,l){const p=e.querySelector("#np-time-current"),g=e.querySelector("#np-time-total");if(p&&(p.textContent=Re(u)),!l||!isFinite(l)||l===0){g&&g.textContent!=="Live"&&(g.textContent="Live");return}if(g){const B=Re(l);g.textContent!==B&&(g.textContent=B)}const v=u/l*100,E=e.querySelector("#np-progress-fill"),C=e.querySelector("#np-progress-thumb");E&&(E.style.width=`${v}%`),C&&(C.style.left=`${v}%`)}return e}function Re(e){if(!e||!isFinite(e))return"0:00";const t=Math.floor(e/60),a=Math.floor(e%60);return`${t}:${a.toString().padStart(2,"0")}`}const E0=document.createElement("style");E0.textContent=`
  .nowplaying-page {
    position: relative;
    display: flex;
    flex-direction: column;
    min-height: 100dvh;
    padding: 0 !important;
    padding-bottom: 0 !important;
    overflow-y: auto;
    overflow-x: hidden;
  }

  .np-bg {
    position: fixed;
    inset: 0;
    background-size: cover;
    background-position: center;
    filter: blur(80px) brightness(0.2) saturate(1.5);
    transform: scale(1.5);
    z-index: 0;
    transition: background-image 0.8s ease;
  }

  .np-header {
    position: sticky;
    top: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: var(--space-md) var(--space-lg);
    z-index: 2;
  }

  .np-body {
    position: relative;
    z-index: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 1;
    padding: 0 var(--space-xl);
    padding-bottom: calc(var(--nav-height) + var(--safe-bottom) + 24px);
  }

  .np-art-container {
    position: relative;
    width: min(260px, 55vw);
    aspect-ratio: 1;
    margin-bottom: var(--space-xl);
    border-radius: var(--radius-xl);
    box-shadow: 0 20px 50px rgba(0,0,0,0.6);
    transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    overflow: hidden;
  }

  .np-art-container.playing {
    transform: scale(1.02);
  }

  .np-art {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: inherit;
  }

  .np-info {
    position: relative;
    z-index: 1;
    width: min(380px, 90vw);
  }

  .np-title-row {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: var(--space-md);
  }

  .np-title-wrap {
    flex: 1;
    min-width: 0;
  }

  .np-title {
    font-size: var(--font-lg);
    font-weight: 700;
    letter-spacing: -0.02em;
    margin: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .np-artist {
    font-size: var(--font-sm);
    color: var(--text-secondary);
    margin-top: 2px;
    margin-bottom: var(--space-lg);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .np-progress-bar {
    height: 4px;
    background: rgba(255,255,255,0.1);
    border-radius: var(--radius-full);
    cursor: pointer;
    position: relative;
  }

  .np-progress-fill {
    height: 100%;
    background: var(--accent);
    box-shadow: 0 0 10px var(--accent-glow);
    border-radius: inherit;
  }

  .np-progress-thumb {
    position: absolute;
    top: 50%;
    width: 14px;
    height: 14px;
    background: var(--accent);
    border-radius: 50%;
    transform: translate(-50%, -50%);
    box-shadow: 0 0 6px var(--accent-glow);
  }

  .np-time {
    display: flex;
    justify-content: space-between;
    font-size: var(--font-xs);
    color: var(--text-tertiary);
    margin-top: var(--space-xs);
  }

  .np-controls {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: var(--space-lg);
  }

  .np-play-btn {
    width: 56px;
    height: 56px;
    background: var(--text-primary);
    color: var(--bg-primary);
  }

  .np-play-btn:hover {
    transform: scale(1.08);
  }

  .np-ctrl-lg .material-symbols-rounded {
    font-size: 36px !important;
  }

  .np-ctrl-btn.active {
    color: var(--accent);
  }

  .np-like.liked {
    color: var(--accent);
  }

  /* Caption / Lyrics */
  .np-caption {
    margin-top: var(--space-xl);
    border-radius: var(--radius-lg);
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(255,255,255,0.08);
    overflow: hidden;
  }

  .np-caption-toggle {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    padding: var(--space-md) var(--space-lg);
    cursor: pointer;
    color: var(--text-secondary);
    font-size: var(--font-sm);
    font-weight: 600;
    -webkit-tap-highlight-color: transparent;
    transition: color var(--transition-fast);
  }

  .np-caption-toggle:hover {
    color: var(--text-primary);
  }

  .np-caption-arrow {
    margin-left: auto;
    transition: transform 0.3s ease;
  }

  .np-caption-body {
    padding: 0 var(--space-lg) var(--space-lg);
    max-height: 200px;
    overflow-y: auto;
  }

  .np-caption-loading {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    color: var(--text-tertiary);
    font-size: var(--font-sm);
  }

  .np-caption-text {
    font-family: inherit;
    font-size: var(--font-sm);
    color: var(--text-secondary);
    line-height: 1.8;
    white-space: pre-wrap;
    word-wrap: break-word;
    margin: 0;
  }

  /* Scrollbar for lyrics */
  .np-caption-body::-webkit-scrollbar { width: 3px; }
  .np-caption-body::-webkit-scrollbar-thumb { background: var(--accent-dim); border-radius: 3px; }

  /* Tablet landscape split view */
  @media (min-width: 1024px) {
    .np-body {
      flex-direction: row;
      align-items: center;
      justify-content: center;
      gap: var(--space-3xl);
      padding-top: var(--space-xl);
    }
    .np-art-container {
      width: min(320px, 35vw);
      margin-bottom: 0;
    }
    .np-info {
      width: min(400px, 40vw);
    }
  }
`;document.head.appendChild(E0);function Nn(){const e=document.createElement("div");e.className="page onboarding-page";const t=new Set;e.innerHTML=`
    <div class="onboarding-content">
      <div class="onboarding-logo">
        <span class="material-symbols-rounded" style="font-size: 48px; color: var(--accent);">music_note</span>
      </div>
      <h1 class="text-greeting" style="text-align: center;">Welcome to Melo</h1>
      <p class="text-subtitle" style="text-align: center; margin-top: var(--space-sm); margin-bottom: var(--space-2xl);">
        What kind of music do you like?<br/>Pick at least 3 to personalize your experience
      </p>
      <div class="onboarding-genres" id="onboarding-genres"></div>
      <button class="onboarding-continue" id="onboarding-continue" disabled>
        Let's Go
      </button>
    </div>
  `;const a=e.querySelector("#onboarding-genres"),r=e.querySelector("#onboarding-continue");return Tt.forEach(i=>{const s=document.createElement("button");s.className="onboarding-genre-chip",s.innerHTML=`
      <span class="material-symbols-rounded">${i.icon}</span>
      <span>${i.name}</span>
    `,s.style.setProperty("--genre-gradient",i.gradient),s.addEventListener("click",()=>{t.has(i.id)?(t.delete(i.id),s.classList.remove("selected")):(t.add(i.id),s.classList.add("selected")),r.disabled=t.size<3}),a.appendChild(s)}),r.addEventListener("click",()=>{M.setInterests([...t]),Y.navigate("home")}),e}const w0=document.createElement("style");w0.textContent=`
  .onboarding-page {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100dvh;
    padding-bottom: var(--space-2xl) !important;
  }

  .onboarding-content {
    max-width: 500px;
    width: 100%;
  }

  .onboarding-logo {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 80px;
    height: 80px;
    margin: 0 auto var(--space-xl);
    border-radius: var(--radius-xl);
    background: var(--accent-dim);
    animation: logoPulse 2s ease-in-out infinite;
  }

  @keyframes logoPulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
  }

  .onboarding-genres {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-md);
    justify-content: center;
    margin-bottom: var(--space-2xl);
  }

  .onboarding-genre-chip {
    display: inline-flex;
    align-items: center;
    gap: var(--space-sm);
    padding: var(--space-md) var(--space-xl);
    border-radius: var(--radius-full);
    border: 2px solid var(--surface-border);
    background: var(--bg-tertiary);
    color: var(--text-primary);
    font-family: var(--font-family);
    font-size: var(--font-base);
    font-weight: 500;
    cursor: pointer;
    transition: all var(--transition-normal);
    -webkit-tap-highlight-color: transparent;
  }

  .onboarding-genre-chip:active {
    transform: scale(0.95);
  }

  .onboarding-genre-chip.selected {
    background: var(--genre-gradient, var(--accent));
    border-color: transparent;
    box-shadow: var(--shadow-md);
    transform: scale(1.05);
  }

  .onboarding-genre-chip .material-symbols-rounded {
    font-size: 20px;
  }

  .onboarding-continue {
    display: block;
    width: 100%;
    padding: var(--space-lg);
    border: none;
    border-radius: var(--radius-full);
    background: var(--accent);
    color: var(--text-on-accent);
    font-family: var(--font-family);
    font-size: var(--font-md);
    font-weight: 600;
    cursor: pointer;
    transition: all var(--transition-normal);
    letter-spacing: 0.02em;
  }

  .onboarding-continue:disabled {
    opacity: 0.3;
    cursor: not-allowed;
  }

  .onboarding-continue:not(:disabled):hover {
    box-shadow: var(--shadow-glow);
    transform: translateY(-1px);
  }

  .onboarding-continue:not(:disabled):active {
    transform: scale(0.98);
  }
`;document.head.appendChild(w0);function Mn(){const e=document.createElement("div");e.className="page artist-page";const t=Y.getParams().get("name");return t?(e.innerHTML=`
    <div class="home-loading" id="artist-loading">
      <div class="loading-spinner"></div>
      <p class="text-subtitle">Loading ${t}...</p>
    </div>
    <div id="artist-content" style="display:none; padding-bottom: 120px;"></div>
  `,In(t,e),e):(e.innerHTML='<div class="empty-state"><p>Artist not found.</p></div>',e)}async function In(e,t){var a;try{const r=t.querySelector("#artist-loading"),i=t.querySelector("#artist-content"),[s,w]=await Promise.allSettled([f0(e),ce(`${e} best songs`)]),c=s.status==="fulfilled"?s.value:null,h=w.status==="fulfilled"?w.value||[]:[];r.style.display="none",i.style.display="block";const n=c?c.name:e,d=(c==null?void 0:c.banner)||(c==null?void 0:c.thumbnail)||((a=h[0])==null?void 0:a.cover)||"",b=c!=null&&c.genre?`<span class="chip" style="pointer-events:none;">${c.genre}</span>`:"",o=c!=null&&c.biography?c.biography:`Explore the top hits and popular songs by ${n}.`,x=document.createElement("div");x.className="artist-header",x.innerHTML=`
      <img class="artist-header-bg" src="${d}" alt="Banner" onerror="this.src=''" />
      <div class="artist-header-overlay"></div>
      <button class="btn-icon artist-back-btn"><span class="material-symbols-rounded">arrow_back</span></button>
      
      <div class="artist-header-content">
        <h1 class="artist-title">${n}</h1>
        <div class="artist-meta">
          ${b}
          <span class="text-subtitle" style="color:#fff;">${h.length} top songs</span>
        </div>
      </div>
      ${h.length>0?'<button class="btn-play artist-play-all"><span class="material-symbols-rounded">play_arrow</span></button>':""}
    `,x.querySelector(".artist-back-btn").addEventListener("click",()=>{window.history.back()}),h.length>0&&x.querySelector(".artist-play-all").addEventListener("click",()=>{z.playAll(h,h[0])}),i.appendChild(x);const f=document.createElement("div");f.className="section",f.innerHTML=`
      <div class="section-header">
        <h2 class="text-section-title">About</h2>
      </div>
      <div class="artist-bio-box">
        <p class="artist-bio-text">${o.replace(/\n\n/g,"<br><br>")}</p>
        <button class="artist-bio-more">Read More</button>
      </div>
    `;const y=f.querySelector(".artist-bio-text"),m=f.querySelector(".artist-bio-more");if(m.addEventListener("click",()=>{y.classList.contains("expanded")?(y.classList.remove("expanded"),m.textContent="Read More"):(y.classList.add("expanded"),m.textContent="Show Less")}),o.length<200&&(m.style.display="none",y.classList.add("expanded")),i.appendChild(f),h.length>0){const l=document.createElement("div");l.className="section",l.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Popular Tracks</h2>
        </div>
      `;const p=document.createElement("div");p.style.display="flex",p.style.flexDirection="column",p.style.gap="var(--space-xs)",h.forEach((g,v)=>{const E=ue(g,h,"horizontal");p.appendChild(E)}),l.appendChild(p),i.appendChild(l)}const u=document.createElement("div");u.className="section",u.innerHTML=`
          <div class="section-header">
            <h2 class="text-section-title">Full Discography</h2>
            <div class="loading-spinner" id="disco-loading" style="width:20px;height:20px;border-width:2px;"></div>
          </div>
          <div id="disco-content" class="horizontal-scroll" style="display:none;"></div>
        `,i.appendChild(u),ve(()=>Promise.resolve().then(()=>m0),void 0).then(async({getArtistDiscography:l})=>{const p=await l(e),g=u.querySelector("#disco-loading"),v=u.querySelector("#disco-content");g.style.display="none",p&&p.length>0?(v.style.display="flex",p.forEach(E=>{const C=document.createElement("div");C.className="album-card",C.innerHTML=`
                      <img class="album-card-art" src="${E.cover}" alt="${E.title}" loading="lazy" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\\'http://www.w3.org/2000/svg\\' viewBox=\\'0 0 100 100\\'%3E%3Crect width=\\'100\\' height=\\'100\\' fill=\\'%232a2a2a\\'/%3E%3Ctext x=\\'50\\' y=\\'55\\' font-family=\\'sans-serif\\' font-size=\\'14\\' fill=\\'%23666\\' text-anchor=\\'middle\\'%3EAlbum%3C/text%3E%3C/svg%3E'" />
                      <div class="album-card-title">${E.title}</div>
                      <div class="album-card-info">${E.year} • ${E.type}</div>
                    `,v.appendChild(C)})):u.style.display="none"})}catch{t.innerHTML='<div class="empty-state"><p>Error loading artist.</p></div>'}}const C0=document.createElement("style");C0.textContent=`
  .artist-page {
    /* Override standard page padding so banner touches the top */
    padding-top: 0 !important;
  }

  .artist-header {
    position: relative;
    width: 100%;
    height: 35vh;
    min-height: 280px;
    margin-bottom: var(--space-2xl);
    border-radius: 0 0 var(--radius-2xl) var(--radius-2xl);
    overflow: hidden;
    box-shadow: var(--shadow-md);
  }

  .artist-header-bg {
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    object-fit: cover;
  }

  .artist-header-overlay {
    position: absolute;
    inset: 0;
    /* Dark gradient overlay so text is legible and fades beautifully into the app */
    background: linear-gradient(to bottom, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.8) 100%);
  }

  .artist-back-btn {
    position: absolute;
    top: max(var(--space-md), env(safe-area-inset-top));
    left: var(--space-md);
    z-index: 10;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(8px);
    color: white;
  }

  .artist-header-content {
    position: absolute;
    bottom: var(--space-xl);
    left: var(--space-xl);
    right: var(--space-xl);
    z-index: 2;
  }

  .artist-title {
    font-size: clamp(28px, 6vw, 42px);
    font-weight: 800;
    color: #ffffff;
    margin: 0 0 var(--space-sm) 0;
    line-height: 1.1;
    text-shadow: 0 2px 8px rgba(0,0,0,0.5);
  }

  .artist-meta {
    display: flex;
    align-items: center;
    gap: var(--space-md);
  }

  .artist-play-all {
    position: absolute;
    bottom: calc(var(--space-xl) - 28px);
    right: var(--space-xl);
    z-index: 10;
    transform: scale(1.1);
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  }

  .artist-bio-box {
    background: var(--surface-glass);
    border: 1px solid var(--surface-border);
    border-radius: var(--radius-xl);
    padding: var(--space-lg);
  }

  .artist-bio-text {
    font-size: var(--font-sm);
    color: var(--text-secondary);
    line-height: 1.6;
    margin: 0;
    
    /* Clamp lines by default */
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
    transition: all 0.3s ease;
  }

  .artist-bio-text.expanded {
    display: block;
    -webkit-line-clamp: unset;
  }

  .artist-bio-more {
    background: none;
    border: none;
    color: var(--accent);
    font-weight: 600;
    font-size: var(--font-sm);
    padding: var(--space-md) 0 0 0;
    cursor: pointer;
  }

  .album-card {
    width: 140px;
    flex-shrink: 0;
  }

  .album-card-art {
    width: 100%;
    aspect-ratio: 1;
    object-fit: cover;
    border-radius: var(--radius-md);
    background: var(--bg-tertiary);
    margin-bottom: var(--space-sm);
    box-shadow: var(--shadow-sm);
  }

  .album-card-title {
    font-size: var(--font-sm);
    font-weight: 500;
    color: var(--text-primary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .album-card-info {
    font-size: var(--font-xs);
    color: var(--text-tertiary);
    margin-top: 2px;
  }
`;document.head.appendChild(C0);function On(){const e=document.createElement("div");e.className="page podcast-page";const t=Y.getParams(),a=t.get("feed"),r=t.get("title")||"Podcast",i=t.get("artist")||"",s=t.get("cover")||"";return a?(e.innerHTML=`
    <div class="header-nav" style="display:flex; align-items:center; gap:var(--space-md); padding:var(--space-md) 0; margin-bottom:var(--space-lg);">
      <button class="btn-icon" id="podcast-back"><span class="material-symbols-rounded">arrow_back</span></button>
      <h2 class="text-greeting" style="margin:0; font-size:var(--font-lg);">Podcast</h2>
    </div>

    <!-- Header Section -->
    <div style="display:flex; flex-direction:column; align-items:center; text-align:center; margin-bottom:var(--space-2xl);">
      <img src="${s}" alt="${r}" style="width:200px; height:200px; border-radius:var(--radius-xl); object-fit:cover; margin-bottom:var(--space-lg); box-shadow:var(--shadow-lg);" />
      <h1 class="text-section-title" style="margin-bottom:var(--space-xs); font-size:24px;">${r}</h1>
      <p class="text-subtitle" style="font-size:var(--font-md);">${i}</p>
    </div>

    <div class="home-loading" id="podcast-loading">
      <div class="loading-spinner"></div>
      <p class="text-subtitle" style="margin-top:var(--space-sm);">Loading latest episodes...</p>
    </div>
    
    <div id="podcast-content" style="display:none; padding-bottom: 120px;"></div>
  `,e.querySelector("#podcast-back").addEventListener("click",()=>{window.history.back()}),jn(a,s,i,e),e):(e.innerHTML='<div class="empty-state"><p>Podcast not found.</p></div>',e)}async function jn(e,t,a,r){try{const i=r.querySelector("#podcast-loading"),s=r.querySelector("#podcast-content"),w=await v0(e,t,a);if(i.style.display="none",s.style.display="block",w.length===0){s.innerHTML=`
        <div class="empty-state">
          <span class="material-symbols-rounded">podcasts</span>
          <p>No episodes found or feed is unsupported.</p>
        </div>
      `;return}const c=document.createElement("div");c.innerHTML=`
      <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:var(--space-lg);">
        <h2 class="text-section-title">Latest Episodes</h2>
        <button class="chip" id="podcast-play-all">
          <span class="material-symbols-rounded" style="font-size:16px;">play_arrow</span> Play Latest
        </button>
      </div>
    `,c.querySelector("#podcast-play-all").addEventListener("click",()=>{z.playAll(w,w[0])}),s.appendChild(c);const h=document.createElement("div");h.style.display="flex",h.style.flexDirection="column",h.style.gap="var(--space-md)",w.forEach(n=>{const d=document.createElement("div");d.className="podcast-ep-card",d.innerHTML=`
        <div class="podcast-ep-meta">
          <span class="text-subtitle" style="font-size:12px;">${Un(n.date)}</span>
        </div>
        <div class="podcast-ep-main">
          <div class="podcast-ep-info">
            <h3 class="podcast-ep-title">${n.title}</h3>
            <p class="podcast-ep-desc">${n.description}</p>
          </div>
          <button class="btn-play podcast-ep-play"><span class="material-symbols-rounded">play_arrow</span></button>
        </div>
      `,d.querySelector(".podcast-ep-play").addEventListener("click",()=>{z.playAll(w,n)}),h.appendChild(d)}),s.appendChild(h)}catch{r.querySelector("#podcast-loading").innerHTML=`
      <div class="empty-state">
        <span class="material-symbols-rounded">error</span>
        <p>Could not load episodes.</p>
      </div>
    `}}function Un(e){if(!e)return"Recent";try{const t=new Date(e);return isNaN(t.getTime())?e:t.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}catch{return e}}const B0=document.createElement("style");B0.textContent=`
  .podcast-ep-card {
    background: var(--surface-glass);
    border: 1px solid var(--surface-border);
    border-radius: var(--radius-lg);
    padding: var(--space-md);
  }

  .podcast-ep-meta {
    margin-bottom: var(--space-xs);
  }

  .podcast-ep-main {
    display: flex;
    align-items: center;
    gap: var(--space-md);
  }

  .podcast-ep-info {
    flex: 1;
    min-width: 0;
  }

  .podcast-ep-title {
    font-size: var(--font-md);
    font-weight: 600;
    color: var(--text-primary);
    margin: 0 0 var(--space-xs) 0;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  .podcast-ep-desc {
    font-size: 13px;
    color: var(--text-secondary);
    margin: 0;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  .podcast-ep-play {
    width: 44px;
    height: 44px;
    flex-shrink: 0;
  }
`;document.head.appendChild(B0);const Wn="__capgo_keep_url_path_after_reload",St="__capgo_history_stack__",Kr=100,Kn=typeof window<"u"&&typeof document<"u"&&typeof history<"u";if(Kn){const e=window;if(!e.__capgoHistoryPatched){e.__capgoHistoryPatched=!0;const t=()=>{try{if(e.__capgoKeepUrlPathAfterReload)return!0}catch{}try{return window.localStorage.getItem(Wn)==="1"}catch{return!1}},a=()=>{try{const v=window.sessionStorage.getItem(St);if(!v)return{stack:[],index:-1};const E=JSON.parse(v);return!E||!Array.isArray(E.stack)||typeof E.index!="number"?{stack:[],index:-1}:E}catch{return{stack:[],index:-1}}},r=(v,E)=>{try{window.sessionStorage.setItem(St,JSON.stringify({stack:v,index:E}))}catch{}},i=()=>{try{window.sessionStorage.removeItem(St)}catch{}},s=v=>{try{const E=v??window.location.href,C=new URL(E instanceof URL?E.toString():E,window.location.href);return`${C.pathname}${C.search}${C.hash}`}catch{return null}},w=(v,E)=>{if(v.length<=Kr)return{stack:v,index:E};const C=v.length-Kr,B=v.slice(C),D=Math.max(0,E-C);return{stack:B,index:D}},c=v=>{document.readyState==="complete"||document.readyState==="interactive"?v():window.addEventListener("DOMContentLoaded",v,{once:!0})};let h=!1,n=!1,d=!1;const b=()=>{if(!h)return;const v=a(),E=s();if(E){if(v.stack.length===0){v.stack.push(E),v.index=0,r(v.stack,v.index);return}(v.index<0||v.index>=v.stack.length)&&(v.index=v.stack.length-1),v.stack[v.index]!==E&&(v.stack[v.index]=E,r(v.stack,v.index))}},o=(v,E)=>{if(!h||n)return;const C=s(v);if(!C)return;let{stack:B,index:D}=a();B.length===0?(B.push(C),D=B.length-1):E?((D<0||D>=B.length)&&(D=B.length-1),B[D]=C):D>=B.length-1?(B.push(C),D=B.length-1):(B=B.slice(0,D+1),B.push(C),D=B.length-1),{stack:B,index:D}=w(B,D),r(B,D)},x=()=>{if(!h||n)return;const v=a();if(v.stack.length===0){b();return}const E=v.index>=0&&v.index<v.stack.length?v.index:v.stack.length-1,C=s();if(v.stack.length===1&&C===v.stack[0])return;const B=v.stack[0];if(!B)return;n=!0;try{history.replaceState(history.state,document.title,B);for(let _=1;_<v.stack.length;_+=1)history.pushState(history.state,document.title,v.stack[_])}catch{n=!1;return}n=!1;const D=v.stack.length-1,A=E-D;A!==0?history.go(A):(history.replaceState(history.state,document.title,v.stack[E]),window.dispatchEvent(new PopStateEvent("popstate")))},f=()=>{!h||d||(d=!0,c(()=>{d=!1,x()}))};let y=null,m=null;const u=()=>{if(!h||n)return;const v=s();if(!v)return;const E=a(),C=E.stack.lastIndexOf(v);C>=0?E.index=C:(E.stack.push(v),E.index=E.stack.length-1);const B=w(E.stack,E.index);r(B.stack,B.index)},l=()=>{y&&m||(y=history.pushState,m=history.replaceState,history.pushState=function(E,C,B){const D=y==null?void 0:y.call(history,E,C,B);return o(B,!1),D},history.replaceState=function(E,C,B){const D=m==null?void 0:m.call(history,E,C,B);return o(B,!0),D},window.addEventListener("popstate",u))},p=()=>{y&&(history.pushState=y,y=null),m&&(history.replaceState=m,m=null),window.removeEventListener("popstate",u)},g=v=>{if(h===v){h&&(b(),f());return}h=v,h?(l(),b(),f()):(p(),i())};window.addEventListener("CapacitorUpdaterKeepUrlPathAfterReload",v=>{var E;const C=v,B=(E=C==null?void 0:C.detail)===null||E===void 0?void 0:E.enabled;typeof B=="boolean"?(e.__capgoKeepUrlPathAfterReload=B,g(B)):(e.__capgoKeepUrlPathAfterReload=!0,g(!0))}),g(t())}}var Gr;(function(e){e[e.UNKNOWN=0]="UNKNOWN",e[e.UPDATE_NOT_AVAILABLE=1]="UPDATE_NOT_AVAILABLE",e[e.UPDATE_AVAILABLE=2]="UPDATE_AVAILABLE",e[e.UPDATE_IN_PROGRESS=3]="UPDATE_IN_PROGRESS"})(Gr||(Gr={}));var Vr;(function(e){e[e.UNKNOWN=0]="UNKNOWN",e[e.PENDING=1]="PENDING",e[e.DOWNLOADING=2]="DOWNLOADING",e[e.INSTALLING=3]="INSTALLING",e[e.INSTALLED=4]="INSTALLED",e[e.FAILED=5]="FAILED",e[e.CANCELED=6]="CANCELED",e[e.DOWNLOADED=11]="DOWNLOADED"})(Vr||(Vr={}));var Xr;(function(e){e[e.OK=0]="OK",e[e.CANCELED=1]="CANCELED",e[e.FAILED=2]="FAILED",e[e.NOT_AVAILABLE=3]="NOT_AVAILABLE",e[e.NOT_ALLOWED=4]="NOT_ALLOWED",e[e.INFO_MISSING=5]="INFO_MISSING"})(Xr||(Xr={}));const Lt=le("CapacitorUpdater",{web:()=>ve(()=>import("./web-BScpio0H.js"),[]).then(e=>new e.CapacitorUpdaterWeb)});var Ht;(function(e){e.Dark="DARK",e.Light="LIGHT",e.Default="DEFAULT"})(Ht||(Ht={}));var Yr;(function(e){e.None="NONE",e.Slide="SLIDE",e.Fade="FADE"})(Yr||(Yr={}));const Qr=le("StatusBar");le("SplashScreen",{web:()=>ve(()=>import("./web-C40brJa3.js"),[]).then(e=>new e.SplashScreenWeb)});const Zr=le("App",{web:()=>ve(()=>import("./web-BdbBe7s-.js"),[]).then(e=>new e.AppWeb)});var Jr;(function(e){e[e.Sunday=1]="Sunday",e[e.Monday=2]="Monday",e[e.Tuesday=3]="Tuesday",e[e.Wednesday=4]="Wednesday",e[e.Thursday=5]="Thursday",e[e.Friday=6]="Friday",e[e.Saturday=7]="Saturday"})(Jr||(Jr={}));const Pt=le("LocalNotifications",{web:()=>ve(()=>import("./web-BkGXpVLK.js"),[]).then(e=>new e.LocalNotificationsWeb)});async function Gn(){try{await Qr.setOverlaysWebView({overlay:!0}),await Qr.setStyle({style:Ht.Dark}),(await Pt.checkPermissions()).display!=="granted"&&await Pt.requestPermissions(),await Pt.createChannel({id:"media_playback",name:"Music Controls",description:"Music playback controls",importance:5,visibility:1,sound:null,vibration:!1}),await Lt.notifyAppReady();const t="1.0.7",a="https://api.github.com/repos/maheshwarkibehan-hub/MElo-music-player/contents/version.json";window.setTimeout(async()=>{try{console.log("[OTA] Checking for updates...");let r;try{const w=await fetch(a+"?t="+Date.now(),{headers:{Accept:"application/vnd.github.v3.raw"},cache:"no-store"});if(!w.ok)throw new Error("Version check failed: "+w.status);r=await w.json()}catch(w){console.log("[OTA] Version check unavailable:",w.message);return}if(!r||!r.version||!r.url){console.log("[OTA] Invalid version data");return}if(r.version===t){console.log("[OTA] Already up to date:",t);return}console.log("[OTA] New version available:",r.version);const i=await Lt.download({url:r.url,version:r.version});console.log("[OTA] Bundle downloaded:",i);const s=document.createElement("div");s.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,0.8);backdrop-filter:blur(10px);display:flex;align-items:center;justify-content:center;z-index:999999;opacity:0;transition:opacity 0.3s ease;padding:20px;",s.innerHTML=`
                    <div style="background:var(--surface,#1a1a2e);padding:30px;border-radius:20px;text-align:center;max-width:320px;width:100%;box-shadow:0 20px 40px rgba(0,0,0,0.5);transform:translateY(20px);transition:transform 0.3s cubic-bezier(0.16,1,0.3,1);">
                        <div style="background:var(--accent,#6c63ff);width:60px;height:60px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;">
                            <span class="material-symbols-rounded" style="color:black;font-size:30px;">system_update</span>
                        </div>
                        <h2 style="margin:0 0 10px;font-size:22px;color:var(--text-primary,#fff);font-weight:700;">Update Ready</h2>
                        <p style="margin:0 0 6px;color:var(--text-secondary,#aaa);font-size:13px;">v${t} → v${r.version}</p>
                        <p style="margin:0 0 25px;color:var(--text-secondary,#aaa);line-height:1.5;font-size:15px;">A new version of Melo is ready!</p>
                        <div style="display:flex;gap:12px;">
                            <button id="ota-skip" style="flex:1;padding:14px;border-radius:12px;border:none;background:rgba(255,255,255,0.05);color:var(--text-primary,#fff);font-weight:600;font-size:15px;cursor:pointer;">Later</button>
                            <button id="ota-update" style="flex:1;padding:14px;border-radius:12px;border:none;background:var(--accent,#6c63ff);color:black;font-weight:600;font-size:15px;cursor:pointer;">Update Now</button>
                        </div>
                    </div>
                `,document.body.appendChild(s),requestAnimationFrame(()=>{s.style.opacity="1",s.firstElementChild.style.transform="translateY(0)"}),document.getElementById("ota-skip").onclick=()=>{s.style.opacity="0",setTimeout(()=>s.remove(),300)},document.getElementById("ota-update").onclick=async()=>{const w=document.getElementById("ota-update");w.textContent="Installing...";try{await Lt.set(i)}catch(c){console.warn("[OTA] Set failed:",c),s.remove()}}}catch(r){console.log("[OTA] Update check error:",r)}},3e3)}catch(e){console.warn("Native APIs not available:",e)}}const Vn=async()=>{try{await n0.impact({style:Ct.Light})}catch{}},Xn=()=>{const e=localStorage.getItem("melo-zoom")||"1.0";document.documentElement.style.setProperty("--zoom",e),document.body.style.zoom=e};Xn();Gn();Zr.addListener("backButton",({canGoBack:e})=>{window.location.hash&&window.location.hash!=="#/home"?window.history.back():Zr.exitApp()});function Yn(){const e=document.getElementById("app");if(!M.get().onboarded){e.innerHTML="",e.appendChild(Nn());const a=M.subscribe(r=>{r==="interests"&&(a(),e0())});return}e0()}function e0(){const e=document.getElementById("app");e.innerHTML="";const t=document.createElement("main");t.id="page-content",e.appendChild(t),e.appendChild(na()),e.appendChild(I0()),Y.register("home",$n),Y.register("search",qn),Y.register("library",Tn),Y.register("nowplaying",Rn),Y.register("artist",Mn),Y.register("podcast",On),Y.init(t),(!window.location.hash||window.location.hash==="#")&&Y.navigate("home"),window.addEventListener("routechange",()=>{Vn()})}window.onerror=(e,t,a,r,i)=>{const s=document.createElement("div");s.style.cssText="position:fixed;top:0;left:0;right:0;padding:20px;background:#e53935;color:#fff;z-index:99999;font-size:14px;white-space:pre-wrap;font-family:monospace;",s.textContent=`ERROR: ${e}
File: ${t}
Line: ${a}:${r}
${(i==null?void 0:i.stack)||""}`,document.body.appendChild(s)};window.addEventListener("unhandledrejection",e=>{var a,r;const t=document.createElement("div");t.style.cssText="position:fixed;top:0;left:0;right:0;padding:20px;background:#e53935;color:#fff;z-index:99999;font-size:14px;white-space:pre-wrap;font-family:monospace;",t.textContent=`PROMISE ERROR: ${((a=e.reason)==null?void 0:a.message)||e.reason}
${((r=e.reason)==null?void 0:r.stack)||""}`,document.body.appendChild(t)});"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").then(e=>console.log("SW registered:",e.scope)).catch(e=>console.warn("SW registration failed:",e))});try{Yn()}catch(e){document.body.innerHTML=`<div style="padding:20px;color:#e53935;font-family:monospace;"><h2>App Crash</h2><pre>${e.message}
${e.stack}</pre></div>`}export{Gr as A,Ct as I,ir as N,zt as W};
