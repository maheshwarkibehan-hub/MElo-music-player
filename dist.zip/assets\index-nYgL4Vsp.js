(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))r(n);new MutationObserver(n=>{for(const i of n)if(i.type==="childList")for(const b of i.addedNodes)b.tagName==="LINK"&&b.rel==="modulepreload"&&r(b)}).observe(document,{childList:!0,subtree:!0});function a(n){const i={};return n.integrity&&(i.integrity=n.integrity),n.referrerPolicy&&(i.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?i.credentials="include":n.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function r(n){if(n.ep)return;n.ep=!0;const i=a(n);fetch(n.href,i)}})();const Qt=new Map;let qe=null;const Y={register(e,t){Qt.set(e,t)},init(e){qe=e,window.addEventListener("hashchange",()=>this._navigate()),this._navigate()},navigate(e){window.location.hash=e},getCurrentRoute(){return(window.location.hash.slice(1)||"home").split("?")[0]},getParams(){const t=(window.location.hash.slice(1)||"").split("?")[1];return new URLSearchParams(t||"")},_navigate(){const e=this.getCurrentRoute(),t=Qt.get(e);if(t&&qe){qe.innerHTML="";const a=t();typeof a=="string"?qe.innerHTML=a:a instanceof HTMLElement&&qe.appendChild(a),window.dispatchEvent(new CustomEvent("routechange",{detail:{route:e}}))}}},Y0="melo_state",Q0={interests:[],onboarded:!1,recentlyPlayed:[],likedSongs:[],playlists:[],trackMetadata:{},currentTrackId:null,queue:[],queueIndex:0,shuffle:!1,repeat:"off",volume:1,downloads:{}};let P={...Q0};function Hr(){try{const e=localStorage.getItem(Y0);e&&(P={...Q0,...JSON.parse(e)})}catch(e){console.warn("Failed to load state:",e)}}function zr(){try{localStorage.setItem(Y0,JSON.stringify(P))}catch(e){console.warn("Failed to save state:",e)}}const Lt=new Set;function Tr(e){return Lt.add(e),()=>Lt.delete(e)}function V(e){Lt.forEach(t=>t(e,P)),zr()}const I={get:()=>P,subscribe:Tr,setInterests(e){P.interests=e,P.onboarded=!0,V("interests")},addRecentlyPlayed(e){!e||!e.id||(P.trackMetadata[e.id]=e,P.recentlyPlayed=[e.id,...P.recentlyPlayed.filter(t=>t!==e.id)].slice(0,20),V("recentlyPlayed"))},toggleLike(e){if(!e||!e.id)return;P.trackMetadata[e.id]=e;const t=e.id,a=P.likedSongs.indexOf(t);a===-1?P.likedSongs.push(t):P.likedSongs.splice(a,1),V("likedSongs")},isLiked(e){return P.likedSongs.includes(e)},setQueue(e,t=0){P.queue=[...e],P.queueIndex=t,P.currentTrackId=e[t]||null,V("queue")},nextInQueue(){if(P.repeat==="one")return V("queue"),P.currentTrackId;if(P.shuffle){const e=P.queue.filter(t=>t!==P.currentTrackId);if(e.length>0){const t=e[Math.floor(Math.random()*e.length)];P.queueIndex=P.queue.indexOf(t),P.currentTrackId=t}}else{if(P.queueIndex++,P.queueIndex>=P.queue.length)if(P.repeat==="all")P.queueIndex=0;else return P.queueIndex=P.queue.length-1,V("queue"),null;P.currentTrackId=P.queue[P.queueIndex]}return V("queue"),P.currentTrackId},prevInQueue(){if(P.shuffle){const e=P.queue.filter(t=>t!==P.currentTrackId);if(e.length>0){const t=e[Math.floor(Math.random()*e.length)];P.queueIndex=P.queue.indexOf(t),P.currentTrackId=t}}else P.queueIndex--,P.queueIndex<0&&(P.queueIndex=P.repeat==="all"?P.queue.length-1:0),P.currentTrackId=P.queue[P.queueIndex];return V("queue"),P.currentTrackId},toggleShuffle(){P.shuffle=!P.shuffle,V("shuffle")},cycleRepeat(){const e=["off","all","one"],t=e.indexOf(P.repeat);P.repeat=e[(t+1)%e.length],V("repeat")},setVolume(e){P.volume=Math.max(0,Math.min(1,e)),V("volume")},createPlaylist(e){const t=Date.now().toString();return P.playlists.push({id:t,name:e,trackIds:[]}),V("playlists"),t},addToPlaylist(e,t){if(!t||!t.id)return;P.trackMetadata[t.id]=t;const a=P.playlists.find(r=>r.id===e);a&&!a.trackIds.includes(t.id)&&(a.trackIds.push(t.id),V("playlists"))},removeFromPlaylist(e,t){const a=P.playlists.find(r=>r.id===e);a&&(a.trackIds=a.trackIds.filter(r=>r!==t),V("playlists"))},deletePlaylist(e){P.playlists=P.playlists.filter(t=>t.id!==e),V("playlists")},updateDownload(e,t){P.downloads[e]={...P.downloads[e],...t},t.track&&(P.trackMetadata[e]=t.track),V("downloads")},removeDownload(e){delete P.downloads[e],V("downloads")},isDownloadComplete(e){var t;return((t=P.downloads[e])==null?void 0:t.status)==="complete"},getDownloads(){return Object.entries(P.downloads).filter(([,e])=>e.status==="complete").map(([e,t])=>({id:e,...t}))}};Hr();function Rr(){const e=document.createElement("nav");e.className="navbar",e.innerHTML=`
    <button class="nav-item active" data-route="home" id="nav-home">
      <span class="material-symbols-rounded">home</span>
      <span class="nav-label">Home</span>
    </button>
    <button class="nav-item" data-route="search" id="nav-search">
      <span class="material-symbols-rounded">search</span>
      <span class="nav-label">Search</span>
    </button>
    <button class="nav-item" data-route="library" id="nav-library">
      <span class="material-symbols-rounded">library_music</span>
      <span class="nav-label">Library</span>
    </button>
    <button class="nav-item" data-route="settings" id="nav-settings">
      <span class="material-symbols-rounded">settings</span>
      <span class="nav-label">Settings</span>
    </button>
  `;const t=e.querySelectorAll(".nav-item");return t.forEach(a=>{a.addEventListener("click",()=>{Y.navigate(a.dataset.route)})}),window.addEventListener("routechange",a=>{t.forEach(r=>{r.classList.toggle("active",r.dataset.route===a.detail.route)})}),e}const Z0=document.createElement("style");Z0.textContent=`
  .navbar {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 100;
    display: flex;
    align-items: center;
    justify-content: space-around;
    height: var(--nav-height);
    background: linear-gradient(to top, var(--bg-primary) 60%, transparent);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    padding-bottom: var(--safe-bottom);
    border-top: 1px solid var(--surface-border);
  }

  .nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2px;
    padding: var(--space-sm) var(--space-xl);
    border: none;
    background: transparent;
    color: var(--text-tertiary);
    cursor: pointer;
    transition: color var(--transition-fast), transform var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
    font-family: var(--font-family);
    border-radius: var(--radius-lg);
  }

  .nav-item:active {
    transform: scale(0.9);
  }

  .nav-item .material-symbols-rounded {
    font-size: 26px;
    transition: font-variation-settings var(--transition-fast);
  }

  .nav-item.active {
    color: var(--text-primary);
  }

  .nav-item.active .material-symbols-rounded {
    font-variation-settings: 'FILL' 1, 'wght' 600, 'GRAD' 0, 'opsz' 24;
  }

  .nav-label {
    font-size: 10px;
    font-weight: 500;
    letter-spacing: 0.02em;
  }
`;document.head.appendChild(Z0);const Mr="modulepreload",Ir=function(e){return"/"+e},Zt={},Be=function(t,a,r){let n=Promise.resolve();if(a&&a.length>0){let b=function(s){return Promise.all(s.map(d=>Promise.resolve(d).then(y=>({status:"fulfilled",value:y}),y=>({status:"rejected",reason:y}))))};document.getElementsByTagName("link");const l=document.querySelector("meta[property=csp-nonce]"),v=(l==null?void 0:l.nonce)||(l==null?void 0:l.getAttribute("nonce"));n=b(a.map(s=>{if(s=Ir(s),s in Zt)return;Zt[s]=!0;const d=s.endsWith(".css"),y=d?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${s}"]${y}`))return;const o=document.createElement("link");if(o.rel=d?"stylesheet":Mr,d||(o.as="script"),o.crossOrigin="",o.href=s,v&&o.setAttribute("nonce",v),document.head.appendChild(o),d)return new Promise((x,f)=>{o.addEventListener("load",x),o.addEventListener("error",()=>f(new Error(`Unable to preload CSS for ${s}`)))})}))}function i(b){const l=new Event("vite:preloadError",{cancelable:!0});if(l.payload=b,window.dispatchEvent(l),!l.defaultPrevented)throw b}return n.then(b=>{for(const l of b||[])l.status==="rejected"&&i(l.reason);return t().catch(i)})};/*! Capacitor: https://capacitorjs.com/ - MIT License */var Ee;(function(e){e.Unimplemented="UNIMPLEMENTED",e.Unavailable="UNAVAILABLE"})(Ee||(Ee={}));class _t extends Error{constructor(t,a,r){super(t),this.message=t,this.code=a,this.data=r}}const Nr=e=>{var t,a;return e!=null&&e.androidBridge?"android":!((a=(t=e==null?void 0:e.webkit)===null||t===void 0?void 0:t.messageHandlers)===null||a===void 0)&&a.bridge?"ios":"web"},jr=e=>{const t=e.CapacitorCustomPlatform||null,a=e.Capacitor||{},r=a.Plugins=a.Plugins||{},n=()=>t!==null?t.name:Nr(e),i=()=>n()!=="web",b=y=>{const o=s.get(y);return!!(o!=null&&o.platforms.has(n())||l(y))},l=y=>{var o;return(o=a.PluginHeaders)===null||o===void 0?void 0:o.find(x=>x.name===y)},v=y=>e.console.error(y),s=new Map,d=(y,o={})=>{const x=s.get(y);if(x)return console.warn(`Capacitor plugin "${y}" already registered. Cannot register plugins twice.`),x.proxy;const f=n(),g=l(y);let m;const u=async()=>(!m&&f in o?m=typeof o[f]=="function"?m=await o[f]():m=o[f]:t!==null&&!m&&"web"in o&&(m=typeof o.web=="function"?m=await o.web():m=o.web),m),c=(D,_)=>{var B,A;if(g){const k=g==null?void 0:g.methods.find(F=>_===F.name);if(k)return k.rtype==="promise"?F=>a.nativePromise(y,_.toString(),F):(F,H)=>a.nativeCallback(y,_.toString(),F,H);if(D)return(B=D[_])===null||B===void 0?void 0:B.bind(D)}else{if(D)return(A=D[_])===null||A===void 0?void 0:A.bind(D);throw new _t(`"${y}" plugin is not implemented on ${f}`,Ee.Unimplemented)}},p=D=>{let _;const B=(...A)=>{const k=u().then(F=>{const H=c(F,D);if(H){const z=H(...A);return _=z==null?void 0:z.remove,z}else throw new _t(`"${y}.${D}()" is not implemented on ${f}`,Ee.Unimplemented)});return D==="addListener"&&(k.remove=async()=>_()),k};return B.toString=()=>`${D.toString()}() { [capacitor code] }`,Object.defineProperty(B,"name",{value:D,writable:!1,configurable:!1}),B},h=p("addListener"),C=p("removeListener"),w=(D,_)=>{const B=h({eventName:D},_),A=async()=>{const F=await B;C({eventName:D,callbackId:F},_)},k=new Promise(F=>B.then(()=>F({remove:A})));return k.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await A()},k},E=new Proxy({},{get(D,_){switch(_){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return g?w:h;case"removeListener":return C;default:return p(_)}}});return r[y]=E,s.set(y,{name:y,proxy:E,platforms:new Set([...Object.keys(o),...g?[f]:[]])}),E};return a.convertFileSrc||(a.convertFileSrc=y=>y),a.getPlatform=n,a.handleError=v,a.isNativePlatform=i,a.isPluginAvailable=b,a.registerPlugin=d,a.Exception=_t,a.DEBUG=!!a.DEBUG,a.isLoggingEnabled=!!a.isLoggingEnabled,a},Or=e=>e.Capacitor=jr(e),wt=Or(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),de=wt.registerPlugin;class Ht{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(t,a){let r=!1;this.listeners[t]||(this.listeners[t]=[],r=!0),this.listeners[t].push(a);const i=this.windowListeners[t];i&&!i.registered&&this.addWindowListener(i),r&&this.sendRetainedArgumentsForEvent(t);const b=async()=>this.removeListener(t,a);return Promise.resolve({remove:b})}async removeAllListeners(){this.listeners={};for(const t in this.windowListeners)this.removeWindowListener(this.windowListeners[t]);this.windowListeners={}}notifyListeners(t,a,r){const n=this.listeners[t];if(!n){if(r){let i=this.retainedEventArguments[t];i||(i=[]),i.push(a),this.retainedEventArguments[t]=i}return}n.forEach(i=>i(a))}hasListeners(t){var a;return!!(!((a=this.listeners[t])===null||a===void 0)&&a.length)}registerWindowListener(t,a){this.windowListeners[a]={registered:!1,windowEventName:t,pluginEventName:a,handler:r=>{this.notifyListeners(a,r)}}}unimplemented(t="not implemented"){return new wt.Exception(t,Ee.Unimplemented)}unavailable(t="not available"){return new wt.Exception(t,Ee.Unavailable)}async removeListener(t,a){const r=this.listeners[t];if(!r)return;const n=r.indexOf(a);this.listeners[t].splice(n,1),this.listeners[t].length||this.removeWindowListener(this.windowListeners[t])}addWindowListener(t){window.addEventListener(t.windowEventName,t.handler),t.registered=!0}removeWindowListener(t){t&&(window.removeEventListener(t.windowEventName,t.handler),t.registered=!1)}sendRetainedArgumentsForEvent(t){const a=this.retainedEventArguments[t];a&&(delete this.retainedEventArguments[t],a.forEach(r=>{this.notifyListeners(t,r)}))}}const Jt=e=>encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),e0=e=>e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class Ur extends Ht{async getCookies(){const t=document.cookie,a={};return t.split(";").forEach(r=>{if(r.length<=0)return;let[n,i]=r.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");n=e0(n).trim(),i=e0(i).trim(),a[n]=i}),a}async setCookie(t){try{const a=Jt(t.key),r=Jt(t.value),n=t.expires?`; expires=${t.expires.replace("expires=","")}`:"",i=(t.path||"/").replace("path=",""),b=t.url!=null&&t.url.length>0?`domain=${t.url}`:"";document.cookie=`${a}=${r||""}${n}; path=${i}; ${b};`}catch(a){return Promise.reject(a)}}async deleteCookie(t){try{document.cookie=`${t.key}=; Max-Age=0`}catch(a){return Promise.reject(a)}}async clearCookies(){try{const t=document.cookie.split(";")||[];for(const a of t)document.cookie=a.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(t){return Promise.reject(t)}}async clearAllCookies(){try{await this.clearCookies()}catch(t){return Promise.reject(t)}}}de("CapacitorCookies",{web:()=>new Ur});const Wr=async e=>new Promise((t,a)=>{const r=new FileReader;r.onload=()=>{const n=r.result;t(n.indexOf(",")>=0?n.split(",")[1]:n)},r.onerror=n=>a(n),r.readAsDataURL(e)}),Kr=(e={})=>{const t=Object.keys(e);return Object.keys(e).map(n=>n.toLocaleLowerCase()).reduce((n,i,b)=>(n[i]=e[t[b]],n),{})},Gr=(e,t=!0)=>e?Object.entries(e).reduce((r,n)=>{const[i,b]=n;let l,v;return Array.isArray(b)?(v="",b.forEach(s=>{l=t?encodeURIComponent(s):s,v+=`${i}=${l}&`}),v.slice(0,-1)):(l=t?encodeURIComponent(b):b,v=`${i}=${l}`),`${r}&${v}`},"").substr(1):null,Xr=(e,t={})=>{const a=Object.assign({method:e.method||"GET",headers:e.headers},t),n=Kr(e.headers)["content-type"]||"";if(typeof e.data=="string")a.body=e.data;else if(n.includes("application/x-www-form-urlencoded")){const i=new URLSearchParams;for(const[b,l]of Object.entries(e.data||{}))i.set(b,l);a.body=i.toString()}else if(n.includes("multipart/form-data")||e.data instanceof FormData){const i=new FormData;if(e.data instanceof FormData)e.data.forEach((l,v)=>{i.append(v,l)});else for(const l of Object.keys(e.data))i.append(l,e.data[l]);a.body=i;const b=new Headers(a.headers);b.delete("content-type"),a.headers=b}else(n.includes("application/json")||typeof e.data=="object")&&(a.body=JSON.stringify(e.data));return a};class Vr extends Ht{async request(t){const a=Xr(t,t.webFetchExtra),r=Gr(t.params,t.shouldEncodeUrlParams),n=r?`${t.url}?${r}`:t.url,i=await fetch(n,a),b=i.headers.get("content-type")||"";let{responseType:l="text"}=i.ok?t:{};b.includes("application/json")&&(l="json");let v,s;switch(l){case"arraybuffer":case"blob":s=await i.blob(),v=await Wr(s);break;case"json":v=await i.json();break;case"document":case"text":default:v=await i.text()}const d={};return i.headers.forEach((y,o)=>{d[o]=y}),{data:v,headers:d,status:i.status,url:i.url}}async get(t){return this.request(Object.assign(Object.assign({},t),{method:"GET"}))}async post(t){return this.request(Object.assign(Object.assign({},t),{method:"POST"}))}async put(t){return this.request(Object.assign(Object.assign({},t),{method:"PUT"}))}async patch(t){return this.request(Object.assign(Object.assign({},t),{method:"PATCH"}))}async delete(t){return this.request(Object.assign(Object.assign({},t),{method:"DELETE"}))}}const Yr=de("CapacitorHttp",{web:()=>new Vr});var t0;(function(e){e.Dark="DARK",e.Light="LIGHT",e.Default="DEFAULT"})(t0||(t0={}));var r0;(function(e){e.StatusBar="StatusBar",e.NavigationBar="NavigationBar"})(r0||(r0={}));class Qr extends Ht{async setStyle(){this.unavailable("not available for web")}async setAnimation(){this.unavailable("not available for web")}async show(){this.unavailable("not available for web")}async hide(){this.unavailable("not available for web")}}de("SystemBars",{web:()=>new Qr});var Et;(function(e){e.Heavy="HEAVY",e.Medium="MEDIUM",e.Light="LIGHT"})(Et||(Et={}));var a0;(function(e){e.Success="SUCCESS",e.Warning="WARNING",e.Error="ERROR"})(a0||(a0={}));const J0=de("Haptics",{web:()=>Be(()=>import("./web-CZq7xoQW.js"),[]).then(e=>new e.HapticsWeb)}),Zr="melo_downloads",Jr=1,Z="tracks";let ze=null;const qt=new Set;function Ce(){return new Promise((e,t)=>{if(ze)return e(ze);const a=indexedDB.open(Zr,Jr);a.onupgradeneeded=r=>{const n=r.target.result;n.objectStoreNames.contains(Z)||n.createObjectStore(Z,{keyPath:"id"})},a.onsuccess=r=>{ze=r.target.result,e(ze)},a.onerror=r=>t(r.target.error)})}function Te(e,t){qt.forEach(a=>a(e,t))}async function n0(e){const t=await fetch(e);if(!t.ok)throw new Error(`Download failed: ${t.status}`);return await t.blob()}const ve={on(e){return qt.add(e),()=>qt.delete(e)},async downloadTrack(e){if(!e||!e.url||!e.id)return!1;try{if(await this.isDownloaded(e.id))return console.log("Already downloaded:",e.title),!0;Te("start",{trackId:e.id,title:e.title}),I.updateDownload(e.id,{status:"downloading",track:e});const t=await n0(e.url);let a=null;try{const l=e.coverSmall||e.cover;l&&(a=await n0(l))}catch(l){console.warn("Cover download failed:",l)}const i=(await Ce()).transaction(Z,"readwrite").objectStore(Z),b={id:e.id,title:e.title,artist:e.artist,album:e.album||"",duration:e.duration||0,cover:e.cover||"",coverSmall:e.coverSmall||"",originalUrl:e.url,audioBlob:t,coverBlob:a,downloadedAt:Date.now(),size:t.size};return await new Promise((l,v)=>{const s=i.put(b);s.onsuccess=()=>l(),s.onerror=d=>v(d.target.error)}),I.updateDownload(e.id,{status:"complete",track:e}),Te("complete",{trackId:e.id,title:e.title}),console.log(`Downloaded: ${e.title} (${(t.size/1024/1024).toFixed(1)}MB)`),!0}catch(t){return console.error("Download failed:",t),I.updateDownload(e.id,{status:"error",track:e}),Te("error",{trackId:e.id,error:t.message}),!1}},async isDownloaded(e){try{const r=(await Ce()).transaction(Z,"readonly").objectStore(Z);return new Promise(n=>{const i=r.get(e);i.onsuccess=()=>n(!!i.result),i.onerror=()=>n(!1)})}catch{return!1}},async getPlaybackUrl(e){try{const r=(await Ce()).transaction(Z,"readonly").objectStore(Z);return new Promise((n,i)=>{const b=r.get(e);b.onsuccess=()=>{b.result&&b.result.audioBlob?n(URL.createObjectURL(b.result.audioBlob)):n(null)},b.onerror=()=>n(null)})}catch{return null}},async getCoverUrl(e){try{const r=(await Ce()).transaction(Z,"readonly").objectStore(Z);return new Promise(n=>{const i=r.get(e);i.onsuccess=()=>{i.result&&i.result.coverBlob?n(URL.createObjectURL(i.result.coverBlob)):n(null)},i.onerror=()=>n(null)})}catch{return null}},async getAllDownloads(){try{const a=(await Ce()).transaction(Z,"readonly").objectStore(Z);return new Promise(r=>{const n=a.getAll();n.onsuccess=()=>{const i=(n.result||[]).map(b=>({id:b.id,title:b.title,artist:b.artist,album:b.album,duration:b.duration,cover:b.cover,coverSmall:b.coverSmall,url:b.originalUrl,downloadedAt:b.downloadedAt,size:b.size}));i.sort((b,l)=>l.downloadedAt-b.downloadedAt),r(i)},n.onerror=()=>r([])})}catch{return[]}},async deleteDownload(e){try{const r=(await Ce()).transaction(Z,"readwrite").objectStore(Z);return await new Promise((n,i)=>{const b=r.delete(e);b.onsuccess=()=>n(),b.onerror=l=>i(l.target.error)}),I.removeDownload(e),Te("deleted",{trackId:e}),!0}catch(t){return console.error("Delete failed:",t),!1}},async getTotalSize(){return(await this.getAllDownloads()).reduce((t,a)=>t+(a.size||0),0)}},ce=de("MediaPlugin"),kt=async()=>{try{await J0.impact({style:Et.Light})}catch{}};class ea{constructor(){this.audio=new Audio,this.audio.preload="none",this.isPlaying=!1,this.currentTrack=null,this._listeners=new Map,this._trackCache=new Map,this._useNative=!1,this._detectNative(),this.audio.addEventListener("ended",()=>this._onEnded()),this.audio.addEventListener("timeupdate",()=>{this._emit("timeupdate",{currentTime:this.audio.currentTime,duration:this.audio.duration||0})}),this.audio.addEventListener("loadedmetadata",()=>this._emit("loaded",{duration:this.audio.duration})),this.audio.addEventListener("play",()=>{this.isPlaying=!0,this._emit("statechange",{isPlaying:!0})}),this.audio.addEventListener("pause",()=>{this.isPlaying=!1,this._emit("statechange",{isPlaying:!1})}),this.audio.addEventListener("error",t=>{console.warn("Audio error:",t),this._emit("error",t),setTimeout(()=>this.next(),1e3)}),this._setupMediaSession()}async _detectNative(){try{window.Capacitor&&window.Capacitor.isNativePlatform()&&(this._useNative=!0,console.log("[Melo] Native Media3 bridge active"),ce.addListener("mediaNext",()=>{console.log("[Melo] Notification: next"),this.next()}),ce.addListener("mediaPrev",()=>{console.log("[Melo] Notification: prev"),this.prev()}),ce.addListener("mediaEnded",()=>{console.log("[Melo] Native playback ended. Triggering auto-play/queue..."),this._onEnded()}),ce.addListener("timeupdate",t=>{this._emit("timeupdate",{currentTime:t.position,duration:t.duration||(this.currentTrack?this.currentTrack.duration:0)})}))}catch{console.log("[Melo] Web fallback mode")}}on(t,a){return this._listeners.has(t)||this._listeners.set(t,new Set),this._listeners.get(t).add(a),()=>{var r;return(r=this._listeners.get(t))==null?void 0:r.delete(a)}}_emit(t,a){var r;(r=this._listeners.get(t))==null||r.forEach(n=>n(a))}cacheTrack(t){t&&t.id&&this._trackCache.set(t.id,t)}cacheTracks(t){t.forEach(a=>this.cacheTrack(a))}getCachedTrack(t){return this._trackCache.get(t)||I.get().trackMetadata[t]||null}async playTrack(t){if(!t||!t.url)return;this.currentTrack=t,this.cacheTrack(t);const r=await ve.getPlaybackUrl(t.id)||t.url;if(this._useNative)try{const n=(t.cover||"").replace(/^http:\/\//i,"https://");await ce.play({url:r,title:t.title||"Melo Music",artist:t.artist||"Melo",cover:n}),this.isPlaying=!0,this._emit("statechange",{isPlaying:!0})}catch(n){console.warn("[Melo] Native play failed, falling back to web:",n),this._playWeb(r)}else this._playWeb(r);I.addRecentlyPlayed(t),this._emit("trackchange",t)}_playWeb(t){this.audio.src=t,this.audio.play().catch(a=>console.warn("Play failed:",a)),this._updateMediaSession()}playTrackById(t){const a=this.getCachedTrack(t);a&&this.playTrack(a)}playAll(t,a){this.cacheTracks(t);const r=t.map(i=>i.id),n=a?r.indexOf(a.id):0;I.setQueue(r,Math.max(0,n)),this.playTrack(t[Math.max(0,n)])}async play(){if(this._useNative)try{await ce.resume(),this.isPlaying=!0,this._emit("statechange",{isPlaying:!0})}catch{this.audio.src&&this.audio.play().catch(()=>{})}else this.audio.src&&this.audio.play().catch(t=>console.warn("Play failed:",t))}async pause(){if(this._useNative)try{await ce.pause()}catch{}this.audio.pause(),this.isPlaying=!1,this._emit("statechange",{isPlaying:!1})}togglePlay(){kt(),this.isPlaying?this.pause():this.play()}next(){kt();const t=I.nextInQueue();if(t){const a=this.getCachedTrack(t);a&&this.playTrack(a)}else this.pause(),this.audio.currentTime=0}prev(){if(kt(),this.audio.currentTime>3){this.audio.currentTime=0,this._useNative&&ce.seek({position:0}).catch(()=>{});return}const t=I.prevInQueue();if(t){const a=this.getCachedTrack(t);a&&this.playTrack(a)}}seek(t){isFinite(t)&&(this.audio.currentTime=t,this._useNative&&ce.seek({position:parseInt(Math.round(t*1e3))}).catch(()=>{}))}seekPercent(t){this.currentTrack&&isFinite(this.currentTrack.duration)&&this.currentTrack.duration>0?this.seek(this.currentTrack.duration*t):this.audio.duration&&isFinite(this.audio.duration)&&this.seek(this.audio.duration*t)}setVolume(t){this.audio.volume=Math.max(0,Math.min(1,t)),I.setVolume(t)}_detectMood(t){if(!t)return"hindi songs";const a=`${t.title||""} ${t.artist||""} ${t.album||""}`.toLowerCase(),r=[{keywords:["sad","dard","dil","tanha","alvida","bewafa","rona","aansu","judai","broken","heartbreak","emotional"],query:"sad emotional hindi songs"},{keywords:["romantic","love","pyar","ishq","mohabbat","prem","valentine","couple"],query:"romantic love hindi songs"},{keywords:["party","dance","club","dj","remix","bass","beat","drop","edm"],query:"party dance hindi songs"},{keywords:["lofi","lo-fi","chill","relax","sleep","calm","acoustic","unplugged","slowed"],query:"lofi chill hindi songs"},{keywords:["motivat","inspire","workout","gym","energy","power","pump"],query:"motivational workout hindi songs"},{keywords:["sufi","qawwali","devotion","bhajan","spiritual"],query:"sufi devotional songs"},{keywords:["rap","hip hop","hiphop","rapper","bars"],query:"hindi rap hip hop songs"},{keywords:["old","classic","90s","80s","70s","retro","purana"],query:"old classic bollywood hits"},{keywords:["punjabi","bhangra","jatt"],query:"punjabi latest songs"}];for(const n of r)if(n.keywords.some(i=>a.includes(i)))return n.query;return t.artist?`${t.artist.split(",")[0].trim()} best songs`:"trending hindi songs 2025"}async _onEnded(){const t=I.nextInQueue();if(t){const a=this.getCachedTrack(t);if(a){this.playTrack(a);return}}if(this.currentTrack){if(this.currentTrack.type==="podcast_episode"){console.log("[Melo] Podcast ended, auto-play disabled for podcasts."),this.pause(),this.audio.currentTime=0;return}try{const{searchSongs:a}=await Be(async()=>{const{searchSongs:i}=await Promise.resolve().then(()=>pr);return{searchSongs:i}},void 0),r=this._detectMood(this.currentTrack);console.log("[Melo] Auto-play mood query:",r);const n=await a(r);if(n.length>0){const i=new Set(I.get().queue),b=n.filter(s=>!i.has(s.id)),l=b.length>0?b:n;this.cacheTracks(l);const v=l.map(s=>s.id);I.setQueue(v,0),this.playTrack(l[0]);return}}catch(a){console.warn("Auto-play fetch failed:",a)}}this.pause(),this.audio.currentTime=0}_setupMediaSession(){"mediaSession"in navigator&&(navigator.mediaSession.setActionHandler("play",()=>this.play()),navigator.mediaSession.setActionHandler("pause",()=>this.pause()),navigator.mediaSession.setActionHandler("previoustrack",()=>this.prev()),navigator.mediaSession.setActionHandler("nexttrack",()=>this.next()),navigator.mediaSession.setActionHandler("seekto",t=>{t.seekTime!=null&&this.seek(t.seekTime)}),navigator.mediaSession.setActionHandler("stop",()=>{this.pause(),this.audio.currentTime=0}))}_updateMediaSession(){if(!this.currentTrack||!("mediaSession"in navigator))return;const t=(this.currentTrack.cover||"").replace(/^http:\/\//i,"https://");try{navigator.mediaSession.metadata=new MediaMetadata({title:this.currentTrack.title||"Melo Music",artist:this.currentTrack.artist||"Melo",album:this.currentTrack.album||"Melo Music",artwork:[{src:t,sizes:"512x512",type:"image/jpeg"}]})}catch{}}}const T=new ea;function ta(){const e=document.createElement("div");e.className="miniplayer glass",e.innerHTML=`
    <div class="mini-progress-bg">
      <div class="mini-progress-fill" id="mini-progress"></div>
    </div>
    <div class="mini-content">
      <div class="mini-info" id="mini-open">
        <img class="mini-art" id="mini-art" src="" alt="" />
        <div class="mini-text">
          <div class="mini-title" id="mini-title">Not Playing</div>
          <div class="mini-artist" id="mini-artist">Select a song</div>
        </div>
      </div>
      <div class="mini-controls">
        <button class="btn-icon" id="mini-prev">
          <span class="material-symbols-rounded">skip_previous</span>
        </button>
        <button class="btn-play" id="mini-play" style="width: 40px; height: 40px;">
          <span class="material-symbols-rounded" style="font-size: 24px;">play_arrow</span>
        </button>
        <button class="btn-icon" id="mini-next">
          <span class="material-symbols-rounded">skip_next</span>
        </button>
      </div>
    </div>
  `;const t=n=>{e.querySelector("#mini-art").src=n.coverSmall||n.cover,e.querySelector("#mini-title").textContent=n.title,e.querySelector("#mini-artist").textContent=n.artist,e.classList.add("active");const i=Y.getCurrentRoute();["nowplaying","onboarding"].includes(i)||(e.style.display="block")},a=n=>{const i=e.querySelector("#mini-play .material-symbols-rounded");i.textContent=n?"pause":"play_arrow"},r=(n,i)=>{const b=n/i*100;e.querySelector("#mini-progress").style.width=`${b}%`};return e.querySelector("#mini-open").addEventListener("click",()=>{Y.navigate("nowplaying")}),e.querySelector("#mini-play").addEventListener("click",n=>{n.stopPropagation(),T.togglePlay()}),e.querySelector("#mini-prev").addEventListener("click",n=>{n.stopPropagation(),T.prev()}),e.querySelector("#mini-next").addEventListener("click",n=>{n.stopPropagation(),T.next()}),T.on("trackchange",t),T.on("statechange",({isPlaying:n})=>a(n)),T.on("timeupdate",({currentTime:n,duration:i})=>r(n,i)),window.addEventListener("routechange",n=>{const i=["nowplaying","onboarding"].includes(n.detail.route);e.style.display=i?"none":T.currentTrack?"block":"none"}),T.currentTrack?(t(T.currentTrack),a(T.isPlaying),e.style.display="block"):e.style.display="none",e}const er=document.createElement("style");er.textContent=`
  .miniplayer {
    position: fixed;
    bottom: calc(var(--nav-height) + var(--safe-bottom) + var(--space-md));
    left: var(--space-md);
    right: var(--space-md);
    height: var(--miniplayer-height);
    border-radius: var(--radius-lg);
    z-index: 101;
    overflow: hidden;
    box-shadow: var(--shadow-lg);
    transition: transform var(--transition-normal), opacity var(--transition-normal);
  }

  .miniplayer:not(.active) {
    display: none;
  }

  .mini-progress-bg {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 2px;
    background: rgba(255,255,255,0.05);
  }

  .mini-progress-fill {
    height: 100%;
    background: var(--accent);
    width: 0;
  }

  .mini-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 100%;
    padding: 0 var(--space-md);
  }

  .mini-info {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    flex: 1;
    min-width: 0;
    cursor: pointer;
  }

  .mini-art {
    width: 40px;
    height: 40px;
    border-radius: var(--radius-sm);
    object-fit: cover;
    box-shadow: var(--shadow-sm);
  }

  .mini-text {
    flex: 1;
    min-width: 0;
  }

  .mini-title {
    font-size: var(--font-sm);
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .mini-artist {
    font-size: var(--font-xs);
    color: var(--text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .mini-controls {
    display: flex;
    align-items: center;
    gap: var(--space-xs);
  }

  .miniplayer .btn-icon {
    width: 36px;
    height: 36px;
  }
`;document.head.appendChild(er);const $t=[{id:"pop",name:"Pop",gradient:"linear-gradient(135deg, #e040fb, #7c4dff)",icon:"star"},{id:"hiphop",name:"Hip Hop",gradient:"linear-gradient(135deg, #ff6d00, #ff3d00)",icon:"mic"},{id:"rock",name:"Rock",gradient:"linear-gradient(135deg, #d50000, #ff1744)",icon:"electric_bolt"},{id:"lofi",name:"Lo-Fi",gradient:"linear-gradient(135deg, #00695c, #26a69a)",icon:"headphones"},{id:"electronic",name:"Electronic",gradient:"linear-gradient(135deg, #2979ff, #00b0ff)",icon:"equalizer"},{id:"rnb",name:"R&B",gradient:"linear-gradient(135deg, #6a1b9a, #ab47bc)",icon:"music_note"},{id:"jazz",name:"Jazz",gradient:"linear-gradient(135deg, #f57f17, #fdd835)",icon:"piano"},{id:"classical",name:"Classical",gradient:"linear-gradient(135deg, #1565c0, #42a5f5)",icon:"library_music"},{id:"indie",name:"Indie",gradient:"linear-gradient(135deg, #00897b, #4db6ac)",icon:"forest"},{id:"kpop",name:"K-Pop",gradient:"linear-gradient(135deg, #f06292, #ec407a)",icon:"favorite"},{id:"bollywood",name:"Bollywood",gradient:"linear-gradient(135deg, #ff8f00, #ffca28)",icon:"movie"},{id:"ambient",name:"Ambient",gradient:"linear-gradient(135deg, #37474f, #78909c)",icon:"spa"}],ra=[{id:"arijit-singh",name:"Arijit Singh",query:"Arijit Singh songs",gradient:"linear-gradient(135deg, #1a1a2e, #16213e)",image:"https://c.saavncdn.com/artists/Arijit_Singh_002_20230801131019_150x150.jpg"},{id:"udit-narayan",name:"Udit Narayan",query:"Udit Narayan best songs",gradient:"linear-gradient(135deg, #2d1b69, #11998e)",image:"https://c.saavncdn.com/artists/Udit_Narayan_150x150.jpg"},{id:"shreya-ghoshal",name:"Shreya Ghoshal",query:"Shreya Ghoshal hits",gradient:"linear-gradient(135deg, #7b2ff7, #c471f5)",image:"https://c.saavncdn.com/artists/Shreya_Ghoshal_006_20200711073954_150x150.jpg"},{id:"atif-aslam",name:"Atif Aslam",query:"Atif Aslam songs",gradient:"linear-gradient(135deg, #134e5e, #71b280)",image:"https://c.saavncdn.com/artists/Atif_Aslam_150x150.jpg"},{id:"neha-kakkar",name:"Neha Kakkar",query:"Neha Kakkar latest",gradient:"linear-gradient(135deg, #e91e63, #ff6f00)",image:"https://c.saavncdn.com/artists/Neha_Kakkar_006_20200822042626_150x150.jpg"},{id:"kishore-kumar",name:"Kishore Kumar",query:"Kishore Kumar classics",gradient:"linear-gradient(135deg, #3a1c71, #d76d77)",image:"https://c.saavncdn.com/artists/Kishore_Kumar_150x150.jpg"},{id:"lata-mangeshkar",name:"Lata Mangeshkar",query:"Lata Mangeshkar best",gradient:"linear-gradient(135deg, #c04848, #480048)",image:"https://c.saavncdn.com/artists/Lata_Mangeshkar_004_20230804105030_150x150.jpg"},{id:"kumar-sanu",name:"Kumar Sanu",query:"Kumar Sanu romantic songs",gradient:"linear-gradient(135deg, #0f0c29, #302b63)",image:"https://c.saavncdn.com/artists/Kumar_Sanu_150x150.jpg"},{id:"ap-dhillon",name:"AP Dhillon",query:"AP Dhillon songs",gradient:"linear-gradient(135deg, #000000, #434343)",image:"https://c.saavncdn.com/artists/AP_Dhillon_001_20221012113605_150x150.jpg"},{id:"honey-singh",name:"Yo Yo Honey Singh",query:"Honey Singh party songs",gradient:"linear-gradient(135deg, #f7971e, #ffd200)",image:"https://c.saavncdn.com/artists/Yo_Yo_Honey_Singh_150x150.jpg"},{id:"jubin-nautiyal",name:"Jubin Nautiyal",query:"Jubin Nautiyal songs",gradient:"linear-gradient(135deg, #0052d4, #6fb1fc)",image:"https://c.saavncdn.com/artists/Jubin_Nautiyal_003_20221012112730_150x150.jpg"},{id:"sunidhi-chauhan",name:"Sunidhi Chauhan",query:"Sunidhi Chauhan hits",gradient:"linear-gradient(135deg, #ee0979, #ff6a00)",image:"https://c.saavncdn.com/artists/Sunidhi_Chauhan_150x150.jpg"}],te={show(e,t="info",a=3e3){let r=document.getElementById("toast-container");if(!r){r=document.createElement("div"),r.id="toast-container",document.body.appendChild(r);const b=document.createElement("style");b.textContent=`
                #toast-container {
                    position: fixed;
                    top: var(--space-xl);
                    right: var(--space-xl);
                    z-index: 9999;
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-sm);
                    pointer-events: none;
                }
                .toast {
                    padding: var(--space-md) var(--space-xl);
                    border-radius: var(--radius-md);
                    background: var(--bg-elevated);
                    color: var(--text-primary);
                    font-size: var(--font-sm);
                    font-weight: 500;
                    box-shadow: var(--shadow-lg);
                    border: 1px solid var(--surface-border);
                    backdrop-filter: blur(20px);
                    animation: toastIn 0.4s cubic-bezier(0.16, 1, 0.3, 1);
                    display: flex;
                    align-items: center;
                    gap: var(--space-sm);
                    pointer-events: auto;
                }
                .toast-success { border-left: 4px solid var(--accent); }
                .toast-error { border-left: 4px solid #ff4d4d; }
                .toast-info { border-left: 4px solid #4d94ff; }
                .toast-exit {
                    animation: toastOut 0.3s forwards;
                }
                @keyframes toastOut {
                    to { opacity: 0; transform: translateX(20px); }
                }
            `,document.head.appendChild(b)}const n=document.createElement("div");n.className=`toast toast-${t}`;let i="info";t==="success"&&(i="check_circle"),t==="error"&&(i="error"),n.innerHTML=`
            <span class="material-symbols-rounded" style="font-size: 18px;">${i}</span>
            <span>${e}</span>
        `,r.appendChild(n),setTimeout(()=>{n.classList.add("toast-exit"),setTimeout(()=>n.remove(),300)},a)}};function ue(e,t,a="vertical"){const r=document.createElement("div");r.className=`track-card ${a}`;const n=I.isLiked(e.id),i=I.isDownloadComplete(e.id);r.innerHTML=`
    <div class="track-card-art-wrapper">
      <img class="track-card-art" src="${e.cover||e.coverSmall||""}" alt="${e.title}" loading="lazy" />
      <button class="track-card-play-btn" aria-label="Play ${e.title}">
        <span class="material-symbols-rounded">play_arrow</span>
      </button>
      <button class="track-card-download-btn ${i?"downloaded":""}" aria-label="Download ${e.title}">
        <span class="material-symbols-rounded">${i?"download_done":"download"}</span>
      </button>
      <button class="track-card-like-btn ${n?"liked":""}" aria-label="Favorite ${e.title}">
        <span class="material-symbols-rounded">${n?"favorite":"favorite_border"}</span>
      </button>
      <button class="track-card-add-btn" aria-label="Add to Playlist">
        <span class="material-symbols-rounded">playlist_add</span>
      </button>
    </div>
    <div class="track-card-title">${e.title}</div>
    <div class="track-card-artist" style="pointer-events: auto;">${e.artist}</div>
  `;const b=r.querySelector(".track-card-artist");return b&&b.addEventListener("click",l=>{l.stopPropagation();const v=e.artist.split(",")[0].trim();window.location.hash=`artist?name=${encodeURIComponent(v)}`}),r.addEventListener("click",l=>{if(l.target.closest(".track-card-download-btn")){l.stopPropagation();const v=l.target.closest(".track-card-download-btn");if(I.isDownloadComplete(e.id)){te.show("Already downloaded!","info");return}te.show(`Downloading: ${e.title}...`,"info"),v.querySelector(".material-symbols-rounded").textContent="hourglass_top",ve.downloadTrack(e).then(s=>{s?(v.classList.add("downloaded"),v.querySelector(".material-symbols-rounded").textContent="download_done",te.show(`Downloaded: ${e.title}`,"success")):(v.querySelector(".material-symbols-rounded").textContent="download",te.show("Download failed","error"))});return}if(l.target.closest(".track-card-like-btn")){l.stopPropagation(),I.toggleLike(e);const v=I.isLiked(e.id),s=l.target.closest(".track-card-like-btn");s.classList.toggle("liked",v),s.querySelector(".material-symbols-rounded").textContent=v?"favorite":"favorite_border",te.show(v?"Added to Liked Songs":"Removed from Liked Songs","success"),v&&T.cacheTrack(e);return}if(l.target.closest(".track-card-add-btn")){l.stopPropagation();const v=I.get();if(v.playlists.length===0){te.show("Create a playlist first in Library","error");return}const s=v.playlists.map(y=>y.name).join(", "),d=prompt(`Add to playlist?
Available: ${s}`);if(d){const y=v.playlists.find(o=>o.name.toLowerCase()===d.toLowerCase());y?(I.addToPlaylist(y.id,e),te.show(`Added to ${y.name}`,"success")):te.show("Playlist not found","error")}return}T.playAll(t,e)}),r}const tr=document.createElement("style");tr.textContent=`
  .track-card {
    cursor: pointer;
    transition: transform var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
  }
  .track-card:active {
    transform: scale(0.97);
  }

  .track-card.vertical {
    width: 130px;
  }

  .track-card.horizontal {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    padding: var(--space-sm);
    border-radius: var(--radius-md);
    width: 100%;
  }

  .track-card-art-wrapper {
    position: relative;
    border-radius: var(--radius-md);
    overflow: hidden;
    aspect-ratio: 1;
    background: var(--bg-tertiary);
  }

  .track-card.horizontal .track-card-art-wrapper {
    width: 56px;
    height: 56px;
    flex-shrink: 0;
    border-radius: var(--radius-sm);
  }

  .track-card-art {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform var(--transition-normal);
  }

  .track-card:hover .track-card-art {
    transform: scale(1.05);
  }

  .track-card-play-btn {
    position: absolute;
    bottom: var(--space-sm);
    right: var(--space-sm);
    width: 40px;
    height: 40px;
    border-radius: var(--radius-full);
    border: none;
    background: var(--accent);
    color: var(--text-on-accent);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: translateY(8px);
    transition: opacity var(--transition-normal), transform var(--transition-normal), box-shadow var(--transition-normal);
    box-shadow: var(--shadow-md);
    z-index: 2;
  }

  .track-card-download-btn {
    position: absolute;
    top: var(--space-sm);
    right: var(--space-sm);
    width: 32px;
    height: 32px;
    border-radius: var(--radius-full);
    border: none;
    background: var(--surface-glass-thick);
    backdrop-filter: blur(10px);
    color: var(--text-primary);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: translateY(-8px);
    transition: opacity var(--transition-normal), transform var(--transition-normal), background var(--transition-fast);
  }

  .track-card-download-btn.downloaded {
    color: var(--accent);
    opacity: 1;
    transform: translateY(0);
  }

  .track-card-like-btn {
    position: absolute;
    bottom: var(--space-sm);
    left: var(--space-sm);
    width: 32px;
    height: 32px;
    border-radius: var(--radius-full);
    border: none;
    background: var(--surface-glass-thick);
    backdrop-filter: blur(10px);
    color: var(--text-primary);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: translateY(8px);
    transition: opacity var(--transition-normal), transform var(--transition-normal), background var(--transition-fast), color var(--transition-fast);
  }

  .track-card-like-btn.liked {
    color: #ff4d4d;
  }

  .track-card-add-btn {
    position: absolute;
    top: var(--space-sm);
    left: var(--space-sm);
    width: 32px;
    height: 32px;
    border-radius: var(--radius-full);
    border: none;
    background: var(--surface-glass-thick);
    backdrop-filter: blur(10px);
    color: var(--text-primary);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: translateY(-8px);
    transition: opacity var(--transition-normal), transform var(--transition-normal), background var(--transition-fast);
  }

  .track-card-download-btn:hover,
  .track-card-like-btn:hover,
  .track-card-add-btn:hover {
    background: var(--accent);
    color: var(--text-on-accent);
  }

  .track-card:hover .track-card-play-btn,
  .track-card:active .track-card-play-btn,
  .track-card:hover .track-card-download-btn,
  .track-card:active .track-card-download-btn,
  .track-card:hover .track-card-add-btn,
  .track-card:active .track-card-add-btn,
  .track-card:hover .track-card-like-btn,
  .track-card:active .track-card-like-btn {
    opacity: 1;
    transform: translateY(0);
  }

  /* Removed hover:none block to keep UI clean on mobile */

  .track-card-play-btn .material-symbols-rounded {
    font-size: 22px;
  }
  .track-card-download-btn .material-symbols-rounded,
  .track-card-add-btn .material-symbols-rounded,
  .track-card-like-btn .material-symbols-rounded {
    font-size: 18px;
  }

  .track-card-title {
    margin-top: var(--space-sm);
    font-size: var(--font-sm);
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: var(--text-primary);
  }

  .track-card.horizontal .track-card-title {
    margin-top: 0;
  }

  .track-card-artist {
    font-size: var(--font-xs);
    color: var(--text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
`;document.head.appendChild(tr);var Ft=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function aa(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function na(e){if(Object.prototype.hasOwnProperty.call(e,"__esModule"))return e;var t=e.default;if(typeof t=="function"){var a=function r(){return this instanceof r?Reflect.construct(t,arguments,this.constructor):t.apply(this,arguments)};a.prototype=t.prototype}else a={};return Object.defineProperty(a,"__esModule",{value:!0}),Object.keys(e).forEach(function(r){var n=Object.getOwnPropertyDescriptor(e,r);Object.defineProperty(a,r,n.get?n:{enumerable:!0,get:function(){return e[r]}})}),a}var Me={exports:{}};function sa(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Ie={exports:{}};const ia={},oa=Object.freeze(Object.defineProperty({__proto__:null,default:ia},Symbol.toStringTag,{value:"Module"})),la=na(oa);var ca=Ie.exports,s0;function N(){return s0||(s0=1,(function(e,t){(function(a,r){e.exports=r()})(ca,function(){var a=a||(function(r,n){var i;if(typeof window<"u"&&window.crypto&&(i=window.crypto),typeof self<"u"&&self.crypto&&(i=self.crypto),typeof globalThis<"u"&&globalThis.crypto&&(i=globalThis.crypto),!i&&typeof window<"u"&&window.msCrypto&&(i=window.msCrypto),!i&&typeof Ft<"u"&&Ft.crypto&&(i=Ft.crypto),!i&&typeof sa=="function")try{i=la}catch{}var b=function(){if(i){if(typeof i.getRandomValues=="function")try{return i.getRandomValues(new Uint32Array(1))[0]}catch{}if(typeof i.randomBytes=="function")try{return i.randomBytes(4).readInt32LE()}catch{}}throw new Error("Native crypto module could not be used to get secure random number.")},l=Object.create||(function(){function c(){}return function(p){var h;return c.prototype=p,h=new c,c.prototype=null,h}})(),v={},s=v.lib={},d=s.Base=(function(){return{extend:function(c){var p=l(this);return c&&p.mixIn(c),(!p.hasOwnProperty("init")||this.init===p.init)&&(p.init=function(){p.$super.init.apply(this,arguments)}),p.init.prototype=p,p.$super=this,p},create:function(){var c=this.extend();return c.init.apply(c,arguments),c},init:function(){},mixIn:function(c){for(var p in c)c.hasOwnProperty(p)&&(this[p]=c[p]);c.hasOwnProperty("toString")&&(this.toString=c.toString)},clone:function(){return this.init.prototype.extend(this)}}})(),y=s.WordArray=d.extend({init:function(c,p){c=this.words=c||[],p!=n?this.sigBytes=p:this.sigBytes=c.length*4},toString:function(c){return(c||x).stringify(this)},concat:function(c){var p=this.words,h=c.words,C=this.sigBytes,w=c.sigBytes;if(this.clamp(),C%4)for(var E=0;E<w;E++){var D=h[E>>>2]>>>24-E%4*8&255;p[C+E>>>2]|=D<<24-(C+E)%4*8}else for(var _=0;_<w;_+=4)p[C+_>>>2]=h[_>>>2];return this.sigBytes+=w,this},clamp:function(){var c=this.words,p=this.sigBytes;c[p>>>2]&=4294967295<<32-p%4*8,c.length=r.ceil(p/4)},clone:function(){var c=d.clone.call(this);return c.words=this.words.slice(0),c},random:function(c){for(var p=[],h=0;h<c;h+=4)p.push(b());return new y.init(p,c)}}),o=v.enc={},x=o.Hex={stringify:function(c){for(var p=c.words,h=c.sigBytes,C=[],w=0;w<h;w++){var E=p[w>>>2]>>>24-w%4*8&255;C.push((E>>>4).toString(16)),C.push((E&15).toString(16))}return C.join("")},parse:function(c){for(var p=c.length,h=[],C=0;C<p;C+=2)h[C>>>3]|=parseInt(c.substr(C,2),16)<<24-C%8*4;return new y.init(h,p/2)}},f=o.Latin1={stringify:function(c){for(var p=c.words,h=c.sigBytes,C=[],w=0;w<h;w++){var E=p[w>>>2]>>>24-w%4*8&255;C.push(String.fromCharCode(E))}return C.join("")},parse:function(c){for(var p=c.length,h=[],C=0;C<p;C++)h[C>>>2]|=(c.charCodeAt(C)&255)<<24-C%4*8;return new y.init(h,p)}},g=o.Utf8={stringify:function(c){try{return decodeURIComponent(escape(f.stringify(c)))}catch{throw new Error("Malformed UTF-8 data")}},parse:function(c){return f.parse(unescape(encodeURIComponent(c)))}},m=s.BufferedBlockAlgorithm=d.extend({reset:function(){this._data=new y.init,this._nDataBytes=0},_append:function(c){typeof c=="string"&&(c=g.parse(c)),this._data.concat(c),this._nDataBytes+=c.sigBytes},_process:function(c){var p,h=this._data,C=h.words,w=h.sigBytes,E=this.blockSize,D=E*4,_=w/D;c?_=r.ceil(_):_=r.max((_|0)-this._minBufferSize,0);var B=_*E,A=r.min(B*4,w);if(B){for(var k=0;k<B;k+=E)this._doProcessBlock(C,k);p=C.splice(0,B),h.sigBytes-=A}return new y.init(p,A)},clone:function(){var c=d.clone.call(this);return c._data=this._data.clone(),c},_minBufferSize:0});s.Hasher=m.extend({cfg:d.extend(),init:function(c){this.cfg=this.cfg.extend(c),this.reset()},reset:function(){m.reset.call(this),this._doReset()},update:function(c){return this._append(c),this._process(),this},finalize:function(c){c&&this._append(c);var p=this._doFinalize();return p},blockSize:16,_createHelper:function(c){return function(p,h){return new c.init(h).finalize(p)}},_createHmacHelper:function(c){return function(p,h){return new u.HMAC.init(c,h).finalize(p)}}});var u=v.algo={};return v})(Math);return a})})(Ie)),Ie.exports}var Ne={exports:{}},da=Ne.exports,i0;function Bt(){return i0||(i0=1,(function(e,t){(function(a,r){e.exports=r(N())})(da,function(a){return(function(r){var n=a,i=n.lib,b=i.Base,l=i.WordArray,v=n.x64={};v.Word=b.extend({init:function(s,d){this.high=s,this.low=d}}),v.WordArray=b.extend({init:function(s,d){s=this.words=s||[],d!=r?this.sigBytes=d:this.sigBytes=s.length*8},toX32:function(){for(var s=this.words,d=s.length,y=[],o=0;o<d;o++){var x=s[o];y.push(x.high),y.push(x.low)}return l.create(y,this.sigBytes)},clone:function(){for(var s=b.clone.call(this),d=s.words=this.words.slice(0),y=d.length,o=0;o<y;o++)d[o]=d[o].clone();return s}})})(),a})})(Ne)),Ne.exports}var je={exports:{}},xa=je.exports,o0;function pa(){return o0||(o0=1,(function(e,t){(function(a,r){e.exports=r(N())})(xa,function(a){return(function(){if(typeof ArrayBuffer=="function"){var r=a,n=r.lib,i=n.WordArray,b=i.init,l=i.init=function(v){if(v instanceof ArrayBuffer&&(v=new Uint8Array(v)),(v instanceof Int8Array||typeof Uint8ClampedArray<"u"&&v instanceof Uint8ClampedArray||v instanceof Int16Array||v instanceof Uint16Array||v instanceof Int32Array||v instanceof Uint32Array||v instanceof Float32Array||v instanceof Float64Array)&&(v=new Uint8Array(v.buffer,v.byteOffset,v.byteLength)),v instanceof Uint8Array){for(var s=v.byteLength,d=[],y=0;y<s;y++)d[y>>>2]|=v[y]<<24-y%4*8;b.call(this,d,s)}else b.apply(this,arguments)};l.prototype=i}})(),a.lib.WordArray})})(je)),je.exports}var Oe={exports:{}},ua=Oe.exports,l0;function fa(){return l0||(l0=1,(function(e,t){(function(a,r){e.exports=r(N())})(ua,function(a){return(function(){var r=a,n=r.lib,i=n.WordArray,b=r.enc;b.Utf16=b.Utf16BE={stringify:function(v){for(var s=v.words,d=v.sigBytes,y=[],o=0;o<d;o+=2){var x=s[o>>>2]>>>16-o%4*8&65535;y.push(String.fromCharCode(x))}return y.join("")},parse:function(v){for(var s=v.length,d=[],y=0;y<s;y++)d[y>>>1]|=v.charCodeAt(y)<<16-y%2*16;return i.create(d,s*2)}},b.Utf16LE={stringify:function(v){for(var s=v.words,d=v.sigBytes,y=[],o=0;o<d;o+=2){var x=l(s[o>>>2]>>>16-o%4*8&65535);y.push(String.fromCharCode(x))}return y.join("")},parse:function(v){for(var s=v.length,d=[],y=0;y<s;y++)d[y>>>1]|=l(v.charCodeAt(y)<<16-y%2*16);return i.create(d,s*2)}};function l(v){return v<<8&4278255360|v>>>8&16711935}})(),a.enc.Utf16})})(Oe)),Oe.exports}var Ue={exports:{}},va=Ue.exports,c0;function he(){return c0||(c0=1,(function(e,t){(function(a,r){e.exports=r(N())})(va,function(a){return(function(){var r=a,n=r.lib,i=n.WordArray,b=r.enc;b.Base64={stringify:function(v){var s=v.words,d=v.sigBytes,y=this._map;v.clamp();for(var o=[],x=0;x<d;x+=3)for(var f=s[x>>>2]>>>24-x%4*8&255,g=s[x+1>>>2]>>>24-(x+1)%4*8&255,m=s[x+2>>>2]>>>24-(x+2)%4*8&255,u=f<<16|g<<8|m,c=0;c<4&&x+c*.75<d;c++)o.push(y.charAt(u>>>6*(3-c)&63));var p=y.charAt(64);if(p)for(;o.length%4;)o.push(p);return o.join("")},parse:function(v){var s=v.length,d=this._map,y=this._reverseMap;if(!y){y=this._reverseMap=[];for(var o=0;o<d.length;o++)y[d.charCodeAt(o)]=o}var x=d.charAt(64);if(x){var f=v.indexOf(x);f!==-1&&(s=f)}return l(v,s,y)},_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="};function l(v,s,d){for(var y=[],o=0,x=0;x<s;x++)if(x%4){var f=d[v.charCodeAt(x-1)]<<x%4*2,g=d[v.charCodeAt(x)]>>>6-x%4*2,m=f|g;y[o>>>2]|=m<<24-o%4*8,o++}return i.create(y,o)}})(),a.enc.Base64})})(Ue)),Ue.exports}var We={exports:{}},ha=We.exports,d0;function ma(){return d0||(d0=1,(function(e,t){(function(a,r){e.exports=r(N())})(ha,function(a){return(function(){var r=a,n=r.lib,i=n.WordArray,b=r.enc;b.Base64url={stringify:function(v,s){s===void 0&&(s=!0);var d=v.words,y=v.sigBytes,o=s?this._safe_map:this._map;v.clamp();for(var x=[],f=0;f<y;f+=3)for(var g=d[f>>>2]>>>24-f%4*8&255,m=d[f+1>>>2]>>>24-(f+1)%4*8&255,u=d[f+2>>>2]>>>24-(f+2)%4*8&255,c=g<<16|m<<8|u,p=0;p<4&&f+p*.75<y;p++)x.push(o.charAt(c>>>6*(3-p)&63));var h=o.charAt(64);if(h)for(;x.length%4;)x.push(h);return x.join("")},parse:function(v,s){s===void 0&&(s=!0);var d=v.length,y=s?this._safe_map:this._map,o=this._reverseMap;if(!o){o=this._reverseMap=[];for(var x=0;x<y.length;x++)o[y.charCodeAt(x)]=x}var f=y.charAt(64);if(f){var g=v.indexOf(f);g!==-1&&(d=g)}return l(v,d,o)},_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",_safe_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"};function l(v,s,d){for(var y=[],o=0,x=0;x<s;x++)if(x%4){var f=d[v.charCodeAt(x-1)]<<x%4*2,g=d[v.charCodeAt(x)]>>>6-x%4*2,m=f|g;y[o>>>2]|=m<<24-o%4*8,o++}return i.create(y,o)}})(),a.enc.Base64url})})(We)),We.exports}var Ke={exports:{}},ga=Ke.exports,x0;function me(){return x0||(x0=1,(function(e,t){(function(a,r){e.exports=r(N())})(ga,function(a){return(function(r){var n=a,i=n.lib,b=i.WordArray,l=i.Hasher,v=n.algo,s=[];(function(){for(var g=0;g<64;g++)s[g]=r.abs(r.sin(g+1))*4294967296|0})();var d=v.MD5=l.extend({_doReset:function(){this._hash=new b.init([1732584193,4023233417,2562383102,271733878])},_doProcessBlock:function(g,m){for(var u=0;u<16;u++){var c=m+u,p=g[c];g[c]=(p<<8|p>>>24)&16711935|(p<<24|p>>>8)&4278255360}var h=this._hash.words,C=g[m+0],w=g[m+1],E=g[m+2],D=g[m+3],_=g[m+4],B=g[m+5],A=g[m+6],k=g[m+7],F=g[m+8],H=g[m+9],z=g[m+10],R=g[m+11],K=g[m+12],j=g[m+13],U=g[m+14],O=g[m+15],S=h[0],q=h[1],$=h[2],L=h[3];S=y(S,q,$,L,C,7,s[0]),L=y(L,S,q,$,w,12,s[1]),$=y($,L,S,q,E,17,s[2]),q=y(q,$,L,S,D,22,s[3]),S=y(S,q,$,L,_,7,s[4]),L=y(L,S,q,$,B,12,s[5]),$=y($,L,S,q,A,17,s[6]),q=y(q,$,L,S,k,22,s[7]),S=y(S,q,$,L,F,7,s[8]),L=y(L,S,q,$,H,12,s[9]),$=y($,L,S,q,z,17,s[10]),q=y(q,$,L,S,R,22,s[11]),S=y(S,q,$,L,K,7,s[12]),L=y(L,S,q,$,j,12,s[13]),$=y($,L,S,q,U,17,s[14]),q=y(q,$,L,S,O,22,s[15]),S=o(S,q,$,L,w,5,s[16]),L=o(L,S,q,$,A,9,s[17]),$=o($,L,S,q,R,14,s[18]),q=o(q,$,L,S,C,20,s[19]),S=o(S,q,$,L,B,5,s[20]),L=o(L,S,q,$,z,9,s[21]),$=o($,L,S,q,O,14,s[22]),q=o(q,$,L,S,_,20,s[23]),S=o(S,q,$,L,H,5,s[24]),L=o(L,S,q,$,U,9,s[25]),$=o($,L,S,q,D,14,s[26]),q=o(q,$,L,S,F,20,s[27]),S=o(S,q,$,L,j,5,s[28]),L=o(L,S,q,$,E,9,s[29]),$=o($,L,S,q,k,14,s[30]),q=o(q,$,L,S,K,20,s[31]),S=x(S,q,$,L,B,4,s[32]),L=x(L,S,q,$,F,11,s[33]),$=x($,L,S,q,R,16,s[34]),q=x(q,$,L,S,U,23,s[35]),S=x(S,q,$,L,w,4,s[36]),L=x(L,S,q,$,_,11,s[37]),$=x($,L,S,q,k,16,s[38]),q=x(q,$,L,S,z,23,s[39]),S=x(S,q,$,L,j,4,s[40]),L=x(L,S,q,$,C,11,s[41]),$=x($,L,S,q,D,16,s[42]),q=x(q,$,L,S,A,23,s[43]),S=x(S,q,$,L,H,4,s[44]),L=x(L,S,q,$,K,11,s[45]),$=x($,L,S,q,O,16,s[46]),q=x(q,$,L,S,E,23,s[47]),S=f(S,q,$,L,C,6,s[48]),L=f(L,S,q,$,k,10,s[49]),$=f($,L,S,q,U,15,s[50]),q=f(q,$,L,S,B,21,s[51]),S=f(S,q,$,L,K,6,s[52]),L=f(L,S,q,$,D,10,s[53]),$=f($,L,S,q,z,15,s[54]),q=f(q,$,L,S,w,21,s[55]),S=f(S,q,$,L,F,6,s[56]),L=f(L,S,q,$,O,10,s[57]),$=f($,L,S,q,A,15,s[58]),q=f(q,$,L,S,j,21,s[59]),S=f(S,q,$,L,_,6,s[60]),L=f(L,S,q,$,R,10,s[61]),$=f($,L,S,q,E,15,s[62]),q=f(q,$,L,S,H,21,s[63]),h[0]=h[0]+S|0,h[1]=h[1]+q|0,h[2]=h[2]+$|0,h[3]=h[3]+L|0},_doFinalize:function(){var g=this._data,m=g.words,u=this._nDataBytes*8,c=g.sigBytes*8;m[c>>>5]|=128<<24-c%32;var p=r.floor(u/4294967296),h=u;m[(c+64>>>9<<4)+15]=(p<<8|p>>>24)&16711935|(p<<24|p>>>8)&4278255360,m[(c+64>>>9<<4)+14]=(h<<8|h>>>24)&16711935|(h<<24|h>>>8)&4278255360,g.sigBytes=(m.length+1)*4,this._process();for(var C=this._hash,w=C.words,E=0;E<4;E++){var D=w[E];w[E]=(D<<8|D>>>24)&16711935|(D<<24|D>>>8)&4278255360}return C},clone:function(){var g=l.clone.call(this);return g._hash=this._hash.clone(),g}});function y(g,m,u,c,p,h,C){var w=g+(m&u|~m&c)+p+C;return(w<<h|w>>>32-h)+m}function o(g,m,u,c,p,h,C){var w=g+(m&c|u&~c)+p+C;return(w<<h|w>>>32-h)+m}function x(g,m,u,c,p,h,C){var w=g+(m^u^c)+p+C;return(w<<h|w>>>32-h)+m}function f(g,m,u,c,p,h,C){var w=g+(u^(m|~c))+p+C;return(w<<h|w>>>32-h)+m}n.MD5=l._createHelper(d),n.HmacMD5=l._createHmacHelper(d)})(Math),a.MD5})})(Ke)),Ke.exports}var Ge={exports:{}},ya=Ge.exports,p0;function rr(){return p0||(p0=1,(function(e,t){(function(a,r){e.exports=r(N())})(ya,function(a){return(function(){var r=a,n=r.lib,i=n.WordArray,b=n.Hasher,l=r.algo,v=[],s=l.SHA1=b.extend({_doReset:function(){this._hash=new i.init([1732584193,4023233417,2562383102,271733878,3285377520])},_doProcessBlock:function(d,y){for(var o=this._hash.words,x=o[0],f=o[1],g=o[2],m=o[3],u=o[4],c=0;c<80;c++){if(c<16)v[c]=d[y+c]|0;else{var p=v[c-3]^v[c-8]^v[c-14]^v[c-16];v[c]=p<<1|p>>>31}var h=(x<<5|x>>>27)+u+v[c];c<20?h+=(f&g|~f&m)+1518500249:c<40?h+=(f^g^m)+1859775393:c<60?h+=(f&g|f&m|g&m)-1894007588:h+=(f^g^m)-899497514,u=m,m=g,g=f<<30|f>>>2,f=x,x=h}o[0]=o[0]+x|0,o[1]=o[1]+f|0,o[2]=o[2]+g|0,o[3]=o[3]+m|0,o[4]=o[4]+u|0},_doFinalize:function(){var d=this._data,y=d.words,o=this._nDataBytes*8,x=d.sigBytes*8;return y[x>>>5]|=128<<24-x%32,y[(x+64>>>9<<4)+14]=Math.floor(o/4294967296),y[(x+64>>>9<<4)+15]=o,d.sigBytes=y.length*4,this._process(),this._hash},clone:function(){var d=b.clone.call(this);return d._hash=this._hash.clone(),d}});r.SHA1=b._createHelper(s),r.HmacSHA1=b._createHmacHelper(s)})(),a.SHA1})})(Ge)),Ge.exports}var Xe={exports:{}},ba=Xe.exports,u0;function zt(){return u0||(u0=1,(function(e,t){(function(a,r){e.exports=r(N())})(ba,function(a){return(function(r){var n=a,i=n.lib,b=i.WordArray,l=i.Hasher,v=n.algo,s=[],d=[];(function(){function x(u){for(var c=r.sqrt(u),p=2;p<=c;p++)if(!(u%p))return!1;return!0}function f(u){return(u-(u|0))*4294967296|0}for(var g=2,m=0;m<64;)x(g)&&(m<8&&(s[m]=f(r.pow(g,1/2))),d[m]=f(r.pow(g,1/3)),m++),g++})();var y=[],o=v.SHA256=l.extend({_doReset:function(){this._hash=new b.init(s.slice(0))},_doProcessBlock:function(x,f){for(var g=this._hash.words,m=g[0],u=g[1],c=g[2],p=g[3],h=g[4],C=g[5],w=g[6],E=g[7],D=0;D<64;D++){if(D<16)y[D]=x[f+D]|0;else{var _=y[D-15],B=(_<<25|_>>>7)^(_<<14|_>>>18)^_>>>3,A=y[D-2],k=(A<<15|A>>>17)^(A<<13|A>>>19)^A>>>10;y[D]=B+y[D-7]+k+y[D-16]}var F=h&C^~h&w,H=m&u^m&c^u&c,z=(m<<30|m>>>2)^(m<<19|m>>>13)^(m<<10|m>>>22),R=(h<<26|h>>>6)^(h<<21|h>>>11)^(h<<7|h>>>25),K=E+R+F+d[D]+y[D],j=z+H;E=w,w=C,C=h,h=p+K|0,p=c,c=u,u=m,m=K+j|0}g[0]=g[0]+m|0,g[1]=g[1]+u|0,g[2]=g[2]+c|0,g[3]=g[3]+p|0,g[4]=g[4]+h|0,g[5]=g[5]+C|0,g[6]=g[6]+w|0,g[7]=g[7]+E|0},_doFinalize:function(){var x=this._data,f=x.words,g=this._nDataBytes*8,m=x.sigBytes*8;return f[m>>>5]|=128<<24-m%32,f[(m+64>>>9<<4)+14]=r.floor(g/4294967296),f[(m+64>>>9<<4)+15]=g,x.sigBytes=f.length*4,this._process(),this._hash},clone:function(){var x=l.clone.call(this);return x._hash=this._hash.clone(),x}});n.SHA256=l._createHelper(o),n.HmacSHA256=l._createHmacHelper(o)})(Math),a.SHA256})})(Xe)),Xe.exports}var Ve={exports:{}},Ca=Ve.exports,f0;function wa(){return f0||(f0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),zt())})(Ca,function(a){return(function(){var r=a,n=r.lib,i=n.WordArray,b=r.algo,l=b.SHA256,v=b.SHA224=l.extend({_doReset:function(){this._hash=new i.init([3238371032,914150663,812702999,4144912697,4290775857,1750603025,1694076839,3204075428])},_doFinalize:function(){var s=l._doFinalize.call(this);return s.sigBytes-=4,s}});r.SHA224=l._createHelper(v),r.HmacSHA224=l._createHmacHelper(v)})(),a.SHA224})})(Ve)),Ve.exports}var Ye={exports:{}},Ea=Ye.exports,v0;function ar(){return v0||(v0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),Bt())})(Ea,function(a){return(function(){var r=a,n=r.lib,i=n.Hasher,b=r.x64,l=b.Word,v=b.WordArray,s=r.algo;function d(){return l.create.apply(l,arguments)}var y=[d(1116352408,3609767458),d(1899447441,602891725),d(3049323471,3964484399),d(3921009573,2173295548),d(961987163,4081628472),d(1508970993,3053834265),d(2453635748,2937671579),d(2870763221,3664609560),d(3624381080,2734883394),d(310598401,1164996542),d(607225278,1323610764),d(1426881987,3590304994),d(1925078388,4068182383),d(2162078206,991336113),d(2614888103,633803317),d(3248222580,3479774868),d(3835390401,2666613458),d(4022224774,944711139),d(264347078,2341262773),d(604807628,2007800933),d(770255983,1495990901),d(1249150122,1856431235),d(1555081692,3175218132),d(1996064986,2198950837),d(2554220882,3999719339),d(2821834349,766784016),d(2952996808,2566594879),d(3210313671,3203337956),d(3336571891,1034457026),d(3584528711,2466948901),d(113926993,3758326383),d(338241895,168717936),d(666307205,1188179964),d(773529912,1546045734),d(1294757372,1522805485),d(1396182291,2643833823),d(1695183700,2343527390),d(1986661051,1014477480),d(2177026350,1206759142),d(2456956037,344077627),d(2730485921,1290863460),d(2820302411,3158454273),d(3259730800,3505952657),d(3345764771,106217008),d(3516065817,3606008344),d(3600352804,1432725776),d(4094571909,1467031594),d(275423344,851169720),d(430227734,3100823752),d(506948616,1363258195),d(659060556,3750685593),d(883997877,3785050280),d(958139571,3318307427),d(1322822218,3812723403),d(1537002063,2003034995),d(1747873779,3602036899),d(1955562222,1575990012),d(2024104815,1125592928),d(2227730452,2716904306),d(2361852424,442776044),d(2428436474,593698344),d(2756734187,3733110249),d(3204031479,2999351573),d(3329325298,3815920427),d(3391569614,3928383900),d(3515267271,566280711),d(3940187606,3454069534),d(4118630271,4000239992),d(116418474,1914138554),d(174292421,2731055270),d(289380356,3203993006),d(460393269,320620315),d(685471733,587496836),d(852142971,1086792851),d(1017036298,365543100),d(1126000580,2618297676),d(1288033470,3409855158),d(1501505948,4234509866),d(1607167915,987167468),d(1816402316,1246189591)],o=[];(function(){for(var f=0;f<80;f++)o[f]=d()})();var x=s.SHA512=i.extend({_doReset:function(){this._hash=new v.init([new l.init(1779033703,4089235720),new l.init(3144134277,2227873595),new l.init(1013904242,4271175723),new l.init(2773480762,1595750129),new l.init(1359893119,2917565137),new l.init(2600822924,725511199),new l.init(528734635,4215389547),new l.init(1541459225,327033209)])},_doProcessBlock:function(f,g){for(var m=this._hash.words,u=m[0],c=m[1],p=m[2],h=m[3],C=m[4],w=m[5],E=m[6],D=m[7],_=u.high,B=u.low,A=c.high,k=c.low,F=p.high,H=p.low,z=h.high,R=h.low,K=C.high,j=C.low,U=w.high,O=w.low,S=E.high,q=E.low,$=D.high,L=D.low,G=_,W=B,Q=A,M=k,Ae=F,ge=H,At=z,De=R,se=K,J=j,$e=U,_e=O,Pe=S,ke=q,Dt=$,Fe=L,ie=0;ie<80;ie++){var re,xe,He=o[ie];if(ie<16)xe=He.high=f[g+ie*2]|0,re=He.low=f[g+ie*2+1]|0;else{var Mt=o[ie-15],ye=Mt.high,Se=Mt.low,wr=(ye>>>1|Se<<31)^(ye>>>8|Se<<24)^ye>>>7,It=(Se>>>1|ye<<31)^(Se>>>8|ye<<24)^(Se>>>7|ye<<25),Nt=o[ie-2],be=Nt.high,Le=Nt.low,Er=(be>>>19|Le<<13)^(be<<3|Le>>>29)^be>>>6,jt=(Le>>>19|be<<13)^(Le<<3|be>>>29)^(Le>>>6|be<<26),Ot=o[ie-7],Br=Ot.high,Ar=Ot.low,Ut=o[ie-16],Dr=Ut.high,Wt=Ut.low;re=It+Ar,xe=wr+Br+(re>>>0<It>>>0?1:0),re=re+jt,xe=xe+Er+(re>>>0<jt>>>0?1:0),re=re+Wt,xe=xe+Dr+(re>>>0<Wt>>>0?1:0),He.high=xe,He.low=re}var _r=se&$e^~se&Pe,Kt=J&_e^~J&ke,kr=G&Q^G&Ae^Q&Ae,Fr=W&M^W&ge^M&ge,Sr=(G>>>28|W<<4)^(G<<30|W>>>2)^(G<<25|W>>>7),Gt=(W>>>28|G<<4)^(W<<30|G>>>2)^(W<<25|G>>>7),Lr=(se>>>14|J<<18)^(se>>>18|J<<14)^(se<<23|J>>>9),qr=(J>>>14|se<<18)^(J>>>18|se<<14)^(J<<23|se>>>9),Xt=y[ie],$r=Xt.high,Vt=Xt.low,ee=Fe+qr,pe=Dt+Lr+(ee>>>0<Fe>>>0?1:0),ee=ee+Kt,pe=pe+_r+(ee>>>0<Kt>>>0?1:0),ee=ee+Vt,pe=pe+$r+(ee>>>0<Vt>>>0?1:0),ee=ee+re,pe=pe+xe+(ee>>>0<re>>>0?1:0),Yt=Gt+Fr,Pr=Sr+kr+(Yt>>>0<Gt>>>0?1:0);Dt=Pe,Fe=ke,Pe=$e,ke=_e,$e=se,_e=J,J=De+ee|0,se=At+pe+(J>>>0<De>>>0?1:0)|0,At=Ae,De=ge,Ae=Q,ge=M,Q=G,M=W,W=ee+Yt|0,G=pe+Pr+(W>>>0<ee>>>0?1:0)|0}B=u.low=B+W,u.high=_+G+(B>>>0<W>>>0?1:0),k=c.low=k+M,c.high=A+Q+(k>>>0<M>>>0?1:0),H=p.low=H+ge,p.high=F+Ae+(H>>>0<ge>>>0?1:0),R=h.low=R+De,h.high=z+At+(R>>>0<De>>>0?1:0),j=C.low=j+J,C.high=K+se+(j>>>0<J>>>0?1:0),O=w.low=O+_e,w.high=U+$e+(O>>>0<_e>>>0?1:0),q=E.low=q+ke,E.high=S+Pe+(q>>>0<ke>>>0?1:0),L=D.low=L+Fe,D.high=$+Dt+(L>>>0<Fe>>>0?1:0)},_doFinalize:function(){var f=this._data,g=f.words,m=this._nDataBytes*8,u=f.sigBytes*8;g[u>>>5]|=128<<24-u%32,g[(u+128>>>10<<5)+30]=Math.floor(m/4294967296),g[(u+128>>>10<<5)+31]=m,f.sigBytes=g.length*4,this._process();var c=this._hash.toX32();return c},clone:function(){var f=i.clone.call(this);return f._hash=this._hash.clone(),f},blockSize:1024/32});r.SHA512=i._createHelper(x),r.HmacSHA512=i._createHmacHelper(x)})(),a.SHA512})})(Ye)),Ye.exports}var Qe={exports:{}},Ba=Qe.exports,h0;function Aa(){return h0||(h0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),Bt(),ar())})(Ba,function(a){return(function(){var r=a,n=r.x64,i=n.Word,b=n.WordArray,l=r.algo,v=l.SHA512,s=l.SHA384=v.extend({_doReset:function(){this._hash=new b.init([new i.init(3418070365,3238371032),new i.init(1654270250,914150663),new i.init(2438529370,812702999),new i.init(355462360,4144912697),new i.init(1731405415,4290775857),new i.init(2394180231,1750603025),new i.init(3675008525,1694076839),new i.init(1203062813,3204075428)])},_doFinalize:function(){var d=v._doFinalize.call(this);return d.sigBytes-=16,d}});r.SHA384=v._createHelper(s),r.HmacSHA384=v._createHmacHelper(s)})(),a.SHA384})})(Qe)),Qe.exports}var Ze={exports:{}},Da=Ze.exports,m0;function _a(){return m0||(m0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),Bt())})(Da,function(a){return(function(r){var n=a,i=n.lib,b=i.WordArray,l=i.Hasher,v=n.x64,s=v.Word,d=n.algo,y=[],o=[],x=[];(function(){for(var m=1,u=0,c=0;c<24;c++){y[m+5*u]=(c+1)*(c+2)/2%64;var p=u%5,h=(2*m+3*u)%5;m=p,u=h}for(var m=0;m<5;m++)for(var u=0;u<5;u++)o[m+5*u]=u+(2*m+3*u)%5*5;for(var C=1,w=0;w<24;w++){for(var E=0,D=0,_=0;_<7;_++){if(C&1){var B=(1<<_)-1;B<32?D^=1<<B:E^=1<<B-32}C&128?C=C<<1^113:C<<=1}x[w]=s.create(E,D)}})();var f=[];(function(){for(var m=0;m<25;m++)f[m]=s.create()})();var g=d.SHA3=l.extend({cfg:l.cfg.extend({outputLength:512}),_doReset:function(){for(var m=this._state=[],u=0;u<25;u++)m[u]=new s.init;this.blockSize=(1600-2*this.cfg.outputLength)/32},_doProcessBlock:function(m,u){for(var c=this._state,p=this.blockSize/2,h=0;h<p;h++){var C=m[u+2*h],w=m[u+2*h+1];C=(C<<8|C>>>24)&16711935|(C<<24|C>>>8)&4278255360,w=(w<<8|w>>>24)&16711935|(w<<24|w>>>8)&4278255360;var E=c[h];E.high^=w,E.low^=C}for(var D=0;D<24;D++){for(var _=0;_<5;_++){for(var B=0,A=0,k=0;k<5;k++){var E=c[_+5*k];B^=E.high,A^=E.low}var F=f[_];F.high=B,F.low=A}for(var _=0;_<5;_++)for(var H=f[(_+4)%5],z=f[(_+1)%5],R=z.high,K=z.low,B=H.high^(R<<1|K>>>31),A=H.low^(K<<1|R>>>31),k=0;k<5;k++){var E=c[_+5*k];E.high^=B,E.low^=A}for(var j=1;j<25;j++){var B,A,E=c[j],U=E.high,O=E.low,S=y[j];S<32?(B=U<<S|O>>>32-S,A=O<<S|U>>>32-S):(B=O<<S-32|U>>>64-S,A=U<<S-32|O>>>64-S);var q=f[o[j]];q.high=B,q.low=A}var $=f[0],L=c[0];$.high=L.high,$.low=L.low;for(var _=0;_<5;_++)for(var k=0;k<5;k++){var j=_+5*k,E=c[j],G=f[j],W=f[(_+1)%5+5*k],Q=f[(_+2)%5+5*k];E.high=G.high^~W.high&Q.high,E.low=G.low^~W.low&Q.low}var E=c[0],M=x[D];E.high^=M.high,E.low^=M.low}},_doFinalize:function(){var m=this._data,u=m.words;this._nDataBytes*8;var c=m.sigBytes*8,p=this.blockSize*32;u[c>>>5]|=1<<24-c%32,u[(r.ceil((c+1)/p)*p>>>5)-1]|=128,m.sigBytes=u.length*4,this._process();for(var h=this._state,C=this.cfg.outputLength/8,w=C/8,E=[],D=0;D<w;D++){var _=h[D],B=_.high,A=_.low;B=(B<<8|B>>>24)&16711935|(B<<24|B>>>8)&4278255360,A=(A<<8|A>>>24)&16711935|(A<<24|A>>>8)&4278255360,E.push(A),E.push(B)}return new b.init(E,C)},clone:function(){for(var m=l.clone.call(this),u=m._state=this._state.slice(0),c=0;c<25;c++)u[c]=u[c].clone();return m}});n.SHA3=l._createHelper(g),n.HmacSHA3=l._createHmacHelper(g)})(Math),a.SHA3})})(Ze)),Ze.exports}var Je={exports:{}},ka=Je.exports,g0;function Fa(){return g0||(g0=1,(function(e,t){(function(a,r){e.exports=r(N())})(ka,function(a){/** @preserve
			(c) 2012 by Cédric Mesnil. All rights reserved.

			Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

			    - Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
			    - Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

			THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
			*/return(function(r){var n=a,i=n.lib,b=i.WordArray,l=i.Hasher,v=n.algo,s=b.create([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,7,4,13,1,10,6,15,3,12,0,9,5,2,14,11,8,3,10,14,4,9,15,8,1,2,7,0,6,13,11,5,12,1,9,11,10,0,8,12,4,13,3,7,15,14,5,6,2,4,0,5,9,7,12,2,10,14,1,3,8,11,6,15,13]),d=b.create([5,14,7,0,9,2,11,4,13,6,15,8,1,10,3,12,6,11,3,7,0,13,5,10,14,15,8,12,4,9,1,2,15,5,1,3,7,14,6,9,11,8,12,2,10,0,4,13,8,6,4,1,3,11,15,0,5,12,2,13,9,7,10,14,12,15,10,4,1,5,8,7,6,2,13,14,0,3,9,11]),y=b.create([11,14,15,12,5,8,7,9,11,13,14,15,6,7,9,8,7,6,8,13,11,9,7,15,7,12,15,9,11,7,13,12,11,13,6,7,14,9,13,15,14,8,13,6,5,12,7,5,11,12,14,15,14,15,9,8,9,14,5,6,8,6,5,12,9,15,5,11,6,8,13,12,5,12,13,14,11,8,5,6]),o=b.create([8,9,9,11,13,15,15,5,7,7,8,11,14,14,12,6,9,13,15,7,12,8,9,11,7,7,12,7,6,15,13,11,9,7,15,11,8,6,6,14,12,13,5,14,13,13,7,5,15,5,8,11,14,14,6,14,6,9,12,9,12,5,15,8,8,5,12,9,12,5,14,6,8,13,6,5,15,13,11,11]),x=b.create([0,1518500249,1859775393,2400959708,2840853838]),f=b.create([1352829926,1548603684,1836072691,2053994217,0]),g=v.RIPEMD160=l.extend({_doReset:function(){this._hash=b.create([1732584193,4023233417,2562383102,271733878,3285377520])},_doProcessBlock:function(w,E){for(var D=0;D<16;D++){var _=E+D,B=w[_];w[_]=(B<<8|B>>>24)&16711935|(B<<24|B>>>8)&4278255360}var A=this._hash.words,k=x.words,F=f.words,H=s.words,z=d.words,R=y.words,K=o.words,j,U,O,S,q,$,L,G,W,Q;$=j=A[0],L=U=A[1],G=O=A[2],W=S=A[3],Q=q=A[4];for(var M,D=0;D<80;D+=1)M=j+w[E+H[D]]|0,D<16?M+=m(U,O,S)+k[0]:D<32?M+=u(U,O,S)+k[1]:D<48?M+=c(U,O,S)+k[2]:D<64?M+=p(U,O,S)+k[3]:M+=h(U,O,S)+k[4],M=M|0,M=C(M,R[D]),M=M+q|0,j=q,q=S,S=C(O,10),O=U,U=M,M=$+w[E+z[D]]|0,D<16?M+=h(L,G,W)+F[0]:D<32?M+=p(L,G,W)+F[1]:D<48?M+=c(L,G,W)+F[2]:D<64?M+=u(L,G,W)+F[3]:M+=m(L,G,W)+F[4],M=M|0,M=C(M,K[D]),M=M+Q|0,$=Q,Q=W,W=C(G,10),G=L,L=M;M=A[1]+O+W|0,A[1]=A[2]+S+Q|0,A[2]=A[3]+q+$|0,A[3]=A[4]+j+L|0,A[4]=A[0]+U+G|0,A[0]=M},_doFinalize:function(){var w=this._data,E=w.words,D=this._nDataBytes*8,_=w.sigBytes*8;E[_>>>5]|=128<<24-_%32,E[(_+64>>>9<<4)+14]=(D<<8|D>>>24)&16711935|(D<<24|D>>>8)&4278255360,w.sigBytes=(E.length+1)*4,this._process();for(var B=this._hash,A=B.words,k=0;k<5;k++){var F=A[k];A[k]=(F<<8|F>>>24)&16711935|(F<<24|F>>>8)&4278255360}return B},clone:function(){var w=l.clone.call(this);return w._hash=this._hash.clone(),w}});function m(w,E,D){return w^E^D}function u(w,E,D){return w&E|~w&D}function c(w,E,D){return(w|~E)^D}function p(w,E,D){return w&D|E&~D}function h(w,E,D){return w^(E|~D)}function C(w,E){return w<<E|w>>>32-E}n.RIPEMD160=l._createHelper(g),n.HmacRIPEMD160=l._createHmacHelper(g)})(),a.RIPEMD160})})(Je)),Je.exports}var et={exports:{}},Sa=et.exports,y0;function Tt(){return y0||(y0=1,(function(e,t){(function(a,r){e.exports=r(N())})(Sa,function(a){(function(){var r=a,n=r.lib,i=n.Base,b=r.enc,l=b.Utf8,v=r.algo;v.HMAC=i.extend({init:function(s,d){s=this._hasher=new s.init,typeof d=="string"&&(d=l.parse(d));var y=s.blockSize,o=y*4;d.sigBytes>o&&(d=s.finalize(d)),d.clamp();for(var x=this._oKey=d.clone(),f=this._iKey=d.clone(),g=x.words,m=f.words,u=0;u<y;u++)g[u]^=1549556828,m[u]^=909522486;x.sigBytes=f.sigBytes=o,this.reset()},reset:function(){var s=this._hasher;s.reset(),s.update(this._iKey)},update:function(s){return this._hasher.update(s),this},finalize:function(s){var d=this._hasher,y=d.finalize(s);d.reset();var o=d.finalize(this._oKey.clone().concat(y));return o}})})()})})(et)),et.exports}var tt={exports:{}},La=tt.exports,b0;function qa(){return b0||(b0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),zt(),Tt())})(La,function(a){return(function(){var r=a,n=r.lib,i=n.Base,b=n.WordArray,l=r.algo,v=l.SHA256,s=l.HMAC,d=l.PBKDF2=i.extend({cfg:i.extend({keySize:128/32,hasher:v,iterations:25e4}),init:function(y){this.cfg=this.cfg.extend(y)},compute:function(y,o){for(var x=this.cfg,f=s.create(x.hasher,y),g=b.create(),m=b.create([1]),u=g.words,c=m.words,p=x.keySize,h=x.iterations;u.length<p;){var C=f.update(o).finalize(m);f.reset();for(var w=C.words,E=w.length,D=C,_=1;_<h;_++){D=f.finalize(D),f.reset();for(var B=D.words,A=0;A<E;A++)w[A]^=B[A]}g.concat(C),c[0]++}return g.sigBytes=p*4,g}});r.PBKDF2=function(y,o,x){return d.create(x).compute(y,o)}})(),a.PBKDF2})})(tt)),tt.exports}var rt={exports:{}},$a=rt.exports,C0;function fe(){return C0||(C0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),rr(),Tt())})($a,function(a){return(function(){var r=a,n=r.lib,i=n.Base,b=n.WordArray,l=r.algo,v=l.MD5,s=l.EvpKDF=i.extend({cfg:i.extend({keySize:128/32,hasher:v,iterations:1}),init:function(d){this.cfg=this.cfg.extend(d)},compute:function(d,y){for(var o,x=this.cfg,f=x.hasher.create(),g=b.create(),m=g.words,u=x.keySize,c=x.iterations;m.length<u;){o&&f.update(o),o=f.update(d).finalize(y),f.reset();for(var p=1;p<c;p++)o=f.finalize(o),f.reset();g.concat(o)}return g.sigBytes=u*4,g}});r.EvpKDF=function(d,y,o){return s.create(o).compute(d,y)}})(),a.EvpKDF})})(rt)),rt.exports}var at={exports:{}},Pa=at.exports,w0;function X(){return w0||(w0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),fe())})(Pa,function(a){a.lib.Cipher||(function(r){var n=a,i=n.lib,b=i.Base,l=i.WordArray,v=i.BufferedBlockAlgorithm,s=n.enc;s.Utf8;var d=s.Base64,y=n.algo,o=y.EvpKDF,x=i.Cipher=v.extend({cfg:b.extend(),createEncryptor:function(B,A){return this.create(this._ENC_XFORM_MODE,B,A)},createDecryptor:function(B,A){return this.create(this._DEC_XFORM_MODE,B,A)},init:function(B,A,k){this.cfg=this.cfg.extend(k),this._xformMode=B,this._key=A,this.reset()},reset:function(){v.reset.call(this),this._doReset()},process:function(B){return this._append(B),this._process()},finalize:function(B){B&&this._append(B);var A=this._doFinalize();return A},keySize:128/32,ivSize:128/32,_ENC_XFORM_MODE:1,_DEC_XFORM_MODE:2,_createHelper:(function(){function B(A){return typeof A=="string"?_:w}return function(A){return{encrypt:function(k,F,H){return B(F).encrypt(A,k,F,H)},decrypt:function(k,F,H){return B(F).decrypt(A,k,F,H)}}}})()});i.StreamCipher=x.extend({_doFinalize:function(){var B=this._process(!0);return B},blockSize:1});var f=n.mode={},g=i.BlockCipherMode=b.extend({createEncryptor:function(B,A){return this.Encryptor.create(B,A)},createDecryptor:function(B,A){return this.Decryptor.create(B,A)},init:function(B,A){this._cipher=B,this._iv=A}}),m=f.CBC=(function(){var B=g.extend();B.Encryptor=B.extend({processBlock:function(k,F){var H=this._cipher,z=H.blockSize;A.call(this,k,F,z),H.encryptBlock(k,F),this._prevBlock=k.slice(F,F+z)}}),B.Decryptor=B.extend({processBlock:function(k,F){var H=this._cipher,z=H.blockSize,R=k.slice(F,F+z);H.decryptBlock(k,F),A.call(this,k,F,z),this._prevBlock=R}});function A(k,F,H){var z,R=this._iv;R?(z=R,this._iv=r):z=this._prevBlock;for(var K=0;K<H;K++)k[F+K]^=z[K]}return B})(),u=n.pad={},c=u.Pkcs7={pad:function(B,A){for(var k=A*4,F=k-B.sigBytes%k,H=F<<24|F<<16|F<<8|F,z=[],R=0;R<F;R+=4)z.push(H);var K=l.create(z,F);B.concat(K)},unpad:function(B){var A=B.words[B.sigBytes-1>>>2]&255;B.sigBytes-=A}};i.BlockCipher=x.extend({cfg:x.cfg.extend({mode:m,padding:c}),reset:function(){var B;x.reset.call(this);var A=this.cfg,k=A.iv,F=A.mode;this._xformMode==this._ENC_XFORM_MODE?B=F.createEncryptor:(B=F.createDecryptor,this._minBufferSize=1),this._mode&&this._mode.__creator==B?this._mode.init(this,k&&k.words):(this._mode=B.call(F,this,k&&k.words),this._mode.__creator=B)},_doProcessBlock:function(B,A){this._mode.processBlock(B,A)},_doFinalize:function(){var B,A=this.cfg.padding;return this._xformMode==this._ENC_XFORM_MODE?(A.pad(this._data,this.blockSize),B=this._process(!0)):(B=this._process(!0),A.unpad(B)),B},blockSize:128/32});var p=i.CipherParams=b.extend({init:function(B){this.mixIn(B)},toString:function(B){return(B||this.formatter).stringify(this)}}),h=n.format={},C=h.OpenSSL={stringify:function(B){var A,k=B.ciphertext,F=B.salt;return F?A=l.create([1398893684,1701076831]).concat(F).concat(k):A=k,A.toString(d)},parse:function(B){var A,k=d.parse(B),F=k.words;return F[0]==1398893684&&F[1]==1701076831&&(A=l.create(F.slice(2,4)),F.splice(0,4),k.sigBytes-=16),p.create({ciphertext:k,salt:A})}},w=i.SerializableCipher=b.extend({cfg:b.extend({format:C}),encrypt:function(B,A,k,F){F=this.cfg.extend(F);var H=B.createEncryptor(k,F),z=H.finalize(A),R=H.cfg;return p.create({ciphertext:z,key:k,iv:R.iv,algorithm:B,mode:R.mode,padding:R.padding,blockSize:B.blockSize,formatter:F.format})},decrypt:function(B,A,k,F){F=this.cfg.extend(F),A=this._parse(A,F.format);var H=B.createDecryptor(k,F).finalize(A.ciphertext);return H},_parse:function(B,A){return typeof B=="string"?A.parse(B,this):B}}),E=n.kdf={},D=E.OpenSSL={execute:function(B,A,k,F,H){if(F||(F=l.random(64/8)),H)var z=o.create({keySize:A+k,hasher:H}).compute(B,F);else var z=o.create({keySize:A+k}).compute(B,F);var R=l.create(z.words.slice(A),k*4);return z.sigBytes=A*4,p.create({key:z,iv:R,salt:F})}},_=i.PasswordBasedCipher=w.extend({cfg:w.cfg.extend({kdf:D}),encrypt:function(B,A,k,F){F=this.cfg.extend(F);var H=F.kdf.execute(k,B.keySize,B.ivSize,F.salt,F.hasher);F.iv=H.iv;var z=w.encrypt.call(this,B,A,H.key,F);return z.mixIn(H),z},decrypt:function(B,A,k,F){F=this.cfg.extend(F),A=this._parse(A,F.format);var H=F.kdf.execute(k,B.keySize,B.ivSize,A.salt,F.hasher);F.iv=H.iv;var z=w.decrypt.call(this,B,A,H.key,F);return z}})})()})})(at)),at.exports}var nt={exports:{}},Ha=nt.exports,E0;function za(){return E0||(E0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),X())})(Ha,function(a){return a.mode.CFB=(function(){var r=a.lib.BlockCipherMode.extend();r.Encryptor=r.extend({processBlock:function(i,b){var l=this._cipher,v=l.blockSize;n.call(this,i,b,v,l),this._prevBlock=i.slice(b,b+v)}}),r.Decryptor=r.extend({processBlock:function(i,b){var l=this._cipher,v=l.blockSize,s=i.slice(b,b+v);n.call(this,i,b,v,l),this._prevBlock=s}});function n(i,b,l,v){var s,d=this._iv;d?(s=d.slice(0),this._iv=void 0):s=this._prevBlock,v.encryptBlock(s,0);for(var y=0;y<l;y++)i[b+y]^=s[y]}return r})(),a.mode.CFB})})(nt)),nt.exports}var st={exports:{}},Ta=st.exports,B0;function Ra(){return B0||(B0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),X())})(Ta,function(a){return a.mode.CTR=(function(){var r=a.lib.BlockCipherMode.extend(),n=r.Encryptor=r.extend({processBlock:function(i,b){var l=this._cipher,v=l.blockSize,s=this._iv,d=this._counter;s&&(d=this._counter=s.slice(0),this._iv=void 0);var y=d.slice(0);l.encryptBlock(y,0),d[v-1]=d[v-1]+1|0;for(var o=0;o<v;o++)i[b+o]^=y[o]}});return r.Decryptor=n,r})(),a.mode.CTR})})(st)),st.exports}var it={exports:{}},Ma=it.exports,A0;function Ia(){return A0||(A0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),X())})(Ma,function(a){/** @preserve
 * Counter block mode compatible with  Dr Brian Gladman fileenc.c
 * derived from CryptoJS.mode.CTR
 * Jan Hruby jhruby.web@gmail.com
 */return a.mode.CTRGladman=(function(){var r=a.lib.BlockCipherMode.extend();function n(l){if((l>>24&255)===255){var v=l>>16&255,s=l>>8&255,d=l&255;v===255?(v=0,s===255?(s=0,d===255?d=0:++d):++s):++v,l=0,l+=v<<16,l+=s<<8,l+=d}else l+=1<<24;return l}function i(l){return(l[0]=n(l[0]))===0&&(l[1]=n(l[1])),l}var b=r.Encryptor=r.extend({processBlock:function(l,v){var s=this._cipher,d=s.blockSize,y=this._iv,o=this._counter;y&&(o=this._counter=y.slice(0),this._iv=void 0),i(o);var x=o.slice(0);s.encryptBlock(x,0);for(var f=0;f<d;f++)l[v+f]^=x[f]}});return r.Decryptor=b,r})(),a.mode.CTRGladman})})(it)),it.exports}var ot={exports:{}},Na=ot.exports,D0;function ja(){return D0||(D0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),X())})(Na,function(a){return a.mode.OFB=(function(){var r=a.lib.BlockCipherMode.extend(),n=r.Encryptor=r.extend({processBlock:function(i,b){var l=this._cipher,v=l.blockSize,s=this._iv,d=this._keystream;s&&(d=this._keystream=s.slice(0),this._iv=void 0),l.encryptBlock(d,0);for(var y=0;y<v;y++)i[b+y]^=d[y]}});return r.Decryptor=n,r})(),a.mode.OFB})})(ot)),ot.exports}var lt={exports:{}},Oa=lt.exports,_0;function Ua(){return _0||(_0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),X())})(Oa,function(a){return a.mode.ECB=(function(){var r=a.lib.BlockCipherMode.extend();return r.Encryptor=r.extend({processBlock:function(n,i){this._cipher.encryptBlock(n,i)}}),r.Decryptor=r.extend({processBlock:function(n,i){this._cipher.decryptBlock(n,i)}}),r})(),a.mode.ECB})})(lt)),lt.exports}var ct={exports:{}},Wa=ct.exports,k0;function Ka(){return k0||(k0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),X())})(Wa,function(a){return a.pad.AnsiX923={pad:function(r,n){var i=r.sigBytes,b=n*4,l=b-i%b,v=i+l-1;r.clamp(),r.words[v>>>2]|=l<<24-v%4*8,r.sigBytes+=l},unpad:function(r){var n=r.words[r.sigBytes-1>>>2]&255;r.sigBytes-=n}},a.pad.Ansix923})})(ct)),ct.exports}var dt={exports:{}},Ga=dt.exports,F0;function Xa(){return F0||(F0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),X())})(Ga,function(a){return a.pad.Iso10126={pad:function(r,n){var i=n*4,b=i-r.sigBytes%i;r.concat(a.lib.WordArray.random(b-1)).concat(a.lib.WordArray.create([b<<24],1))},unpad:function(r){var n=r.words[r.sigBytes-1>>>2]&255;r.sigBytes-=n}},a.pad.Iso10126})})(dt)),dt.exports}var xt={exports:{}},Va=xt.exports,S0;function Ya(){return S0||(S0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),X())})(Va,function(a){return a.pad.Iso97971={pad:function(r,n){r.concat(a.lib.WordArray.create([2147483648],1)),a.pad.ZeroPadding.pad(r,n)},unpad:function(r){a.pad.ZeroPadding.unpad(r),r.sigBytes--}},a.pad.Iso97971})})(xt)),xt.exports}var pt={exports:{}},Qa=pt.exports,L0;function Za(){return L0||(L0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),X())})(Qa,function(a){return a.pad.ZeroPadding={pad:function(r,n){var i=n*4;r.clamp(),r.sigBytes+=i-(r.sigBytes%i||i)},unpad:function(r){for(var n=r.words,i=r.sigBytes-1,i=r.sigBytes-1;i>=0;i--)if(n[i>>>2]>>>24-i%4*8&255){r.sigBytes=i+1;break}}},a.pad.ZeroPadding})})(pt)),pt.exports}var ut={exports:{}},Ja=ut.exports,q0;function en(){return q0||(q0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),X())})(Ja,function(a){return a.pad.NoPadding={pad:function(){},unpad:function(){}},a.pad.NoPadding})})(ut)),ut.exports}var ft={exports:{}},tn=ft.exports,$0;function rn(){return $0||($0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),X())})(tn,function(a){return(function(r){var n=a,i=n.lib,b=i.CipherParams,l=n.enc,v=l.Hex,s=n.format;s.Hex={stringify:function(d){return d.ciphertext.toString(v)},parse:function(d){var y=v.parse(d);return b.create({ciphertext:y})}}})(),a.format.Hex})})(ft)),ft.exports}var vt={exports:{}},an=vt.exports,P0;function nn(){return P0||(P0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),he(),me(),fe(),X())})(an,function(a){return(function(){var r=a,n=r.lib,i=n.BlockCipher,b=r.algo,l=[],v=[],s=[],d=[],y=[],o=[],x=[],f=[],g=[],m=[];(function(){for(var p=[],h=0;h<256;h++)h<128?p[h]=h<<1:p[h]=h<<1^283;for(var C=0,w=0,h=0;h<256;h++){var E=w^w<<1^w<<2^w<<3^w<<4;E=E>>>8^E&255^99,l[C]=E,v[E]=C;var D=p[C],_=p[D],B=p[_],A=p[E]*257^E*16843008;s[C]=A<<24|A>>>8,d[C]=A<<16|A>>>16,y[C]=A<<8|A>>>24,o[C]=A;var A=B*16843009^_*65537^D*257^C*16843008;x[E]=A<<24|A>>>8,f[E]=A<<16|A>>>16,g[E]=A<<8|A>>>24,m[E]=A,C?(C=D^p[p[p[B^D]]],w^=p[p[w]]):C=w=1}})();var u=[0,1,2,4,8,16,32,64,128,27,54],c=b.AES=i.extend({_doReset:function(){var p;if(!(this._nRounds&&this._keyPriorReset===this._key)){for(var h=this._keyPriorReset=this._key,C=h.words,w=h.sigBytes/4,E=this._nRounds=w+6,D=(E+1)*4,_=this._keySchedule=[],B=0;B<D;B++)B<w?_[B]=C[B]:(p=_[B-1],B%w?w>6&&B%w==4&&(p=l[p>>>24]<<24|l[p>>>16&255]<<16|l[p>>>8&255]<<8|l[p&255]):(p=p<<8|p>>>24,p=l[p>>>24]<<24|l[p>>>16&255]<<16|l[p>>>8&255]<<8|l[p&255],p^=u[B/w|0]<<24),_[B]=_[B-w]^p);for(var A=this._invKeySchedule=[],k=0;k<D;k++){var B=D-k;if(k%4)var p=_[B];else var p=_[B-4];k<4||B<=4?A[k]=p:A[k]=x[l[p>>>24]]^f[l[p>>>16&255]]^g[l[p>>>8&255]]^m[l[p&255]]}}},encryptBlock:function(p,h){this._doCryptBlock(p,h,this._keySchedule,s,d,y,o,l)},decryptBlock:function(p,h){var C=p[h+1];p[h+1]=p[h+3],p[h+3]=C,this._doCryptBlock(p,h,this._invKeySchedule,x,f,g,m,v);var C=p[h+1];p[h+1]=p[h+3],p[h+3]=C},_doCryptBlock:function(p,h,C,w,E,D,_,B){for(var A=this._nRounds,k=p[h]^C[0],F=p[h+1]^C[1],H=p[h+2]^C[2],z=p[h+3]^C[3],R=4,K=1;K<A;K++){var j=w[k>>>24]^E[F>>>16&255]^D[H>>>8&255]^_[z&255]^C[R++],U=w[F>>>24]^E[H>>>16&255]^D[z>>>8&255]^_[k&255]^C[R++],O=w[H>>>24]^E[z>>>16&255]^D[k>>>8&255]^_[F&255]^C[R++],S=w[z>>>24]^E[k>>>16&255]^D[F>>>8&255]^_[H&255]^C[R++];k=j,F=U,H=O,z=S}var j=(B[k>>>24]<<24|B[F>>>16&255]<<16|B[H>>>8&255]<<8|B[z&255])^C[R++],U=(B[F>>>24]<<24|B[H>>>16&255]<<16|B[z>>>8&255]<<8|B[k&255])^C[R++],O=(B[H>>>24]<<24|B[z>>>16&255]<<16|B[k>>>8&255]<<8|B[F&255])^C[R++],S=(B[z>>>24]<<24|B[k>>>16&255]<<16|B[F>>>8&255]<<8|B[H&255])^C[R++];p[h]=j,p[h+1]=U,p[h+2]=O,p[h+3]=S},keySize:256/32});r.AES=i._createHelper(c)})(),a.AES})})(vt)),vt.exports}var ht={exports:{}},sn=ht.exports,H0;function on(){return H0||(H0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),he(),me(),fe(),X())})(sn,function(a){return(function(){var r=a,n=r.lib,i=n.WordArray,b=n.BlockCipher,l=r.algo,v=[57,49,41,33,25,17,9,1,58,50,42,34,26,18,10,2,59,51,43,35,27,19,11,3,60,52,44,36,63,55,47,39,31,23,15,7,62,54,46,38,30,22,14,6,61,53,45,37,29,21,13,5,28,20,12,4],s=[14,17,11,24,1,5,3,28,15,6,21,10,23,19,12,4,26,8,16,7,27,20,13,2,41,52,31,37,47,55,30,40,51,45,33,48,44,49,39,56,34,53,46,42,50,36,29,32],d=[1,2,4,6,8,10,12,14,15,17,19,21,23,25,27,28],y=[{0:8421888,268435456:32768,536870912:8421378,805306368:2,1073741824:512,1342177280:8421890,1610612736:8389122,1879048192:8388608,2147483648:514,2415919104:8389120,2684354560:33280,2952790016:8421376,3221225472:32770,3489660928:8388610,3758096384:0,4026531840:33282,134217728:0,402653184:8421890,671088640:33282,939524096:32768,1207959552:8421888,1476395008:512,1744830464:8421378,2013265920:2,2281701376:8389120,2550136832:33280,2818572288:8421376,3087007744:8389122,3355443200:8388610,3623878656:32770,3892314112:514,4160749568:8388608,1:32768,268435457:2,536870913:8421888,805306369:8388608,1073741825:8421378,1342177281:33280,1610612737:512,1879048193:8389122,2147483649:8421890,2415919105:8421376,2684354561:8388610,2952790017:33282,3221225473:514,3489660929:8389120,3758096385:32770,4026531841:0,134217729:8421890,402653185:8421376,671088641:8388608,939524097:512,1207959553:32768,1476395009:8388610,1744830465:2,2013265921:33282,2281701377:32770,2550136833:8389122,2818572289:514,3087007745:8421888,3355443201:8389120,3623878657:0,3892314113:33280,4160749569:8421378},{0:1074282512,16777216:16384,33554432:524288,50331648:1074266128,67108864:1073741840,83886080:1074282496,100663296:1073758208,117440512:16,134217728:540672,150994944:1073758224,167772160:1073741824,184549376:540688,201326592:524304,218103808:0,234881024:16400,251658240:1074266112,8388608:1073758208,25165824:540688,41943040:16,58720256:1073758224,75497472:1074282512,92274688:1073741824,109051904:524288,125829120:1074266128,142606336:524304,159383552:0,176160768:16384,192937984:1074266112,209715200:1073741840,226492416:540672,243269632:1074282496,260046848:16400,268435456:0,285212672:1074266128,301989888:1073758224,318767104:1074282496,335544320:1074266112,352321536:16,369098752:540688,385875968:16384,402653184:16400,419430400:524288,436207616:524304,452984832:1073741840,469762048:540672,486539264:1073758208,503316480:1073741824,520093696:1074282512,276824064:540688,293601280:524288,310378496:1074266112,327155712:16384,343932928:1073758208,360710144:1074282512,377487360:16,394264576:1073741824,411041792:1074282496,427819008:1073741840,444596224:1073758224,461373440:524304,478150656:0,494927872:16400,511705088:1074266128,528482304:540672},{0:260,1048576:0,2097152:67109120,3145728:65796,4194304:65540,5242880:67108868,6291456:67174660,7340032:67174400,8388608:67108864,9437184:67174656,10485760:65792,11534336:67174404,12582912:67109124,13631488:65536,14680064:4,15728640:256,524288:67174656,1572864:67174404,2621440:0,3670016:67109120,4718592:67108868,5767168:65536,6815744:65540,7864320:260,8912896:4,9961472:256,11010048:67174400,12058624:65796,13107200:65792,14155776:67109124,15204352:67174660,16252928:67108864,16777216:67174656,17825792:65540,18874368:65536,19922944:67109120,20971520:256,22020096:67174660,23068672:67108868,24117248:0,25165824:67109124,26214400:67108864,27262976:4,28311552:65792,29360128:67174400,30408704:260,31457280:65796,32505856:67174404,17301504:67108864,18350080:260,19398656:67174656,20447232:0,21495808:65540,22544384:67109120,23592960:256,24641536:67174404,25690112:65536,26738688:67174660,27787264:65796,28835840:67108868,29884416:67109124,30932992:67174400,31981568:4,33030144:65792},{0:2151682048,65536:2147487808,131072:4198464,196608:2151677952,262144:0,327680:4198400,393216:2147483712,458752:4194368,524288:2147483648,589824:4194304,655360:64,720896:2147487744,786432:2151678016,851968:4160,917504:4096,983040:2151682112,32768:2147487808,98304:64,163840:2151678016,229376:2147487744,294912:4198400,360448:2151682112,425984:0,491520:2151677952,557056:4096,622592:2151682048,688128:4194304,753664:4160,819200:2147483648,884736:4194368,950272:4198464,1015808:2147483712,1048576:4194368,1114112:4198400,1179648:2147483712,1245184:0,1310720:4160,1376256:2151678016,1441792:2151682048,1507328:2147487808,1572864:2151682112,1638400:2147483648,1703936:2151677952,1769472:4198464,1835008:2147487744,1900544:4194304,1966080:64,2031616:4096,1081344:2151677952,1146880:2151682112,1212416:0,1277952:4198400,1343488:4194368,1409024:2147483648,1474560:2147487808,1540096:64,1605632:2147483712,1671168:4096,1736704:2147487744,1802240:2151678016,1867776:4160,1933312:2151682048,1998848:4194304,2064384:4198464},{0:128,4096:17039360,8192:262144,12288:536870912,16384:537133184,20480:16777344,24576:553648256,28672:262272,32768:16777216,36864:537133056,40960:536871040,45056:553910400,49152:553910272,53248:0,57344:17039488,61440:553648128,2048:17039488,6144:553648256,10240:128,14336:17039360,18432:262144,22528:537133184,26624:553910272,30720:536870912,34816:537133056,38912:0,43008:553910400,47104:16777344,51200:536871040,55296:553648128,59392:16777216,63488:262272,65536:262144,69632:128,73728:536870912,77824:553648256,81920:16777344,86016:553910272,90112:537133184,94208:16777216,98304:553910400,102400:553648128,106496:17039360,110592:537133056,114688:262272,118784:536871040,122880:0,126976:17039488,67584:553648256,71680:16777216,75776:17039360,79872:537133184,83968:536870912,88064:17039488,92160:128,96256:553910272,100352:262272,104448:553910400,108544:0,112640:553648128,116736:16777344,120832:262144,124928:537133056,129024:536871040},{0:268435464,256:8192,512:270532608,768:270540808,1024:268443648,1280:2097152,1536:2097160,1792:268435456,2048:0,2304:268443656,2560:2105344,2816:8,3072:270532616,3328:2105352,3584:8200,3840:270540800,128:270532608,384:270540808,640:8,896:2097152,1152:2105352,1408:268435464,1664:268443648,1920:8200,2176:2097160,2432:8192,2688:268443656,2944:270532616,3200:0,3456:270540800,3712:2105344,3968:268435456,4096:268443648,4352:270532616,4608:270540808,4864:8200,5120:2097152,5376:268435456,5632:268435464,5888:2105344,6144:2105352,6400:0,6656:8,6912:270532608,7168:8192,7424:268443656,7680:270540800,7936:2097160,4224:8,4480:2105344,4736:2097152,4992:268435464,5248:268443648,5504:8200,5760:270540808,6016:270532608,6272:270540800,6528:270532616,6784:8192,7040:2105352,7296:2097160,7552:0,7808:268435456,8064:268443656},{0:1048576,16:33555457,32:1024,48:1049601,64:34604033,80:0,96:1,112:34603009,128:33555456,144:1048577,160:33554433,176:34604032,192:34603008,208:1025,224:1049600,240:33554432,8:34603009,24:0,40:33555457,56:34604032,72:1048576,88:33554433,104:33554432,120:1025,136:1049601,152:33555456,168:34603008,184:1048577,200:1024,216:34604033,232:1,248:1049600,256:33554432,272:1048576,288:33555457,304:34603009,320:1048577,336:33555456,352:34604032,368:1049601,384:1025,400:34604033,416:1049600,432:1,448:0,464:34603008,480:33554433,496:1024,264:1049600,280:33555457,296:34603009,312:1,328:33554432,344:1048576,360:1025,376:34604032,392:33554433,408:34603008,424:0,440:34604033,456:1049601,472:1024,488:33555456,504:1048577},{0:134219808,1:131072,2:134217728,3:32,4:131104,5:134350880,6:134350848,7:2048,8:134348800,9:134219776,10:133120,11:134348832,12:2080,13:0,14:134217760,15:133152,2147483648:2048,2147483649:134350880,2147483650:134219808,2147483651:134217728,2147483652:134348800,2147483653:133120,2147483654:133152,2147483655:32,2147483656:134217760,2147483657:2080,2147483658:131104,2147483659:134350848,2147483660:0,2147483661:134348832,2147483662:134219776,2147483663:131072,16:133152,17:134350848,18:32,19:2048,20:134219776,21:134217760,22:134348832,23:131072,24:0,25:131104,26:134348800,27:134219808,28:134350880,29:133120,30:2080,31:134217728,2147483664:131072,2147483665:2048,2147483666:134348832,2147483667:133152,2147483668:32,2147483669:134348800,2147483670:134217728,2147483671:134219808,2147483672:134350880,2147483673:134217760,2147483674:134219776,2147483675:0,2147483676:133120,2147483677:2080,2147483678:131104,2147483679:134350848}],o=[4160749569,528482304,33030144,2064384,129024,8064,504,2147483679],x=l.DES=b.extend({_doReset:function(){for(var u=this._key,c=u.words,p=[],h=0;h<56;h++){var C=v[h]-1;p[h]=c[C>>>5]>>>31-C%32&1}for(var w=this._subKeys=[],E=0;E<16;E++){for(var D=w[E]=[],_=d[E],h=0;h<24;h++)D[h/6|0]|=p[(s[h]-1+_)%28]<<31-h%6,D[4+(h/6|0)]|=p[28+(s[h+24]-1+_)%28]<<31-h%6;D[0]=D[0]<<1|D[0]>>>31;for(var h=1;h<7;h++)D[h]=D[h]>>>(h-1)*4+3;D[7]=D[7]<<5|D[7]>>>27}for(var B=this._invSubKeys=[],h=0;h<16;h++)B[h]=w[15-h]},encryptBlock:function(u,c){this._doCryptBlock(u,c,this._subKeys)},decryptBlock:function(u,c){this._doCryptBlock(u,c,this._invSubKeys)},_doCryptBlock:function(u,c,p){this._lBlock=u[c],this._rBlock=u[c+1],f.call(this,4,252645135),f.call(this,16,65535),g.call(this,2,858993459),g.call(this,8,16711935),f.call(this,1,1431655765);for(var h=0;h<16;h++){for(var C=p[h],w=this._lBlock,E=this._rBlock,D=0,_=0;_<8;_++)D|=y[_][((E^C[_])&o[_])>>>0];this._lBlock=E,this._rBlock=w^D}var B=this._lBlock;this._lBlock=this._rBlock,this._rBlock=B,f.call(this,1,1431655765),g.call(this,8,16711935),g.call(this,2,858993459),f.call(this,16,65535),f.call(this,4,252645135),u[c]=this._lBlock,u[c+1]=this._rBlock},keySize:64/32,ivSize:64/32,blockSize:64/32});function f(u,c){var p=(this._lBlock>>>u^this._rBlock)&c;this._rBlock^=p,this._lBlock^=p<<u}function g(u,c){var p=(this._rBlock>>>u^this._lBlock)&c;this._lBlock^=p,this._rBlock^=p<<u}r.DES=b._createHelper(x);var m=l.TripleDES=b.extend({_doReset:function(){var u=this._key,c=u.words;if(c.length!==2&&c.length!==4&&c.length<6)throw new Error("Invalid key length - 3DES requires the key length to be 64, 128, 192 or >192.");var p=c.slice(0,2),h=c.length<4?c.slice(0,2):c.slice(2,4),C=c.length<6?c.slice(0,2):c.slice(4,6);this._des1=x.createEncryptor(i.create(p)),this._des2=x.createEncryptor(i.create(h)),this._des3=x.createEncryptor(i.create(C))},encryptBlock:function(u,c){this._des1.encryptBlock(u,c),this._des2.decryptBlock(u,c),this._des3.encryptBlock(u,c)},decryptBlock:function(u,c){this._des3.decryptBlock(u,c),this._des2.encryptBlock(u,c),this._des1.decryptBlock(u,c)},keySize:192/32,ivSize:64/32,blockSize:64/32});r.TripleDES=b._createHelper(m)})(),a.TripleDES})})(ht)),ht.exports}var mt={exports:{}},ln=mt.exports,z0;function cn(){return z0||(z0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),he(),me(),fe(),X())})(ln,function(a){return(function(){var r=a,n=r.lib,i=n.StreamCipher,b=r.algo,l=b.RC4=i.extend({_doReset:function(){for(var d=this._key,y=d.words,o=d.sigBytes,x=this._S=[],f=0;f<256;f++)x[f]=f;for(var f=0,g=0;f<256;f++){var m=f%o,u=y[m>>>2]>>>24-m%4*8&255;g=(g+x[f]+u)%256;var c=x[f];x[f]=x[g],x[g]=c}this._i=this._j=0},_doProcessBlock:function(d,y){d[y]^=v.call(this)},keySize:256/32,ivSize:0});function v(){for(var d=this._S,y=this._i,o=this._j,x=0,f=0;f<4;f++){y=(y+1)%256,o=(o+d[y])%256;var g=d[y];d[y]=d[o],d[o]=g,x|=d[(d[y]+d[o])%256]<<24-f*8}return this._i=y,this._j=o,x}r.RC4=i._createHelper(l);var s=b.RC4Drop=l.extend({cfg:l.cfg.extend({drop:192}),_doReset:function(){l._doReset.call(this);for(var d=this.cfg.drop;d>0;d--)v.call(this)}});r.RC4Drop=i._createHelper(s)})(),a.RC4})})(mt)),mt.exports}var gt={exports:{}},dn=gt.exports,T0;function xn(){return T0||(T0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),he(),me(),fe(),X())})(dn,function(a){return(function(){var r=a,n=r.lib,i=n.StreamCipher,b=r.algo,l=[],v=[],s=[],d=b.Rabbit=i.extend({_doReset:function(){for(var o=this._key.words,x=this.cfg.iv,f=0;f<4;f++)o[f]=(o[f]<<8|o[f]>>>24)&16711935|(o[f]<<24|o[f]>>>8)&4278255360;var g=this._X=[o[0],o[3]<<16|o[2]>>>16,o[1],o[0]<<16|o[3]>>>16,o[2],o[1]<<16|o[0]>>>16,o[3],o[2]<<16|o[1]>>>16],m=this._C=[o[2]<<16|o[2]>>>16,o[0]&4294901760|o[1]&65535,o[3]<<16|o[3]>>>16,o[1]&4294901760|o[2]&65535,o[0]<<16|o[0]>>>16,o[2]&4294901760|o[3]&65535,o[1]<<16|o[1]>>>16,o[3]&4294901760|o[0]&65535];this._b=0;for(var f=0;f<4;f++)y.call(this);for(var f=0;f<8;f++)m[f]^=g[f+4&7];if(x){var u=x.words,c=u[0],p=u[1],h=(c<<8|c>>>24)&16711935|(c<<24|c>>>8)&4278255360,C=(p<<8|p>>>24)&16711935|(p<<24|p>>>8)&4278255360,w=h>>>16|C&4294901760,E=C<<16|h&65535;m[0]^=h,m[1]^=w,m[2]^=C,m[3]^=E,m[4]^=h,m[5]^=w,m[6]^=C,m[7]^=E;for(var f=0;f<4;f++)y.call(this)}},_doProcessBlock:function(o,x){var f=this._X;y.call(this),l[0]=f[0]^f[5]>>>16^f[3]<<16,l[1]=f[2]^f[7]>>>16^f[5]<<16,l[2]=f[4]^f[1]>>>16^f[7]<<16,l[3]=f[6]^f[3]>>>16^f[1]<<16;for(var g=0;g<4;g++)l[g]=(l[g]<<8|l[g]>>>24)&16711935|(l[g]<<24|l[g]>>>8)&4278255360,o[x+g]^=l[g]},blockSize:128/32,ivSize:64/32});function y(){for(var o=this._X,x=this._C,f=0;f<8;f++)v[f]=x[f];x[0]=x[0]+1295307597+this._b|0,x[1]=x[1]+3545052371+(x[0]>>>0<v[0]>>>0?1:0)|0,x[2]=x[2]+886263092+(x[1]>>>0<v[1]>>>0?1:0)|0,x[3]=x[3]+1295307597+(x[2]>>>0<v[2]>>>0?1:0)|0,x[4]=x[4]+3545052371+(x[3]>>>0<v[3]>>>0?1:0)|0,x[5]=x[5]+886263092+(x[4]>>>0<v[4]>>>0?1:0)|0,x[6]=x[6]+1295307597+(x[5]>>>0<v[5]>>>0?1:0)|0,x[7]=x[7]+3545052371+(x[6]>>>0<v[6]>>>0?1:0)|0,this._b=x[7]>>>0<v[7]>>>0?1:0;for(var f=0;f<8;f++){var g=o[f]+x[f],m=g&65535,u=g>>>16,c=((m*m>>>17)+m*u>>>15)+u*u,p=((g&4294901760)*g|0)+((g&65535)*g|0);s[f]=c^p}o[0]=s[0]+(s[7]<<16|s[7]>>>16)+(s[6]<<16|s[6]>>>16)|0,o[1]=s[1]+(s[0]<<8|s[0]>>>24)+s[7]|0,o[2]=s[2]+(s[1]<<16|s[1]>>>16)+(s[0]<<16|s[0]>>>16)|0,o[3]=s[3]+(s[2]<<8|s[2]>>>24)+s[1]|0,o[4]=s[4]+(s[3]<<16|s[3]>>>16)+(s[2]<<16|s[2]>>>16)|0,o[5]=s[5]+(s[4]<<8|s[4]>>>24)+s[3]|0,o[6]=s[6]+(s[5]<<16|s[5]>>>16)+(s[4]<<16|s[4]>>>16)|0,o[7]=s[7]+(s[6]<<8|s[6]>>>24)+s[5]|0}r.Rabbit=i._createHelper(d)})(),a.Rabbit})})(gt)),gt.exports}var yt={exports:{}},pn=yt.exports,R0;function un(){return R0||(R0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),he(),me(),fe(),X())})(pn,function(a){return(function(){var r=a,n=r.lib,i=n.StreamCipher,b=r.algo,l=[],v=[],s=[],d=b.RabbitLegacy=i.extend({_doReset:function(){var o=this._key.words,x=this.cfg.iv,f=this._X=[o[0],o[3]<<16|o[2]>>>16,o[1],o[0]<<16|o[3]>>>16,o[2],o[1]<<16|o[0]>>>16,o[3],o[2]<<16|o[1]>>>16],g=this._C=[o[2]<<16|o[2]>>>16,o[0]&4294901760|o[1]&65535,o[3]<<16|o[3]>>>16,o[1]&4294901760|o[2]&65535,o[0]<<16|o[0]>>>16,o[2]&4294901760|o[3]&65535,o[1]<<16|o[1]>>>16,o[3]&4294901760|o[0]&65535];this._b=0;for(var m=0;m<4;m++)y.call(this);for(var m=0;m<8;m++)g[m]^=f[m+4&7];if(x){var u=x.words,c=u[0],p=u[1],h=(c<<8|c>>>24)&16711935|(c<<24|c>>>8)&4278255360,C=(p<<8|p>>>24)&16711935|(p<<24|p>>>8)&4278255360,w=h>>>16|C&4294901760,E=C<<16|h&65535;g[0]^=h,g[1]^=w,g[2]^=C,g[3]^=E,g[4]^=h,g[5]^=w,g[6]^=C,g[7]^=E;for(var m=0;m<4;m++)y.call(this)}},_doProcessBlock:function(o,x){var f=this._X;y.call(this),l[0]=f[0]^f[5]>>>16^f[3]<<16,l[1]=f[2]^f[7]>>>16^f[5]<<16,l[2]=f[4]^f[1]>>>16^f[7]<<16,l[3]=f[6]^f[3]>>>16^f[1]<<16;for(var g=0;g<4;g++)l[g]=(l[g]<<8|l[g]>>>24)&16711935|(l[g]<<24|l[g]>>>8)&4278255360,o[x+g]^=l[g]},blockSize:128/32,ivSize:64/32});function y(){for(var o=this._X,x=this._C,f=0;f<8;f++)v[f]=x[f];x[0]=x[0]+1295307597+this._b|0,x[1]=x[1]+3545052371+(x[0]>>>0<v[0]>>>0?1:0)|0,x[2]=x[2]+886263092+(x[1]>>>0<v[1]>>>0?1:0)|0,x[3]=x[3]+1295307597+(x[2]>>>0<v[2]>>>0?1:0)|0,x[4]=x[4]+3545052371+(x[3]>>>0<v[3]>>>0?1:0)|0,x[5]=x[5]+886263092+(x[4]>>>0<v[4]>>>0?1:0)|0,x[6]=x[6]+1295307597+(x[5]>>>0<v[5]>>>0?1:0)|0,x[7]=x[7]+3545052371+(x[6]>>>0<v[6]>>>0?1:0)|0,this._b=x[7]>>>0<v[7]>>>0?1:0;for(var f=0;f<8;f++){var g=o[f]+x[f],m=g&65535,u=g>>>16,c=((m*m>>>17)+m*u>>>15)+u*u,p=((g&4294901760)*g|0)+((g&65535)*g|0);s[f]=c^p}o[0]=s[0]+(s[7]<<16|s[7]>>>16)+(s[6]<<16|s[6]>>>16)|0,o[1]=s[1]+(s[0]<<8|s[0]>>>24)+s[7]|0,o[2]=s[2]+(s[1]<<16|s[1]>>>16)+(s[0]<<16|s[0]>>>16)|0,o[3]=s[3]+(s[2]<<8|s[2]>>>24)+s[1]|0,o[4]=s[4]+(s[3]<<16|s[3]>>>16)+(s[2]<<16|s[2]>>>16)|0,o[5]=s[5]+(s[4]<<8|s[4]>>>24)+s[3]|0,o[6]=s[6]+(s[5]<<16|s[5]>>>16)+(s[4]<<16|s[4]>>>16)|0,o[7]=s[7]+(s[6]<<8|s[6]>>>24)+s[5]|0}r.RabbitLegacy=i._createHelper(d)})(),a.RabbitLegacy})})(yt)),yt.exports}var bt={exports:{}},fn=bt.exports,M0;function vn(){return M0||(M0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),he(),me(),fe(),X())})(fn,function(a){return(function(){var r=a,n=r.lib,i=n.BlockCipher,b=r.algo;const l=16,v=[608135816,2242054355,320440878,57701188,2752067618,698298832,137296536,3964562569,1160258022,953160567,3193202383,887688300,3232508343,3380367581,1065670069,3041331479,2450970073,2306472731],s=[[3509652390,2564797868,805139163,3491422135,3101798381,1780907670,3128725573,4046225305,614570311,3012652279,134345442,2240740374,1667834072,1901547113,2757295779,4103290238,227898511,1921955416,1904987480,2182433518,2069144605,3260701109,2620446009,720527379,3318853667,677414384,3393288472,3101374703,2390351024,1614419982,1822297739,2954791486,3608508353,3174124327,2024746970,1432378464,3864339955,2857741204,1464375394,1676153920,1439316330,715854006,3033291828,289532110,2706671279,2087905683,3018724369,1668267050,732546397,1947742710,3462151702,2609353502,2950085171,1814351708,2050118529,680887927,999245976,1800124847,3300911131,1713906067,1641548236,4213287313,1216130144,1575780402,4018429277,3917837745,3693486850,3949271944,596196993,3549867205,258830323,2213823033,772490370,2760122372,1774776394,2652871518,566650946,4142492826,1728879713,2882767088,1783734482,3629395816,2517608232,2874225571,1861159788,326777828,3124490320,2130389656,2716951837,967770486,1724537150,2185432712,2364442137,1164943284,2105845187,998989502,3765401048,2244026483,1075463327,1455516326,1322494562,910128902,469688178,1117454909,936433444,3490320968,3675253459,1240580251,122909385,2157517691,634681816,4142456567,3825094682,3061402683,2540495037,79693498,3249098678,1084186820,1583128258,426386531,1761308591,1047286709,322548459,995290223,1845252383,2603652396,3431023940,2942221577,3202600964,3727903485,1712269319,422464435,3234572375,1170764815,3523960633,3117677531,1434042557,442511882,3600875718,1076654713,1738483198,4213154764,2393238008,3677496056,1014306527,4251020053,793779912,2902807211,842905082,4246964064,1395751752,1040244610,2656851899,3396308128,445077038,3742853595,3577915638,679411651,2892444358,2354009459,1767581616,3150600392,3791627101,3102740896,284835224,4246832056,1258075500,768725851,2589189241,3069724005,3532540348,1274779536,3789419226,2764799539,1660621633,3471099624,4011903706,913787905,3497959166,737222580,2514213453,2928710040,3937242737,1804850592,3499020752,2949064160,2386320175,2390070455,2415321851,4061277028,2290661394,2416832540,1336762016,1754252060,3520065937,3014181293,791618072,3188594551,3933548030,2332172193,3852520463,3043980520,413987798,3465142937,3030929376,4245938359,2093235073,3534596313,375366246,2157278981,2479649556,555357303,3870105701,2008414854,3344188149,4221384143,3956125452,2067696032,3594591187,2921233993,2428461,544322398,577241275,1471733935,610547355,4027169054,1432588573,1507829418,2025931657,3646575487,545086370,48609733,2200306550,1653985193,298326376,1316178497,3007786442,2064951626,458293330,2589141269,3591329599,3164325604,727753846,2179363840,146436021,1461446943,4069977195,705550613,3059967265,3887724982,4281599278,3313849956,1404054877,2845806497,146425753,1854211946],[1266315497,3048417604,3681880366,3289982499,290971e4,1235738493,2632868024,2414719590,3970600049,1771706367,1449415276,3266420449,422970021,1963543593,2690192192,3826793022,1062508698,1531092325,1804592342,2583117782,2714934279,4024971509,1294809318,4028980673,1289560198,2221992742,1669523910,35572830,157838143,1052438473,1016535060,1802137761,1753167236,1386275462,3080475397,2857371447,1040679964,2145300060,2390574316,1461121720,2956646967,4031777805,4028374788,33600511,2920084762,1018524850,629373528,3691585981,3515945977,2091462646,2486323059,586499841,988145025,935516892,3367335476,2599673255,2839830854,265290510,3972581182,2759138881,3795373465,1005194799,847297441,406762289,1314163512,1332590856,1866599683,4127851711,750260880,613907577,1450815602,3165620655,3734664991,3650291728,3012275730,3704569646,1427272223,778793252,1343938022,2676280711,2052605720,1946737175,3164576444,3914038668,3967478842,3682934266,1661551462,3294938066,4011595847,840292616,3712170807,616741398,312560963,711312465,1351876610,322626781,1910503582,271666773,2175563734,1594956187,70604529,3617834859,1007753275,1495573769,4069517037,2549218298,2663038764,504708206,2263041392,3941167025,2249088522,1514023603,1998579484,1312622330,694541497,2582060303,2151582166,1382467621,776784248,2618340202,3323268794,2497899128,2784771155,503983604,4076293799,907881277,423175695,432175456,1378068232,4145222326,3954048622,3938656102,3820766613,2793130115,2977904593,26017576,3274890735,3194772133,1700274565,1756076034,4006520079,3677328699,720338349,1533947780,354530856,688349552,3973924725,1637815568,332179504,3949051286,53804574,2852348879,3044236432,1282449977,3583942155,3416972820,4006381244,1617046695,2628476075,3002303598,1686838959,431878346,2686675385,1700445008,1080580658,1009431731,832498133,3223435511,2605976345,2271191193,2516031870,1648197032,4164389018,2548247927,300782431,375919233,238389289,3353747414,2531188641,2019080857,1475708069,455242339,2609103871,448939670,3451063019,1395535956,2413381860,1841049896,1491858159,885456874,4264095073,4001119347,1565136089,3898914787,1108368660,540939232,1173283510,2745871338,3681308437,4207628240,3343053890,4016749493,1699691293,1103962373,3625875870,2256883143,3830138730,1031889488,3479347698,1535977030,4236805024,3251091107,2132092099,1774941330,1199868427,1452454533,157007616,2904115357,342012276,595725824,1480756522,206960106,497939518,591360097,863170706,2375253569,3596610801,1814182875,2094937945,3421402208,1082520231,3463918190,2785509508,435703966,3908032597,1641649973,2842273706,3305899714,1510255612,2148256476,2655287854,3276092548,4258621189,236887753,3681803219,274041037,1734335097,3815195456,3317970021,1899903192,1026095262,4050517792,356393447,2410691914,3873677099,3682840055],[3913112168,2491498743,4132185628,2489919796,1091903735,1979897079,3170134830,3567386728,3557303409,857797738,1136121015,1342202287,507115054,2535736646,337727348,3213592640,1301675037,2528481711,1895095763,1721773893,3216771564,62756741,2142006736,835421444,2531993523,1442658625,3659876326,2882144922,676362277,1392781812,170690266,3921047035,1759253602,3611846912,1745797284,664899054,1329594018,3901205900,3045908486,2062866102,2865634940,3543621612,3464012697,1080764994,553557557,3656615353,3996768171,991055499,499776247,1265440854,648242737,3940784050,980351604,3713745714,1749149687,3396870395,4211799374,3640570775,1161844396,3125318951,1431517754,545492359,4268468663,3499529547,1437099964,2702547544,3433638243,2581715763,2787789398,1060185593,1593081372,2418618748,4260947970,69676912,2159744348,86519011,2512459080,3838209314,1220612927,3339683548,133810670,1090789135,1078426020,1569222167,845107691,3583754449,4072456591,1091646820,628848692,1613405280,3757631651,526609435,236106946,48312990,2942717905,3402727701,1797494240,859738849,992217954,4005476642,2243076622,3870952857,3732016268,765654824,3490871365,2511836413,1685915746,3888969200,1414112111,2273134842,3281911079,4080962846,172450625,2569994100,980381355,4109958455,2819808352,2716589560,2568741196,3681446669,3329971472,1835478071,660984891,3704678404,4045999559,3422617507,3040415634,1762651403,1719377915,3470491036,2693910283,3642056355,3138596744,1364962596,2073328063,1983633131,926494387,3423689081,2150032023,4096667949,1749200295,3328846651,309677260,2016342300,1779581495,3079819751,111262694,1274766160,443224088,298511866,1025883608,3806446537,1145181785,168956806,3641502830,3584813610,1689216846,3666258015,3200248200,1692713982,2646376535,4042768518,1618508792,1610833997,3523052358,4130873264,2001055236,3610705100,2202168115,4028541809,2961195399,1006657119,2006996926,3186142756,1430667929,3210227297,1314452623,4074634658,4101304120,2273951170,1399257539,3367210612,3027628629,1190975929,2062231137,2333990788,2221543033,2438960610,1181637006,548689776,2362791313,3372408396,3104550113,3145860560,296247880,1970579870,3078560182,3769228297,1714227617,3291629107,3898220290,166772364,1251581989,493813264,448347421,195405023,2709975567,677966185,3703036547,1463355134,2715995803,1338867538,1343315457,2802222074,2684532164,233230375,2599980071,2000651841,3277868038,1638401717,4028070440,3237316320,6314154,819756386,300326615,590932579,1405279636,3267499572,3150704214,2428286686,3959192993,3461946742,1862657033,1266418056,963775037,2089974820,2263052895,1917689273,448879540,3550394620,3981727096,150775221,3627908307,1303187396,508620638,2975983352,2726630617,1817252668,1876281319,1457606340,908771278,3720792119,3617206836,2455994898,1729034894,1080033504],[976866871,3556439503,2881648439,1522871579,1555064734,1336096578,3548522304,2579274686,3574697629,3205460757,3593280638,3338716283,3079412587,564236357,2993598910,1781952180,1464380207,3163844217,3332601554,1699332808,1393555694,1183702653,3581086237,1288719814,691649499,2847557200,2895455976,3193889540,2717570544,1781354906,1676643554,2592534050,3230253752,1126444790,2770207658,2633158820,2210423226,2615765581,2414155088,3127139286,673620729,2805611233,1269405062,4015350505,3341807571,4149409754,1057255273,2012875353,2162469141,2276492801,2601117357,993977747,3918593370,2654263191,753973209,36408145,2530585658,25011837,3520020182,2088578344,530523599,2918365339,1524020338,1518925132,3760827505,3759777254,1202760957,3985898139,3906192525,674977740,4174734889,2031300136,2019492241,3983892565,4153806404,3822280332,352677332,2297720250,60907813,90501309,3286998549,1016092578,2535922412,2839152426,457141659,509813237,4120667899,652014361,1966332200,2975202805,55981186,2327461051,676427537,3255491064,2882294119,3433927263,1307055953,942726286,933058658,2468411793,3933900994,4215176142,1361170020,2001714738,2830558078,3274259782,1222529897,1679025792,2729314320,3714953764,1770335741,151462246,3013232138,1682292957,1483529935,471910574,1539241949,458788160,3436315007,1807016891,3718408830,978976581,1043663428,3165965781,1927990952,4200891579,2372276910,3208408903,3533431907,1412390302,2931980059,4132332400,1947078029,3881505623,4168226417,2941484381,1077988104,1320477388,886195818,18198404,3786409e3,2509781533,112762804,3463356488,1866414978,891333506,18488651,661792760,1628790961,3885187036,3141171499,876946877,2693282273,1372485963,791857591,2686433993,3759982718,3167212022,3472953795,2716379847,445679433,3561995674,3504004811,3574258232,54117162,3331405415,2381918588,3769707343,4154350007,1140177722,4074052095,668550556,3214352940,367459370,261225585,2610173221,4209349473,3468074219,3265815641,314222801,3066103646,3808782860,282218597,3406013506,3773591054,379116347,1285071038,846784868,2669647154,3771962079,3550491691,2305946142,453669953,1268987020,3317592352,3279303384,3744833421,2610507566,3859509063,266596637,3847019092,517658769,3462560207,3443424879,370717030,4247526661,2224018117,4143653529,4112773975,2788324899,2477274417,1456262402,2901442914,1517677493,1846949527,2295493580,3734397586,2176403920,1280348187,1908823572,3871786941,846861322,1172426758,3287448474,3383383037,1655181056,3139813346,901632758,1897031941,2986607138,3066810236,3447102507,1393639104,373351379,950779232,625454576,3124240540,4148612726,2007998917,544563296,2244738638,2330496472,2058025392,1291430526,424198748,50039436,29584100,3605783033,2429876329,2791104160,1057563949,3255363231,3075367218,3463963227,1469046755,985887462]];var d={pbox:[],sbox:[]};function y(m,u){let c=u>>24&255,p=u>>16&255,h=u>>8&255,C=u&255,w=m.sbox[0][c]+m.sbox[1][p];return w=w^m.sbox[2][h],w=w+m.sbox[3][C],w}function o(m,u,c){let p=u,h=c,C;for(let w=0;w<l;++w)p=p^m.pbox[w],h=y(m,p)^h,C=p,p=h,h=C;return C=p,p=h,h=C,h=h^m.pbox[l],p=p^m.pbox[l+1],{left:p,right:h}}function x(m,u,c){let p=u,h=c,C;for(let w=l+1;w>1;--w)p=p^m.pbox[w],h=y(m,p)^h,C=p,p=h,h=C;return C=p,p=h,h=C,h=h^m.pbox[1],p=p^m.pbox[0],{left:p,right:h}}function f(m,u,c){for(let E=0;E<4;E++){m.sbox[E]=[];for(let D=0;D<256;D++)m.sbox[E][D]=s[E][D]}let p=0;for(let E=0;E<l+2;E++)m.pbox[E]=v[E]^u[p],p++,p>=c&&(p=0);let h=0,C=0,w=0;for(let E=0;E<l+2;E+=2)w=o(m,h,C),h=w.left,C=w.right,m.pbox[E]=h,m.pbox[E+1]=C;for(let E=0;E<4;E++)for(let D=0;D<256;D+=2)w=o(m,h,C),h=w.left,C=w.right,m.sbox[E][D]=h,m.sbox[E][D+1]=C;return!0}var g=b.Blowfish=i.extend({_doReset:function(){if(this._keyPriorReset!==this._key){var m=this._keyPriorReset=this._key,u=m.words,c=m.sigBytes/4;f(d,u,c)}},encryptBlock:function(m,u){var c=o(d,m[u],m[u+1]);m[u]=c.left,m[u+1]=c.right},decryptBlock:function(m,u){var c=x(d,m[u],m[u+1]);m[u]=c.left,m[u+1]=c.right},blockSize:64/32,keySize:128/32,ivSize:64/32});r.Blowfish=i._createHelper(g)})(),a.Blowfish})})(bt)),bt.exports}var hn=Me.exports,I0;function mn(){return I0||(I0=1,(function(e,t){(function(a,r,n){e.exports=r(N(),Bt(),pa(),fa(),he(),ma(),me(),rr(),zt(),wa(),ar(),Aa(),_a(),Fa(),Tt(),qa(),fe(),X(),za(),Ra(),Ia(),ja(),Ua(),Ka(),Xa(),Ya(),Za(),en(),rn(),nn(),on(),cn(),xn(),un(),vn())})(hn,function(a){return a})})(Me)),Me.exports}var gn=mn();const we=aa(gn),ne=wt.isNativePlatform(),yn="38346591",N0={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",Accept:"*/*","Accept-Language":"en-US,en;q=0.9,hi;q=0.8",Referer:"https://www.jiosaavn.com/"};async function ae(e){if(ne){const t=await Yr.get({url:e,headers:N0});if(t.status!==200)throw new Error(`HTTP ${t.status}`);return typeof t.data=="string"?t.data:JSON.stringify(t.data)}else{const t=await fetch(e,{headers:N0});if(!t.ok)throw new Error(`HTTP ${t.status}`);return await t.text()}}function j0(e){if(!e)return"";try{const t=we.enc.Utf8.parse(yn),a=we.enc.Base64.parse(e.trim());let n=we.DES.decrypt({ciphertext:a},t,{mode:we.mode.ECB,padding:we.pad.Pkcs7}).toString(we.enc.Utf8);return n?(n=n.replace("_96.mp4","_320.mp4"),n):""}catch(t){return console.error("Decrypt error:",t),""}}function oe(e){if(!e)return"";const t=document.createElement("textarea");return t.innerHTML=e,t.value}function Rt(e){var t,a,r,n;if(!e)return null;try{let i="";if(e.encrypted_media_url?(i=j0(e.encrypted_media_url),e["320kbps"]!=="true"&&(i=i.replace("_320.mp4","_160.mp4"))):(t=e.more_info)!=null&&t.encrypted_media_url?(i=j0(e.more_info.encrypted_media_url),e.more_info["320kbps"]!=="true"&&(i=i.replace("_320.mp4","_160.mp4"))):e.media_preview_url&&(i=e.media_preview_url.replace("preview.saavncdn.com","aac.saavncdn.com"),i=e["320kbps"]==="true"?i.replace("_96_p.mp4","_320.mp4"):i.replace("_96_p.mp4","_160.mp4")),!i)return null;let b=(e.image||"").replace(/150x150/g,"500x500").replace(/50x50/g,"500x500"),l=(e.image||"").replace(/500x500/g,"150x150").replace(/50x50/g,"150x150");return{id:e.id||"",title:oe(e.song||e.title||""),artist:oe(e.primary_artists||((a=e.more_info)==null?void 0:a.primary_artists)||e.singers||e.music||e.subtitle||""),album:oe(e.album||((r=e.more_info)==null?void 0:r.album)||""),duration:parseInt(e.duration||((n=e.more_info)==null?void 0:n.duration)||"0"),cover:b,coverSmall:l,url:i}}catch(i){return console.error("Format error:",i),null}}function Ct(e){const t=new Set,a=new Set;return e.filter(r=>{if(!r)return!1;const n=(r.cover||"").replace(/\d+x\d+/g,"SIZE").toLowerCase(),i=(r.title||"").toLowerCase().trim();return n&&t.has(n)&&a.has(i)?!1:(n&&t.add(n),i&&a.add(i),!0)})}const bn=(e,t,a)=>`https://www.jiosaavn.com/api.php?__call=search.getResults&_format=json&_marker=0&cc=in&p=${t}&n=${a}&q=${encodeURIComponent(e)}`,Cn="https://www.jiosaavn.com/api.php?__call=search.getAll&_format=json&_marker=0&cc=in&query=",wn="https://www.jiosaavn.com/api.php?__call=autocomplete.get&_format=json&_marker=0&cc=in&includeMetaTags=1&query=",nr="https://www.jiosaavn.com/api.php?__call=song.getDetails&cc=in&_marker=0&_format=json&pids=",En="https://www.jiosaavn.com/api.php?__call=playlist.getDetails&_format=json&_marker=0&cc=in&listid=";async function le(e,t=1,a=10){var r;try{if(console.log(`[${ne?"NATIVE":"WEB"}] Searching for: ${e} (Page ${t})`),ne){try{const y=(await ae(bn(e,t,a))).replace(/\(From "([^"]+)"\)/g,"(From '$1')"),o=JSON.parse(y),x=(o==null?void 0:o.results)||[];if(console.log(`search.getResults: ${x.length} results`),x.length>0){const f=x.map(g=>g.id).filter(Boolean).join(",");if(f){const g=await ae(nr+f),m=JSON.parse(g),u=Object.values(m).map(c=>Rt(c)).filter(c=>c&&c.url);if(u.length>0)return console.log(`Formatted ${u.length} full songs from IDs`),Ct(u)}}}catch(d){console.warn("search.getResults failed, trying autocomplete:",d.message)}const i=(await ae(wn+encodeURIComponent(e))).replace(/\(From "([^"]+)"\)/g,"(From '$1')"),b=JSON.parse(i),l=((r=b==null?void 0:b.songs)==null?void 0:r.data)||[];console.log(`Autocomplete fallback: ${l.length} IDs`);const v=l.map(d=>or(d.id)),s=await Promise.all(v);return Ct(s.filter(d=>d&&d.url))}else{const n=await fetch(`/api/search?q=${encodeURIComponent(e)}&page=${t}&limit=${a}`);if(!n.ok)return[];const i=await n.json();return Array.isArray(i)?Ct(i):[]}}catch(n){return console.error("Search failed:",n),[]}}async function sr(e){var t,a,r;try{if(!ne)return{songs:await le(e),playlists:[],albums:[]};const i=(await ae(Cn+encodeURIComponent(e))).replace(/\(From "([^"]+)"\)/g,"(From '$1')"),b=JSON.parse(i);let l=[];const v=((t=b==null?void 0:b.songs)==null?void 0:t.data)||[];v.length>0&&(l=v.map(x=>{var f;return{id:x.id||"",title:oe(x.title||""),artist:oe(x.description||((f=x.more_info)==null?void 0:f.primary_artists)||""),cover:(x.image||"").replace(/150x150/g,"500x500").replace(/50x50/g,"500x500"),coverSmall:(x.image||"").replace(/500x500/g,"150x150"),_needsDetail:!0}}).filter(x=>x.id));let s=[];const d=((a=b==null?void 0:b.playlists)==null?void 0:a.data)||[];d.length>0&&(s=d.map(x=>{var f;return{id:x.id||"",title:oe(x.title||""),description:oe(x.description||x.subtitle||""),cover:(x.image||"").replace(/150x150/g,"500x500").replace(/50x50/g,"500x500"),coverSmall:(x.image||"").replace(/500x500/g,"150x150"),songCount:((f=x.more_info)==null?void 0:f.song_count)||x.count||0,type:"playlist"}}).filter(x=>x.id));let y=[];const o=((r=b==null?void 0:b.albums)==null?void 0:r.data)||[];return o.length>0&&(y=o.map(x=>{var f;return{id:x.id||"",title:oe(x.title||""),artist:oe(x.description||x.music||((f=x.more_info)==null?void 0:f.music)||""),cover:(x.image||"").replace(/150x150/g,"500x500").replace(/50x50/g,"500x500"),coverSmall:(x.image||"").replace(/500x500/g,"150x150"),type:"album"}}).filter(x=>x.id)),{songs:l,playlists:s,albums:y}}catch(n){return console.error("searchAll failed:",n),{songs:[],playlists:[],albums:[]}}}async function ir(e){try{if(!ne)return[];const a=(await ae(En+e)).replace(/\(From "([^"]+)"\)/g,"(From '$1')"),r=JSON.parse(a),i=((r==null?void 0:r.songs)||(r==null?void 0:r.list)||[]).map(b=>Rt(b)).filter(b=>b&&b.url);return Ct(i)}catch(t){return console.error("Playlist fetch failed:",t),[]}}async function or(e){try{if(ne){const t=await ae(nr+e),r=JSON.parse(t)[e];return Rt(r)}else{const t=await fetch(`/api/song?id=${e}`);return t.ok?await t.json():null}}catch(t){return console.error("Get song failed:",t,e),null}}const Bn="https://api.lyrics.ovh/v1/";async function lr(e,t){if(!e||!t)return null;try{const a=e.split(",")[0].trim(),r=t.replace(/\s*\(.*?\)\s*/g,"").replace(/\s*\[.*?\]\s*/g,"").replace(/\s*-\s*.*$/,"").trim(),n=Bn+encodeURIComponent(a)+"/"+encodeURIComponent(r);let i="";if(ne){const b=await ae(n),l=JSON.parse(b);i=(l==null?void 0:l.lyrics)||""}else{const b=await fetch(n);if(!b.ok)return null;const l=await b.json();i=(l==null?void 0:l.lyrics)||""}return i.trim()||null}catch(a){return console.warn("Lyrics not found:",a.message),null}}const An="https://www.theaudiodb.com/api/v1/json/2/search.php?s=";async function cr(e){if(!e)return null;const t=e.split(",")[0].trim(),a=An+encodeURIComponent(t);try{let r;if(ne){const n=await ae(a);r=JSON.parse(n)}else{const n=await fetch(a);if(!n.ok)return null;r=await n.json()}if(r&&r.artists&&r.artists.length>0){const n=r.artists[0];return{name:n.strArtist||t,biography:n.strBiographyEN||"",thumbnail:n.strArtistThumb||"",logo:n.strArtistLogo||"",banner:n.strArtistBanner||n.strArtistThumb||"",genre:n.strGenre||"",country:n.strCountry||"",yearFormed:n.intFormedYear||""}}}catch(r){console.warn("Artist info fetch failed:",r.message)}return null}const Dn="https://itunes.apple.com/search?media=podcast&limit=15&term=";async function dr(e){if(!e)return[];try{const t=Dn+encodeURIComponent(e);let a;if(ne){const r=await ae(t);a=JSON.parse(r)}else{const r=await fetch(t);if(!r.ok)return[];a=await r.json()}if(a&&a.results)return a.results.map(r=>({id:r.collectionId,title:r.collectionName,artist:r.artistName,cover:r.artworkUrl600||r.artworkUrl100,feedUrl:r.feedUrl,genre:r.primaryGenreName,type:"podcast"})).filter(r=>r.feedUrl)}catch(t){console.error("Podcast search failed:",t)}return[]}async function xr(e,t,a){if(!e)return[];try{let r="";if(ne)r=await ae(e);else{const l=await fetch(e);if(!l.ok)return[];r=await l.text()}const i=new DOMParser().parseFromString(r,"text/xml");return Array.from(i.querySelectorAll("item")).slice(0,50).map((l,v)=>{var g,m,u;const s=((g=l.querySelector("title"))==null?void 0:g.textContent)||`Episode ${v+1}`,d=l.querySelector("enclosure"),y=d?d.getAttribute("url"):"",o=((m=l.querySelector("pubDate"))==null?void 0:m.textContent)||"",f=(((u=l.querySelector("description"))==null?void 0:u.textContent)||"").replace(/<[^>]+>/g," ").substring(0,150)+"...";return y?{id:`podcast_${btoa(y).substring(0,10)}_${v}`,title:oe(s),artist:a||"Podcast",cover:t,url:y,duration:0,type:"podcast_episode",date:o,description:f}:null}).filter(Boolean)}catch(r){console.error("Podcast feed fetch failed:",r)}return[]}const _n="https://musicbrainz.org/ws/2/artist/?fmt=json&query=";async function kn(e){if(!e)return[];const t=e.split(",")[0].trim(),a=_n+encodeURIComponent(t);try{const r={"User-Agent":"MeloMusicPlayer/1.0 (mahesh@example.com)"};let n=null;if(ne){const l=await ae(a),v=JSON.parse(l);v.artists&&v.artists.length>0&&(n=v.artists[0].id)}else{const l=await fetch(a,{headers:r});if(!l.ok)return[];const v=await l.json();v.artists&&v.artists.length>0&&(n=v.artists[0].id)}if(!n)return[];const i=`https://musicbrainz.org/ws/2/release-group?artist=${n}&fmt=json&limit=50`;let b;if(ne){const l=await ae(i);b=JSON.parse(l)}else{const l=await fetch(i,{headers:r});if(!l.ok)return[];b=await l.json()}if(b&&b["release-groups"]){const l=b["release-groups"],v=new Map;return l.forEach(s=>{if(!s.title||!s["first-release-date"])return;const d=s["first-release-date"].substring(0,4),y=s.title.toLowerCase().replace(/\\(.*\\)|\[.*\]/g,"").trim();v.has(y)||v.set(y,{id:s.id,title:s.title,type:s["primary-type"]||"Single",year:d,cover:`https://coverartarchive.org/release-group/${s.id}/front-250`})}),Array.from(v.values()).sort((s,d)=>parseInt(d.year)-parseInt(s.year))}}catch(r){console.error("MusicBrainz discography failed:",r)}return[]}const pr=Object.freeze(Object.defineProperty({__proto__:null,getArtistDiscography:kn,getArtistInfo:cr,getLyrics:lr,getPlaylistSongs:ir,getPodcastEpisodes:xr,getSongById:or,searchAll:sr,searchPodcasts:dr,searchSongs:le},Symbol.toStringTag,{value:"Module"})),Fn={pop:"latest pop hits",hiphop:"hip hop trending",rock:"rock hits",lofi:"lofi chill beats",electronic:"electronic dance",rnb:"r&b soul",jazz:"jazz classics",classical:"classical music",indie:"indie music",kpop:"kpop trending",bollywood:"bollywood latest songs",ambient:"ambient relax"};function Sn(){const e=document.createElement("div");e.className="page";const t=I.get(),a=new Date().getHours();let r="Good evening";a<12?r="Good morning":a<17&&(r="Good afternoon"),e.innerHTML=`
    <div class="home-header">
      <h1 class="text-greeting">${r} <span style="font-size: 14px; color: var(--accent); vertical-align: middle; margin-left: 10px;">v1.0.10</span></h1>
    </div>
    <div class="section" style="margin-top: var(--space-xl);">
      <div class="horizontal-scroll" id="home-chips"></div>
    </div>
    <div id="home-sections">
      <div class="home-loading">
        <div class="loading-spinner"></div>
        <p class="text-subtitle">Loading your music...</p>
      </div>
    </div>
  `;const n=e.querySelector("#home-chips"),i=document.createElement("button");i.className="chip active",i.textContent="For You",n.appendChild(i),(t.interests.length>0?t.interests:["bollywood","pop","lofi","hiphop"]).forEach(o=>{const x=$t.find(f=>f.id===o);if(x){const f=document.createElement("button");f.className="chip",f.textContent=x.name,f.dataset.genre=o,n.appendChild(f)}});let l=null;n.addEventListener("click",o=>{const x=o.target.closest(".chip");x&&(n.querySelectorAll(".chip").forEach(f=>f.classList.remove("active")),x.classList.add("active"),l=x.dataset.genre||null,s())});const v=e.querySelector("#home-sections");async function s(){var o;v.innerHTML=`
      <div class="home-loading">
        <div class="loading-spinner"></div>
        <p class="text-subtitle">Loading...</p>
      </div>
    `;try{if(l){const x=Fn[l]||l,f=await le(x);if(v.innerHTML="",f.length>0){const g=((o=$t.find(m=>m.id===l))==null?void 0:o.name)||l;v.appendChild(d(`${g} Hits`,f,x))}else v.innerHTML='<div class="empty-state"><span class="material-symbols-rounded">music_off</span><p>No tracks found</p></div>'}else{if(v.innerHTML="",t.recentlyPlayed.length>0){const E=t.recentlyPlayed.map(D=>T.getCachedTrack(D)).filter(Boolean).slice(0,10);E.length>0&&v.appendChild(d("Recently played",E))}const x=await ve.getAllDownloads();x.length>0&&v.appendChild(d("Downloaded · Offline",x.slice(0,20)));const f=[],g={pop:[{title:"Pop Hits 🎵",query:"latest pop songs new 2025"},{title:"International Pop",query:"top english pop songs trending"}],hiphop:[{title:"Hip Hop Fire 🔥",query:"hindi rap songs trending 2025"},{title:"Underground Beats",query:"indian hip hop rapper tracks"}],rock:[{title:"Rock Anthems 🎸",query:"rock songs hindi best"},{title:"Alt Rock Picks",query:"alternative rock band songs"}],lofi:[{title:"Lo-Fi Chill 🌙",query:"lofi hindi chill beats study"},{title:"Late Night Vibes",query:"slowed reverb songs hindi aesthetic"}],electronic:[{title:"EDM Drops ⚡",query:"edm electronic dance songs"},{title:"Bass & Beats",query:"electronic bass music remix"}],rnb:[{title:"R&B Smooth 🎤",query:"rnb soul music smooth"},{title:"Soulful Vibes",query:"soul music relaxing"}],jazz:[{title:"Jazz Sessions 🎷",query:"jazz songs instrumental smooth"},{title:"Jazz Classics",query:"jazz classic legends vocals"}],classical:[{title:"Classical Ragas 🎻",query:"indian classical music raga"},{title:"Timeless Melodies",query:"classical instrumental piano soothing"}],indie:[{title:"Indie Picks 🌿",query:"indie music hindi artist"},{title:"Fresh Indie",query:"independent artist songs new"}],kpop:[{title:"K-Pop Faves 💜",query:"kpop trending songs BTS"},{title:"K-Pop New Releases",query:"kpop latest songs 2025"}],bollywood:[{title:"Bollywood Hits 🎬",query:"bollywood songs latest trending 2025"},{title:"Filmi Favorites",query:"best bollywood movie songs romantic"}],ambient:[{title:"Ambient Escape 🧘",query:"ambient meditation music calm"},{title:"Nature & Peace",query:"relaxing music nature sounds sleep"}]};(t.interests.length>0?t.interests:["bollywood","pop","lofi"]).forEach(E=>{(g[E]||[]).forEach(_=>f.push(_))});const u=new Set;if(t.recentlyPlayed.length>0)for(const E of t.recentlyPlayed.slice(0,10)){const D=T.getCachedTrack(E);if(D!=null&&D.artist){const _=D.artist.split(",")[0].trim();!u.has(_.toLowerCase())&&u.size<2&&(u.add(_.toLowerCase()),f.splice(2+u.size,0,{title:`Because you listened to ${_}`,query:`${_} best songs more`}))}}const c=f.slice(0,8),p=await Promise.allSettled(c.map(E=>le(E.query).then(D=>({...E,songs:D})))),h=v.querySelector(".home-loading");h&&h.remove();let C=0;async function w(){if(C>=p.length||v.parentElement!==e)return;const E=p[C];E.status==="fulfilled"&&E.value.songs.length>0&&v.appendChild(d(E.value.title,E.value.songs,E.value.query)),C++,setTimeout(w,30)}w().then(()=>{v.parentElement===e&&v.appendChild(y())}),p.length===0&&(v.innerHTML=`
            <div class="empty-state">
              <span class="material-symbols-rounded">wifi_off</span>
              <p>Couldn't load music</p>
              <p class="text-subtitle" style="margin-top: var(--space-sm);">Check your internet and try again</p>
            </div>
          `)}}catch(x){console.error("Failed to load home content:",x),v.innerHTML=`
        <div class="empty-state">
          <span class="material-symbols-rounded">error</span>
          <p>Something went wrong</p>
        </div>
      `}}function d(o,x,f=null){const g=document.createElement("div");g.className="section";let m=1;g.innerHTML=`
      <div class="section-header">
        <h2 class="text-section-title">${o}</h2>
        <span class="text-subtitle">${x.length} songs</span>
      </div>
    `;const u=document.createElement("div");if(u.className="horizontal-scroll",x.slice(0,10).forEach(c=>{u.appendChild(ue(c,x))}),x.length>=10&&f){const c=document.createElement("div");c.className="view-more-card";let p=!1;c.innerHTML=`
        <div class="view-more-inner">
          <span class="material-symbols-rounded">arrow_forward</span>
          <span>Load More</span>
        </div>
      `,c.addEventListener("click",async()=>{if(!p){p=!0,c.innerHTML='<div class="loading-spinner" style="width:24px;height:24px;border-width:2px;"></div>',m++;try{const h=await le(f,m,10);h&&h.length>0?(h.forEach(C=>{x.push(C),u.insertBefore(ue(C,x),c)}),g.querySelector(".text-subtitle").textContent=`${x.length} songs`,c.innerHTML=`
              <div class="view-more-inner">
                <span class="material-symbols-rounded">arrow_forward</span>
                <span>Load More</span>
              </div>
            `):c.remove()}catch{c.innerHTML='<div class="view-more-inner"><span>Error</span></div>'}p=!1}}),u.appendChild(c)}return g.appendChild(u),g}function y(){const o=document.createElement("div");o.className="section",o.innerHTML=`
      <div class="section-header">
        <h2 class="text-section-title">Popular Artists</h2>
      </div>
    `;const x=document.createElement("div");return x.className="horizontal-scroll artist-scroll",ra.forEach(f=>{const g=document.createElement("div");g.className="artist-card";const m=f.name.split(" ").map(u=>u[0]).join("").slice(0,2);g.innerHTML=`
        <div class="artist-avatar" style="background: ${f.gradient};">
          ${f.image?`<img class="artist-img" src="${f.image}" alt="${f.name}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';" /><span class="artist-initials" style="display:none;">${m}</span>`:`<span class="artist-initials">${m}</span>`}
        </div>
        <div class="artist-name">${f.name}</div>
      `,g.addEventListener("click",async()=>{var p;v.innerHTML=`
          <div class="home-loading">
            <div class="loading-spinner"></div>
            <p class="text-subtitle">Loading ${f.name} songs...</p>
          </div>
        `;const u=await le(f.query);v.innerHTML="";const c=document.createElement("div");c.style.cssText="display:flex;align-items:center;gap:var(--space-md);margin-bottom:var(--space-xl);",c.innerHTML=`
          <button class="btn-icon" id="artist-back"><span class="material-symbols-rounded">arrow_back</span></button>
          <div class="artist-avatar" style="background:${f.gradient};width:48px;height:48px;"><span class="material-symbols-rounded" style="font-size:24px;">person</span></div>
          <div>
            <h2 class="text-section-title">${f.name}</h2>
            <span class="text-subtitle">${u.length} songs</span>
          </div>
          ${u.length>0?'<button class="btn-play" id="artist-play-all" style="margin-left:auto;width:44px;height:44px;"><span class="material-symbols-rounded" style="font-size:22px;">play_arrow</span></button>':""}
        `,c.querySelector("#artist-back").addEventListener("click",()=>{l=null,s()}),v.appendChild(c),u.length>0?((p=c.querySelector("#artist-play-all"))==null||p.addEventListener("click",()=>{T.playAll(u,u[0])}),v.appendChild(d(`${f.name} Songs`,u,f.query))):v.innerHTML+='<div class="empty-state"><span class="material-symbols-rounded">music_off</span><p>No songs found</p></div>'}),x.appendChild(g)}),o.appendChild(x),o}return s(),e}const ur=document.createElement("style");ur.textContent=`
  .home-header {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    margin-bottom: var(--space-sm);
  }
  .home-logo {
    width: 32px;
    height: 32px;
    filter: drop-shadow(0 0 8px var(--accent-glow));
    cursor: pointer;
    transition: transform var(--transition-fast);
  }
  .home-logo:active {
    transform: scale(0.9);
  }

  .home-loading {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: var(--space-3xl);
    gap: var(--space-lg);
  }

  .loading-spinner {
    width: 36px;
    height: 36px;
    border: 3px solid var(--bg-active);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }

  /* View More card at end of row */
  .view-more-card {
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 100px;
    height: 130px;
    cursor: pointer;
    -webkit-tap-highlight-color: transparent;
    flex-shrink: 0;
  }

  .view-more-inner {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: var(--space-sm);
    color: var(--text-secondary);
    font-size: var(--font-sm);
    font-weight: 500;
    text-align: center;
    transition: color var(--transition-fast), transform var(--transition-fast);
  }

  .view-more-inner .material-symbols-rounded {
    font-size: 32px;
    width: 56px;
    height: 56px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--radius-full);
    background: var(--surface-glass);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid var(--surface-border);
    transition: background var(--transition-fast), transform var(--transition-fast);
  }

  .view-more-card:hover .view-more-inner {
    color: var(--accent);
  }

  .view-more-card:hover .material-symbols-rounded {
    background: var(--accent-dim);
    transform: scale(1.05);
  }

  .view-more-card:active .view-more-inner {
    transform: scale(0.95);
  }

  .view-more-inner small {
    font-size: var(--font-xs);
    color: var(--text-tertiary);
  }

  /* Artist cards */
  .artist-scroll {
    gap: var(--space-xl);
  }

  .artist-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: var(--space-sm);
    cursor: pointer;
    transition: transform var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
    width: 90px;
  }

  .artist-card:active {
    transform: scale(0.95);
  }

  .artist-avatar {
    width: 72px;
    height: 72px;
    border-radius: var(--radius-full);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: var(--shadow-md);
    transition: transform var(--transition-normal), box-shadow var(--transition-normal);
    overflow: hidden;
  }

  .artist-card:hover .artist-avatar {
    transform: scale(1.05);
    box-shadow: var(--shadow-lg);
  }

  .artist-avatar .material-symbols-rounded {
    font-size: 32px;
    opacity: 0.9;
  }

  .artist-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: var(--radius-full);
  }

  .artist-initials {
    font-size: 24px;
    font-weight: 700;
    color: rgba(255,255,255,0.85);
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
  }

  .artist-name {
    font-size: var(--font-xs);
    font-weight: 500;
    color: var(--text-primary);
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
  }

  /* Tablet: bigger artist cards */
  @media (min-width: 768px) {
    .artist-card {
      width: 110px;
    }
    .artist-avatar {
      width: 88px;
      height: 88px;
    }
    .artist-name {
      font-size: var(--font-sm);
    }
    .artist-initials {
      font-size: 30px;
    }
  }

  @media (min-width: 1024px) {
    .artist-card {
      width: 130px;
    }
    .artist-avatar {
      width: 100px;
      height: 100px;
    }
    .artist-avatar .material-symbols-rounded {
      font-size: 40px;
    }
    .artist-initials {
      font-size: 36px;
    }
  }
`;document.head.appendChild(ur);function Ln(){const e=document.createElement("div");e.className="page",e.innerHTML=`
    <h1 class="text-greeting">Search</h1>
    <div class="search-input-wrapper" style="margin-top: var(--space-xl);">
      <span class="material-symbols-rounded">search</span>
      <input type="text" class="search-input" placeholder="Search songs, artists, playlists..." id="search-input" autocomplete="off" />
    </div>
    <div id="search-loading" class="home-loading" style="display:none;">
      <div class="loading-spinner"></div>
      <p class="text-subtitle">Searching...</p>
    </div>
    <div id="search-results" style="display: none;"></div>
    <div id="browse-section"></div>
  `;const t=e.querySelector("#search-input"),a=e.querySelector("#search-results"),r=e.querySelector("#search-loading"),n=e.querySelector("#browse-section");function i(){const u=I.get();if(n.innerHTML="",u.recentlyPlayed.length>0){const p=document.createElement("div");p.className="section",p.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Recently Played</h2>
          <span class="text-subtitle">${u.recentlyPlayed.length} songs</span>
        </div>
      `;const h=document.createElement("div");h.className="search-history-list",u.recentlyPlayed.slice(0,10).forEach(C=>{const w=u.trackMetadata[C];w&&h.appendChild(ue(w,u.recentlyPlayed.map(E=>u.trackMetadata[E]).filter(Boolean),"horizontal"))}),p.appendChild(h),n.appendChild(p)}if(u.likedSongs.length>0){const p=document.createElement("div");p.className="section",p.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Your Liked Songs</h2>
          <span class="text-subtitle">${u.likedSongs.length} songs</span>
        </div>
      `;const h=document.createElement("div");h.className="search-history-list",u.likedSongs.slice(0,10).forEach(C=>{const w=u.trackMetadata[C];w&&h.appendChild(ue(w,u.likedSongs.map(E=>u.trackMetadata[E]).filter(Boolean),"horizontal"))}),p.appendChild(h),n.appendChild(p)}const c=b(u);if(c.length>0){const p=document.createElement("div");p.className="section",p.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Try Searching</h2>
        </div>
      `;const h=document.createElement("div");h.className="suggestion-chips",c.forEach(C=>{const w=document.createElement("button");w.className="chip suggestion-chip",w.innerHTML=`<span class="material-symbols-rounded" style="font-size:16px;">${C.icon}</span> ${C.label}`,w.addEventListener("click",()=>{t.value=C.query,g(C.query)}),h.appendChild(w)}),p.appendChild(h),n.appendChild(p)}if(u.recentlyPlayed.length===0&&u.likedSongs.length===0){const p=document.createElement("div");p.className="section",p.innerHTML=`
        <div class="empty-state" style="padding: var(--space-2xl) 0;">
          <span class="material-symbols-rounded" style="font-size:48px;color:var(--text-tertiary);">search</span>
          <p style="margin-top:var(--space-md);color:var(--text-secondary);">Search for any song, artist, or playlist</p>
          <p class="text-subtitle" style="margin-top:var(--space-sm);">Your listening history will appear here</p>
        </div>
      `,n.appendChild(p);const h=document.createElement("div");h.className="section",h.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Popular Searches</h2>
        </div>
      `;const C=document.createElement("div");C.className="suggestion-chips",[{label:"Arijit Singh",icon:"person",query:"Arijit Singh"},{label:"Bollywood Hits",icon:"music_note",query:"bollywood hits 2025"},{label:"Party Songs",icon:"celebration",query:"party songs hindi"},{label:"Romantic",icon:"favorite",query:"romantic hindi songs"},{label:"Punjabi",icon:"queue_music",query:"punjabi hits 2025"},{label:"Sad Songs",icon:"sentiment_sad",query:"sad hindi songs broken heart"},{label:"Lo-fi Chill",icon:"headphones",query:"lofi chill hindi"},{label:"Top Playlists",icon:"playlist_play",query:"top hindi playlist trending"}].forEach(E=>{const D=document.createElement("button");D.className="chip suggestion-chip",D.innerHTML=`<span class="material-symbols-rounded" style="font-size:16px;">${E.icon}</span> ${E.label}`,D.addEventListener("click",()=>{t.value=E.query,g(E.query)}),C.appendChild(D)}),h.appendChild(C),n.appendChild(h)}}function b(u){const c=[],p=new Set;return u.recentlyPlayed.slice(0,15).forEach(C=>{const w=u.trackMetadata[C];if(w&&w.artist){const E=w.artist.split(",")[0].trim();p.has(E.toLowerCase())||(p.add(E.toLowerCase()),c.push({label:E,icon:"person",query:E}))}}),[{label:"New Releases",icon:"new_releases",query:"new hindi songs 2025"},{label:"Trending Now",icon:"trending_up",query:"trending songs india"},{label:"Workout Mix",icon:"fitness_center",query:"workout hindi songs"},{label:"Chill Vibes",icon:"spa",query:"chill hindi lofi"}].forEach(C=>{p.has(C.label.toLowerCase())||(p.add(C.label.toLowerCase()),c.push(C))}),c.slice(0,12)}let l=null,v=0,s="",d=1,y=!1,o=!0,x=[];function f(u,c){new IntersectionObserver(async h=>{if(h[0].isIntersecting&&!y&&o){y=!0,d++,u.innerHTML='<div class="loading-spinner" style="width: 24px; height: 24px; border-width: 2px;"></div>',u.style.display="flex",u.style.justifyContent="center";try{const C=await le(s,d,10);!C||C.length===0?(o=!1,u.innerHTML=""):(C.forEach(w=>x.push(w)),C.forEach(w=>{c.appendChild(ue(w,x,"horizontal"))}),u.innerHTML="")}catch{u.innerHTML=""}y=!1}},{rootMargin:"150px"}).observe(u)}async function g(u){const c=++v;if(!u.trim()){a.style.display="none",r.style.display="none",n.style.display="block";return}n.style.display="none",a.style.display="none",r.style.display="flex",s=u,d=1,y=!1,o=!0,x=[];try{const[p,h]=await Promise.allSettled([sr(u),dr(u)]),C=p.status==="fulfilled"?p.value:{},w=h.status==="fulfilled"?h.value:[];if(c!==v)return;const E=C.songs||[],D=C.playlists||[];if(E.length>0&&E[0]._needsDetail)try{x=await le(u,1,10)}catch{x=E}else if(E.length===0)try{x=await le(u,1,10)}catch{x=[]}else x=E;if(c!==v)return;if(r.style.display="none",a.style.display="block",a.innerHTML="",x.length===0&&D.length===0&&w.length===0){a.innerHTML=`
          <div class="empty-state">
            <span class="material-symbols-rounded">search_off</span>
            <p>No results found for "${u}"</p>
            <p class="text-subtitle" style="margin-top: var(--space-sm);">Try a different search</p>
          </div>
        `;return}if(w.length>0){const _=document.createElement("div");_.className="section",_.innerHTML=`
          <div class="section-header">
            <h2 class="text-section-title">Podcasts</h2>
            <span class="text-subtitle">from Apple Podcasts</span>
          </div>
        `;const B=document.createElement("div");B.className="horizontal-scroll",w.slice(0,10).forEach(A=>{const k=document.createElement("div");k.className="playlist-card",k.style.width="160px",k.innerHTML=`
            <div class="playlist-card-art-wrapper" style="border-radius: var(--radius-lg);">
              <img class="playlist-card-art" src="${A.cover}" alt="${A.title}" loading="lazy" />
              <div class="playlist-card-overlay">
                <span class="material-symbols-rounded">podcasts</span>
              </div>
            </div>
            <div class="playlist-card-title">${A.title}</div>
            <div class="playlist-card-info">${A.artist}</div>
          `,k.addEventListener("click",()=>{window.location.hash=`podcast?feed=${encodeURIComponent(A.feedUrl)}&title=${encodeURIComponent(A.title)}&artist=${encodeURIComponent(A.artist)}&cover=${encodeURIComponent(A.cover)}`}),B.appendChild(k)}),_.appendChild(B),a.appendChild(_)}if(D.length>0){const _=document.createElement("div");_.className="section",_.innerHTML=`
          <div class="section-header">
            <h2 class="text-section-title">Playlists</h2>
            <span class="text-subtitle">${D.length} found</span>
          </div>
        `;const B=document.createElement("div");B.className="horizontal-scroll",D.slice(0,10).forEach(A=>{const k=document.createElement("div");k.className="playlist-card",k.innerHTML=`
            <div class="playlist-card-art-wrapper">
              <img class="playlist-card-art" src="${A.coverSmall||A.cover||""}" alt="${A.title}" loading="lazy" />
              <div class="playlist-card-overlay">
                <span class="material-symbols-rounded">playlist_play</span>
              </div>
            </div>
            <div class="playlist-card-title">${A.title}</div>
            <div class="playlist-card-info">${A.songCount?A.songCount+" songs":A.description||""}</div>
          `,k.addEventListener("click",()=>m(A)),B.appendChild(k)}),_.appendChild(B),a.appendChild(_)}if(x.length>0){const _=document.createElement("div");_.innerHTML=`
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:var(--space-lg);margin-top:var(--space-lg);">
            <span class="text-section-title">Songs</span>
            <button class="chip" id="play-all-results">
              <span class="material-symbols-rounded" style="font-size:16px;">play_arrow</span>
              Play All
            </button>
          </div>
        `,_.querySelector("#play-all-results").addEventListener("click",()=>{T.playAll(x,x[0])});const B=document.createElement("div");B.id="search-song-container",x.forEach(k=>{B.appendChild(ue(k,x,"horizontal"))}),_.appendChild(B);const A=document.createElement("div");A.id="infinite-scroll-trigger",A.style.height="40px",A.style.marginTop="var(--space-md)",_.appendChild(A),a.appendChild(_),f(A,B)}}catch{r.style.display="none",a.style.display="block",a.innerHTML=`
        <div class="empty-state">
          <span class="material-symbols-rounded">error</span>
          <p>Search failed. Check your internet connection.</p>
        </div>
      `}}async function m(u){var h;a.innerHTML=`
      <div class="home-loading">
        <div class="loading-spinner"></div>
        <p class="text-subtitle">Loading playlist...</p>
      </div>
    `;const c=await ir(u.id);a.innerHTML="";const p=document.createElement("div");p.className="playlist-header",p.innerHTML=`
      <button class="btn-icon" id="playlist-back"><span class="material-symbols-rounded">arrow_back</span></button>
      <img class="playlist-header-art" src="${u.cover||u.coverSmall||""}" alt="${u.title}" />
      <div class="playlist-header-info">
        <h2 class="text-section-title">${u.title}</h2>
        <span class="text-subtitle">${c.length} songs</span>
      </div>
      ${c.length>0?'<button class="btn-play" id="playlist-play-all" style="margin-left:auto;"><span class="material-symbols-rounded">play_arrow</span></button>':""}
    `,p.querySelector("#playlist-back").addEventListener("click",()=>{g(t.value)}),a.appendChild(p),c.length>0?((h=p.querySelector("#playlist-play-all"))==null||h.addEventListener("click",()=>{T.playAll(c,c[0])}),c.forEach(C=>{a.appendChild(ue(C,c,"horizontal"))})):a.innerHTML+=`
        <div class="empty-state">
          <span class="material-symbols-rounded">music_off</span>
          <p>No songs found in this playlist</p>
        </div>
      `}return t.addEventListener("input",()=>{clearTimeout(l);const u=t.value;if(!u.trim()){a.style.display="none",r.style.display="none",n.style.display="block";return}l=setTimeout(()=>g(u),400)}),i(),setTimeout(()=>t.focus(),100),e}const fr=document.createElement("style");fr.textContent=`
  .search-history-list {
    display: flex;
    flex-direction: column;
    gap: var(--space-xs);
  }

  .suggestion-chips {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-sm);
  }

  .suggestion-chip {
    animation: fadeInUp 0.3s ease both;
  }

  @keyframes fadeInUp {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }

  /* Playlist cards */
  .playlist-card {
    width: 140px;
    cursor: pointer;
    transition: transform var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
    flex-shrink: 0;
  }

  .playlist-card:active {
    transform: scale(0.97);
  }

  .playlist-card-art-wrapper {
    position: relative;
    border-radius: var(--radius-md);
    overflow: hidden;
    aspect-ratio: 1;
    background: var(--bg-tertiary);
  }

  .playlist-card-art {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .playlist-card-overlay {
    position: absolute;
    inset: 0;
    background: rgba(0,0,0,0.35);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity var(--transition-normal);
  }

  .playlist-card:hover .playlist-card-overlay {
    opacity: 1;
  }

  .playlist-card-overlay .material-symbols-rounded {
    font-size: 36px;
    color: white;
  }

  .playlist-card-title {
    margin-top: var(--space-sm);
    font-size: var(--font-sm);
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: var(--text-primary);
  }

  .playlist-card-info {
    font-size: var(--font-xs);
    color: var(--text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  /* Playlist detail header */
  .playlist-header {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    margin-bottom: var(--space-xl);
    padding: var(--space-md) 0;
  }

  .playlist-header-art {
    width: 56px;
    height: 56px;
    border-radius: var(--radius-md);
    object-fit: cover;
  }
`;document.head.appendChild(fr);function qn(){const e=document.createElement("div");e.className="page",e.innerHTML=`
    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: var(--space-xl);">
      <h1 class="text-greeting">Your Library</h1>
    </div>
    <div id="library-content"></div>
  `;const t=e.querySelector("#library-content");async function a(){const i=I.get();t.innerHTML="";const b=localStorage.getItem("melo-zoom")||"1.0",l=document.createElement("div");l.className="library-settings-card",l.innerHTML=`
      <div class="settings-header">
        <span class="material-symbols-rounded">zoom_in</span>
        <div class="settings-info">
          <div class="settings-title">Display Scaling</div>
          <div class="settings-subtitle">Adjust text and element sizes</div>
        </div>
        <div class="zoom-value">${Math.round(b*100)}%</div>
      </div>
      <div class="settings-body">
        <input type="range" id="zoom-slider" min="0.8" max="1.5" step="0.05" value="${b}" class="zoom-slider">
        <div class="zoom-labels">
          <span>Small</span>
          <span>Default</span>
          <span>Large</span>
        </div>
      </div>
    `;const v=l.querySelector("#zoom-slider"),s=l.querySelector(".zoom-value");v.addEventListener("input",g=>{const m=g.target.value;s.textContent=Math.round(m*100)+"%",localStorage.setItem("melo-zoom",m),document.documentElement.style.setProperty("--zoom",m),document.body.style.zoom=m}),t.appendChild(l);const d=await ve.getAllDownloads(),y=document.createElement("div");y.className="library-playlist-item",y.innerHTML=`
      <div class="library-playlist-art downloads-art">
        <span class="material-symbols-rounded">download_done</span>
      </div>
      <div class="library-playlist-info">
        <div class="library-playlist-name">Downloads</div>
        <div class="library-playlist-meta">${d.length} song${d.length!==1?"s":""}${d.length>0?" · "+O0(d.reduce((g,m)=>g+(m.size||0),0)):""}</div>
      </div>
    `,y.addEventListener("click",()=>{r(d,t)}),t.appendChild(y);const o=i.likedSongs.length,x=document.createElement("div");if(x.className="library-playlist-item",x.innerHTML=`
      <div class="library-playlist-art liked-art">
        <span class="material-symbols-rounded">favorite</span>
      </div>
      <div class="library-playlist-info">
        <div class="library-playlist-name">Liked Songs</div>
        <div class="library-playlist-meta">${o} song${o!==1?"s":""}</div>
      </div>
    `,x.addEventListener("click",()=>{o>0&&n("Liked Songs",i.likedSongs,t)}),t.appendChild(x),i.recentlyPlayed.length>0){const g=document.createElement("div");g.className="library-playlist-item";const m=T.getCachedTrack(i.recentlyPlayed[0]),u=(m==null?void 0:m.coverSmall)||(m==null?void 0:m.cover)||"";g.innerHTML=`
        <div class="library-playlist-art" style="background: var(--bg-tertiary);">
          ${u?`<img src="${u}" style="width:100%;height:100%;object-fit:cover;border-radius:var(--radius-md);" />`:'<span class="material-symbols-rounded" style="color:var(--text-tertiary);">history</span>'}
        </div>
        <div class="library-playlist-info">
          <div class="library-playlist-name">Recently Played</div>
          <div class="library-playlist-meta">${i.recentlyPlayed.length} song${i.recentlyPlayed.length!==1?"s":""}</div>
        </div>
      `,g.addEventListener("click",()=>{n("Recently Played",i.recentlyPlayed,t)}),t.appendChild(g)}i.playlists.forEach(g=>{const m=document.createElement("div");m.className="library-playlist-item";const u=g.trackIds.length>0?T.getCachedTrack(g.trackIds[0]):null;m.innerHTML=`
        <div class="library-playlist-art" style="background: var(--bg-tertiary);">
          ${u?`<img src="${u.coverSmall||u.cover}" style="width:100%;height:100%;object-fit:cover;border-radius:var(--radius-md);" />`:'<span class="material-symbols-rounded" style="color:var(--text-tertiary);">queue_music</span>'}
        </div>
        <div class="library-playlist-info">
          <div class="library-playlist-name">${g.name}</div>
          <div class="library-playlist-meta">${g.trackIds.length} song${g.trackIds.length!==1?"s":""}</div>
        </div>
      `,m.addEventListener("click",()=>{n(g.name,g.trackIds,t)}),t.appendChild(m)});const f=document.createElement("div");f.className="library-playlist-item create-playlist",f.innerHTML=`
      <div class="library-playlist-art create-art">
        <span class="material-symbols-rounded">add</span>
      </div>
      <div class="library-playlist-info">
        <div class="library-playlist-name">Create Playlist</div>
        <div class="library-playlist-meta">Build your collection</div>
      </div>
    `,f.addEventListener("click",()=>{const g=prompt("Enter playlist name:");g!=null&&g.trim()&&(I.createPlaylist(g.trim()),a())}),t.appendChild(f)}function r(i,b){var v;b.innerHTML="";const l=document.createElement("div");if(l.style.cssText="display:flex;align-items:center;gap:var(--space-md);margin-bottom:var(--space-xl);",l.innerHTML=`
      <button class="btn-icon" id="dl-back"><span class="material-symbols-rounded">arrow_back</span></button>
      <h2 class="text-section-title" style="flex:1;">Downloads</h2>
      <span class="text-subtitle">${i.length} song${i.length!==1?"s":""}</span>
      ${i.length>0?`
        <button class="btn-play" id="dl-play-all" style="width:44px;height:44px;">
          <span class="material-symbols-rounded" style="font-size:22px;">play_arrow</span>
        </button>
      `:""}
    `,l.querySelector("#dl-back").addEventListener("click",()=>a()),b.appendChild(l),i.length>0&&((v=l.querySelector("#dl-play-all"))==null||v.addEventListener("click",()=>{T.playAll(i,i[0])})),i.length===0){b.innerHTML+=`
        <div class="empty-state">
          <span class="material-symbols-rounded">download</span>
          <p>No downloads yet</p>
          <p class="text-subtitle" style="margin-top:var(--space-sm);">Download songs to play them offline</p>
        </div>
      `;return}i.forEach(s=>{const d=document.createElement("div");d.className="track-item",d.innerHTML=`
        <img class="track-item-art" src="${s.coverSmall||s.cover}" alt="" loading="lazy" />
        <div class="track-item-info">
          <div class="track-item-title">${s.title}</div>
          <div class="track-item-artist">${s.artist}</div>
        </div>
        <span class="track-item-duration">${O0(s.size||0)}</span>
        <button class="btn-icon dl-delete-btn" data-id="${s.id}" title="Delete download">
          <span class="material-symbols-rounded" style="font-size:20px;color:var(--text-tertiary);">delete</span>
        </button>
      `,d.addEventListener("click",y=>{if(y.target.closest(".dl-delete-btn")){y.stopPropagation();const o=y.target.closest(".dl-delete-btn").dataset.id;ve.deleteDownload(o).then(()=>{te.show("Download removed","info"),ve.getAllDownloads().then(x=>r(x,b))});return}T.playAll(i,s)}),b.appendChild(d)})}function n(i,b,l){l.innerHTML="";const v=document.createElement("div");v.style.cssText="display:flex;align-items:center;gap:var(--space-md);margin-bottom:var(--space-xl);",v.innerHTML=`
      <button class="btn-icon" id="lib-back"><span class="material-symbols-rounded">arrow_back</span></button>
      <h2 class="text-section-title" style="flex:1;">${i}</h2>
      <button class="btn-play" id="lib-play-all" style="width:44px;height:44px;">
        <span class="material-symbols-rounded" style="font-size:22px;">play_arrow</span>
      </button>
    `,v.querySelector("#lib-back").addEventListener("click",()=>a()),l.appendChild(v);const s=b.map(d=>T.getCachedTrack(d)).filter(Boolean);if(v.querySelector("#lib-play-all").addEventListener("click",()=>{s.length>0&&T.playAll(s,s[0])}),s.length===0){l.innerHTML+=`
        <div class="empty-state">
          <span class="material-symbols-rounded">library_music</span>
          <p>No songs yet</p>
          <p class="text-subtitle" style="margin-top:var(--space-sm);">Search and play songs to see them here</p>
        </div>
      `;return}s.forEach(d=>{const y=document.createElement("div");y.className="track-item",y.innerHTML=`
        <img class="track-item-art" src="${d.coverSmall||d.cover}" alt="" loading="lazy" />
        <div class="track-item-info">
          <div class="track-item-title">${d.title}</div>
          <div class="track-item-artist">${d.artist}</div>
        </div>
        <span class="track-item-duration">${$n(d.duration)}</span>
      `,y.addEventListener("click",()=>{T.playAll(s,d)}),l.appendChild(y)})}return a(),I.subscribe(i=>{["likedSongs","playlists","recentlyPlayed","downloads"].includes(i)&&a()}),e}function $n(e){if(!e||!isFinite(e))return"";const t=Math.floor(e/60),a=Math.floor(e%60);return`${t}:${a.toString().padStart(2,"0")}`}function O0(e){return e?e<1024?e+" B":e<1024*1024?(e/1024).toFixed(0)+" KB":(e/1024/1024).toFixed(1)+" MB":"0 B"}const vr=document.createElement("style");vr.textContent=`
  .library-settings-card {
    background: var(--surface-glass);
    border: 1px solid var(--surface-border);
    border-radius: var(--radius-lg);
    padding: var(--space-lg);
    margin-bottom: var(--space-xl);
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
  }
  .settings-header {
    display: flex;
    align-items: center;
    gap: var(--space-md);
  }
  .settings-header .material-symbols-rounded {
    font-size: 24px;
    color: var(--accent);
    background: var(--accent-dim);
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--radius-md);
  }
  .settings-info {
    flex: 1;
  }
  .settings-title {
    font-size: var(--font-md);
    font-weight: 600;
  }
  .settings-subtitle {
    font-size: var(--font-xs);
    color: var(--text-secondary);
  }
  .zoom-value {
    font-size: var(--font-sm);
    font-weight: 700;
    color: var(--accent);
    background: var(--accent-dim);
    padding: 4px 10px;
    border-radius: var(--radius-sm);
  }
  .settings-body {
    display: flex;
    flex-direction: column;
    gap: var(--space-xs);
  }
  .zoom-slider {
    width: 100%;
    accent-color: var(--accent);
    cursor: pointer;
  }
  .zoom-labels {
    display: flex;
    justify-content: space-between;
    font-size: 10px;
    color: var(--text-tertiary);
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }
  .library-playlist-item {
    display: flex;
    align-items: center;
    gap: var(--space-lg);
    padding: var(--space-md);
    border-radius: var(--radius-md);
    cursor: pointer;
    transition: background var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
  }
  .library-playlist-item:hover {
    background: var(--surface-glass-hover);
  }
  .library-playlist-item:active {
    background: var(--bg-active);
  }
  .library-playlist-art {
    width: 56px;
    height: 56px;
    border-radius: var(--radius-md);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    overflow: hidden;
  }
  .liked-art {
    background: linear-gradient(135deg, #7c4dff, #e040fb);
  }
  .liked-art .material-symbols-rounded {
    font-size: 28px;
  }
  .downloads-art {
    background: linear-gradient(135deg, #1ed760, #0ea5e9);
  }
  .downloads-art .material-symbols-rounded {
    font-size: 28px;
  }
  .create-art {
    background: var(--bg-tertiary);
    border: 2px dashed var(--text-tertiary);
  }
  .create-art .material-symbols-rounded {
    font-size: 28px;
    color: var(--text-tertiary);
  }
  .library-playlist-info {
    flex: 1;
    min-width: 0;
  }
  .library-playlist-name {
    font-size: var(--font-md);
    font-weight: 500;
    color: var(--text-primary);
  }
  .library-playlist-meta {
    font-size: var(--font-sm);
    color: var(--text-secondary);
  }
  .dl-delete-btn {
    width: 36px;
    height: 36px;
    flex-shrink: 0;
  }
`;document.head.appendChild(vr);async function Pn(e,t){try{return await lr(t,e)}catch(a){console.warn("Lyrics fetch failed:",a)}return null}function Hn(){const e=document.createElement("div");e.className="page nowplaying-page";const t=T.currentTrack;if(!t)return e.innerHTML=`
      <div class="empty-state" style="padding-top: 30vh;">
        <span class="material-symbols-rounded">music_off</span>
        <p>No track playing</p>
        <p class="text-subtitle" style="margin-top: var(--space-sm);">Choose a song to get started</p>
      </div>
    `,e;const a=I.get(),r=I.isLiked(t.id);e.innerHTML=`
    <div class="np-bg" id="np-bg"></div>
    <div class="np-header">
      <button class="btn-icon" id="np-back">
        <span class="material-symbols-rounded">keyboard_arrow_down</span>
      </button>
      <div class="np-header-title">
        <span class="text-tiny" style="text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600;">Now Playing</span>
      </div>
      <button class="btn-icon" id="np-queue">
        <span class="material-symbols-rounded">queue_music</span>
      </button>
    </div>

    <div class="np-body">
      <div class="np-art-container ${T.isPlaying?"playing":""}">
        <img class="np-art" id="np-art" src="${t.cover}" alt="${t.title}" />
      </div>

      <div class="np-info">
        <div class="np-title-row">
          <div class="np-title-wrap">
            <h2 class="np-title" id="np-title">${t.title}</h2>
            <p class="np-artist" id="np-artist" style="pointer-events: auto;">${t.artist}</p>
          </div>
          <button class="btn-icon np-like ${r?"liked":""}" id="np-like">
            <span class="material-symbols-rounded">${r?"favorite":"favorite_border"}</span>
          </button>
        </div>

        <div class="np-progress">
          <div class="np-progress-bar" id="np-progress-bar">
            <div class="np-progress-fill" id="np-progress-fill"></div>
            <div class="np-progress-thumb" id="np-progress-thumb"></div>
          </div>
          <div class="np-time">
            <span id="np-time-current">0:00</span>
            <span id="np-time-total">${Re(t.duration)}</span>
          </div>
        </div>

        <div class="np-controls">
          <button class="btn-icon np-ctrl-btn ${a.shuffle?"active":""}" id="np-shuffle">
            <span class="material-symbols-rounded">shuffle</span>
          </button>
          <button class="btn-icon np-ctrl-btn np-ctrl-lg" id="np-prev">
            <span class="material-symbols-rounded">skip_previous</span>
          </button>
          <button class="btn-play np-play-btn" id="np-play">
            <span class="material-symbols-rounded">${T.isPlaying?"pause":"play_arrow"}</span>
          </button>
          <button class="btn-icon np-ctrl-btn np-ctrl-lg" id="np-next">
            <span class="material-symbols-rounded">skip_next</span>
          </button>
          <button class="btn-icon np-ctrl-btn ${I.isDownloadComplete(t.id)?"active":""}" id="np-download">
             <span class="material-symbols-rounded">${I.isDownloadComplete(t.id)?"download_done":"download"}</span>
          </button>
        </div>

        <!-- Caption / Lyrics Section -->
        <div class="np-caption" id="np-caption">
          <div class="np-caption-toggle" id="np-caption-toggle">
            <span class="material-symbols-rounded" style="font-size:18px;">lyrics</span>
            <span>Lyrics</span>
            <span class="material-symbols-rounded np-caption-arrow" id="np-caption-arrow">expand_more</span>
          </div>
          <div class="np-caption-body" id="np-caption-body" style="display:none;">
            <div class="np-caption-loading" id="np-caption-loading">
              <div class="loading-spinner" style="width:20px;height:20px;border-width:2px;"></div>
              <span>Finding lyrics...</span>
            </div>
            <pre class="np-caption-text" id="np-caption-text" style="display:none;"></pre>
          </div>
        </div>
      </div>
    </div>
  `;const n=e.querySelector("#np-bg");n.style.backgroundImage=`url(${t.cover})`,e.querySelector("#np-back").addEventListener("click",()=>{Y.navigate("home")}),e.querySelector("#np-artist").addEventListener("click",()=>{const u=t.artist.split(",")[0].trim();Y.navigate(`artist?name=${encodeURIComponent(u)}`)}),e.querySelector("#np-download").addEventListener("click",async()=>{const u=e.querySelector("#np-download");if(I.isDownloadComplete(t.id)){te.show("Already downloaded!","info");return}te.show(`Downloading ${t.title}...`,"info"),u.querySelector(".material-symbols-rounded").textContent="hourglass_top",await ve.downloadTrack(t)?(u.classList.add("active"),u.querySelector(".material-symbols-rounded").textContent="download_done",te.show(`Downloaded: ${t.title}`,"success")):(u.querySelector(".material-symbols-rounded").textContent="download",te.show("Download failed","error"))}),e.querySelector("#np-play").addEventListener("click",()=>T.togglePlay()),e.querySelector("#np-prev").addEventListener("click",()=>T.prev()),e.querySelector("#np-next").addEventListener("click",()=>T.next()),e.querySelector("#np-shuffle").addEventListener("click",()=>{I.toggleShuffle(),e.querySelector("#np-shuffle").classList.toggle("active")}),e.querySelector("#np-like").addEventListener("click",()=>{I.toggleLike(t);const u=I.isLiked(t.id),c=e.querySelector("#np-like");c.classList.toggle("liked",u),c.querySelector(".material-symbols-rounded").textContent=u?"favorite":"favorite_border"});let i=!1;const b=e.querySelector("#np-caption-toggle"),l=e.querySelector("#np-caption-body"),v=e.querySelector("#np-caption-arrow"),s=e.querySelector("#np-caption-text"),d=e.querySelector("#np-caption-loading");b.addEventListener("click",async()=>{const u=l.style.display!=="none";if(l.style.display=u?"none":"block",v.textContent=u?"expand_more":"expand_less",!u&&!i){i=!0;const c=await Pn(t.title,t.artist);d.style.display="none",s.style.display="block",c?s.textContent=c.replace(/\r\n/g,`
`).replace(/\n{3,}/g,`

`).trim():(s.textContent="Lyrics not available for this song.",s.style.textAlign="center",s.style.color="var(--text-tertiary)")}});const y=e.querySelector("#np-progress-bar");let o=!1,x=0;function f(u){const c=y.getBoundingClientRect();let p=c.left;u.touches&&u.touches.length>0?p=u.touches[0].clientX:u.clientX!==void 0?p=u.clientX:u.changedTouches&&u.changedTouches.length>0&&(p=u.changedTouches[0].clientX);const h=p-c.left;x=Math.max(0,Math.min(1,h/c.width));const C=T.currentTrack?T.currentTrack.duration:parseInt(T.audio.duration||0);C&&m(x*C,C)}function g(){if(!o)return;o=!1;const u=T.currentTrack?T.currentTrack.duration:parseInt(T.audio.duration||0);if(!u)return;const c=Math.floor(u*x);T.seek(c)}y.addEventListener("mousedown",u=>{o=!0,f(u)}),y.addEventListener("touchstart",u=>{o=!0,f(u)},{passive:!0}),document.addEventListener("mousemove",u=>{o&&f(u)}),document.addEventListener("touchmove",u=>{o&&f(u)},{passive:!0}),document.addEventListener("mouseup",()=>{o&&g()}),document.addEventListener("touchend",()=>{o&&g()}),T.on("statechange",({isPlaying:u})=>{const c=e.querySelector("#np-play .material-symbols-rounded");c&&(c.textContent=u?"pause":"play_arrow");const p=e.querySelector(".np-art-container");p&&p.classList.toggle("playing",u)}),T.on("timeupdate",({currentTime:u,duration:c})=>{o||m(u,c)}),T.on("trackchange",u=>{const c=e.querySelector("#np-art"),p=e.querySelector("#np-title"),h=e.querySelector("#np-artist"),C=e.querySelector("#np-time-total"),w=e.querySelector("#np-bg");c&&(c.src=u.cover),p&&(p.textContent=u.title),h&&(h.textContent=u.artist),C&&(u.duration?C.textContent=Re(u.duration):C.textContent="Live"),w&&(w.style.backgroundImage=`url(${u.cover})`);const E=I.isLiked(u.id),D=e.querySelector("#np-like");D&&(D.classList.toggle("liked",E),D.querySelector(".material-symbols-rounded").textContent=E?"favorite":"favorite_border"),i=!1,l.style.display="none",v.textContent="expand_more",d.style.display="flex",s.style.display="none",s.textContent=""});function m(u,c){const p=e.querySelector("#np-time-current"),h=e.querySelector("#np-time-total");if(p&&(p.textContent=Re(u)),!c||!isFinite(c)||c===0){h&&h.textContent!=="Live"&&(h.textContent="Live");return}if(h){const D=Re(c);h.textContent!==D&&(h.textContent=D)}const C=u/c*100,w=e.querySelector("#np-progress-fill"),E=e.querySelector("#np-progress-thumb");w&&(w.style.width=`${C}%`),E&&(E.style.left=`${C}%`)}return e}function Re(e){if(!e||!isFinite(e))return"0:00";const t=Math.floor(e/60),a=Math.floor(e%60);return`${t}:${a.toString().padStart(2,"0")}`}const hr=document.createElement("style");hr.textContent=`
  .nowplaying-page {
    position: relative;
    display: flex;
    flex-direction: column;
    min-height: 100dvh;
    padding: 0 !important;
    padding-bottom: 0 !important;
    overflow-y: auto;
    overflow-x: hidden;
  }

  .np-bg {
    position: fixed;
    inset: 0;
    background-size: cover;
    background-position: center;
    filter: blur(80px) brightness(0.2) saturate(1.5);
    transform: scale(1.5);
    z-index: 0;
    transition: background-image 0.8s ease;
  }

  .np-header {
    position: sticky;
    top: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: var(--space-md) var(--space-lg);
    z-index: 2;
  }

  .np-body {
    position: relative;
    z-index: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 1;
    padding: 0 var(--space-xl);
    padding-bottom: calc(var(--nav-height) + var(--safe-bottom) + 24px);
  }

  .np-art-container {
    position: relative;
    width: min(260px, 55vw);
    aspect-ratio: 1;
    margin-bottom: var(--space-xl);
    border-radius: var(--radius-xl);
    box-shadow: 0 20px 50px rgba(0,0,0,0.6);
    transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    overflow: hidden;
  }

  .np-art-container.playing {
    transform: scale(1.02);
  }

  .np-art {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: inherit;
  }

  .np-info {
    position: relative;
    z-index: 1;
    width: min(380px, 90vw);
  }

  .np-title-row {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: var(--space-md);
  }

  .np-title-wrap {
    flex: 1;
    min-width: 0;
  }

  .np-title {
    font-size: var(--font-lg);
    font-weight: 700;
    letter-spacing: -0.02em;
    margin: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .np-artist {
    font-size: var(--font-sm);
    color: var(--text-secondary);
    margin-top: 2px;
    margin-bottom: var(--space-lg);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .np-progress-bar {
    height: 4px;
    background: rgba(255,255,255,0.1);
    border-radius: var(--radius-full);
    cursor: pointer;
    position: relative;
  }

  .np-progress-fill {
    height: 100%;
    background: var(--accent);
    box-shadow: 0 0 10px var(--accent-glow);
    border-radius: inherit;
  }

  .np-progress-thumb {
    position: absolute;
    top: 50%;
    width: 14px;
    height: 14px;
    background: var(--accent);
    border-radius: 50%;
    transform: translate(-50%, -50%);
    box-shadow: 0 0 6px var(--accent-glow);
  }

  .np-time {
    display: flex;
    justify-content: space-between;
    font-size: var(--font-xs);
    color: var(--text-tertiary);
    margin-top: var(--space-xs);
  }

  .np-controls {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: var(--space-lg);
  }

  .np-play-btn {
    width: 56px;
    height: 56px;
    background: var(--text-primary);
    color: var(--bg-primary);
  }

  .np-play-btn:hover {
    transform: scale(1.08);
  }

  .np-ctrl-lg .material-symbols-rounded {
    font-size: 36px !important;
  }

  .np-ctrl-btn.active {
    color: var(--accent);
  }

  .np-like.liked {
    color: var(--accent);
  }

  /* Caption / Lyrics */
  .np-caption {
    margin-top: var(--space-xl);
    border-radius: var(--radius-lg);
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(255,255,255,0.08);
    overflow: hidden;
  }

  .np-caption-toggle {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    padding: var(--space-md) var(--space-lg);
    cursor: pointer;
    color: var(--text-secondary);
    font-size: var(--font-sm);
    font-weight: 600;
    -webkit-tap-highlight-color: transparent;
    transition: color var(--transition-fast);
  }

  .np-caption-toggle:hover {
    color: var(--text-primary);
  }

  .np-caption-arrow {
    margin-left: auto;
    transition: transform 0.3s ease;
  }

  .np-caption-body {
    padding: 0 var(--space-lg) var(--space-lg);
    max-height: 200px;
    overflow-y: auto;
  }

  .np-caption-loading {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    color: var(--text-tertiary);
    font-size: var(--font-sm);
  }

  .np-caption-text {
    font-family: inherit;
    font-size: var(--font-sm);
    color: var(--text-secondary);
    line-height: 1.8;
    white-space: pre-wrap;
    word-wrap: break-word;
    margin: 0;
  }

  /* Scrollbar for lyrics */
  .np-caption-body::-webkit-scrollbar { width: 3px; }
  .np-caption-body::-webkit-scrollbar-thumb { background: var(--accent-dim); border-radius: 3px; }

  /* Tablet landscape split view */
  @media (min-width: 1024px) {
    .np-body {
      flex-direction: row;
      align-items: center;
      justify-content: center;
      gap: var(--space-3xl);
      padding-top: var(--space-xl);
    }
    .np-art-container {
      width: min(320px, 35vw);
      margin-bottom: 0;
    }
    .np-info {
      width: min(400px, 40vw);
    }
  }
`;document.head.appendChild(hr);function zn(){const e=document.createElement("div");e.className="page onboarding-page";const t=new Set;e.innerHTML=`
    <div class="onboarding-content">
      <div class="onboarding-logo">
        <span class="material-symbols-rounded" style="font-size: 48px; color: var(--accent);">music_note</span>
      </div>
      <h1 class="text-greeting" style="text-align: center;">Welcome to Melo</h1>
      <p class="text-subtitle" style="text-align: center; margin-top: var(--space-sm); margin-bottom: var(--space-2xl);">
        What kind of music do you like?<br/>Pick at least 3 to personalize your experience
      </p>
      <div class="onboarding-genres" id="onboarding-genres"></div>
      <button class="onboarding-continue" id="onboarding-continue" disabled>
        Let's Go
      </button>
    </div>
  `;const a=e.querySelector("#onboarding-genres"),r=e.querySelector("#onboarding-continue");return $t.forEach(n=>{const i=document.createElement("button");i.className="onboarding-genre-chip",i.innerHTML=`
      <span class="material-symbols-rounded">${n.icon}</span>
      <span>${n.name}</span>
    `,i.style.setProperty("--genre-gradient",n.gradient),i.addEventListener("click",()=>{t.has(n.id)?(t.delete(n.id),i.classList.remove("selected")):(t.add(n.id),i.classList.add("selected")),r.disabled=t.size<3}),a.appendChild(i)}),r.addEventListener("click",()=>{I.setInterests([...t]),Y.navigate("home")}),e}const mr=document.createElement("style");mr.textContent=`
  .onboarding-page {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100dvh;
    padding-bottom: var(--space-2xl) !important;
  }

  .onboarding-content {
    max-width: 500px;
    width: 100%;
  }

  .onboarding-logo {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 80px;
    height: 80px;
    margin: 0 auto var(--space-xl);
    border-radius: var(--radius-xl);
    background: var(--accent-dim);
    animation: logoPulse 2s ease-in-out infinite;
  }

  @keyframes logoPulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
  }

  .onboarding-genres {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-md);
    justify-content: center;
    margin-bottom: var(--space-2xl);
  }

  .onboarding-genre-chip {
    display: inline-flex;
    align-items: center;
    gap: var(--space-sm);
    padding: var(--space-md) var(--space-xl);
    border-radius: var(--radius-full);
    border: 2px solid var(--surface-border);
    background: var(--bg-tertiary);
    color: var(--text-primary);
    font-family: var(--font-family);
    font-size: var(--font-base);
    font-weight: 500;
    cursor: pointer;
    transition: all var(--transition-normal);
    -webkit-tap-highlight-color: transparent;
  }

  .onboarding-genre-chip:active {
    transform: scale(0.95);
  }

  .onboarding-genre-chip.selected {
    background: var(--genre-gradient, var(--accent));
    border-color: transparent;
    box-shadow: var(--shadow-md);
    transform: scale(1.05);
  }

  .onboarding-genre-chip .material-symbols-rounded {
    font-size: 20px;
  }

  .onboarding-continue {
    display: block;
    width: 100%;
    padding: var(--space-lg);
    border: none;
    border-radius: var(--radius-full);
    background: var(--accent);
    color: var(--text-on-accent);
    font-family: var(--font-family);
    font-size: var(--font-md);
    font-weight: 600;
    cursor: pointer;
    transition: all var(--transition-normal);
    letter-spacing: 0.02em;
  }

  .onboarding-continue:disabled {
    opacity: 0.3;
    cursor: not-allowed;
  }

  .onboarding-continue:not(:disabled):hover {
    box-shadow: var(--shadow-glow);
    transform: translateY(-1px);
  }

  .onboarding-continue:not(:disabled):active {
    transform: scale(0.98);
  }
`;document.head.appendChild(mr);function Tn(){const e=document.createElement("div");e.className="page artist-page";const t=Y.getParams().get("name");return t?(e.innerHTML=`
    <div class="home-loading" id="artist-loading">
      <div class="loading-spinner"></div>
      <p class="text-subtitle">Loading ${t}...</p>
    </div>
    <div id="artist-content" style="display:none; padding-bottom: 120px;"></div>
  `,Rn(t,e),e):(e.innerHTML='<div class="empty-state"><p>Artist not found.</p></div>',e)}async function Rn(e,t){var a;try{const r=t.querySelector("#artist-loading"),n=t.querySelector("#artist-content"),[i,b]=await Promise.allSettled([cr(e),le(`${e} best songs`)]),l=i.status==="fulfilled"?i.value:null,v=b.status==="fulfilled"?b.value||[]:[];r.style.display="none",n.style.display="block";const s=l?l.name:e,d=(l==null?void 0:l.banner)||(l==null?void 0:l.thumbnail)||((a=v[0])==null?void 0:a.cover)||"",y=l!=null&&l.genre?`<span class="chip" style="pointer-events:none;">${l.genre}</span>`:"",o=l!=null&&l.biography?l.biography:`Explore the top hits and popular songs by ${s}.`,x=document.createElement("div");x.className="artist-header",x.innerHTML=`
      <img class="artist-header-bg" src="${d}" alt="Banner" onerror="this.src=''" />
      <div class="artist-header-overlay"></div>
      <button class="btn-icon artist-back-btn"><span class="material-symbols-rounded">arrow_back</span></button>
      
      <div class="artist-header-content">
        <h1 class="artist-title">${s}</h1>
        <div class="artist-meta">
          ${y}
          <span class="text-subtitle" style="color:#fff;">${v.length} top songs</span>
        </div>
      </div>
      ${v.length>0?'<button class="btn-play artist-play-all"><span class="material-symbols-rounded">play_arrow</span></button>':""}
    `,x.querySelector(".artist-back-btn").addEventListener("click",()=>{window.history.back()}),v.length>0&&x.querySelector(".artist-play-all").addEventListener("click",()=>{T.playAll(v,v[0])}),n.appendChild(x);const f=document.createElement("div");f.className="section",f.innerHTML=`
      <div class="section-header">
        <h2 class="text-section-title">About</h2>
      </div>
      <div class="artist-bio-box">
        <p class="artist-bio-text">${o.replace(/\n\n/g,"<br><br>")}</p>
        <button class="artist-bio-more">Read More</button>
      </div>
    `;const g=f.querySelector(".artist-bio-text"),m=f.querySelector(".artist-bio-more");if(m.addEventListener("click",()=>{g.classList.contains("expanded")?(g.classList.remove("expanded"),m.textContent="Read More"):(g.classList.add("expanded"),m.textContent="Show Less")}),o.length<200&&(m.style.display="none",g.classList.add("expanded")),n.appendChild(f),v.length>0){const c=document.createElement("div");c.className="section",c.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Popular Tracks</h2>
        </div>
      `;const p=document.createElement("div");p.style.display="flex",p.style.flexDirection="column",p.style.gap="var(--space-xs)",v.forEach((h,C)=>{const w=ue(h,v,"horizontal");p.appendChild(w)}),c.appendChild(p),n.appendChild(c)}const u=document.createElement("div");u.className="section",u.innerHTML=`
          <div class="section-header">
            <h2 class="text-section-title">Full Discography</h2>
            <div class="loading-spinner" id="disco-loading" style="width:20px;height:20px;border-width:2px;"></div>
          </div>
          <div id="disco-content" class="horizontal-scroll" style="display:none;"></div>
        `,n.appendChild(u),Be(()=>Promise.resolve().then(()=>pr),void 0).then(async({getArtistDiscography:c})=>{const p=await c(e),h=u.querySelector("#disco-loading"),C=u.querySelector("#disco-content");h.style.display="none",p&&p.length>0?(C.style.display="flex",p.forEach(w=>{const E=document.createElement("div");E.className="album-card",E.innerHTML=`
                      <img class="album-card-art" src="${w.cover}" alt="${w.title}" loading="lazy" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\\'http://www.w3.org/2000/svg\\' viewBox=\\'0 0 100 100\\'%3E%3Crect width=\\'100\\' height=\\'100\\' fill=\\'%232a2a2a\\'/%3E%3Ctext x=\\'50\\' y=\\'55\\' font-family=\\'sans-serif\\' font-size=\\'14\\' fill=\\'%23666\\' text-anchor=\\'middle\\'%3EAlbum%3C/text%3E%3C/svg%3E'" />
                      <div class="album-card-title">${w.title}</div>
                      <div class="album-card-info">${w.year} • ${w.type}</div>
                    `,C.appendChild(E)})):u.style.display="none"})}catch{t.innerHTML='<div class="empty-state"><p>Error loading artist.</p></div>'}}const gr=document.createElement("style");gr.textContent=`
  .artist-page {
    /* Override standard page padding so banner touches the top */
    padding-top: 0 !important;
  }

  .artist-header {
    position: relative;
    width: 100%;
    height: 35vh;
    min-height: 280px;
    margin-bottom: var(--space-2xl);
    border-radius: 0 0 var(--radius-2xl) var(--radius-2xl);
    overflow: hidden;
    box-shadow: var(--shadow-md);
  }

  .artist-header-bg {
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    object-fit: cover;
  }

  .artist-header-overlay {
    position: absolute;
    inset: 0;
    /* Dark gradient overlay so text is legible and fades beautifully into the app */
    background: linear-gradient(to bottom, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.8) 100%);
  }

  .artist-back-btn {
    position: absolute;
    top: max(var(--space-md), env(safe-area-inset-top));
    left: var(--space-md);
    z-index: 10;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(8px);
    color: white;
  }

  .artist-header-content {
    position: absolute;
    bottom: var(--space-xl);
    left: var(--space-xl);
    right: var(--space-xl);
    z-index: 2;
  }

  .artist-title {
    font-size: clamp(28px, 6vw, 42px);
    font-weight: 800;
    color: #ffffff;
    margin: 0 0 var(--space-sm) 0;
    line-height: 1.1;
    text-shadow: 0 2px 8px rgba(0,0,0,0.5);
  }

  .artist-meta {
    display: flex;
    align-items: center;
    gap: var(--space-md);
  }

  .artist-play-all {
    position: absolute;
    bottom: calc(var(--space-xl) - 28px);
    right: var(--space-xl);
    z-index: 10;
    transform: scale(1.1);
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  }

  .artist-bio-box {
    background: var(--surface-glass);
    border: 1px solid var(--surface-border);
    border-radius: var(--radius-xl);
    padding: var(--space-lg);
  }

  .artist-bio-text {
    font-size: var(--font-sm);
    color: var(--text-secondary);
    line-height: 1.6;
    margin: 0;
    
    /* Clamp lines by default */
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
    transition: all 0.3s ease;
  }

  .artist-bio-text.expanded {
    display: block;
    -webkit-line-clamp: unset;
  }

  .artist-bio-more {
    background: none;
    border: none;
    color: var(--accent);
    font-weight: 600;
    font-size: var(--font-sm);
    padding: var(--space-md) 0 0 0;
    cursor: pointer;
  }

  .album-card {
    width: 140px;
    flex-shrink: 0;
  }

  .album-card-art {
    width: 100%;
    aspect-ratio: 1;
    object-fit: cover;
    border-radius: var(--radius-md);
    background: var(--bg-tertiary);
    margin-bottom: var(--space-sm);
    box-shadow: var(--shadow-sm);
  }

  .album-card-title {
    font-size: var(--font-sm);
    font-weight: 500;
    color: var(--text-primary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .album-card-info {
    font-size: var(--font-xs);
    color: var(--text-tertiary);
    margin-top: 2px;
  }
`;document.head.appendChild(gr);function Mn(){const e=document.createElement("div");e.className="page podcast-page";const t=Y.getParams(),a=t.get("feed"),r=t.get("title")||"Podcast",n=t.get("artist")||"",i=t.get("cover")||"";return a?(e.innerHTML=`
    <div class="header-nav" style="display:flex; align-items:center; gap:var(--space-md); padding:var(--space-md) 0; margin-bottom:var(--space-lg);">
      <button class="btn-icon" id="podcast-back"><span class="material-symbols-rounded">arrow_back</span></button>
      <h2 class="text-greeting" style="margin:0; font-size:var(--font-lg);">Podcast</h2>
    </div>

    <!-- Header Section -->
    <div style="display:flex; flex-direction:column; align-items:center; text-align:center; margin-bottom:var(--space-2xl);">
      <img src="${i}" alt="${r}" style="width:200px; height:200px; border-radius:var(--radius-xl); object-fit:cover; margin-bottom:var(--space-lg); box-shadow:var(--shadow-lg);" />
      <h1 class="text-section-title" style="margin-bottom:var(--space-xs); font-size:24px;">${r}</h1>
      <p class="text-subtitle" style="font-size:var(--font-md);">${n}</p>
    </div>

    <div class="home-loading" id="podcast-loading">
      <div class="loading-spinner"></div>
      <p class="text-subtitle" style="margin-top:var(--space-sm);">Loading latest episodes...</p>
    </div>
    
    <div id="podcast-content" style="display:none; padding-bottom: 120px;"></div>
  `,e.querySelector("#podcast-back").addEventListener("click",()=>{window.history.back()}),In(a,i,n,e),e):(e.innerHTML='<div class="empty-state"><p>Podcast not found.</p></div>',e)}async function In(e,t,a,r){try{const n=r.querySelector("#podcast-loading"),i=r.querySelector("#podcast-content"),b=await xr(e,t,a);if(n.style.display="none",i.style.display="block",b.length===0){i.innerHTML=`
        <div class="empty-state">
          <span class="material-symbols-rounded">podcasts</span>
          <p>No episodes found or feed is unsupported.</p>
        </div>
      `;return}const l=document.createElement("div");l.innerHTML=`
      <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:var(--space-lg);">
        <h2 class="text-section-title">Latest Episodes</h2>
        <button class="chip" id="podcast-play-all">
          <span class="material-symbols-rounded" style="font-size:16px;">play_arrow</span> Play Latest
        </button>
      </div>
    `,l.querySelector("#podcast-play-all").addEventListener("click",()=>{T.playAll(b,b[0])}),i.appendChild(l);const v=document.createElement("div");v.style.display="flex",v.style.flexDirection="column",v.style.gap="var(--space-md)",b.forEach(s=>{const d=document.createElement("div");d.className="podcast-ep-card",d.innerHTML=`
        <div class="podcast-ep-meta">
          <span class="text-subtitle" style="font-size:12px;">${Nn(s.date)}</span>
        </div>
        <div class="podcast-ep-main">
          <div class="podcast-ep-info">
            <h3 class="podcast-ep-title">${s.title}</h3>
            <p class="podcast-ep-desc">${s.description}</p>
          </div>
          <button class="btn-play podcast-ep-play"><span class="material-symbols-rounded">play_arrow</span></button>
        </div>
      `,d.querySelector(".podcast-ep-play").addEventListener("click",()=>{T.playAll(b,s)}),v.appendChild(d)}),i.appendChild(v)}catch{r.querySelector("#podcast-loading").innerHTML=`
      <div class="empty-state">
        <span class="material-symbols-rounded">error</span>
        <p>Could not load episodes.</p>
      </div>
    `}}function Nn(e){if(!e)return"Recent";try{const t=new Date(e);return isNaN(t.getTime())?e:t.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}catch{return e}}const yr=document.createElement("style");yr.textContent=`
  .podcast-ep-card {
    background: var(--surface-glass);
    border: 1px solid var(--surface-border);
    border-radius: var(--radius-lg);
    padding: var(--space-md);
  }

  .podcast-ep-meta {
    margin-bottom: var(--space-xs);
  }

  .podcast-ep-main {
    display: flex;
    align-items: center;
    gap: var(--space-md);
  }

  .podcast-ep-info {
    flex: 1;
    min-width: 0;
  }

  .podcast-ep-title {
    font-size: var(--font-md);
    font-weight: 600;
    color: var(--text-primary);
    margin: 0 0 var(--space-xs) 0;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  .podcast-ep-desc {
    font-size: 13px;
    color: var(--text-secondary);
    margin: 0;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  .podcast-ep-play {
    width: 44px;
    height: 44px;
    flex-shrink: 0;
  }
`;document.head.appendChild(yr);const br="1.0.10",jn="https://api.github.com/repos/maheshwarkibehan-hub/MElo-music-player/contents/version.json";function On(e,t){const a=e.split(".").map(Number),r=t.split(".").map(Number);for(let n=0;n<Math.max(a.length,r.length);n++){const i=a[n]||0,b=r[n]||0;if(i>b)return!0;if(i<b)return!1}return!1}function Un(){const e=document.createElement("div");return e.className="page settings-page",e.innerHTML=`
    <div class="settings-header">
      <h1 class="settings-title">Settings</h1>
    </div>

    <div class="settings-section">
      <div class="settings-section-title">App Info</div>
      <div class="settings-card">
        <div class="settings-row">
          <span class="material-symbols-rounded" style="color: var(--accent);">info</span>
          <div class="settings-row-text">
            <span class="settings-label">Current Version</span>
            <span class="settings-value" id="settings-version">${br}</span>
          </div>
        </div>
        <div class="settings-divider"></div>
        <div class="settings-row">
          <span class="material-symbols-rounded" style="color: var(--accent);">cloud_done</span>
          <div class="settings-row-text">
            <span class="settings-label">Update Status</span>
            <span class="settings-value" id="settings-status">Checking...</span>
          </div>
        </div>
        <div class="settings-divider"></div>
        <div class="settings-row">
          <span class="material-symbols-rounded" style="color: var(--accent);">new_releases</span>
          <div class="settings-row-text">
            <span class="settings-label">Latest Version</span>
            <span class="settings-value" id="settings-latest">--</span>
          </div>
        </div>
      </div>
    </div>

    <div class="settings-section">
      <div class="settings-section-title">Updates</div>
      <div class="settings-card">
        <button class="settings-btn" id="settings-check-update">
          <span class="material-symbols-rounded">system_update</span>
          <span>Check for Updates</span>
        </button>
        <div id="settings-update-area"></div>
      </div>
    </div>

    <div class="settings-section">
      <div class="settings-section-title">About</div>
      <div class="settings-card">
        <div class="settings-row">
          <span class="material-symbols-rounded" style="color: var(--text-secondary);">code</span>
          <div class="settings-row-text">
            <span class="settings-label">Developer</span>
            <span class="settings-value">Maheshwar</span>
          </div>
        </div>
        <div class="settings-divider"></div>
        <div class="settings-row">
          <span class="material-symbols-rounded" style="color: var(--text-secondary);">music_note</span>
          <div class="settings-row-text">
            <span class="settings-label">App Name</span>
            <span class="settings-value">Melo Music Player</span>
          </div>
        </div>
      </div>
    </div>
  `,setTimeout(()=>U0(e),500),e.querySelector("#settings-check-update").addEventListener("click",()=>U0(e)),e}async function U0(e){const t=e.querySelector("#settings-status"),a=e.querySelector("#settings-latest"),r=e.querySelector("#settings-update-area"),n=e.querySelector("#settings-check-update");n.disabled=!0,n.querySelector("span:last-child").textContent="Checking...",t.textContent="Checking...",t.style.color="var(--text-secondary)";try{const i=await fetch(jn+"?t="+Date.now(),{headers:{Accept:"application/vnd.github.v3.raw"},cache:"no-store"});if(!i.ok)throw new Error("Failed: "+i.status);const b=await i.json();a.textContent=b.version||"--",On(b.version,br)?(t.textContent="Update available!",t.style.color="#ff9800",r.innerHTML=`
        <div class="settings-divider"></div>
        <p class="settings-hint" style="color:#ff9800;font-weight:600;">v${b.version} is available!</p>
      `):(t.textContent="Up to date",t.style.color="#4caf50",r.innerHTML="")}catch{t.textContent="Check failed",t.style.color="#e53935",a.textContent="--"}n.disabled=!1,n.querySelector("span:last-child").textContent="Check for Updates"}const Cr=document.createElement("style");Cr.textContent=`
  .settings-page { padding: 20px 16px 120px; }
  .settings-header { padding: 20px 0 10px; }
  .settings-title { font-size: 28px; font-weight: 700; color: var(--text-primary); }
  .settings-section { margin-bottom: 24px; }
  .settings-section-title { font-size: 13px; font-weight: 600; color: var(--accent); text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 10px; padding-left: 4px; }
  .settings-card { background: var(--surface); border-radius: 16px; padding: 4px 0; border: 1px solid var(--surface-border); }
  .settings-row { display: flex; align-items: center; gap: 14px; padding: 14px 18px; }
  .settings-row .material-symbols-rounded { font-size: 22px; flex-shrink: 0; }
  .settings-row-text { display: flex; flex-direction: column; flex: 1; min-width: 0; }
  .settings-label { font-size: 15px; font-weight: 500; color: var(--text-primary); }
  .settings-value { font-size: 13px; color: var(--text-secondary); margin-top: 2px; }
  .settings-divider { height: 1px; background: var(--surface-border); margin: 0 18px; }
  .settings-btn { display: flex; align-items: center; justify-content: center; gap: 10px; width: calc(100% - 24px); margin: 10px 12px; padding: 14px; border-radius: 12px; border: none; background: rgba(255,255,255,0.05); color: var(--text-primary); font-weight: 600; font-size: 15px; cursor: pointer; font-family: var(--font-family); transition: all 0.2s ease; }
  .settings-btn:active { transform: scale(0.97); }
  .settings-btn:disabled { opacity: 0.5; pointer-events: none; }
  .settings-hint { text-align: center; font-size: 13px; color: var(--text-secondary); margin: 8px 0 12px; padding: 0; }
`;document.head.appendChild(Cr);var Pt;(function(e){e.Dark="DARK",e.Light="LIGHT",e.Default="DEFAULT"})(Pt||(Pt={}));var W0;(function(e){e.None="NONE",e.Slide="SLIDE",e.Fade="FADE"})(W0||(W0={}));const K0=de("StatusBar");de("SplashScreen",{web:()=>Be(()=>import("./web-CBbWd862.js"),[]).then(e=>new e.SplashScreenWeb)});const G0=de("App",{web:()=>Be(()=>import("./web-yFgQ1EVO.js"),[]).then(e=>new e.AppWeb)});var X0;(function(e){e[e.Sunday=1]="Sunday",e[e.Monday=2]="Monday",e[e.Tuesday=3]="Tuesday",e[e.Wednesday=4]="Wednesday",e[e.Thursday=5]="Thursday",e[e.Friday=6]="Friday",e[e.Saturday=7]="Saturday"})(X0||(X0={}));const St=de("LocalNotifications",{web:()=>Be(()=>import("./web-Bl-31fAO.js"),[]).then(e=>new e.LocalNotificationsWeb)});async function Wn(){try{let a=function(r,n){const i=r.split(".").map(Number),b=n.split(".").map(Number);for(let l=0;l<Math.max(i.length,b.length);l++){const v=i[l]||0,s=b[l]||0;if(v>s)return!0;if(v<s)return!1}return!1};try{await K0.setOverlaysWebView({overlay:!0})}catch{}try{await K0.setStyle({style:Pt.Dark})}catch{}try{(await St.checkPermissions()).display!=="granted"&&await St.requestPermissions()}catch{}try{await St.createChannel({id:"media_playback",name:"Music Controls",description:"Music playback controls",importance:5,visibility:1,sound:null,vibration:!1})}catch{}CapacitorUpdater.notifyAppReady().catch(()=>{});const e="1.0.10",t="https://api.github.com/repos/maheshwarkibehan-hub/MElo-music-player/contents/version.json";window.__otaChecked||(window.__otaChecked=!0,window.setTimeout(async()=>{try{console.log("[OTA] Checking for updates...");let r;try{const i=await fetch(t+"?t="+Date.now(),{headers:{Accept:"application/vnd.github.v3.raw"},cache:"no-store"});if(!i.ok)throw new Error("Version check failed: "+i.status);r=await i.json()}catch(i){console.log("[OTA] Version check unavailable:",i.message);return}if(!r||!r.version||!r.url){console.log("[OTA] Invalid version data");return}if(!a(r.version,e)){console.log("[OTA] Already up to date:",e);return}console.log("[OTA] New version available:",r.version);const n=document.createElement("div");n.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,0.8);backdrop-filter:blur(10px);display:flex;align-items:center;justify-content:center;z-index:999999;opacity:0;transition:opacity 0.3s ease;padding:20px;",n.innerHTML=`
                      <div style="background:#1a1a2e;border-radius:20px;padding:28px;max-width:340px;width:100%;text-align:center;transform:translateY(20px);transition:transform 0.3s ease;border:1px solid rgba(255,255,255,0.08);">
                        <span class="material-symbols-rounded" style="font-size:48px;color:#bb86fc;margin-bottom:12px;display:block;">system_update</span>
                        <h2 style="color:#fff;margin:0 0 8px;font-size:20px;">Update Available</h2>
                        <p style="color:rgba(255,255,255,0.6);margin:0 0 24px;font-size:14px;">v${e} → v${r.version}</p>
                        <p style="color:rgba(255,255,255,0.4);margin:0 0 20px;font-size:12px;">Check Settings for details</p>
                        <button id="ota-ok" style="width:100%;padding:14px;border-radius:12px;border:none;background:#bb86fc;color:#1a1a2e;font-weight:700;font-size:15px;cursor:pointer;">OK</button>
                      </div>`,document.body.appendChild(n),requestAnimationFrame(()=>{n.style.opacity="1",n.firstElementChild.style.transform="translateY(0)"}),document.getElementById("ota-ok").onclick=()=>{n.style.opacity="0",setTimeout(()=>n.remove(),300)}}catch(r){console.log("[OTA] Update check error:",r)}},3e3))}catch(e){console.warn("Native APIs not available:",e)}}const Kn=async()=>{try{await J0.impact({style:Et.Light})}catch{}},Gn=()=>{const e=localStorage.getItem("melo-zoom")||"1.0";document.documentElement.style.setProperty("--zoom",e),document.body.style.zoom=e};Gn();Wn();G0.addListener("backButton",({canGoBack:e})=>{window.location.hash&&window.location.hash!=="#/home"?window.history.back():G0.exitApp()});function Xn(){const e=document.getElementById("app");if(!I.get().onboarded){e.innerHTML="",e.appendChild(zn());const a=I.subscribe(r=>{r==="interests"&&(a(),V0())});return}V0()}function V0(){const e=document.getElementById("app");e.innerHTML="";const t=document.createElement("main");t.id="page-content",e.appendChild(t),e.appendChild(ta()),e.appendChild(Rr()),Y.register("home",Sn),Y.register("search",Ln),Y.register("library",qn),Y.register("nowplaying",Hn),Y.register("artist",Tn),Y.register("podcast",Mn),Y.register("settings",Un),Y.init(t),(!window.location.hash||window.location.hash==="#")&&Y.navigate("home"),window.addEventListener("routechange",()=>{Kn()})}window.onerror=(e,t,a,r,n)=>{const i=document.createElement("div");i.style.cssText="position:fixed;top:0;left:0;right:0;padding:20px;background:#e53935;color:#fff;z-index:99999;font-size:14px;white-space:pre-wrap;font-family:monospace;",i.textContent=`ERROR: ${e}
File: ${t}
Line: ${a}:${r}
${(n==null?void 0:n.stack)||""}`,document.body.appendChild(i)};window.addEventListener("unhandledrejection",e=>{var a,r;const t=document.createElement("div");t.style.cssText="position:fixed;top:0;left:0;right:0;padding:20px;background:#e53935;color:#fff;z-index:99999;font-size:14px;white-space:pre-wrap;font-family:monospace;",t.textContent=`PROMISE ERROR: ${((a=e.reason)==null?void 0:a.message)||e.reason}
${((r=e.reason)==null?void 0:r.stack)||""}`,document.body.appendChild(t)});"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").then(e=>console.log("SW registered:",e.scope)).catch(e=>console.warn("SW registration failed:",e))});try{Xn()}catch(e){document.body.innerHTML=`<div style="padding:20px;color:#e53935;font-family:monospace;"><h2>App Crash</h2><pre>${e.message}
${e.stack}</pre></div>`}export{Et as I,a0 as N,Ht as W};
