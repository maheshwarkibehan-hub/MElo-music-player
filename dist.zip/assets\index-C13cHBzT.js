(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))r(n);new MutationObserver(n=>{for(const s of n)if(s.type==="childList")for(const b of s.addedNodes)b.tagName==="LINK"&&b.rel==="modulepreload"&&r(b)}).observe(document,{childList:!0,subtree:!0});function a(n){const s={};return n.integrity&&(s.integrity=n.integrity),n.referrerPolicy&&(s.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?s.credentials="include":n.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function r(n){if(n.ep)return;n.ep=!0;const s=a(n);fetch(n.href,s)}})();const er=new Map;let qe=null;const Y={register(e,t){er.set(e,t)},init(e){qe=e,window.addEventListener("hashchange",()=>this._navigate()),this._navigate()},navigate(e){window.location.hash=e},getCurrentRoute(){return(window.location.hash.slice(1)||"home").split("?")[0]},getParams(){const t=(window.location.hash.slice(1)||"").split("?")[1];return new URLSearchParams(t||"")},_navigate(){const e=this.getCurrentRoute(),t=er.get(e);if(t&&qe){qe.innerHTML="";const a=t();typeof a=="string"?qe.innerHTML=a:a instanceof HTMLElement&&qe.appendChild(a),window.dispatchEvent(new CustomEvent("routechange",{detail:{route:e}}))}}},e0="melo_state",t0={interests:[],onboarded:!1,recentlyPlayed:[],likedSongs:[],playlists:[],trackMetadata:{},currentTrackId:null,queue:[],queueIndex:0,shuffle:!1,repeat:"off",volume:1,downloads:{}};let H={...t0};function N0(){try{const e=localStorage.getItem(e0);e&&(H={...t0,...JSON.parse(e)})}catch(e){console.warn("Failed to load state:",e)}}function M0(){try{localStorage.setItem(e0,JSON.stringify(H))}catch(e){console.warn("Failed to save state:",e)}}const qt=new Set;function I0(e){return qt.add(e),()=>qt.delete(e)}function X(e){qt.forEach(t=>t(e,H)),M0()}const M={get:()=>H,subscribe:I0,setInterests(e){H.interests=e,H.onboarded=!0,X("interests")},addRecentlyPlayed(e){!e||!e.id||(H.trackMetadata[e.id]=e,H.recentlyPlayed=[e.id,...H.recentlyPlayed.filter(t=>t!==e.id)].slice(0,20),X("recentlyPlayed"))},toggleLike(e){if(!e||!e.id)return;H.trackMetadata[e.id]=e;const t=e.id,a=H.likedSongs.indexOf(t);a===-1?H.likedSongs.push(t):H.likedSongs.splice(a,1),X("likedSongs")},isLiked(e){return H.likedSongs.includes(e)},setQueue(e,t=0){H.queue=[...e],H.queueIndex=t,H.currentTrackId=e[t]||null,X("queue")},nextInQueue(){if(H.repeat==="one")return X("queue"),H.currentTrackId;if(H.shuffle){const e=H.queue.filter(t=>t!==H.currentTrackId);if(e.length>0){const t=e[Math.floor(Math.random()*e.length)];H.queueIndex=H.queue.indexOf(t),H.currentTrackId=t}}else{if(H.queueIndex++,H.queueIndex>=H.queue.length)if(H.repeat==="all")H.queueIndex=0;else return H.queueIndex=H.queue.length-1,X("queue"),null;H.currentTrackId=H.queue[H.queueIndex]}return X("queue"),H.currentTrackId},prevInQueue(){if(H.shuffle){const e=H.queue.filter(t=>t!==H.currentTrackId);if(e.length>0){const t=e[Math.floor(Math.random()*e.length)];H.queueIndex=H.queue.indexOf(t),H.currentTrackId=t}}else H.queueIndex--,H.queueIndex<0&&(H.queueIndex=H.repeat==="all"?H.queue.length-1:0),H.currentTrackId=H.queue[H.queueIndex];return X("queue"),H.currentTrackId},toggleShuffle(){H.shuffle=!H.shuffle,X("shuffle")},cycleRepeat(){const e=["off","all","one"],t=e.indexOf(H.repeat);H.repeat=e[(t+1)%e.length],X("repeat")},setVolume(e){H.volume=Math.max(0,Math.min(1,e)),X("volume")},createPlaylist(e){const t=Date.now().toString();return H.playlists.push({id:t,name:e,trackIds:[]}),X("playlists"),t},addToPlaylist(e,t){if(!t||!t.id)return;H.trackMetadata[t.id]=t;const a=H.playlists.find(r=>r.id===e);a&&!a.trackIds.includes(t.id)&&(a.trackIds.push(t.id),X("playlists"))},removeFromPlaylist(e,t){const a=H.playlists.find(r=>r.id===e);a&&(a.trackIds=a.trackIds.filter(r=>r!==t),X("playlists"))},deletePlaylist(e){H.playlists=H.playlists.filter(t=>t.id!==e),X("playlists")},updateDownload(e,t){H.downloads[e]={...H.downloads[e],...t},t.track&&(H.trackMetadata[e]=t.track),X("downloads")},removeDownload(e){delete H.downloads[e],X("downloads")},isDownloadComplete(e){var t;return((t=H.downloads[e])==null?void 0:t.status)==="complete"},getDownloads(){return Object.entries(H.downloads).filter(([,e])=>e.status==="complete").map(([e,t])=>({id:e,...t}))}};N0();function O0(){const e=document.createElement("nav");e.className="navbar",e.innerHTML=`
    <button class="nav-item active" data-route="home" id="nav-home">
      <span class="material-symbols-rounded">home</span>
      <span class="nav-label">Home</span>
    </button>
    <button class="nav-item" data-route="search" id="nav-search">
      <span class="material-symbols-rounded">search</span>
      <span class="nav-label">Search</span>
    </button>
    <button class="nav-item" data-route="library" id="nav-library">
      <span class="material-symbols-rounded">library_music</span>
      <span class="nav-label">Library</span>
    </button>
    <button class="nav-item" data-route="settings" id="nav-settings">
      <span class="material-symbols-rounded">settings</span>
      <span class="nav-label">Settings</span>
    </button>
  `;const t=e.querySelectorAll(".nav-item");return t.forEach(a=>{a.addEventListener("click",()=>{Y.navigate(a.dataset.route)})}),window.addEventListener("routechange",a=>{t.forEach(r=>{r.classList.toggle("active",r.dataset.route===a.detail.route)})}),e}const r0=document.createElement("style");r0.textContent=`
  .navbar {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 100;
    display: flex;
    align-items: center;
    justify-content: space-around;
    height: var(--nav-height);
    background: linear-gradient(to top, var(--bg-primary) 60%, transparent);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    padding-bottom: var(--safe-bottom);
    border-top: 1px solid var(--surface-border);
  }

  .nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2px;
    padding: var(--space-sm) var(--space-xl);
    border: none;
    background: transparent;
    color: var(--text-tertiary);
    cursor: pointer;
    transition: color var(--transition-fast), transform var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
    font-family: var(--font-family);
    border-radius: var(--radius-lg);
  }

  .nav-item:active {
    transform: scale(0.9);
  }

  .nav-item .material-symbols-rounded {
    font-size: 26px;
    transition: font-variation-settings var(--transition-fast);
  }

  .nav-item.active {
    color: var(--text-primary);
  }

  .nav-item.active .material-symbols-rounded {
    font-variation-settings: 'FILL' 1, 'wght' 600, 'GRAD' 0, 'opsz' 24;
  }

  .nav-label {
    font-size: 10px;
    font-weight: 500;
    letter-spacing: 0.02em;
  }
`;document.head.appendChild(r0);const j0="modulepreload",U0=function(e){return"/"+e},tr={},Be=function(t,a,r){let n=Promise.resolve();if(a&&a.length>0){let b=function(i){return Promise.all(i.map(x=>Promise.resolve(x).then(w=>({status:"fulfilled",value:w}),w=>({status:"rejected",reason:w}))))};document.getElementsByTagName("link");const d=document.querySelector("meta[property=csp-nonce]"),h=(d==null?void 0:d.nonce)||(d==null?void 0:d.getAttribute("nonce"));n=b(a.map(i=>{if(i=U0(i),i in tr)return;tr[i]=!0;const x=i.endsWith(".css"),w=x?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${i}"]${w}`))return;const o=document.createElement("link");if(o.rel=x?"stylesheet":j0,x||(o.as="script"),o.crossOrigin="",o.href=i,h&&o.setAttribute("nonce",h),document.head.appendChild(o),x)return new Promise((p,f)=>{o.addEventListener("load",p),o.addEventListener("error",()=>f(new Error(`Unable to preload CSS for ${i}`)))})}))}function s(b){const d=new Event("vite:preloadError",{cancelable:!0});if(d.payload=b,window.dispatchEvent(d),!d.defaultPrevented)throw b}return n.then(b=>{for(const d of b||[])d.status==="rejected"&&s(d.reason);return t().catch(s)})};/*! Capacitor: https://capacitorjs.com/ - MIT License */var Ce;(function(e){e.Unimplemented="UNIMPLEMENTED",e.Unavailable="UNAVAILABLE"})(Ce||(Ce={}));class Dt extends Error{constructor(t,a,r){super(t),this.message=t,this.code=a,this.data=r}}const W0=e=>{var t,a;return e!=null&&e.androidBridge?"android":!((a=(t=e==null?void 0:e.webkit)===null||t===void 0?void 0:t.messageHandlers)===null||a===void 0)&&a.bridge?"ios":"web"},K0=e=>{const t=e.CapacitorCustomPlatform||null,a=e.Capacitor||{},r=a.Plugins=a.Plugins||{},n=()=>t!==null?t.name:W0(e),s=()=>n()!=="web",b=w=>{const o=i.get(w);return!!(o!=null&&o.platforms.has(n())||d(w))},d=w=>{var o;return(o=a.PluginHeaders)===null||o===void 0?void 0:o.find(p=>p.name===w)},h=w=>e.console.error(w),i=new Map,x=(w,o={})=>{const p=i.get(w);if(p)return console.warn(`Capacitor plugin "${w}" already registered. Cannot register plugins twice.`),p.proxy;const f=n(),y=d(w);let g;const u=async()=>(!g&&f in o?g=typeof o[f]=="function"?g=await o[f]():g=o[f]:t!==null&&!g&&"web"in o&&(g=typeof o.web=="function"?g=await o.web():g=o.web),g),l=(B,D)=>{var A,_;if(y){const k=y==null?void 0:y.methods.find(F=>D===F.name);if(k)return k.rtype==="promise"?F=>a.nativePromise(w,D.toString(),F):(F,$)=>a.nativeCallback(w,D.toString(),F,$);if(B)return(A=B[D])===null||A===void 0?void 0:A.bind(B)}else{if(B)return(_=B[D])===null||_===void 0?void 0:_.bind(B);throw new Dt(`"${w}" plugin is not implemented on ${f}`,Ce.Unimplemented)}},c=B=>{let D;const A=(..._)=>{const k=u().then(F=>{const $=l(F,B);if($){const T=$(..._);return D=T==null?void 0:T.remove,T}else throw new Dt(`"${w}.${B}()" is not implemented on ${f}`,Ce.Unimplemented)});return B==="addListener"&&(k.remove=async()=>D()),k};return A.toString=()=>`${B.toString()}() { [capacitor code] }`,Object.defineProperty(A,"name",{value:B,writable:!1,configurable:!1}),A},m=c("addListener"),v=c("removeListener"),E=(B,D)=>{const A=m({eventName:B},D),_=async()=>{const F=await A;v({eventName:B,callbackId:F},D)},k=new Promise(F=>A.then(()=>F({remove:_})));return k.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await _()},k},C=new Proxy({},{get(B,D){switch(D){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return y?E:m;case"removeListener":return v;default:return c(D)}}});return r[w]=C,i.set(w,{name:w,proxy:C,platforms:new Set([...Object.keys(o),...y?[f]:[]])}),C};return a.convertFileSrc||(a.convertFileSrc=w=>w),a.getPlatform=n,a.handleError=h,a.isNativePlatform=s,a.isPluginAvailable=b,a.registerPlugin=x,a.Exception=Dt,a.DEBUG=!!a.DEBUG,a.isLoggingEnabled=!!a.isLoggingEnabled,a},G0=e=>e.Capacitor=K0(e),Et=G0(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),de=Et.registerPlugin;class Rt{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(t,a){let r=!1;this.listeners[t]||(this.listeners[t]=[],r=!0),this.listeners[t].push(a);const s=this.windowListeners[t];s&&!s.registered&&this.addWindowListener(s),r&&this.sendRetainedArgumentsForEvent(t);const b=async()=>this.removeListener(t,a);return Promise.resolve({remove:b})}async removeAllListeners(){this.listeners={};for(const t in this.windowListeners)this.removeWindowListener(this.windowListeners[t]);this.windowListeners={}}notifyListeners(t,a,r){const n=this.listeners[t];if(!n){if(r){let s=this.retainedEventArguments[t];s||(s=[]),s.push(a),this.retainedEventArguments[t]=s}return}n.forEach(s=>s(a))}hasListeners(t){var a;return!!(!((a=this.listeners[t])===null||a===void 0)&&a.length)}registerWindowListener(t,a){this.windowListeners[a]={registered:!1,windowEventName:t,pluginEventName:a,handler:r=>{this.notifyListeners(a,r)}}}unimplemented(t="not implemented"){return new Et.Exception(t,Ce.Unimplemented)}unavailable(t="not available"){return new Et.Exception(t,Ce.Unavailable)}async removeListener(t,a){const r=this.listeners[t];if(!r)return;const n=r.indexOf(a);this.listeners[t].splice(n,1),this.listeners[t].length||this.removeWindowListener(this.windowListeners[t])}addWindowListener(t){window.addEventListener(t.windowEventName,t.handler),t.registered=!0}removeWindowListener(t){t&&(window.removeEventListener(t.windowEventName,t.handler),t.registered=!1)}sendRetainedArgumentsForEvent(t){const a=this.retainedEventArguments[t];a&&(delete this.retainedEventArguments[t],a.forEach(r=>{this.notifyListeners(t,r)}))}}const rr=e=>encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),ar=e=>e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class V0 extends Rt{async getCookies(){const t=document.cookie,a={};return t.split(";").forEach(r=>{if(r.length<=0)return;let[n,s]=r.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");n=ar(n).trim(),s=ar(s).trim(),a[n]=s}),a}async setCookie(t){try{const a=rr(t.key),r=rr(t.value),n=t.expires?`; expires=${t.expires.replace("expires=","")}`:"",s=(t.path||"/").replace("path=",""),b=t.url!=null&&t.url.length>0?`domain=${t.url}`:"";document.cookie=`${a}=${r||""}${n}; path=${s}; ${b};`}catch(a){return Promise.reject(a)}}async deleteCookie(t){try{document.cookie=`${t.key}=; Max-Age=0`}catch(a){return Promise.reject(a)}}async clearCookies(){try{const t=document.cookie.split(";")||[];for(const a of t)document.cookie=a.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(t){return Promise.reject(t)}}async clearAllCookies(){try{await this.clearCookies()}catch(t){return Promise.reject(t)}}}de("CapacitorCookies",{web:()=>new V0});const X0=async e=>new Promise((t,a)=>{const r=new FileReader;r.onload=()=>{const n=r.result;t(n.indexOf(",")>=0?n.split(",")[1]:n)},r.onerror=n=>a(n),r.readAsDataURL(e)}),Y0=(e={})=>{const t=Object.keys(e);return Object.keys(e).map(n=>n.toLocaleLowerCase()).reduce((n,s,b)=>(n[s]=e[t[b]],n),{})},Q0=(e,t=!0)=>e?Object.entries(e).reduce((r,n)=>{const[s,b]=n;let d,h;return Array.isArray(b)?(h="",b.forEach(i=>{d=t?encodeURIComponent(i):i,h+=`${s}=${d}&`}),h.slice(0,-1)):(d=t?encodeURIComponent(b):b,h=`${s}=${d}`),`${r}&${h}`},"").substr(1):null,Z0=(e,t={})=>{const a=Object.assign({method:e.method||"GET",headers:e.headers},t),n=Y0(e.headers)["content-type"]||"";if(typeof e.data=="string")a.body=e.data;else if(n.includes("application/x-www-form-urlencoded")){const s=new URLSearchParams;for(const[b,d]of Object.entries(e.data||{}))s.set(b,d);a.body=s.toString()}else if(n.includes("multipart/form-data")||e.data instanceof FormData){const s=new FormData;if(e.data instanceof FormData)e.data.forEach((d,h)=>{s.append(h,d)});else for(const d of Object.keys(e.data))s.append(d,e.data[d]);a.body=s;const b=new Headers(a.headers);b.delete("content-type"),a.headers=b}else(n.includes("application/json")||typeof e.data=="object")&&(a.body=JSON.stringify(e.data));return a};class J0 extends Rt{async request(t){const a=Z0(t,t.webFetchExtra),r=Q0(t.params,t.shouldEncodeUrlParams),n=r?`${t.url}?${r}`:t.url,s=await fetch(n,a),b=s.headers.get("content-type")||"";let{responseType:d="text"}=s.ok?t:{};b.includes("application/json")&&(d="json");let h,i;switch(d){case"arraybuffer":case"blob":i=await s.blob(),h=await X0(i);break;case"json":h=await s.json();break;case"document":case"text":default:h=await s.text()}const x={};return s.headers.forEach((w,o)=>{x[o]=w}),{data:h,headers:x,status:s.status,url:s.url}}async get(t){return this.request(Object.assign(Object.assign({},t),{method:"GET"}))}async post(t){return this.request(Object.assign(Object.assign({},t),{method:"POST"}))}async put(t){return this.request(Object.assign(Object.assign({},t),{method:"PUT"}))}async patch(t){return this.request(Object.assign(Object.assign({},t),{method:"PATCH"}))}async delete(t){return this.request(Object.assign(Object.assign({},t),{method:"DELETE"}))}}const ea=de("CapacitorHttp",{web:()=>new J0});var nr;(function(e){e.Dark="DARK",e.Light="LIGHT",e.Default="DEFAULT"})(nr||(nr={}));var ir;(function(e){e.StatusBar="StatusBar",e.NavigationBar="NavigationBar"})(ir||(ir={}));class ta extends Rt{async setStyle(){this.unavailable("not available for web")}async setAnimation(){this.unavailable("not available for web")}async show(){this.unavailable("not available for web")}async hide(){this.unavailable("not available for web")}}de("SystemBars",{web:()=>new ta});var Ct;(function(e){e.Heavy="HEAVY",e.Medium="MEDIUM",e.Light="LIGHT"})(Ct||(Ct={}));var sr;(function(e){e.Success="SUCCESS",e.Warning="WARNING",e.Error="ERROR"})(sr||(sr={}));const a0=de("Haptics",{web:()=>Be(()=>import("./web-DaV3ohC_.js"),[]).then(e=>new e.HapticsWeb)}),ra="melo_downloads",aa=1,Z="tracks";let Te=null;const Pt=new Set;function we(){return new Promise((e,t)=>{if(Te)return e(Te);const a=indexedDB.open(ra,aa);a.onupgradeneeded=r=>{const n=r.target.result;n.objectStoreNames.contains(Z)||n.createObjectStore(Z,{keyPath:"id"})},a.onsuccess=r=>{Te=r.target.result,e(Te)},a.onerror=r=>t(r.target.error)})}function ze(e,t){Pt.forEach(a=>a(e,t))}async function or(e){const t=await fetch(e);if(!t.ok)throw new Error(`Download failed: ${t.status}`);return await t.blob()}const he={on(e){return Pt.add(e),()=>Pt.delete(e)},async downloadTrack(e){if(!e||!e.url||!e.id)return!1;try{if(await this.isDownloaded(e.id))return console.log("Already downloaded:",e.title),!0;ze("start",{trackId:e.id,title:e.title}),M.updateDownload(e.id,{status:"downloading",track:e});const t=await or(e.url);let a=null;try{const d=e.coverSmall||e.cover;d&&(a=await or(d))}catch(d){console.warn("Cover download failed:",d)}const s=(await we()).transaction(Z,"readwrite").objectStore(Z),b={id:e.id,title:e.title,artist:e.artist,album:e.album||"",duration:e.duration||0,cover:e.cover||"",coverSmall:e.coverSmall||"",originalUrl:e.url,audioBlob:t,coverBlob:a,downloadedAt:Date.now(),size:t.size};return await new Promise((d,h)=>{const i=s.put(b);i.onsuccess=()=>d(),i.onerror=x=>h(x.target.error)}),M.updateDownload(e.id,{status:"complete",track:e}),ze("complete",{trackId:e.id,title:e.title}),console.log(`Downloaded: ${e.title} (${(t.size/1024/1024).toFixed(1)}MB)`),!0}catch(t){return console.error("Download failed:",t),M.updateDownload(e.id,{status:"error",track:e}),ze("error",{trackId:e.id,error:t.message}),!1}},async isDownloaded(e){try{const r=(await we()).transaction(Z,"readonly").objectStore(Z);return new Promise(n=>{const s=r.get(e);s.onsuccess=()=>n(!!s.result),s.onerror=()=>n(!1)})}catch{return!1}},async getPlaybackUrl(e){try{const r=(await we()).transaction(Z,"readonly").objectStore(Z);return new Promise((n,s)=>{const b=r.get(e);b.onsuccess=()=>{b.result&&b.result.audioBlob?n(URL.createObjectURL(b.result.audioBlob)):n(null)},b.onerror=()=>n(null)})}catch{return null}},async getCoverUrl(e){try{const r=(await we()).transaction(Z,"readonly").objectStore(Z);return new Promise(n=>{const s=r.get(e);s.onsuccess=()=>{s.result&&s.result.coverBlob?n(URL.createObjectURL(s.result.coverBlob)):n(null)},s.onerror=()=>n(null)})}catch{return null}},async getAllDownloads(){try{const a=(await we()).transaction(Z,"readonly").objectStore(Z);return new Promise(r=>{const n=a.getAll();n.onsuccess=()=>{const s=(n.result||[]).map(b=>({id:b.id,title:b.title,artist:b.artist,album:b.album,duration:b.duration,cover:b.cover,coverSmall:b.coverSmall,url:b.originalUrl,downloadedAt:b.downloadedAt,size:b.size}));s.sort((b,d)=>d.downloadedAt-b.downloadedAt),r(s)},n.onerror=()=>r([])})}catch{return[]}},async deleteDownload(e){try{const r=(await we()).transaction(Z,"readwrite").objectStore(Z);return await new Promise((n,s)=>{const b=r.delete(e);b.onsuccess=()=>n(),b.onerror=d=>s(d.target.error)}),M.removeDownload(e),ze("deleted",{trackId:e}),!0}catch(t){return console.error("Delete failed:",t),!1}},async getTotalSize(){return(await this.getAllDownloads()).reduce((t,a)=>t+(a.size||0),0)}},le=de("MediaPlugin"),kt=async()=>{try{await a0.impact({style:Ct.Light})}catch{}};class na{constructor(){this.audio=new Audio,this.audio.preload="none",this.isPlaying=!1,this.currentTrack=null,this._listeners=new Map,this._trackCache=new Map,this._useNative=!1,this._detectNative(),this.audio.addEventListener("ended",()=>this._onEnded()),this.audio.addEventListener("timeupdate",()=>{this._emit("timeupdate",{currentTime:this.audio.currentTime,duration:this.audio.duration||0})}),this.audio.addEventListener("loadedmetadata",()=>this._emit("loaded",{duration:this.audio.duration})),this.audio.addEventListener("play",()=>{this.isPlaying=!0,this._emit("statechange",{isPlaying:!0})}),this.audio.addEventListener("pause",()=>{this.isPlaying=!1,this._emit("statechange",{isPlaying:!1})}),this.audio.addEventListener("error",t=>{console.warn("Audio error:",t),this._emit("error",t),setTimeout(()=>this.next(),1e3)}),this._setupMediaSession()}async _detectNative(){try{window.Capacitor&&window.Capacitor.isNativePlatform()&&(this._useNative=!0,console.log("[Melo] Native Media3 bridge active"),le.addListener("mediaNext",()=>{console.log("[Melo] Notification: next"),this.next()}),le.addListener("mediaPrev",()=>{console.log("[Melo] Notification: prev"),this.prev()}),le.addListener("mediaEnded",()=>{console.log("[Melo] Native playback ended. Triggering auto-play/queue..."),this._onEnded()}),le.addListener("timeupdate",t=>{this._emit("timeupdate",{currentTime:t.position,duration:t.duration||(this.currentTrack?this.currentTrack.duration:0)})}))}catch{console.log("[Melo] Web fallback mode")}}on(t,a){return this._listeners.has(t)||this._listeners.set(t,new Set),this._listeners.get(t).add(a),()=>{var r;return(r=this._listeners.get(t))==null?void 0:r.delete(a)}}_emit(t,a){var r;(r=this._listeners.get(t))==null||r.forEach(n=>n(a))}cacheTrack(t){t&&t.id&&this._trackCache.set(t.id,t)}cacheTracks(t){t.forEach(a=>this.cacheTrack(a))}getCachedTrack(t){return this._trackCache.get(t)||M.get().trackMetadata[t]||null}async playTrack(t){if(!t||!t.url)return;this.currentTrack=t,this.cacheTrack(t);const r=await he.getPlaybackUrl(t.id)||t.url;if(this._useNative)try{const n=(t.cover||"").replace(/^http:\/\//i,"https://");await le.play({url:r,title:t.title||"Melo Music",artist:t.artist||"Melo",cover:n}),this.isPlaying=!0,this._emit("statechange",{isPlaying:!0})}catch(n){console.warn("[Melo] Native play failed, falling back to web:",n),this._playWeb(r)}else this._playWeb(r);M.addRecentlyPlayed(t),this._emit("trackchange",t)}_playWeb(t){this.audio.src=t,this.audio.play().catch(a=>console.warn("Play failed:",a)),this._updateMediaSession()}playTrackById(t){const a=this.getCachedTrack(t);a&&this.playTrack(a)}playAll(t,a){this.cacheTracks(t);const r=t.map(s=>s.id),n=a?r.indexOf(a.id):0;M.setQueue(r,Math.max(0,n)),this.playTrack(t[Math.max(0,n)])}async play(){if(this._useNative)try{await le.resume(),this.isPlaying=!0,this._emit("statechange",{isPlaying:!0})}catch{this.audio.src&&this.audio.play().catch(()=>{})}else this.audio.src&&this.audio.play().catch(t=>console.warn("Play failed:",t))}async pause(){if(this._useNative)try{await le.pause()}catch{}this.audio.pause(),this.isPlaying=!1,this._emit("statechange",{isPlaying:!1})}togglePlay(){kt(),this.isPlaying?this.pause():this.play()}next(){kt();const t=M.nextInQueue();if(t){const a=this.getCachedTrack(t);a&&this.playTrack(a)}else this.pause(),this.audio.currentTime=0}prev(){if(kt(),this.audio.currentTime>3){this.audio.currentTime=0,this._useNative&&le.seek({position:0}).catch(()=>{});return}const t=M.prevInQueue();if(t){const a=this.getCachedTrack(t);a&&this.playTrack(a)}}seek(t){isFinite(t)&&(this.audio.currentTime=t,this._useNative&&le.seek({position:parseInt(Math.round(t*1e3))}).catch(()=>{}))}seekPercent(t){this.currentTrack&&isFinite(this.currentTrack.duration)&&this.currentTrack.duration>0?this.seek(this.currentTrack.duration*t):this.audio.duration&&isFinite(this.audio.duration)&&this.seek(this.audio.duration*t)}setVolume(t){this.audio.volume=Math.max(0,Math.min(1,t)),M.setVolume(t)}_detectMood(t){if(!t)return"hindi songs";const a=`${t.title||""} ${t.artist||""} ${t.album||""}`.toLowerCase(),r=[{keywords:["sad","dard","dil","tanha","alvida","bewafa","rona","aansu","judai","broken","heartbreak","emotional"],query:"sad emotional hindi songs"},{keywords:["romantic","love","pyar","ishq","mohabbat","prem","valentine","couple"],query:"romantic love hindi songs"},{keywords:["party","dance","club","dj","remix","bass","beat","drop","edm"],query:"party dance hindi songs"},{keywords:["lofi","lo-fi","chill","relax","sleep","calm","acoustic","unplugged","slowed"],query:"lofi chill hindi songs"},{keywords:["motivat","inspire","workout","gym","energy","power","pump"],query:"motivational workout hindi songs"},{keywords:["sufi","qawwali","devotion","bhajan","spiritual"],query:"sufi devotional songs"},{keywords:["rap","hip hop","hiphop","rapper","bars"],query:"hindi rap hip hop songs"},{keywords:["old","classic","90s","80s","70s","retro","purana"],query:"old classic bollywood hits"},{keywords:["punjabi","bhangra","jatt"],query:"punjabi latest songs"}];for(const n of r)if(n.keywords.some(s=>a.includes(s)))return n.query;return t.artist?`${t.artist.split(",")[0].trim()} best songs`:"trending hindi songs 2025"}async _onEnded(){const t=M.nextInQueue();if(t){const a=this.getCachedTrack(t);if(a){this.playTrack(a);return}}if(this.currentTrack){if(this.currentTrack.type==="podcast_episode"){console.log("[Melo] Podcast ended, auto-play disabled for podcasts."),this.pause(),this.audio.currentTime=0;return}try{const{searchSongs:a}=await Be(async()=>{const{searchSongs:s}=await Promise.resolve().then(()=>v0);return{searchSongs:s}},void 0),r=this._detectMood(this.currentTrack);console.log("[Melo] Auto-play mood query:",r);const n=await a(r);if(n.length>0){const s=new Set(M.get().queue),b=n.filter(i=>!s.has(i.id)),d=b.length>0?b:n;this.cacheTracks(d);const h=d.map(i=>i.id);M.setQueue(h,0),this.playTrack(d[0]);return}}catch(a){console.warn("Auto-play fetch failed:",a)}}this.pause(),this.audio.currentTime=0}_setupMediaSession(){"mediaSession"in navigator&&(navigator.mediaSession.setActionHandler("play",()=>this.play()),navigator.mediaSession.setActionHandler("pause",()=>this.pause()),navigator.mediaSession.setActionHandler("previoustrack",()=>this.prev()),navigator.mediaSession.setActionHandler("nexttrack",()=>this.next()),navigator.mediaSession.setActionHandler("seekto",t=>{t.seekTime!=null&&this.seek(t.seekTime)}),navigator.mediaSession.setActionHandler("stop",()=>{this.pause(),this.audio.currentTime=0}))}_updateMediaSession(){if(!this.currentTrack||!("mediaSession"in navigator))return;const t=(this.currentTrack.cover||"").replace(/^http:\/\//i,"https://");try{navigator.mediaSession.metadata=new MediaMetadata({title:this.currentTrack.title||"Melo Music",artist:this.currentTrack.artist||"Melo",album:this.currentTrack.album||"Melo Music",artwork:[{src:t,sizes:"512x512",type:"image/jpeg"}]})}catch{}}}const z=new na;function ia(){const e=document.createElement("div");e.className="miniplayer glass",e.innerHTML=`
    <div class="mini-progress-bg">
      <div class="mini-progress-fill" id="mini-progress"></div>
    </div>
    <div class="mini-content">
      <div class="mini-info" id="mini-open">
        <img class="mini-art" id="mini-art" src="" alt="" />
        <div class="mini-text">
          <div class="mini-title" id="mini-title">Not Playing</div>
          <div class="mini-artist" id="mini-artist">Select a song</div>
        </div>
      </div>
      <div class="mini-controls">
        <button class="btn-icon" id="mini-prev">
          <span class="material-symbols-rounded">skip_previous</span>
        </button>
        <button class="btn-play" id="mini-play" style="width: 40px; height: 40px;">
          <span class="material-symbols-rounded" style="font-size: 24px;">play_arrow</span>
        </button>
        <button class="btn-icon" id="mini-next">
          <span class="material-symbols-rounded">skip_next</span>
        </button>
      </div>
    </div>
  `;const t=n=>{e.querySelector("#mini-art").src=n.coverSmall||n.cover,e.querySelector("#mini-title").textContent=n.title,e.querySelector("#mini-artist").textContent=n.artist,e.classList.add("active");const s=Y.getCurrentRoute();["nowplaying","onboarding"].includes(s)||(e.style.display="block")},a=n=>{const s=e.querySelector("#mini-play .material-symbols-rounded");s.textContent=n?"pause":"play_arrow"},r=(n,s)=>{const b=n/s*100;e.querySelector("#mini-progress").style.width=`${b}%`};return e.querySelector("#mini-open").addEventListener("click",()=>{Y.navigate("nowplaying")}),e.querySelector("#mini-play").addEventListener("click",n=>{n.stopPropagation(),z.togglePlay()}),e.querySelector("#mini-prev").addEventListener("click",n=>{n.stopPropagation(),z.prev()}),e.querySelector("#mini-next").addEventListener("click",n=>{n.stopPropagation(),z.next()}),z.on("trackchange",t),z.on("statechange",({isPlaying:n})=>a(n)),z.on("timeupdate",({currentTime:n,duration:s})=>r(n,s)),window.addEventListener("routechange",n=>{const s=["nowplaying","onboarding"].includes(n.detail.route);e.style.display=s?"none":z.currentTrack?"block":"none"}),z.currentTrack?(t(z.currentTrack),a(z.isPlaying),e.style.display="block"):e.style.display="none",e}const n0=document.createElement("style");n0.textContent=`
  .miniplayer {
    position: fixed;
    bottom: calc(var(--nav-height) + var(--safe-bottom) + var(--space-md));
    left: var(--space-md);
    right: var(--space-md);
    height: var(--miniplayer-height);
    border-radius: var(--radius-lg);
    z-index: 101;
    overflow: hidden;
    box-shadow: var(--shadow-lg);
    transition: transform var(--transition-normal), opacity var(--transition-normal);
  }

  .miniplayer:not(.active) {
    display: none;
  }

  .mini-progress-bg {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 2px;
    background: rgba(255,255,255,0.05);
  }

  .mini-progress-fill {
    height: 100%;
    background: var(--accent);
    width: 0;
  }

  .mini-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 100%;
    padding: 0 var(--space-md);
  }

  .mini-info {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    flex: 1;
    min-width: 0;
    cursor: pointer;
  }

  .mini-art {
    width: 40px;
    height: 40px;
    border-radius: var(--radius-sm);
    object-fit: cover;
    box-shadow: var(--shadow-sm);
  }

  .mini-text {
    flex: 1;
    min-width: 0;
  }

  .mini-title {
    font-size: var(--font-sm);
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .mini-artist {
    font-size: var(--font-xs);
    color: var(--text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .mini-controls {
    display: flex;
    align-items: center;
    gap: var(--space-xs);
  }

  .miniplayer .btn-icon {
    width: 36px;
    height: 36px;
  }
`;document.head.appendChild(n0);const Ht=[{id:"pop",name:"Pop",gradient:"linear-gradient(135deg, #e040fb, #7c4dff)",icon:"star"},{id:"hiphop",name:"Hip Hop",gradient:"linear-gradient(135deg, #ff6d00, #ff3d00)",icon:"mic"},{id:"rock",name:"Rock",gradient:"linear-gradient(135deg, #d50000, #ff1744)",icon:"electric_bolt"},{id:"lofi",name:"Lo-Fi",gradient:"linear-gradient(135deg, #00695c, #26a69a)",icon:"headphones"},{id:"electronic",name:"Electronic",gradient:"linear-gradient(135deg, #2979ff, #00b0ff)",icon:"equalizer"},{id:"rnb",name:"R&B",gradient:"linear-gradient(135deg, #6a1b9a, #ab47bc)",icon:"music_note"},{id:"jazz",name:"Jazz",gradient:"linear-gradient(135deg, #f57f17, #fdd835)",icon:"piano"},{id:"classical",name:"Classical",gradient:"linear-gradient(135deg, #1565c0, #42a5f5)",icon:"library_music"},{id:"indie",name:"Indie",gradient:"linear-gradient(135deg, #00897b, #4db6ac)",icon:"forest"},{id:"kpop",name:"K-Pop",gradient:"linear-gradient(135deg, #f06292, #ec407a)",icon:"favorite"},{id:"bollywood",name:"Bollywood",gradient:"linear-gradient(135deg, #ff8f00, #ffca28)",icon:"movie"},{id:"ambient",name:"Ambient",gradient:"linear-gradient(135deg, #37474f, #78909c)",icon:"spa"}],sa=[{id:"arijit-singh",name:"Arijit Singh",query:"Arijit Singh songs",gradient:"linear-gradient(135deg, #1a1a2e, #16213e)",image:"https://c.saavncdn.com/artists/Arijit_Singh_002_20230801131019_150x150.jpg"},{id:"udit-narayan",name:"Udit Narayan",query:"Udit Narayan best songs",gradient:"linear-gradient(135deg, #2d1b69, #11998e)",image:"https://c.saavncdn.com/artists/Udit_Narayan_150x150.jpg"},{id:"shreya-ghoshal",name:"Shreya Ghoshal",query:"Shreya Ghoshal hits",gradient:"linear-gradient(135deg, #7b2ff7, #c471f5)",image:"https://c.saavncdn.com/artists/Shreya_Ghoshal_006_20200711073954_150x150.jpg"},{id:"atif-aslam",name:"Atif Aslam",query:"Atif Aslam songs",gradient:"linear-gradient(135deg, #134e5e, #71b280)",image:"https://c.saavncdn.com/artists/Atif_Aslam_150x150.jpg"},{id:"neha-kakkar",name:"Neha Kakkar",query:"Neha Kakkar latest",gradient:"linear-gradient(135deg, #e91e63, #ff6f00)",image:"https://c.saavncdn.com/artists/Neha_Kakkar_006_20200822042626_150x150.jpg"},{id:"kishore-kumar",name:"Kishore Kumar",query:"Kishore Kumar classics",gradient:"linear-gradient(135deg, #3a1c71, #d76d77)",image:"https://c.saavncdn.com/artists/Kishore_Kumar_150x150.jpg"},{id:"lata-mangeshkar",name:"Lata Mangeshkar",query:"Lata Mangeshkar best",gradient:"linear-gradient(135deg, #c04848, #480048)",image:"https://c.saavncdn.com/artists/Lata_Mangeshkar_004_20230804105030_150x150.jpg"},{id:"kumar-sanu",name:"Kumar Sanu",query:"Kumar Sanu romantic songs",gradient:"linear-gradient(135deg, #0f0c29, #302b63)",image:"https://c.saavncdn.com/artists/Kumar_Sanu_150x150.jpg"},{id:"ap-dhillon",name:"AP Dhillon",query:"AP Dhillon songs",gradient:"linear-gradient(135deg, #000000, #434343)",image:"https://c.saavncdn.com/artists/AP_Dhillon_001_20221012113605_150x150.jpg"},{id:"honey-singh",name:"Yo Yo Honey Singh",query:"Honey Singh party songs",gradient:"linear-gradient(135deg, #f7971e, #ffd200)",image:"https://c.saavncdn.com/artists/Yo_Yo_Honey_Singh_150x150.jpg"},{id:"jubin-nautiyal",name:"Jubin Nautiyal",query:"Jubin Nautiyal songs",gradient:"linear-gradient(135deg, #0052d4, #6fb1fc)",image:"https://c.saavncdn.com/artists/Jubin_Nautiyal_003_20221012112730_150x150.jpg"},{id:"sunidhi-chauhan",name:"Sunidhi Chauhan",query:"Sunidhi Chauhan hits",gradient:"linear-gradient(135deg, #ee0979, #ff6a00)",image:"https://c.saavncdn.com/artists/Sunidhi_Chauhan_150x150.jpg"}],te={show(e,t="info",a=3e3){let r=document.getElementById("toast-container");if(!r){r=document.createElement("div"),r.id="toast-container",document.body.appendChild(r);const b=document.createElement("style");b.textContent=`
                #toast-container {
                    position: fixed;
                    top: var(--space-xl);
                    right: var(--space-xl);
                    z-index: 9999;
                    display: flex;
                    flex-direction: column;
                    gap: var(--space-sm);
                    pointer-events: none;
                }
                .toast {
                    padding: var(--space-md) var(--space-xl);
                    border-radius: var(--radius-md);
                    background: var(--bg-elevated);
                    color: var(--text-primary);
                    font-size: var(--font-sm);
                    font-weight: 500;
                    box-shadow: var(--shadow-lg);
                    border: 1px solid var(--surface-border);
                    backdrop-filter: blur(20px);
                    animation: toastIn 0.4s cubic-bezier(0.16, 1, 0.3, 1);
                    display: flex;
                    align-items: center;
                    gap: var(--space-sm);
                    pointer-events: auto;
                }
                .toast-success { border-left: 4px solid var(--accent); }
                .toast-error { border-left: 4px solid #ff4d4d; }
                .toast-info { border-left: 4px solid #4d94ff; }
                .toast-exit {
                    animation: toastOut 0.3s forwards;
                }
                @keyframes toastOut {
                    to { opacity: 0; transform: translateX(20px); }
                }
            `,document.head.appendChild(b)}const n=document.createElement("div");n.className=`toast toast-${t}`;let s="info";t==="success"&&(s="check_circle"),t==="error"&&(s="error"),n.innerHTML=`
            <span class="material-symbols-rounded" style="font-size: 18px;">${s}</span>
            <span>${e}</span>
        `,r.appendChild(n),setTimeout(()=>{n.classList.add("toast-exit"),setTimeout(()=>n.remove(),300)},a)}};function ue(e,t,a="vertical"){const r=document.createElement("div");r.className=`track-card ${a}`;const n=M.isLiked(e.id),s=M.isDownloadComplete(e.id);r.innerHTML=`
    <div class="track-card-art-wrapper">
      <img class="track-card-art" src="${e.cover||e.coverSmall||""}" alt="${e.title}" loading="lazy" />
      <button class="track-card-play-btn" aria-label="Play ${e.title}">
        <span class="material-symbols-rounded">play_arrow</span>
      </button>
      <button class="track-card-download-btn ${s?"downloaded":""}" aria-label="Download ${e.title}">
        <span class="material-symbols-rounded">${s?"download_done":"download"}</span>
      </button>
      <button class="track-card-like-btn ${n?"liked":""}" aria-label="Favorite ${e.title}">
        <span class="material-symbols-rounded">${n?"favorite":"favorite_border"}</span>
      </button>
      <button class="track-card-add-btn" aria-label="Add to Playlist">
        <span class="material-symbols-rounded">playlist_add</span>
      </button>
    </div>
    <div class="track-card-title">${e.title}</div>
    <div class="track-card-artist" style="pointer-events: auto;">${e.artist}</div>
  `;const b=r.querySelector(".track-card-artist");return b&&b.addEventListener("click",d=>{d.stopPropagation();const h=e.artist.split(",")[0].trim();window.location.hash=`artist?name=${encodeURIComponent(h)}`}),r.addEventListener("click",d=>{if(d.target.closest(".track-card-download-btn")){d.stopPropagation();const h=d.target.closest(".track-card-download-btn");if(M.isDownloadComplete(e.id)){te.show("Already downloaded!","info");return}te.show(`Downloading: ${e.title}...`,"info"),h.querySelector(".material-symbols-rounded").textContent="hourglass_top",he.downloadTrack(e).then(i=>{i?(h.classList.add("downloaded"),h.querySelector(".material-symbols-rounded").textContent="download_done",te.show(`Downloaded: ${e.title}`,"success")):(h.querySelector(".material-symbols-rounded").textContent="download",te.show("Download failed","error"))});return}if(d.target.closest(".track-card-like-btn")){d.stopPropagation(),M.toggleLike(e);const h=M.isLiked(e.id),i=d.target.closest(".track-card-like-btn");i.classList.toggle("liked",h),i.querySelector(".material-symbols-rounded").textContent=h?"favorite":"favorite_border",te.show(h?"Added to Liked Songs":"Removed from Liked Songs","success"),h&&z.cacheTrack(e);return}if(d.target.closest(".track-card-add-btn")){d.stopPropagation();const h=M.get();if(h.playlists.length===0){te.show("Create a playlist first in Library","error");return}const i=h.playlists.map(w=>w.name).join(", "),x=prompt(`Add to playlist?
Available: ${i}`);if(x){const w=h.playlists.find(o=>o.name.toLowerCase()===x.toLowerCase());w?(M.addToPlaylist(w.id,e),te.show(`Added to ${w.name}`,"success")):te.show("Playlist not found","error")}return}z.playAll(t,e)}),r}const i0=document.createElement("style");i0.textContent=`
  .track-card {
    cursor: pointer;
    transition: transform var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
  }
  .track-card:active {
    transform: scale(0.97);
  }

  .track-card.vertical {
    width: 130px;
  }

  .track-card.horizontal {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    padding: var(--space-sm);
    border-radius: var(--radius-md);
    width: 100%;
  }

  .track-card-art-wrapper {
    position: relative;
    border-radius: var(--radius-md);
    overflow: hidden;
    aspect-ratio: 1;
    background: var(--bg-tertiary);
  }

  .track-card.horizontal .track-card-art-wrapper {
    width: 56px;
    height: 56px;
    flex-shrink: 0;
    border-radius: var(--radius-sm);
  }

  .track-card-art {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform var(--transition-normal);
  }

  .track-card:hover .track-card-art {
    transform: scale(1.05);
  }

  .track-card-play-btn {
    position: absolute;
    bottom: var(--space-sm);
    right: var(--space-sm);
    width: 40px;
    height: 40px;
    border-radius: var(--radius-full);
    border: none;
    background: var(--accent);
    color: var(--text-on-accent);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: translateY(8px);
    transition: opacity var(--transition-normal), transform var(--transition-normal), box-shadow var(--transition-normal);
    box-shadow: var(--shadow-md);
    z-index: 2;
  }

  .track-card-download-btn {
    position: absolute;
    top: var(--space-sm);
    right: var(--space-sm);
    width: 32px;
    height: 32px;
    border-radius: var(--radius-full);
    border: none;
    background: var(--surface-glass-thick);
    backdrop-filter: blur(10px);
    color: var(--text-primary);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: translateY(-8px);
    transition: opacity var(--transition-normal), transform var(--transition-normal), background var(--transition-fast);
  }

  .track-card-download-btn.downloaded {
    color: var(--accent);
    opacity: 1;
    transform: translateY(0);
  }

  .track-card-like-btn {
    position: absolute;
    bottom: var(--space-sm);
    left: var(--space-sm);
    width: 32px;
    height: 32px;
    border-radius: var(--radius-full);
    border: none;
    background: var(--surface-glass-thick);
    backdrop-filter: blur(10px);
    color: var(--text-primary);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: translateY(8px);
    transition: opacity var(--transition-normal), transform var(--transition-normal), background var(--transition-fast), color var(--transition-fast);
  }

  .track-card-like-btn.liked {
    color: #ff4d4d;
  }

  .track-card-add-btn {
    position: absolute;
    top: var(--space-sm);
    left: var(--space-sm);
    width: 32px;
    height: 32px;
    border-radius: var(--radius-full);
    border: none;
    background: var(--surface-glass-thick);
    backdrop-filter: blur(10px);
    color: var(--text-primary);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: translateY(-8px);
    transition: opacity var(--transition-normal), transform var(--transition-normal), background var(--transition-fast);
  }

  .track-card-download-btn:hover,
  .track-card-like-btn:hover,
  .track-card-add-btn:hover {
    background: var(--accent);
    color: var(--text-on-accent);
  }

  .track-card:hover .track-card-play-btn,
  .track-card:active .track-card-play-btn,
  .track-card:hover .track-card-download-btn,
  .track-card:active .track-card-download-btn,
  .track-card:hover .track-card-add-btn,
  .track-card:active .track-card-add-btn,
  .track-card:hover .track-card-like-btn,
  .track-card:active .track-card-like-btn {
    opacity: 1;
    transform: translateY(0);
  }

  /* Removed hover:none block to keep UI clean on mobile */

  .track-card-play-btn .material-symbols-rounded {
    font-size: 22px;
  }
  .track-card-download-btn .material-symbols-rounded,
  .track-card-add-btn .material-symbols-rounded,
  .track-card-like-btn .material-symbols-rounded {
    font-size: 18px;
  }

  .track-card-title {
    margin-top: var(--space-sm);
    font-size: var(--font-sm);
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: var(--text-primary);
  }

  .track-card.horizontal .track-card-title {
    margin-top: 0;
  }

  .track-card-artist {
    font-size: var(--font-xs);
    color: var(--text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
`;document.head.appendChild(i0);var Ft=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function oa(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function ca(e){if(Object.prototype.hasOwnProperty.call(e,"__esModule"))return e;var t=e.default;if(typeof t=="function"){var a=function r(){return this instanceof r?Reflect.construct(t,arguments,this.constructor):t.apply(this,arguments)};a.prototype=t.prototype}else a={};return Object.defineProperty(a,"__esModule",{value:!0}),Object.keys(e).forEach(function(r){var n=Object.getOwnPropertyDescriptor(e,r);Object.defineProperty(a,r,n.get?n:{enumerable:!0,get:function(){return e[r]}})}),a}var Ne={exports:{}};function la(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Me={exports:{}};const da={},xa=Object.freeze(Object.defineProperty({__proto__:null,default:da},Symbol.toStringTag,{value:"Module"})),pa=ca(xa);var ua=Me.exports,cr;function I(){return cr||(cr=1,(function(e,t){(function(a,r){e.exports=r()})(ua,function(){var a=a||(function(r,n){var s;if(typeof window<"u"&&window.crypto&&(s=window.crypto),typeof self<"u"&&self.crypto&&(s=self.crypto),typeof globalThis<"u"&&globalThis.crypto&&(s=globalThis.crypto),!s&&typeof window<"u"&&window.msCrypto&&(s=window.msCrypto),!s&&typeof Ft<"u"&&Ft.crypto&&(s=Ft.crypto),!s&&typeof la=="function")try{s=pa}catch{}var b=function(){if(s){if(typeof s.getRandomValues=="function")try{return s.getRandomValues(new Uint32Array(1))[0]}catch{}if(typeof s.randomBytes=="function")try{return s.randomBytes(4).readInt32LE()}catch{}}throw new Error("Native crypto module could not be used to get secure random number.")},d=Object.create||(function(){function l(){}return function(c){var m;return l.prototype=c,m=new l,l.prototype=null,m}})(),h={},i=h.lib={},x=i.Base=(function(){return{extend:function(l){var c=d(this);return l&&c.mixIn(l),(!c.hasOwnProperty("init")||this.init===c.init)&&(c.init=function(){c.$super.init.apply(this,arguments)}),c.init.prototype=c,c.$super=this,c},create:function(){var l=this.extend();return l.init.apply(l,arguments),l},init:function(){},mixIn:function(l){for(var c in l)l.hasOwnProperty(c)&&(this[c]=l[c]);l.hasOwnProperty("toString")&&(this.toString=l.toString)},clone:function(){return this.init.prototype.extend(this)}}})(),w=i.WordArray=x.extend({init:function(l,c){l=this.words=l||[],c!=n?this.sigBytes=c:this.sigBytes=l.length*4},toString:function(l){return(l||p).stringify(this)},concat:function(l){var c=this.words,m=l.words,v=this.sigBytes,E=l.sigBytes;if(this.clamp(),v%4)for(var C=0;C<E;C++){var B=m[C>>>2]>>>24-C%4*8&255;c[v+C>>>2]|=B<<24-(v+C)%4*8}else for(var D=0;D<E;D+=4)c[v+D>>>2]=m[D>>>2];return this.sigBytes+=E,this},clamp:function(){var l=this.words,c=this.sigBytes;l[c>>>2]&=4294967295<<32-c%4*8,l.length=r.ceil(c/4)},clone:function(){var l=x.clone.call(this);return l.words=this.words.slice(0),l},random:function(l){for(var c=[],m=0;m<l;m+=4)c.push(b());return new w.init(c,l)}}),o=h.enc={},p=o.Hex={stringify:function(l){for(var c=l.words,m=l.sigBytes,v=[],E=0;E<m;E++){var C=c[E>>>2]>>>24-E%4*8&255;v.push((C>>>4).toString(16)),v.push((C&15).toString(16))}return v.join("")},parse:function(l){for(var c=l.length,m=[],v=0;v<c;v+=2)m[v>>>3]|=parseInt(l.substr(v,2),16)<<24-v%8*4;return new w.init(m,c/2)}},f=o.Latin1={stringify:function(l){for(var c=l.words,m=l.sigBytes,v=[],E=0;E<m;E++){var C=c[E>>>2]>>>24-E%4*8&255;v.push(String.fromCharCode(C))}return v.join("")},parse:function(l){for(var c=l.length,m=[],v=0;v<c;v++)m[v>>>2]|=(l.charCodeAt(v)&255)<<24-v%4*8;return new w.init(m,c)}},y=o.Utf8={stringify:function(l){try{return decodeURIComponent(escape(f.stringify(l)))}catch{throw new Error("Malformed UTF-8 data")}},parse:function(l){return f.parse(unescape(encodeURIComponent(l)))}},g=i.BufferedBlockAlgorithm=x.extend({reset:function(){this._data=new w.init,this._nDataBytes=0},_append:function(l){typeof l=="string"&&(l=y.parse(l)),this._data.concat(l),this._nDataBytes+=l.sigBytes},_process:function(l){var c,m=this._data,v=m.words,E=m.sigBytes,C=this.blockSize,B=C*4,D=E/B;l?D=r.ceil(D):D=r.max((D|0)-this._minBufferSize,0);var A=D*C,_=r.min(A*4,E);if(A){for(var k=0;k<A;k+=C)this._doProcessBlock(v,k);c=v.splice(0,A),m.sigBytes-=_}return new w.init(c,_)},clone:function(){var l=x.clone.call(this);return l._data=this._data.clone(),l},_minBufferSize:0});i.Hasher=g.extend({cfg:x.extend(),init:function(l){this.cfg=this.cfg.extend(l),this.reset()},reset:function(){g.reset.call(this),this._doReset()},update:function(l){return this._append(l),this._process(),this},finalize:function(l){l&&this._append(l);var c=this._doFinalize();return c},blockSize:16,_createHelper:function(l){return function(c,m){return new l.init(m).finalize(c)}},_createHmacHelper:function(l){return function(c,m){return new u.HMAC.init(l,m).finalize(c)}}});var u=h.algo={};return h})(Math);return a})})(Me)),Me.exports}var Ie={exports:{}},fa=Ie.exports,lr;function Bt(){return lr||(lr=1,(function(e,t){(function(a,r){e.exports=r(I())})(fa,function(a){return(function(r){var n=a,s=n.lib,b=s.Base,d=s.WordArray,h=n.x64={};h.Word=b.extend({init:function(i,x){this.high=i,this.low=x}}),h.WordArray=b.extend({init:function(i,x){i=this.words=i||[],x!=r?this.sigBytes=x:this.sigBytes=i.length*8},toX32:function(){for(var i=this.words,x=i.length,w=[],o=0;o<x;o++){var p=i[o];w.push(p.high),w.push(p.low)}return d.create(w,this.sigBytes)},clone:function(){for(var i=b.clone.call(this),x=i.words=this.words.slice(0),w=x.length,o=0;o<w;o++)x[o]=x[o].clone();return i}})})(),a})})(Ie)),Ie.exports}var Oe={exports:{}},ha=Oe.exports,dr;function va(){return dr||(dr=1,(function(e,t){(function(a,r){e.exports=r(I())})(ha,function(a){return(function(){if(typeof ArrayBuffer=="function"){var r=a,n=r.lib,s=n.WordArray,b=s.init,d=s.init=function(h){if(h instanceof ArrayBuffer&&(h=new Uint8Array(h)),(h instanceof Int8Array||typeof Uint8ClampedArray<"u"&&h instanceof Uint8ClampedArray||h instanceof Int16Array||h instanceof Uint16Array||h instanceof Int32Array||h instanceof Uint32Array||h instanceof Float32Array||h instanceof Float64Array)&&(h=new Uint8Array(h.buffer,h.byteOffset,h.byteLength)),h instanceof Uint8Array){for(var i=h.byteLength,x=[],w=0;w<i;w++)x[w>>>2]|=h[w]<<24-w%4*8;b.call(this,x,i)}else b.apply(this,arguments)};d.prototype=s}})(),a.lib.WordArray})})(Oe)),Oe.exports}var je={exports:{}},ma=je.exports,xr;function ga(){return xr||(xr=1,(function(e,t){(function(a,r){e.exports=r(I())})(ma,function(a){return(function(){var r=a,n=r.lib,s=n.WordArray,b=r.enc;b.Utf16=b.Utf16BE={stringify:function(h){for(var i=h.words,x=h.sigBytes,w=[],o=0;o<x;o+=2){var p=i[o>>>2]>>>16-o%4*8&65535;w.push(String.fromCharCode(p))}return w.join("")},parse:function(h){for(var i=h.length,x=[],w=0;w<i;w++)x[w>>>1]|=h.charCodeAt(w)<<16-w%2*16;return s.create(x,i*2)}},b.Utf16LE={stringify:function(h){for(var i=h.words,x=h.sigBytes,w=[],o=0;o<x;o+=2){var p=d(i[o>>>2]>>>16-o%4*8&65535);w.push(String.fromCharCode(p))}return w.join("")},parse:function(h){for(var i=h.length,x=[],w=0;w<i;w++)x[w>>>1]|=d(h.charCodeAt(w)<<16-w%2*16);return s.create(x,i*2)}};function d(h){return h<<8&4278255360|h>>>8&16711935}})(),a.enc.Utf16})})(je)),je.exports}var Ue={exports:{}},ya=Ue.exports,pr;function ve(){return pr||(pr=1,(function(e,t){(function(a,r){e.exports=r(I())})(ya,function(a){return(function(){var r=a,n=r.lib,s=n.WordArray,b=r.enc;b.Base64={stringify:function(h){var i=h.words,x=h.sigBytes,w=this._map;h.clamp();for(var o=[],p=0;p<x;p+=3)for(var f=i[p>>>2]>>>24-p%4*8&255,y=i[p+1>>>2]>>>24-(p+1)%4*8&255,g=i[p+2>>>2]>>>24-(p+2)%4*8&255,u=f<<16|y<<8|g,l=0;l<4&&p+l*.75<x;l++)o.push(w.charAt(u>>>6*(3-l)&63));var c=w.charAt(64);if(c)for(;o.length%4;)o.push(c);return o.join("")},parse:function(h){var i=h.length,x=this._map,w=this._reverseMap;if(!w){w=this._reverseMap=[];for(var o=0;o<x.length;o++)w[x.charCodeAt(o)]=o}var p=x.charAt(64);if(p){var f=h.indexOf(p);f!==-1&&(i=f)}return d(h,i,w)},_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="};function d(h,i,x){for(var w=[],o=0,p=0;p<i;p++)if(p%4){var f=x[h.charCodeAt(p-1)]<<p%4*2,y=x[h.charCodeAt(p)]>>>6-p%4*2,g=f|y;w[o>>>2]|=g<<24-o%4*8,o++}return s.create(w,o)}})(),a.enc.Base64})})(Ue)),Ue.exports}var We={exports:{}},ba=We.exports,ur;function wa(){return ur||(ur=1,(function(e,t){(function(a,r){e.exports=r(I())})(ba,function(a){return(function(){var r=a,n=r.lib,s=n.WordArray,b=r.enc;b.Base64url={stringify:function(h,i){i===void 0&&(i=!0);var x=h.words,w=h.sigBytes,o=i?this._safe_map:this._map;h.clamp();for(var p=[],f=0;f<w;f+=3)for(var y=x[f>>>2]>>>24-f%4*8&255,g=x[f+1>>>2]>>>24-(f+1)%4*8&255,u=x[f+2>>>2]>>>24-(f+2)%4*8&255,l=y<<16|g<<8|u,c=0;c<4&&f+c*.75<w;c++)p.push(o.charAt(l>>>6*(3-c)&63));var m=o.charAt(64);if(m)for(;p.length%4;)p.push(m);return p.join("")},parse:function(h,i){i===void 0&&(i=!0);var x=h.length,w=i?this._safe_map:this._map,o=this._reverseMap;if(!o){o=this._reverseMap=[];for(var p=0;p<w.length;p++)o[w.charCodeAt(p)]=p}var f=w.charAt(64);if(f){var y=h.indexOf(f);y!==-1&&(x=y)}return d(h,x,o)},_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",_safe_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"};function d(h,i,x){for(var w=[],o=0,p=0;p<i;p++)if(p%4){var f=x[h.charCodeAt(p-1)]<<p%4*2,y=x[h.charCodeAt(p)]>>>6-p%4*2,g=f|y;w[o>>>2]|=g<<24-o%4*8,o++}return s.create(w,o)}})(),a.enc.Base64url})})(We)),We.exports}var Ke={exports:{}},Ea=Ke.exports,fr;function me(){return fr||(fr=1,(function(e,t){(function(a,r){e.exports=r(I())})(Ea,function(a){return(function(r){var n=a,s=n.lib,b=s.WordArray,d=s.Hasher,h=n.algo,i=[];(function(){for(var y=0;y<64;y++)i[y]=r.abs(r.sin(y+1))*4294967296|0})();var x=h.MD5=d.extend({_doReset:function(){this._hash=new b.init([1732584193,4023233417,2562383102,271733878])},_doProcessBlock:function(y,g){for(var u=0;u<16;u++){var l=g+u,c=y[l];y[l]=(c<<8|c>>>24)&16711935|(c<<24|c>>>8)&4278255360}var m=this._hash.words,v=y[g+0],E=y[g+1],C=y[g+2],B=y[g+3],D=y[g+4],A=y[g+5],_=y[g+6],k=y[g+7],F=y[g+8],$=y[g+9],T=y[g+10],R=y[g+11],K=y[g+12],O=y[g+13],U=y[g+14],j=y[g+15],S=m[0],q=m[1],P=m[2],L=m[3];S=w(S,q,P,L,v,7,i[0]),L=w(L,S,q,P,E,12,i[1]),P=w(P,L,S,q,C,17,i[2]),q=w(q,P,L,S,B,22,i[3]),S=w(S,q,P,L,D,7,i[4]),L=w(L,S,q,P,A,12,i[5]),P=w(P,L,S,q,_,17,i[6]),q=w(q,P,L,S,k,22,i[7]),S=w(S,q,P,L,F,7,i[8]),L=w(L,S,q,P,$,12,i[9]),P=w(P,L,S,q,T,17,i[10]),q=w(q,P,L,S,R,22,i[11]),S=w(S,q,P,L,K,7,i[12]),L=w(L,S,q,P,O,12,i[13]),P=w(P,L,S,q,U,17,i[14]),q=w(q,P,L,S,j,22,i[15]),S=o(S,q,P,L,E,5,i[16]),L=o(L,S,q,P,_,9,i[17]),P=o(P,L,S,q,R,14,i[18]),q=o(q,P,L,S,v,20,i[19]),S=o(S,q,P,L,A,5,i[20]),L=o(L,S,q,P,T,9,i[21]),P=o(P,L,S,q,j,14,i[22]),q=o(q,P,L,S,D,20,i[23]),S=o(S,q,P,L,$,5,i[24]),L=o(L,S,q,P,U,9,i[25]),P=o(P,L,S,q,B,14,i[26]),q=o(q,P,L,S,F,20,i[27]),S=o(S,q,P,L,O,5,i[28]),L=o(L,S,q,P,C,9,i[29]),P=o(P,L,S,q,k,14,i[30]),q=o(q,P,L,S,K,20,i[31]),S=p(S,q,P,L,A,4,i[32]),L=p(L,S,q,P,F,11,i[33]),P=p(P,L,S,q,R,16,i[34]),q=p(q,P,L,S,U,23,i[35]),S=p(S,q,P,L,E,4,i[36]),L=p(L,S,q,P,D,11,i[37]),P=p(P,L,S,q,k,16,i[38]),q=p(q,P,L,S,T,23,i[39]),S=p(S,q,P,L,O,4,i[40]),L=p(L,S,q,P,v,11,i[41]),P=p(P,L,S,q,B,16,i[42]),q=p(q,P,L,S,_,23,i[43]),S=p(S,q,P,L,$,4,i[44]),L=p(L,S,q,P,K,11,i[45]),P=p(P,L,S,q,j,16,i[46]),q=p(q,P,L,S,C,23,i[47]),S=f(S,q,P,L,v,6,i[48]),L=f(L,S,q,P,k,10,i[49]),P=f(P,L,S,q,U,15,i[50]),q=f(q,P,L,S,A,21,i[51]),S=f(S,q,P,L,K,6,i[52]),L=f(L,S,q,P,B,10,i[53]),P=f(P,L,S,q,T,15,i[54]),q=f(q,P,L,S,E,21,i[55]),S=f(S,q,P,L,F,6,i[56]),L=f(L,S,q,P,j,10,i[57]),P=f(P,L,S,q,_,15,i[58]),q=f(q,P,L,S,O,21,i[59]),S=f(S,q,P,L,D,6,i[60]),L=f(L,S,q,P,R,10,i[61]),P=f(P,L,S,q,C,15,i[62]),q=f(q,P,L,S,$,21,i[63]),m[0]=m[0]+S|0,m[1]=m[1]+q|0,m[2]=m[2]+P|0,m[3]=m[3]+L|0},_doFinalize:function(){var y=this._data,g=y.words,u=this._nDataBytes*8,l=y.sigBytes*8;g[l>>>5]|=128<<24-l%32;var c=r.floor(u/4294967296),m=u;g[(l+64>>>9<<4)+15]=(c<<8|c>>>24)&16711935|(c<<24|c>>>8)&4278255360,g[(l+64>>>9<<4)+14]=(m<<8|m>>>24)&16711935|(m<<24|m>>>8)&4278255360,y.sigBytes=(g.length+1)*4,this._process();for(var v=this._hash,E=v.words,C=0;C<4;C++){var B=E[C];E[C]=(B<<8|B>>>24)&16711935|(B<<24|B>>>8)&4278255360}return v},clone:function(){var y=d.clone.call(this);return y._hash=this._hash.clone(),y}});function w(y,g,u,l,c,m,v){var E=y+(g&u|~g&l)+c+v;return(E<<m|E>>>32-m)+g}function o(y,g,u,l,c,m,v){var E=y+(g&l|u&~l)+c+v;return(E<<m|E>>>32-m)+g}function p(y,g,u,l,c,m,v){var E=y+(g^u^l)+c+v;return(E<<m|E>>>32-m)+g}function f(y,g,u,l,c,m,v){var E=y+(u^(g|~l))+c+v;return(E<<m|E>>>32-m)+g}n.MD5=d._createHelper(x),n.HmacMD5=d._createHmacHelper(x)})(Math),a.MD5})})(Ke)),Ke.exports}var Ge={exports:{}},Ca=Ge.exports,hr;function s0(){return hr||(hr=1,(function(e,t){(function(a,r){e.exports=r(I())})(Ca,function(a){return(function(){var r=a,n=r.lib,s=n.WordArray,b=n.Hasher,d=r.algo,h=[],i=d.SHA1=b.extend({_doReset:function(){this._hash=new s.init([1732584193,4023233417,2562383102,271733878,3285377520])},_doProcessBlock:function(x,w){for(var o=this._hash.words,p=o[0],f=o[1],y=o[2],g=o[3],u=o[4],l=0;l<80;l++){if(l<16)h[l]=x[w+l]|0;else{var c=h[l-3]^h[l-8]^h[l-14]^h[l-16];h[l]=c<<1|c>>>31}var m=(p<<5|p>>>27)+u+h[l];l<20?m+=(f&y|~f&g)+1518500249:l<40?m+=(f^y^g)+1859775393:l<60?m+=(f&y|f&g|y&g)-1894007588:m+=(f^y^g)-899497514,u=g,g=y,y=f<<30|f>>>2,f=p,p=m}o[0]=o[0]+p|0,o[1]=o[1]+f|0,o[2]=o[2]+y|0,o[3]=o[3]+g|0,o[4]=o[4]+u|0},_doFinalize:function(){var x=this._data,w=x.words,o=this._nDataBytes*8,p=x.sigBytes*8;return w[p>>>5]|=128<<24-p%32,w[(p+64>>>9<<4)+14]=Math.floor(o/4294967296),w[(p+64>>>9<<4)+15]=o,x.sigBytes=w.length*4,this._process(),this._hash},clone:function(){var x=b.clone.call(this);return x._hash=this._hash.clone(),x}});r.SHA1=b._createHelper(i),r.HmacSHA1=b._createHmacHelper(i)})(),a.SHA1})})(Ge)),Ge.exports}var Ve={exports:{}},Ba=Ve.exports,vr;function Nt(){return vr||(vr=1,(function(e,t){(function(a,r){e.exports=r(I())})(Ba,function(a){return(function(r){var n=a,s=n.lib,b=s.WordArray,d=s.Hasher,h=n.algo,i=[],x=[];(function(){function p(u){for(var l=r.sqrt(u),c=2;c<=l;c++)if(!(u%c))return!1;return!0}function f(u){return(u-(u|0))*4294967296|0}for(var y=2,g=0;g<64;)p(y)&&(g<8&&(i[g]=f(r.pow(y,1/2))),x[g]=f(r.pow(y,1/3)),g++),y++})();var w=[],o=h.SHA256=d.extend({_doReset:function(){this._hash=new b.init(i.slice(0))},_doProcessBlock:function(p,f){for(var y=this._hash.words,g=y[0],u=y[1],l=y[2],c=y[3],m=y[4],v=y[5],E=y[6],C=y[7],B=0;B<64;B++){if(B<16)w[B]=p[f+B]|0;else{var D=w[B-15],A=(D<<25|D>>>7)^(D<<14|D>>>18)^D>>>3,_=w[B-2],k=(_<<15|_>>>17)^(_<<13|_>>>19)^_>>>10;w[B]=A+w[B-7]+k+w[B-16]}var F=m&v^~m&E,$=g&u^g&l^u&l,T=(g<<30|g>>>2)^(g<<19|g>>>13)^(g<<10|g>>>22),R=(m<<26|m>>>6)^(m<<21|m>>>11)^(m<<7|m>>>25),K=C+R+F+x[B]+w[B],O=T+$;C=E,E=v,v=m,m=c+K|0,c=l,l=u,u=g,g=K+O|0}y[0]=y[0]+g|0,y[1]=y[1]+u|0,y[2]=y[2]+l|0,y[3]=y[3]+c|0,y[4]=y[4]+m|0,y[5]=y[5]+v|0,y[6]=y[6]+E|0,y[7]=y[7]+C|0},_doFinalize:function(){var p=this._data,f=p.words,y=this._nDataBytes*8,g=p.sigBytes*8;return f[g>>>5]|=128<<24-g%32,f[(g+64>>>9<<4)+14]=r.floor(y/4294967296),f[(g+64>>>9<<4)+15]=y,p.sigBytes=f.length*4,this._process(),this._hash},clone:function(){var p=d.clone.call(this);return p._hash=this._hash.clone(),p}});n.SHA256=d._createHelper(o),n.HmacSHA256=d._createHmacHelper(o)})(Math),a.SHA256})})(Ve)),Ve.exports}var Xe={exports:{}},Aa=Xe.exports,mr;function _a(){return mr||(mr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),Nt())})(Aa,function(a){return(function(){var r=a,n=r.lib,s=n.WordArray,b=r.algo,d=b.SHA256,h=b.SHA224=d.extend({_doReset:function(){this._hash=new s.init([3238371032,914150663,812702999,4144912697,4290775857,1750603025,1694076839,3204075428])},_doFinalize:function(){var i=d._doFinalize.call(this);return i.sigBytes-=4,i}});r.SHA224=d._createHelper(h),r.HmacSHA224=d._createHmacHelper(h)})(),a.SHA224})})(Xe)),Xe.exports}var Ye={exports:{}},Da=Ye.exports,gr;function o0(){return gr||(gr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),Bt())})(Da,function(a){return(function(){var r=a,n=r.lib,s=n.Hasher,b=r.x64,d=b.Word,h=b.WordArray,i=r.algo;function x(){return d.create.apply(d,arguments)}var w=[x(1116352408,3609767458),x(1899447441,602891725),x(3049323471,3964484399),x(3921009573,2173295548),x(961987163,4081628472),x(1508970993,3053834265),x(2453635748,2937671579),x(2870763221,3664609560),x(3624381080,2734883394),x(310598401,1164996542),x(607225278,1323610764),x(1426881987,3590304994),x(1925078388,4068182383),x(2162078206,991336113),x(2614888103,633803317),x(3248222580,3479774868),x(3835390401,2666613458),x(4022224774,944711139),x(264347078,2341262773),x(604807628,2007800933),x(770255983,1495990901),x(1249150122,1856431235),x(1555081692,3175218132),x(1996064986,2198950837),x(2554220882,3999719339),x(2821834349,766784016),x(2952996808,2566594879),x(3210313671,3203337956),x(3336571891,1034457026),x(3584528711,2466948901),x(113926993,3758326383),x(338241895,168717936),x(666307205,1188179964),x(773529912,1546045734),x(1294757372,1522805485),x(1396182291,2643833823),x(1695183700,2343527390),x(1986661051,1014477480),x(2177026350,1206759142),x(2456956037,344077627),x(2730485921,1290863460),x(2820302411,3158454273),x(3259730800,3505952657),x(3345764771,106217008),x(3516065817,3606008344),x(3600352804,1432725776),x(4094571909,1467031594),x(275423344,851169720),x(430227734,3100823752),x(506948616,1363258195),x(659060556,3750685593),x(883997877,3785050280),x(958139571,3318307427),x(1322822218,3812723403),x(1537002063,2003034995),x(1747873779,3602036899),x(1955562222,1575990012),x(2024104815,1125592928),x(2227730452,2716904306),x(2361852424,442776044),x(2428436474,593698344),x(2756734187,3733110249),x(3204031479,2999351573),x(3329325298,3815920427),x(3391569614,3928383900),x(3515267271,566280711),x(3940187606,3454069534),x(4118630271,4000239992),x(116418474,1914138554),x(174292421,2731055270),x(289380356,3203993006),x(460393269,320620315),x(685471733,587496836),x(852142971,1086792851),x(1017036298,365543100),x(1126000580,2618297676),x(1288033470,3409855158),x(1501505948,4234509866),x(1607167915,987167468),x(1816402316,1246189591)],o=[];(function(){for(var f=0;f<80;f++)o[f]=x()})();var p=i.SHA512=s.extend({_doReset:function(){this._hash=new h.init([new d.init(1779033703,4089235720),new d.init(3144134277,2227873595),new d.init(1013904242,4271175723),new d.init(2773480762,1595750129),new d.init(1359893119,2917565137),new d.init(2600822924,725511199),new d.init(528734635,4215389547),new d.init(1541459225,327033209)])},_doProcessBlock:function(f,y){for(var g=this._hash.words,u=g[0],l=g[1],c=g[2],m=g[3],v=g[4],E=g[5],C=g[6],B=g[7],D=u.high,A=u.low,_=l.high,k=l.low,F=c.high,$=c.low,T=m.high,R=m.low,K=v.high,O=v.low,U=E.high,j=E.low,S=C.high,q=C.low,P=B.high,L=B.low,G=D,W=A,Q=_,N=k,Ae=F,ge=$,At=T,_e=R,ie=K,J=O,Pe=U,De=j,He=S,ke=q,_t=P,Fe=L,se=0;se<80;se++){var re,xe,$e=o[se];if(se<16)xe=$e.high=f[y+se*2]|0,re=$e.low=f[y+se*2+1]|0;else{var Ot=o[se-15],ye=Ot.high,Se=Ot.low,_0=(ye>>>1|Se<<31)^(ye>>>8|Se<<24)^ye>>>7,jt=(Se>>>1|ye<<31)^(Se>>>8|ye<<24)^(Se>>>7|ye<<25),Ut=o[se-2],be=Ut.high,Le=Ut.low,D0=(be>>>19|Le<<13)^(be<<3|Le>>>29)^be>>>6,Wt=(Le>>>19|be<<13)^(Le<<3|be>>>29)^(Le>>>6|be<<26),Kt=o[se-7],k0=Kt.high,F0=Kt.low,Gt=o[se-16],S0=Gt.high,Vt=Gt.low;re=jt+F0,xe=_0+k0+(re>>>0<jt>>>0?1:0),re=re+Wt,xe=xe+D0+(re>>>0<Wt>>>0?1:0),re=re+Vt,xe=xe+S0+(re>>>0<Vt>>>0?1:0),$e.high=xe,$e.low=re}var L0=ie&Pe^~ie&He,Xt=J&De^~J&ke,q0=G&Q^G&Ae^Q&Ae,P0=W&N^W&ge^N&ge,H0=(G>>>28|W<<4)^(G<<30|W>>>2)^(G<<25|W>>>7),Yt=(W>>>28|G<<4)^(W<<30|G>>>2)^(W<<25|G>>>7),$0=(ie>>>14|J<<18)^(ie>>>18|J<<14)^(ie<<23|J>>>9),T0=(J>>>14|ie<<18)^(J>>>18|ie<<14)^(J<<23|ie>>>9),Qt=w[se],z0=Qt.high,Zt=Qt.low,ee=Fe+T0,pe=_t+$0+(ee>>>0<Fe>>>0?1:0),ee=ee+Xt,pe=pe+L0+(ee>>>0<Xt>>>0?1:0),ee=ee+Zt,pe=pe+z0+(ee>>>0<Zt>>>0?1:0),ee=ee+re,pe=pe+xe+(ee>>>0<re>>>0?1:0),Jt=Yt+P0,R0=H0+q0+(Jt>>>0<Yt>>>0?1:0);_t=He,Fe=ke,He=Pe,ke=De,Pe=ie,De=J,J=_e+ee|0,ie=At+pe+(J>>>0<_e>>>0?1:0)|0,At=Ae,_e=ge,Ae=Q,ge=N,Q=G,N=W,W=ee+Jt|0,G=pe+R0+(W>>>0<ee>>>0?1:0)|0}A=u.low=A+W,u.high=D+G+(A>>>0<W>>>0?1:0),k=l.low=k+N,l.high=_+Q+(k>>>0<N>>>0?1:0),$=c.low=$+ge,c.high=F+Ae+($>>>0<ge>>>0?1:0),R=m.low=R+_e,m.high=T+At+(R>>>0<_e>>>0?1:0),O=v.low=O+J,v.high=K+ie+(O>>>0<J>>>0?1:0),j=E.low=j+De,E.high=U+Pe+(j>>>0<De>>>0?1:0),q=C.low=q+ke,C.high=S+He+(q>>>0<ke>>>0?1:0),L=B.low=L+Fe,B.high=P+_t+(L>>>0<Fe>>>0?1:0)},_doFinalize:function(){var f=this._data,y=f.words,g=this._nDataBytes*8,u=f.sigBytes*8;y[u>>>5]|=128<<24-u%32,y[(u+128>>>10<<5)+30]=Math.floor(g/4294967296),y[(u+128>>>10<<5)+31]=g,f.sigBytes=y.length*4,this._process();var l=this._hash.toX32();return l},clone:function(){var f=s.clone.call(this);return f._hash=this._hash.clone(),f},blockSize:1024/32});r.SHA512=s._createHelper(p),r.HmacSHA512=s._createHmacHelper(p)})(),a.SHA512})})(Ye)),Ye.exports}var Qe={exports:{}},ka=Qe.exports,yr;function Fa(){return yr||(yr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),Bt(),o0())})(ka,function(a){return(function(){var r=a,n=r.x64,s=n.Word,b=n.WordArray,d=r.algo,h=d.SHA512,i=d.SHA384=h.extend({_doReset:function(){this._hash=new b.init([new s.init(3418070365,3238371032),new s.init(1654270250,914150663),new s.init(2438529370,812702999),new s.init(355462360,4144912697),new s.init(1731405415,4290775857),new s.init(2394180231,1750603025),new s.init(3675008525,1694076839),new s.init(1203062813,3204075428)])},_doFinalize:function(){var x=h._doFinalize.call(this);return x.sigBytes-=16,x}});r.SHA384=h._createHelper(i),r.HmacSHA384=h._createHmacHelper(i)})(),a.SHA384})})(Qe)),Qe.exports}var Ze={exports:{}},Sa=Ze.exports,br;function La(){return br||(br=1,(function(e,t){(function(a,r,n){e.exports=r(I(),Bt())})(Sa,function(a){return(function(r){var n=a,s=n.lib,b=s.WordArray,d=s.Hasher,h=n.x64,i=h.Word,x=n.algo,w=[],o=[],p=[];(function(){for(var g=1,u=0,l=0;l<24;l++){w[g+5*u]=(l+1)*(l+2)/2%64;var c=u%5,m=(2*g+3*u)%5;g=c,u=m}for(var g=0;g<5;g++)for(var u=0;u<5;u++)o[g+5*u]=u+(2*g+3*u)%5*5;for(var v=1,E=0;E<24;E++){for(var C=0,B=0,D=0;D<7;D++){if(v&1){var A=(1<<D)-1;A<32?B^=1<<A:C^=1<<A-32}v&128?v=v<<1^113:v<<=1}p[E]=i.create(C,B)}})();var f=[];(function(){for(var g=0;g<25;g++)f[g]=i.create()})();var y=x.SHA3=d.extend({cfg:d.cfg.extend({outputLength:512}),_doReset:function(){for(var g=this._state=[],u=0;u<25;u++)g[u]=new i.init;this.blockSize=(1600-2*this.cfg.outputLength)/32},_doProcessBlock:function(g,u){for(var l=this._state,c=this.blockSize/2,m=0;m<c;m++){var v=g[u+2*m],E=g[u+2*m+1];v=(v<<8|v>>>24)&16711935|(v<<24|v>>>8)&4278255360,E=(E<<8|E>>>24)&16711935|(E<<24|E>>>8)&4278255360;var C=l[m];C.high^=E,C.low^=v}for(var B=0;B<24;B++){for(var D=0;D<5;D++){for(var A=0,_=0,k=0;k<5;k++){var C=l[D+5*k];A^=C.high,_^=C.low}var F=f[D];F.high=A,F.low=_}for(var D=0;D<5;D++)for(var $=f[(D+4)%5],T=f[(D+1)%5],R=T.high,K=T.low,A=$.high^(R<<1|K>>>31),_=$.low^(K<<1|R>>>31),k=0;k<5;k++){var C=l[D+5*k];C.high^=A,C.low^=_}for(var O=1;O<25;O++){var A,_,C=l[O],U=C.high,j=C.low,S=w[O];S<32?(A=U<<S|j>>>32-S,_=j<<S|U>>>32-S):(A=j<<S-32|U>>>64-S,_=U<<S-32|j>>>64-S);var q=f[o[O]];q.high=A,q.low=_}var P=f[0],L=l[0];P.high=L.high,P.low=L.low;for(var D=0;D<5;D++)for(var k=0;k<5;k++){var O=D+5*k,C=l[O],G=f[O],W=f[(D+1)%5+5*k],Q=f[(D+2)%5+5*k];C.high=G.high^~W.high&Q.high,C.low=G.low^~W.low&Q.low}var C=l[0],N=p[B];C.high^=N.high,C.low^=N.low}},_doFinalize:function(){var g=this._data,u=g.words;this._nDataBytes*8;var l=g.sigBytes*8,c=this.blockSize*32;u[l>>>5]|=1<<24-l%32,u[(r.ceil((l+1)/c)*c>>>5)-1]|=128,g.sigBytes=u.length*4,this._process();for(var m=this._state,v=this.cfg.outputLength/8,E=v/8,C=[],B=0;B<E;B++){var D=m[B],A=D.high,_=D.low;A=(A<<8|A>>>24)&16711935|(A<<24|A>>>8)&4278255360,_=(_<<8|_>>>24)&16711935|(_<<24|_>>>8)&4278255360,C.push(_),C.push(A)}return new b.init(C,v)},clone:function(){for(var g=d.clone.call(this),u=g._state=this._state.slice(0),l=0;l<25;l++)u[l]=u[l].clone();return g}});n.SHA3=d._createHelper(y),n.HmacSHA3=d._createHmacHelper(y)})(Math),a.SHA3})})(Ze)),Ze.exports}var Je={exports:{}},qa=Je.exports,wr;function Pa(){return wr||(wr=1,(function(e,t){(function(a,r){e.exports=r(I())})(qa,function(a){/** @preserve
			(c) 2012 by Cédric Mesnil. All rights reserved.

			Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

			    - Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
			    - Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

			THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
			*/return(function(r){var n=a,s=n.lib,b=s.WordArray,d=s.Hasher,h=n.algo,i=b.create([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,7,4,13,1,10,6,15,3,12,0,9,5,2,14,11,8,3,10,14,4,9,15,8,1,2,7,0,6,13,11,5,12,1,9,11,10,0,8,12,4,13,3,7,15,14,5,6,2,4,0,5,9,7,12,2,10,14,1,3,8,11,6,15,13]),x=b.create([5,14,7,0,9,2,11,4,13,6,15,8,1,10,3,12,6,11,3,7,0,13,5,10,14,15,8,12,4,9,1,2,15,5,1,3,7,14,6,9,11,8,12,2,10,0,4,13,8,6,4,1,3,11,15,0,5,12,2,13,9,7,10,14,12,15,10,4,1,5,8,7,6,2,13,14,0,3,9,11]),w=b.create([11,14,15,12,5,8,7,9,11,13,14,15,6,7,9,8,7,6,8,13,11,9,7,15,7,12,15,9,11,7,13,12,11,13,6,7,14,9,13,15,14,8,13,6,5,12,7,5,11,12,14,15,14,15,9,8,9,14,5,6,8,6,5,12,9,15,5,11,6,8,13,12,5,12,13,14,11,8,5,6]),o=b.create([8,9,9,11,13,15,15,5,7,7,8,11,14,14,12,6,9,13,15,7,12,8,9,11,7,7,12,7,6,15,13,11,9,7,15,11,8,6,6,14,12,13,5,14,13,13,7,5,15,5,8,11,14,14,6,14,6,9,12,9,12,5,15,8,8,5,12,9,12,5,14,6,8,13,6,5,15,13,11,11]),p=b.create([0,1518500249,1859775393,2400959708,2840853838]),f=b.create([1352829926,1548603684,1836072691,2053994217,0]),y=h.RIPEMD160=d.extend({_doReset:function(){this._hash=b.create([1732584193,4023233417,2562383102,271733878,3285377520])},_doProcessBlock:function(E,C){for(var B=0;B<16;B++){var D=C+B,A=E[D];E[D]=(A<<8|A>>>24)&16711935|(A<<24|A>>>8)&4278255360}var _=this._hash.words,k=p.words,F=f.words,$=i.words,T=x.words,R=w.words,K=o.words,O,U,j,S,q,P,L,G,W,Q;P=O=_[0],L=U=_[1],G=j=_[2],W=S=_[3],Q=q=_[4];for(var N,B=0;B<80;B+=1)N=O+E[C+$[B]]|0,B<16?N+=g(U,j,S)+k[0]:B<32?N+=u(U,j,S)+k[1]:B<48?N+=l(U,j,S)+k[2]:B<64?N+=c(U,j,S)+k[3]:N+=m(U,j,S)+k[4],N=N|0,N=v(N,R[B]),N=N+q|0,O=q,q=S,S=v(j,10),j=U,U=N,N=P+E[C+T[B]]|0,B<16?N+=m(L,G,W)+F[0]:B<32?N+=c(L,G,W)+F[1]:B<48?N+=l(L,G,W)+F[2]:B<64?N+=u(L,G,W)+F[3]:N+=g(L,G,W)+F[4],N=N|0,N=v(N,K[B]),N=N+Q|0,P=Q,Q=W,W=v(G,10),G=L,L=N;N=_[1]+j+W|0,_[1]=_[2]+S+Q|0,_[2]=_[3]+q+P|0,_[3]=_[4]+O+L|0,_[4]=_[0]+U+G|0,_[0]=N},_doFinalize:function(){var E=this._data,C=E.words,B=this._nDataBytes*8,D=E.sigBytes*8;C[D>>>5]|=128<<24-D%32,C[(D+64>>>9<<4)+14]=(B<<8|B>>>24)&16711935|(B<<24|B>>>8)&4278255360,E.sigBytes=(C.length+1)*4,this._process();for(var A=this._hash,_=A.words,k=0;k<5;k++){var F=_[k];_[k]=(F<<8|F>>>24)&16711935|(F<<24|F>>>8)&4278255360}return A},clone:function(){var E=d.clone.call(this);return E._hash=this._hash.clone(),E}});function g(E,C,B){return E^C^B}function u(E,C,B){return E&C|~E&B}function l(E,C,B){return(E|~C)^B}function c(E,C,B){return E&B|C&~B}function m(E,C,B){return E^(C|~B)}function v(E,C){return E<<C|E>>>32-C}n.RIPEMD160=d._createHelper(y),n.HmacRIPEMD160=d._createHmacHelper(y)})(),a.RIPEMD160})})(Je)),Je.exports}var et={exports:{}},Ha=et.exports,Er;function Mt(){return Er||(Er=1,(function(e,t){(function(a,r){e.exports=r(I())})(Ha,function(a){(function(){var r=a,n=r.lib,s=n.Base,b=r.enc,d=b.Utf8,h=r.algo;h.HMAC=s.extend({init:function(i,x){i=this._hasher=new i.init,typeof x=="string"&&(x=d.parse(x));var w=i.blockSize,o=w*4;x.sigBytes>o&&(x=i.finalize(x)),x.clamp();for(var p=this._oKey=x.clone(),f=this._iKey=x.clone(),y=p.words,g=f.words,u=0;u<w;u++)y[u]^=1549556828,g[u]^=909522486;p.sigBytes=f.sigBytes=o,this.reset()},reset:function(){var i=this._hasher;i.reset(),i.update(this._iKey)},update:function(i){return this._hasher.update(i),this},finalize:function(i){var x=this._hasher,w=x.finalize(i);x.reset();var o=x.finalize(this._oKey.clone().concat(w));return o}})})()})})(et)),et.exports}var tt={exports:{}},$a=tt.exports,Cr;function Ta(){return Cr||(Cr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),Nt(),Mt())})($a,function(a){return(function(){var r=a,n=r.lib,s=n.Base,b=n.WordArray,d=r.algo,h=d.SHA256,i=d.HMAC,x=d.PBKDF2=s.extend({cfg:s.extend({keySize:128/32,hasher:h,iterations:25e4}),init:function(w){this.cfg=this.cfg.extend(w)},compute:function(w,o){for(var p=this.cfg,f=i.create(p.hasher,w),y=b.create(),g=b.create([1]),u=y.words,l=g.words,c=p.keySize,m=p.iterations;u.length<c;){var v=f.update(o).finalize(g);f.reset();for(var E=v.words,C=E.length,B=v,D=1;D<m;D++){B=f.finalize(B),f.reset();for(var A=B.words,_=0;_<C;_++)E[_]^=A[_]}y.concat(v),l[0]++}return y.sigBytes=c*4,y}});r.PBKDF2=function(w,o,p){return x.create(p).compute(w,o)}})(),a.PBKDF2})})(tt)),tt.exports}var rt={exports:{}},za=rt.exports,Br;function fe(){return Br||(Br=1,(function(e,t){(function(a,r,n){e.exports=r(I(),s0(),Mt())})(za,function(a){return(function(){var r=a,n=r.lib,s=n.Base,b=n.WordArray,d=r.algo,h=d.MD5,i=d.EvpKDF=s.extend({cfg:s.extend({keySize:128/32,hasher:h,iterations:1}),init:function(x){this.cfg=this.cfg.extend(x)},compute:function(x,w){for(var o,p=this.cfg,f=p.hasher.create(),y=b.create(),g=y.words,u=p.keySize,l=p.iterations;g.length<u;){o&&f.update(o),o=f.update(x).finalize(w),f.reset();for(var c=1;c<l;c++)o=f.finalize(o),f.reset();y.concat(o)}return y.sigBytes=u*4,y}});r.EvpKDF=function(x,w,o){return i.create(o).compute(x,w)}})(),a.EvpKDF})})(rt)),rt.exports}var at={exports:{}},Ra=at.exports,Ar;function V(){return Ar||(Ar=1,(function(e,t){(function(a,r,n){e.exports=r(I(),fe())})(Ra,function(a){a.lib.Cipher||(function(r){var n=a,s=n.lib,b=s.Base,d=s.WordArray,h=s.BufferedBlockAlgorithm,i=n.enc;i.Utf8;var x=i.Base64,w=n.algo,o=w.EvpKDF,p=s.Cipher=h.extend({cfg:b.extend(),createEncryptor:function(A,_){return this.create(this._ENC_XFORM_MODE,A,_)},createDecryptor:function(A,_){return this.create(this._DEC_XFORM_MODE,A,_)},init:function(A,_,k){this.cfg=this.cfg.extend(k),this._xformMode=A,this._key=_,this.reset()},reset:function(){h.reset.call(this),this._doReset()},process:function(A){return this._append(A),this._process()},finalize:function(A){A&&this._append(A);var _=this._doFinalize();return _},keySize:128/32,ivSize:128/32,_ENC_XFORM_MODE:1,_DEC_XFORM_MODE:2,_createHelper:(function(){function A(_){return typeof _=="string"?D:E}return function(_){return{encrypt:function(k,F,$){return A(F).encrypt(_,k,F,$)},decrypt:function(k,F,$){return A(F).decrypt(_,k,F,$)}}}})()});s.StreamCipher=p.extend({_doFinalize:function(){var A=this._process(!0);return A},blockSize:1});var f=n.mode={},y=s.BlockCipherMode=b.extend({createEncryptor:function(A,_){return this.Encryptor.create(A,_)},createDecryptor:function(A,_){return this.Decryptor.create(A,_)},init:function(A,_){this._cipher=A,this._iv=_}}),g=f.CBC=(function(){var A=y.extend();A.Encryptor=A.extend({processBlock:function(k,F){var $=this._cipher,T=$.blockSize;_.call(this,k,F,T),$.encryptBlock(k,F),this._prevBlock=k.slice(F,F+T)}}),A.Decryptor=A.extend({processBlock:function(k,F){var $=this._cipher,T=$.blockSize,R=k.slice(F,F+T);$.decryptBlock(k,F),_.call(this,k,F,T),this._prevBlock=R}});function _(k,F,$){var T,R=this._iv;R?(T=R,this._iv=r):T=this._prevBlock;for(var K=0;K<$;K++)k[F+K]^=T[K]}return A})(),u=n.pad={},l=u.Pkcs7={pad:function(A,_){for(var k=_*4,F=k-A.sigBytes%k,$=F<<24|F<<16|F<<8|F,T=[],R=0;R<F;R+=4)T.push($);var K=d.create(T,F);A.concat(K)},unpad:function(A){var _=A.words[A.sigBytes-1>>>2]&255;A.sigBytes-=_}};s.BlockCipher=p.extend({cfg:p.cfg.extend({mode:g,padding:l}),reset:function(){var A;p.reset.call(this);var _=this.cfg,k=_.iv,F=_.mode;this._xformMode==this._ENC_XFORM_MODE?A=F.createEncryptor:(A=F.createDecryptor,this._minBufferSize=1),this._mode&&this._mode.__creator==A?this._mode.init(this,k&&k.words):(this._mode=A.call(F,this,k&&k.words),this._mode.__creator=A)},_doProcessBlock:function(A,_){this._mode.processBlock(A,_)},_doFinalize:function(){var A,_=this.cfg.padding;return this._xformMode==this._ENC_XFORM_MODE?(_.pad(this._data,this.blockSize),A=this._process(!0)):(A=this._process(!0),_.unpad(A)),A},blockSize:128/32});var c=s.CipherParams=b.extend({init:function(A){this.mixIn(A)},toString:function(A){return(A||this.formatter).stringify(this)}}),m=n.format={},v=m.OpenSSL={stringify:function(A){var _,k=A.ciphertext,F=A.salt;return F?_=d.create([1398893684,1701076831]).concat(F).concat(k):_=k,_.toString(x)},parse:function(A){var _,k=x.parse(A),F=k.words;return F[0]==1398893684&&F[1]==1701076831&&(_=d.create(F.slice(2,4)),F.splice(0,4),k.sigBytes-=16),c.create({ciphertext:k,salt:_})}},E=s.SerializableCipher=b.extend({cfg:b.extend({format:v}),encrypt:function(A,_,k,F){F=this.cfg.extend(F);var $=A.createEncryptor(k,F),T=$.finalize(_),R=$.cfg;return c.create({ciphertext:T,key:k,iv:R.iv,algorithm:A,mode:R.mode,padding:R.padding,blockSize:A.blockSize,formatter:F.format})},decrypt:function(A,_,k,F){F=this.cfg.extend(F),_=this._parse(_,F.format);var $=A.createDecryptor(k,F).finalize(_.ciphertext);return $},_parse:function(A,_){return typeof A=="string"?_.parse(A,this):A}}),C=n.kdf={},B=C.OpenSSL={execute:function(A,_,k,F,$){if(F||(F=d.random(64/8)),$)var T=o.create({keySize:_+k,hasher:$}).compute(A,F);else var T=o.create({keySize:_+k}).compute(A,F);var R=d.create(T.words.slice(_),k*4);return T.sigBytes=_*4,c.create({key:T,iv:R,salt:F})}},D=s.PasswordBasedCipher=E.extend({cfg:E.cfg.extend({kdf:B}),encrypt:function(A,_,k,F){F=this.cfg.extend(F);var $=F.kdf.execute(k,A.keySize,A.ivSize,F.salt,F.hasher);F.iv=$.iv;var T=E.encrypt.call(this,A,_,$.key,F);return T.mixIn($),T},decrypt:function(A,_,k,F){F=this.cfg.extend(F),_=this._parse(_,F.format);var $=F.kdf.execute(k,A.keySize,A.ivSize,_.salt,F.hasher);F.iv=$.iv;var T=E.decrypt.call(this,A,_,$.key,F);return T}})})()})})(at)),at.exports}var nt={exports:{}},Na=nt.exports,_r;function Ma(){return _r||(_r=1,(function(e,t){(function(a,r,n){e.exports=r(I(),V())})(Na,function(a){return a.mode.CFB=(function(){var r=a.lib.BlockCipherMode.extend();r.Encryptor=r.extend({processBlock:function(s,b){var d=this._cipher,h=d.blockSize;n.call(this,s,b,h,d),this._prevBlock=s.slice(b,b+h)}}),r.Decryptor=r.extend({processBlock:function(s,b){var d=this._cipher,h=d.blockSize,i=s.slice(b,b+h);n.call(this,s,b,h,d),this._prevBlock=i}});function n(s,b,d,h){var i,x=this._iv;x?(i=x.slice(0),this._iv=void 0):i=this._prevBlock,h.encryptBlock(i,0);for(var w=0;w<d;w++)s[b+w]^=i[w]}return r})(),a.mode.CFB})})(nt)),nt.exports}var it={exports:{}},Ia=it.exports,Dr;function Oa(){return Dr||(Dr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),V())})(Ia,function(a){return a.mode.CTR=(function(){var r=a.lib.BlockCipherMode.extend(),n=r.Encryptor=r.extend({processBlock:function(s,b){var d=this._cipher,h=d.blockSize,i=this._iv,x=this._counter;i&&(x=this._counter=i.slice(0),this._iv=void 0);var w=x.slice(0);d.encryptBlock(w,0),x[h-1]=x[h-1]+1|0;for(var o=0;o<h;o++)s[b+o]^=w[o]}});return r.Decryptor=n,r})(),a.mode.CTR})})(it)),it.exports}var st={exports:{}},ja=st.exports,kr;function Ua(){return kr||(kr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),V())})(ja,function(a){/** @preserve
 * Counter block mode compatible with  Dr Brian Gladman fileenc.c
 * derived from CryptoJS.mode.CTR
 * Jan Hruby jhruby.web@gmail.com
 */return a.mode.CTRGladman=(function(){var r=a.lib.BlockCipherMode.extend();function n(d){if((d>>24&255)===255){var h=d>>16&255,i=d>>8&255,x=d&255;h===255?(h=0,i===255?(i=0,x===255?x=0:++x):++i):++h,d=0,d+=h<<16,d+=i<<8,d+=x}else d+=1<<24;return d}function s(d){return(d[0]=n(d[0]))===0&&(d[1]=n(d[1])),d}var b=r.Encryptor=r.extend({processBlock:function(d,h){var i=this._cipher,x=i.blockSize,w=this._iv,o=this._counter;w&&(o=this._counter=w.slice(0),this._iv=void 0),s(o);var p=o.slice(0);i.encryptBlock(p,0);for(var f=0;f<x;f++)d[h+f]^=p[f]}});return r.Decryptor=b,r})(),a.mode.CTRGladman})})(st)),st.exports}var ot={exports:{}},Wa=ot.exports,Fr;function Ka(){return Fr||(Fr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),V())})(Wa,function(a){return a.mode.OFB=(function(){var r=a.lib.BlockCipherMode.extend(),n=r.Encryptor=r.extend({processBlock:function(s,b){var d=this._cipher,h=d.blockSize,i=this._iv,x=this._keystream;i&&(x=this._keystream=i.slice(0),this._iv=void 0),d.encryptBlock(x,0);for(var w=0;w<h;w++)s[b+w]^=x[w]}});return r.Decryptor=n,r})(),a.mode.OFB})})(ot)),ot.exports}var ct={exports:{}},Ga=ct.exports,Sr;function Va(){return Sr||(Sr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),V())})(Ga,function(a){return a.mode.ECB=(function(){var r=a.lib.BlockCipherMode.extend();return r.Encryptor=r.extend({processBlock:function(n,s){this._cipher.encryptBlock(n,s)}}),r.Decryptor=r.extend({processBlock:function(n,s){this._cipher.decryptBlock(n,s)}}),r})(),a.mode.ECB})})(ct)),ct.exports}var lt={exports:{}},Xa=lt.exports,Lr;function Ya(){return Lr||(Lr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),V())})(Xa,function(a){return a.pad.AnsiX923={pad:function(r,n){var s=r.sigBytes,b=n*4,d=b-s%b,h=s+d-1;r.clamp(),r.words[h>>>2]|=d<<24-h%4*8,r.sigBytes+=d},unpad:function(r){var n=r.words[r.sigBytes-1>>>2]&255;r.sigBytes-=n}},a.pad.Ansix923})})(lt)),lt.exports}var dt={exports:{}},Qa=dt.exports,qr;function Za(){return qr||(qr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),V())})(Qa,function(a){return a.pad.Iso10126={pad:function(r,n){var s=n*4,b=s-r.sigBytes%s;r.concat(a.lib.WordArray.random(b-1)).concat(a.lib.WordArray.create([b<<24],1))},unpad:function(r){var n=r.words[r.sigBytes-1>>>2]&255;r.sigBytes-=n}},a.pad.Iso10126})})(dt)),dt.exports}var xt={exports:{}},Ja=xt.exports,Pr;function en(){return Pr||(Pr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),V())})(Ja,function(a){return a.pad.Iso97971={pad:function(r,n){r.concat(a.lib.WordArray.create([2147483648],1)),a.pad.ZeroPadding.pad(r,n)},unpad:function(r){a.pad.ZeroPadding.unpad(r),r.sigBytes--}},a.pad.Iso97971})})(xt)),xt.exports}var pt={exports:{}},tn=pt.exports,Hr;function rn(){return Hr||(Hr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),V())})(tn,function(a){return a.pad.ZeroPadding={pad:function(r,n){var s=n*4;r.clamp(),r.sigBytes+=s-(r.sigBytes%s||s)},unpad:function(r){for(var n=r.words,s=r.sigBytes-1,s=r.sigBytes-1;s>=0;s--)if(n[s>>>2]>>>24-s%4*8&255){r.sigBytes=s+1;break}}},a.pad.ZeroPadding})})(pt)),pt.exports}var ut={exports:{}},an=ut.exports,$r;function nn(){return $r||($r=1,(function(e,t){(function(a,r,n){e.exports=r(I(),V())})(an,function(a){return a.pad.NoPadding={pad:function(){},unpad:function(){}},a.pad.NoPadding})})(ut)),ut.exports}var ft={exports:{}},sn=ft.exports,Tr;function on(){return Tr||(Tr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),V())})(sn,function(a){return(function(r){var n=a,s=n.lib,b=s.CipherParams,d=n.enc,h=d.Hex,i=n.format;i.Hex={stringify:function(x){return x.ciphertext.toString(h)},parse:function(x){var w=h.parse(x);return b.create({ciphertext:w})}}})(),a.format.Hex})})(ft)),ft.exports}var ht={exports:{}},cn=ht.exports,zr;function ln(){return zr||(zr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),ve(),me(),fe(),V())})(cn,function(a){return(function(){var r=a,n=r.lib,s=n.BlockCipher,b=r.algo,d=[],h=[],i=[],x=[],w=[],o=[],p=[],f=[],y=[],g=[];(function(){for(var c=[],m=0;m<256;m++)m<128?c[m]=m<<1:c[m]=m<<1^283;for(var v=0,E=0,m=0;m<256;m++){var C=E^E<<1^E<<2^E<<3^E<<4;C=C>>>8^C&255^99,d[v]=C,h[C]=v;var B=c[v],D=c[B],A=c[D],_=c[C]*257^C*16843008;i[v]=_<<24|_>>>8,x[v]=_<<16|_>>>16,w[v]=_<<8|_>>>24,o[v]=_;var _=A*16843009^D*65537^B*257^v*16843008;p[C]=_<<24|_>>>8,f[C]=_<<16|_>>>16,y[C]=_<<8|_>>>24,g[C]=_,v?(v=B^c[c[c[A^B]]],E^=c[c[E]]):v=E=1}})();var u=[0,1,2,4,8,16,32,64,128,27,54],l=b.AES=s.extend({_doReset:function(){var c;if(!(this._nRounds&&this._keyPriorReset===this._key)){for(var m=this._keyPriorReset=this._key,v=m.words,E=m.sigBytes/4,C=this._nRounds=E+6,B=(C+1)*4,D=this._keySchedule=[],A=0;A<B;A++)A<E?D[A]=v[A]:(c=D[A-1],A%E?E>6&&A%E==4&&(c=d[c>>>24]<<24|d[c>>>16&255]<<16|d[c>>>8&255]<<8|d[c&255]):(c=c<<8|c>>>24,c=d[c>>>24]<<24|d[c>>>16&255]<<16|d[c>>>8&255]<<8|d[c&255],c^=u[A/E|0]<<24),D[A]=D[A-E]^c);for(var _=this._invKeySchedule=[],k=0;k<B;k++){var A=B-k;if(k%4)var c=D[A];else var c=D[A-4];k<4||A<=4?_[k]=c:_[k]=p[d[c>>>24]]^f[d[c>>>16&255]]^y[d[c>>>8&255]]^g[d[c&255]]}}},encryptBlock:function(c,m){this._doCryptBlock(c,m,this._keySchedule,i,x,w,o,d)},decryptBlock:function(c,m){var v=c[m+1];c[m+1]=c[m+3],c[m+3]=v,this._doCryptBlock(c,m,this._invKeySchedule,p,f,y,g,h);var v=c[m+1];c[m+1]=c[m+3],c[m+3]=v},_doCryptBlock:function(c,m,v,E,C,B,D,A){for(var _=this._nRounds,k=c[m]^v[0],F=c[m+1]^v[1],$=c[m+2]^v[2],T=c[m+3]^v[3],R=4,K=1;K<_;K++){var O=E[k>>>24]^C[F>>>16&255]^B[$>>>8&255]^D[T&255]^v[R++],U=E[F>>>24]^C[$>>>16&255]^B[T>>>8&255]^D[k&255]^v[R++],j=E[$>>>24]^C[T>>>16&255]^B[k>>>8&255]^D[F&255]^v[R++],S=E[T>>>24]^C[k>>>16&255]^B[F>>>8&255]^D[$&255]^v[R++];k=O,F=U,$=j,T=S}var O=(A[k>>>24]<<24|A[F>>>16&255]<<16|A[$>>>8&255]<<8|A[T&255])^v[R++],U=(A[F>>>24]<<24|A[$>>>16&255]<<16|A[T>>>8&255]<<8|A[k&255])^v[R++],j=(A[$>>>24]<<24|A[T>>>16&255]<<16|A[k>>>8&255]<<8|A[F&255])^v[R++],S=(A[T>>>24]<<24|A[k>>>16&255]<<16|A[F>>>8&255]<<8|A[$&255])^v[R++];c[m]=O,c[m+1]=U,c[m+2]=j,c[m+3]=S},keySize:256/32});r.AES=s._createHelper(l)})(),a.AES})})(ht)),ht.exports}var vt={exports:{}},dn=vt.exports,Rr;function xn(){return Rr||(Rr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),ve(),me(),fe(),V())})(dn,function(a){return(function(){var r=a,n=r.lib,s=n.WordArray,b=n.BlockCipher,d=r.algo,h=[57,49,41,33,25,17,9,1,58,50,42,34,26,18,10,2,59,51,43,35,27,19,11,3,60,52,44,36,63,55,47,39,31,23,15,7,62,54,46,38,30,22,14,6,61,53,45,37,29,21,13,5,28,20,12,4],i=[14,17,11,24,1,5,3,28,15,6,21,10,23,19,12,4,26,8,16,7,27,20,13,2,41,52,31,37,47,55,30,40,51,45,33,48,44,49,39,56,34,53,46,42,50,36,29,32],x=[1,2,4,6,8,10,12,14,15,17,19,21,23,25,27,28],w=[{0:8421888,268435456:32768,536870912:8421378,805306368:2,1073741824:512,1342177280:8421890,1610612736:8389122,1879048192:8388608,2147483648:514,2415919104:8389120,2684354560:33280,2952790016:8421376,3221225472:32770,3489660928:8388610,3758096384:0,4026531840:33282,134217728:0,402653184:8421890,671088640:33282,939524096:32768,1207959552:8421888,1476395008:512,1744830464:8421378,2013265920:2,2281701376:8389120,2550136832:33280,2818572288:8421376,3087007744:8389122,3355443200:8388610,3623878656:32770,3892314112:514,4160749568:8388608,1:32768,268435457:2,536870913:8421888,805306369:8388608,1073741825:8421378,1342177281:33280,1610612737:512,1879048193:8389122,2147483649:8421890,2415919105:8421376,2684354561:8388610,2952790017:33282,3221225473:514,3489660929:8389120,3758096385:32770,4026531841:0,134217729:8421890,402653185:8421376,671088641:8388608,939524097:512,1207959553:32768,1476395009:8388610,1744830465:2,2013265921:33282,2281701377:32770,2550136833:8389122,2818572289:514,3087007745:8421888,3355443201:8389120,3623878657:0,3892314113:33280,4160749569:8421378},{0:1074282512,16777216:16384,33554432:524288,50331648:1074266128,67108864:1073741840,83886080:1074282496,100663296:1073758208,117440512:16,134217728:540672,150994944:1073758224,167772160:1073741824,184549376:540688,201326592:524304,218103808:0,234881024:16400,251658240:1074266112,8388608:1073758208,25165824:540688,41943040:16,58720256:1073758224,75497472:1074282512,92274688:1073741824,109051904:524288,125829120:1074266128,142606336:524304,159383552:0,176160768:16384,192937984:1074266112,209715200:1073741840,226492416:540672,243269632:1074282496,260046848:16400,268435456:0,285212672:1074266128,301989888:1073758224,318767104:1074282496,335544320:1074266112,352321536:16,369098752:540688,385875968:16384,402653184:16400,419430400:524288,436207616:524304,452984832:1073741840,469762048:540672,486539264:1073758208,503316480:1073741824,520093696:1074282512,276824064:540688,293601280:524288,310378496:1074266112,327155712:16384,343932928:1073758208,360710144:1074282512,377487360:16,394264576:1073741824,411041792:1074282496,427819008:1073741840,444596224:1073758224,461373440:524304,478150656:0,494927872:16400,511705088:1074266128,528482304:540672},{0:260,1048576:0,2097152:67109120,3145728:65796,4194304:65540,5242880:67108868,6291456:67174660,7340032:67174400,8388608:67108864,9437184:67174656,10485760:65792,11534336:67174404,12582912:67109124,13631488:65536,14680064:4,15728640:256,524288:67174656,1572864:67174404,2621440:0,3670016:67109120,4718592:67108868,5767168:65536,6815744:65540,7864320:260,8912896:4,9961472:256,11010048:67174400,12058624:65796,13107200:65792,14155776:67109124,15204352:67174660,16252928:67108864,16777216:67174656,17825792:65540,18874368:65536,19922944:67109120,20971520:256,22020096:67174660,23068672:67108868,24117248:0,25165824:67109124,26214400:67108864,27262976:4,28311552:65792,29360128:67174400,30408704:260,31457280:65796,32505856:67174404,17301504:67108864,18350080:260,19398656:67174656,20447232:0,21495808:65540,22544384:67109120,23592960:256,24641536:67174404,25690112:65536,26738688:67174660,27787264:65796,28835840:67108868,29884416:67109124,30932992:67174400,31981568:4,33030144:65792},{0:2151682048,65536:2147487808,131072:4198464,196608:2151677952,262144:0,327680:4198400,393216:2147483712,458752:4194368,524288:2147483648,589824:4194304,655360:64,720896:2147487744,786432:2151678016,851968:4160,917504:4096,983040:2151682112,32768:2147487808,98304:64,163840:2151678016,229376:2147487744,294912:4198400,360448:2151682112,425984:0,491520:2151677952,557056:4096,622592:2151682048,688128:4194304,753664:4160,819200:2147483648,884736:4194368,950272:4198464,1015808:2147483712,1048576:4194368,1114112:4198400,1179648:2147483712,1245184:0,1310720:4160,1376256:2151678016,1441792:2151682048,1507328:2147487808,1572864:2151682112,1638400:2147483648,1703936:2151677952,1769472:4198464,1835008:2147487744,1900544:4194304,1966080:64,2031616:4096,1081344:2151677952,1146880:2151682112,1212416:0,1277952:4198400,1343488:4194368,1409024:2147483648,1474560:2147487808,1540096:64,1605632:2147483712,1671168:4096,1736704:2147487744,1802240:2151678016,1867776:4160,1933312:2151682048,1998848:4194304,2064384:4198464},{0:128,4096:17039360,8192:262144,12288:536870912,16384:537133184,20480:16777344,24576:553648256,28672:262272,32768:16777216,36864:537133056,40960:536871040,45056:553910400,49152:553910272,53248:0,57344:17039488,61440:553648128,2048:17039488,6144:553648256,10240:128,14336:17039360,18432:262144,22528:537133184,26624:553910272,30720:536870912,34816:537133056,38912:0,43008:553910400,47104:16777344,51200:536871040,55296:553648128,59392:16777216,63488:262272,65536:262144,69632:128,73728:536870912,77824:553648256,81920:16777344,86016:553910272,90112:537133184,94208:16777216,98304:553910400,102400:553648128,106496:17039360,110592:537133056,114688:262272,118784:536871040,122880:0,126976:17039488,67584:553648256,71680:16777216,75776:17039360,79872:537133184,83968:536870912,88064:17039488,92160:128,96256:553910272,100352:262272,104448:553910400,108544:0,112640:553648128,116736:16777344,120832:262144,124928:537133056,129024:536871040},{0:268435464,256:8192,512:270532608,768:270540808,1024:268443648,1280:2097152,1536:2097160,1792:268435456,2048:0,2304:268443656,2560:2105344,2816:8,3072:270532616,3328:2105352,3584:8200,3840:270540800,128:270532608,384:270540808,640:8,896:2097152,1152:2105352,1408:268435464,1664:268443648,1920:8200,2176:2097160,2432:8192,2688:268443656,2944:270532616,3200:0,3456:270540800,3712:2105344,3968:268435456,4096:268443648,4352:270532616,4608:270540808,4864:8200,5120:2097152,5376:268435456,5632:268435464,5888:2105344,6144:2105352,6400:0,6656:8,6912:270532608,7168:8192,7424:268443656,7680:270540800,7936:2097160,4224:8,4480:2105344,4736:2097152,4992:268435464,5248:268443648,5504:8200,5760:270540808,6016:270532608,6272:270540800,6528:270532616,6784:8192,7040:2105352,7296:2097160,7552:0,7808:268435456,8064:268443656},{0:1048576,16:33555457,32:1024,48:1049601,64:34604033,80:0,96:1,112:34603009,128:33555456,144:1048577,160:33554433,176:34604032,192:34603008,208:1025,224:1049600,240:33554432,8:34603009,24:0,40:33555457,56:34604032,72:1048576,88:33554433,104:33554432,120:1025,136:1049601,152:33555456,168:34603008,184:1048577,200:1024,216:34604033,232:1,248:1049600,256:33554432,272:1048576,288:33555457,304:34603009,320:1048577,336:33555456,352:34604032,368:1049601,384:1025,400:34604033,416:1049600,432:1,448:0,464:34603008,480:33554433,496:1024,264:1049600,280:33555457,296:34603009,312:1,328:33554432,344:1048576,360:1025,376:34604032,392:33554433,408:34603008,424:0,440:34604033,456:1049601,472:1024,488:33555456,504:1048577},{0:134219808,1:131072,2:134217728,3:32,4:131104,5:134350880,6:134350848,7:2048,8:134348800,9:134219776,10:133120,11:134348832,12:2080,13:0,14:134217760,15:133152,2147483648:2048,2147483649:134350880,2147483650:134219808,2147483651:134217728,2147483652:134348800,2147483653:133120,2147483654:133152,2147483655:32,2147483656:134217760,2147483657:2080,2147483658:131104,2147483659:134350848,2147483660:0,2147483661:134348832,2147483662:134219776,2147483663:131072,16:133152,17:134350848,18:32,19:2048,20:134219776,21:134217760,22:134348832,23:131072,24:0,25:131104,26:134348800,27:134219808,28:134350880,29:133120,30:2080,31:134217728,2147483664:131072,2147483665:2048,2147483666:134348832,2147483667:133152,2147483668:32,2147483669:134348800,2147483670:134217728,2147483671:134219808,2147483672:134350880,2147483673:134217760,2147483674:134219776,2147483675:0,2147483676:133120,2147483677:2080,2147483678:131104,2147483679:134350848}],o=[4160749569,528482304,33030144,2064384,129024,8064,504,2147483679],p=d.DES=b.extend({_doReset:function(){for(var u=this._key,l=u.words,c=[],m=0;m<56;m++){var v=h[m]-1;c[m]=l[v>>>5]>>>31-v%32&1}for(var E=this._subKeys=[],C=0;C<16;C++){for(var B=E[C]=[],D=x[C],m=0;m<24;m++)B[m/6|0]|=c[(i[m]-1+D)%28]<<31-m%6,B[4+(m/6|0)]|=c[28+(i[m+24]-1+D)%28]<<31-m%6;B[0]=B[0]<<1|B[0]>>>31;for(var m=1;m<7;m++)B[m]=B[m]>>>(m-1)*4+3;B[7]=B[7]<<5|B[7]>>>27}for(var A=this._invSubKeys=[],m=0;m<16;m++)A[m]=E[15-m]},encryptBlock:function(u,l){this._doCryptBlock(u,l,this._subKeys)},decryptBlock:function(u,l){this._doCryptBlock(u,l,this._invSubKeys)},_doCryptBlock:function(u,l,c){this._lBlock=u[l],this._rBlock=u[l+1],f.call(this,4,252645135),f.call(this,16,65535),y.call(this,2,858993459),y.call(this,8,16711935),f.call(this,1,1431655765);for(var m=0;m<16;m++){for(var v=c[m],E=this._lBlock,C=this._rBlock,B=0,D=0;D<8;D++)B|=w[D][((C^v[D])&o[D])>>>0];this._lBlock=C,this._rBlock=E^B}var A=this._lBlock;this._lBlock=this._rBlock,this._rBlock=A,f.call(this,1,1431655765),y.call(this,8,16711935),y.call(this,2,858993459),f.call(this,16,65535),f.call(this,4,252645135),u[l]=this._lBlock,u[l+1]=this._rBlock},keySize:64/32,ivSize:64/32,blockSize:64/32});function f(u,l){var c=(this._lBlock>>>u^this._rBlock)&l;this._rBlock^=c,this._lBlock^=c<<u}function y(u,l){var c=(this._rBlock>>>u^this._lBlock)&l;this._lBlock^=c,this._rBlock^=c<<u}r.DES=b._createHelper(p);var g=d.TripleDES=b.extend({_doReset:function(){var u=this._key,l=u.words;if(l.length!==2&&l.length!==4&&l.length<6)throw new Error("Invalid key length - 3DES requires the key length to be 64, 128, 192 or >192.");var c=l.slice(0,2),m=l.length<4?l.slice(0,2):l.slice(2,4),v=l.length<6?l.slice(0,2):l.slice(4,6);this._des1=p.createEncryptor(s.create(c)),this._des2=p.createEncryptor(s.create(m)),this._des3=p.createEncryptor(s.create(v))},encryptBlock:function(u,l){this._des1.encryptBlock(u,l),this._des2.decryptBlock(u,l),this._des3.encryptBlock(u,l)},decryptBlock:function(u,l){this._des3.decryptBlock(u,l),this._des2.encryptBlock(u,l),this._des1.decryptBlock(u,l)},keySize:192/32,ivSize:64/32,blockSize:64/32});r.TripleDES=b._createHelper(g)})(),a.TripleDES})})(vt)),vt.exports}var mt={exports:{}},pn=mt.exports,Nr;function un(){return Nr||(Nr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),ve(),me(),fe(),V())})(pn,function(a){return(function(){var r=a,n=r.lib,s=n.StreamCipher,b=r.algo,d=b.RC4=s.extend({_doReset:function(){for(var x=this._key,w=x.words,o=x.sigBytes,p=this._S=[],f=0;f<256;f++)p[f]=f;for(var f=0,y=0;f<256;f++){var g=f%o,u=w[g>>>2]>>>24-g%4*8&255;y=(y+p[f]+u)%256;var l=p[f];p[f]=p[y],p[y]=l}this._i=this._j=0},_doProcessBlock:function(x,w){x[w]^=h.call(this)},keySize:256/32,ivSize:0});function h(){for(var x=this._S,w=this._i,o=this._j,p=0,f=0;f<4;f++){w=(w+1)%256,o=(o+x[w])%256;var y=x[w];x[w]=x[o],x[o]=y,p|=x[(x[w]+x[o])%256]<<24-f*8}return this._i=w,this._j=o,p}r.RC4=s._createHelper(d);var i=b.RC4Drop=d.extend({cfg:d.cfg.extend({drop:192}),_doReset:function(){d._doReset.call(this);for(var x=this.cfg.drop;x>0;x--)h.call(this)}});r.RC4Drop=s._createHelper(i)})(),a.RC4})})(mt)),mt.exports}var gt={exports:{}},fn=gt.exports,Mr;function hn(){return Mr||(Mr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),ve(),me(),fe(),V())})(fn,function(a){return(function(){var r=a,n=r.lib,s=n.StreamCipher,b=r.algo,d=[],h=[],i=[],x=b.Rabbit=s.extend({_doReset:function(){for(var o=this._key.words,p=this.cfg.iv,f=0;f<4;f++)o[f]=(o[f]<<8|o[f]>>>24)&16711935|(o[f]<<24|o[f]>>>8)&4278255360;var y=this._X=[o[0],o[3]<<16|o[2]>>>16,o[1],o[0]<<16|o[3]>>>16,o[2],o[1]<<16|o[0]>>>16,o[3],o[2]<<16|o[1]>>>16],g=this._C=[o[2]<<16|o[2]>>>16,o[0]&4294901760|o[1]&65535,o[3]<<16|o[3]>>>16,o[1]&4294901760|o[2]&65535,o[0]<<16|o[0]>>>16,o[2]&4294901760|o[3]&65535,o[1]<<16|o[1]>>>16,o[3]&4294901760|o[0]&65535];this._b=0;for(var f=0;f<4;f++)w.call(this);for(var f=0;f<8;f++)g[f]^=y[f+4&7];if(p){var u=p.words,l=u[0],c=u[1],m=(l<<8|l>>>24)&16711935|(l<<24|l>>>8)&4278255360,v=(c<<8|c>>>24)&16711935|(c<<24|c>>>8)&4278255360,E=m>>>16|v&4294901760,C=v<<16|m&65535;g[0]^=m,g[1]^=E,g[2]^=v,g[3]^=C,g[4]^=m,g[5]^=E,g[6]^=v,g[7]^=C;for(var f=0;f<4;f++)w.call(this)}},_doProcessBlock:function(o,p){var f=this._X;w.call(this),d[0]=f[0]^f[5]>>>16^f[3]<<16,d[1]=f[2]^f[7]>>>16^f[5]<<16,d[2]=f[4]^f[1]>>>16^f[7]<<16,d[3]=f[6]^f[3]>>>16^f[1]<<16;for(var y=0;y<4;y++)d[y]=(d[y]<<8|d[y]>>>24)&16711935|(d[y]<<24|d[y]>>>8)&4278255360,o[p+y]^=d[y]},blockSize:128/32,ivSize:64/32});function w(){for(var o=this._X,p=this._C,f=0;f<8;f++)h[f]=p[f];p[0]=p[0]+1295307597+this._b|0,p[1]=p[1]+3545052371+(p[0]>>>0<h[0]>>>0?1:0)|0,p[2]=p[2]+886263092+(p[1]>>>0<h[1]>>>0?1:0)|0,p[3]=p[3]+1295307597+(p[2]>>>0<h[2]>>>0?1:0)|0,p[4]=p[4]+3545052371+(p[3]>>>0<h[3]>>>0?1:0)|0,p[5]=p[5]+886263092+(p[4]>>>0<h[4]>>>0?1:0)|0,p[6]=p[6]+1295307597+(p[5]>>>0<h[5]>>>0?1:0)|0,p[7]=p[7]+3545052371+(p[6]>>>0<h[6]>>>0?1:0)|0,this._b=p[7]>>>0<h[7]>>>0?1:0;for(var f=0;f<8;f++){var y=o[f]+p[f],g=y&65535,u=y>>>16,l=((g*g>>>17)+g*u>>>15)+u*u,c=((y&4294901760)*y|0)+((y&65535)*y|0);i[f]=l^c}o[0]=i[0]+(i[7]<<16|i[7]>>>16)+(i[6]<<16|i[6]>>>16)|0,o[1]=i[1]+(i[0]<<8|i[0]>>>24)+i[7]|0,o[2]=i[2]+(i[1]<<16|i[1]>>>16)+(i[0]<<16|i[0]>>>16)|0,o[3]=i[3]+(i[2]<<8|i[2]>>>24)+i[1]|0,o[4]=i[4]+(i[3]<<16|i[3]>>>16)+(i[2]<<16|i[2]>>>16)|0,o[5]=i[5]+(i[4]<<8|i[4]>>>24)+i[3]|0,o[6]=i[6]+(i[5]<<16|i[5]>>>16)+(i[4]<<16|i[4]>>>16)|0,o[7]=i[7]+(i[6]<<8|i[6]>>>24)+i[5]|0}r.Rabbit=s._createHelper(x)})(),a.Rabbit})})(gt)),gt.exports}var yt={exports:{}},vn=yt.exports,Ir;function mn(){return Ir||(Ir=1,(function(e,t){(function(a,r,n){e.exports=r(I(),ve(),me(),fe(),V())})(vn,function(a){return(function(){var r=a,n=r.lib,s=n.StreamCipher,b=r.algo,d=[],h=[],i=[],x=b.RabbitLegacy=s.extend({_doReset:function(){var o=this._key.words,p=this.cfg.iv,f=this._X=[o[0],o[3]<<16|o[2]>>>16,o[1],o[0]<<16|o[3]>>>16,o[2],o[1]<<16|o[0]>>>16,o[3],o[2]<<16|o[1]>>>16],y=this._C=[o[2]<<16|o[2]>>>16,o[0]&4294901760|o[1]&65535,o[3]<<16|o[3]>>>16,o[1]&4294901760|o[2]&65535,o[0]<<16|o[0]>>>16,o[2]&4294901760|o[3]&65535,o[1]<<16|o[1]>>>16,o[3]&4294901760|o[0]&65535];this._b=0;for(var g=0;g<4;g++)w.call(this);for(var g=0;g<8;g++)y[g]^=f[g+4&7];if(p){var u=p.words,l=u[0],c=u[1],m=(l<<8|l>>>24)&16711935|(l<<24|l>>>8)&4278255360,v=(c<<8|c>>>24)&16711935|(c<<24|c>>>8)&4278255360,E=m>>>16|v&4294901760,C=v<<16|m&65535;y[0]^=m,y[1]^=E,y[2]^=v,y[3]^=C,y[4]^=m,y[5]^=E,y[6]^=v,y[7]^=C;for(var g=0;g<4;g++)w.call(this)}},_doProcessBlock:function(o,p){var f=this._X;w.call(this),d[0]=f[0]^f[5]>>>16^f[3]<<16,d[1]=f[2]^f[7]>>>16^f[5]<<16,d[2]=f[4]^f[1]>>>16^f[7]<<16,d[3]=f[6]^f[3]>>>16^f[1]<<16;for(var y=0;y<4;y++)d[y]=(d[y]<<8|d[y]>>>24)&16711935|(d[y]<<24|d[y]>>>8)&4278255360,o[p+y]^=d[y]},blockSize:128/32,ivSize:64/32});function w(){for(var o=this._X,p=this._C,f=0;f<8;f++)h[f]=p[f];p[0]=p[0]+1295307597+this._b|0,p[1]=p[1]+3545052371+(p[0]>>>0<h[0]>>>0?1:0)|0,p[2]=p[2]+886263092+(p[1]>>>0<h[1]>>>0?1:0)|0,p[3]=p[3]+1295307597+(p[2]>>>0<h[2]>>>0?1:0)|0,p[4]=p[4]+3545052371+(p[3]>>>0<h[3]>>>0?1:0)|0,p[5]=p[5]+886263092+(p[4]>>>0<h[4]>>>0?1:0)|0,p[6]=p[6]+1295307597+(p[5]>>>0<h[5]>>>0?1:0)|0,p[7]=p[7]+3545052371+(p[6]>>>0<h[6]>>>0?1:0)|0,this._b=p[7]>>>0<h[7]>>>0?1:0;for(var f=0;f<8;f++){var y=o[f]+p[f],g=y&65535,u=y>>>16,l=((g*g>>>17)+g*u>>>15)+u*u,c=((y&4294901760)*y|0)+((y&65535)*y|0);i[f]=l^c}o[0]=i[0]+(i[7]<<16|i[7]>>>16)+(i[6]<<16|i[6]>>>16)|0,o[1]=i[1]+(i[0]<<8|i[0]>>>24)+i[7]|0,o[2]=i[2]+(i[1]<<16|i[1]>>>16)+(i[0]<<16|i[0]>>>16)|0,o[3]=i[3]+(i[2]<<8|i[2]>>>24)+i[1]|0,o[4]=i[4]+(i[3]<<16|i[3]>>>16)+(i[2]<<16|i[2]>>>16)|0,o[5]=i[5]+(i[4]<<8|i[4]>>>24)+i[3]|0,o[6]=i[6]+(i[5]<<16|i[5]>>>16)+(i[4]<<16|i[4]>>>16)|0,o[7]=i[7]+(i[6]<<8|i[6]>>>24)+i[5]|0}r.RabbitLegacy=s._createHelper(x)})(),a.RabbitLegacy})})(yt)),yt.exports}var bt={exports:{}},gn=bt.exports,Or;function yn(){return Or||(Or=1,(function(e,t){(function(a,r,n){e.exports=r(I(),ve(),me(),fe(),V())})(gn,function(a){return(function(){var r=a,n=r.lib,s=n.BlockCipher,b=r.algo;const d=16,h=[608135816,2242054355,320440878,57701188,2752067618,698298832,137296536,3964562569,1160258022,953160567,3193202383,887688300,3232508343,3380367581,1065670069,3041331479,2450970073,2306472731],i=[[3509652390,2564797868,805139163,3491422135,3101798381,1780907670,3128725573,4046225305,614570311,3012652279,134345442,2240740374,1667834072,1901547113,2757295779,4103290238,227898511,1921955416,1904987480,2182433518,2069144605,3260701109,2620446009,720527379,3318853667,677414384,3393288472,3101374703,2390351024,1614419982,1822297739,2954791486,3608508353,3174124327,2024746970,1432378464,3864339955,2857741204,1464375394,1676153920,1439316330,715854006,3033291828,289532110,2706671279,2087905683,3018724369,1668267050,732546397,1947742710,3462151702,2609353502,2950085171,1814351708,2050118529,680887927,999245976,1800124847,3300911131,1713906067,1641548236,4213287313,1216130144,1575780402,4018429277,3917837745,3693486850,3949271944,596196993,3549867205,258830323,2213823033,772490370,2760122372,1774776394,2652871518,566650946,4142492826,1728879713,2882767088,1783734482,3629395816,2517608232,2874225571,1861159788,326777828,3124490320,2130389656,2716951837,967770486,1724537150,2185432712,2364442137,1164943284,2105845187,998989502,3765401048,2244026483,1075463327,1455516326,1322494562,910128902,469688178,1117454909,936433444,3490320968,3675253459,1240580251,122909385,2157517691,634681816,4142456567,3825094682,3061402683,2540495037,79693498,3249098678,1084186820,1583128258,426386531,1761308591,1047286709,322548459,995290223,1845252383,2603652396,3431023940,2942221577,3202600964,3727903485,1712269319,422464435,3234572375,1170764815,3523960633,3117677531,1434042557,442511882,3600875718,1076654713,1738483198,4213154764,2393238008,3677496056,1014306527,4251020053,793779912,2902807211,842905082,4246964064,1395751752,1040244610,2656851899,3396308128,445077038,3742853595,3577915638,679411651,2892444358,2354009459,1767581616,3150600392,3791627101,3102740896,284835224,4246832056,1258075500,768725851,2589189241,3069724005,3532540348,1274779536,3789419226,2764799539,1660621633,3471099624,4011903706,913787905,3497959166,737222580,2514213453,2928710040,3937242737,1804850592,3499020752,2949064160,2386320175,2390070455,2415321851,4061277028,2290661394,2416832540,1336762016,1754252060,3520065937,3014181293,791618072,3188594551,3933548030,2332172193,3852520463,3043980520,413987798,3465142937,3030929376,4245938359,2093235073,3534596313,375366246,2157278981,2479649556,555357303,3870105701,2008414854,3344188149,4221384143,3956125452,2067696032,3594591187,2921233993,2428461,544322398,577241275,1471733935,610547355,4027169054,1432588573,1507829418,2025931657,3646575487,545086370,48609733,2200306550,1653985193,298326376,1316178497,3007786442,2064951626,458293330,2589141269,3591329599,3164325604,727753846,2179363840,146436021,1461446943,4069977195,705550613,3059967265,3887724982,4281599278,3313849956,1404054877,2845806497,146425753,1854211946],[1266315497,3048417604,3681880366,3289982499,290971e4,1235738493,2632868024,2414719590,3970600049,1771706367,1449415276,3266420449,422970021,1963543593,2690192192,3826793022,1062508698,1531092325,1804592342,2583117782,2714934279,4024971509,1294809318,4028980673,1289560198,2221992742,1669523910,35572830,157838143,1052438473,1016535060,1802137761,1753167236,1386275462,3080475397,2857371447,1040679964,2145300060,2390574316,1461121720,2956646967,4031777805,4028374788,33600511,2920084762,1018524850,629373528,3691585981,3515945977,2091462646,2486323059,586499841,988145025,935516892,3367335476,2599673255,2839830854,265290510,3972581182,2759138881,3795373465,1005194799,847297441,406762289,1314163512,1332590856,1866599683,4127851711,750260880,613907577,1450815602,3165620655,3734664991,3650291728,3012275730,3704569646,1427272223,778793252,1343938022,2676280711,2052605720,1946737175,3164576444,3914038668,3967478842,3682934266,1661551462,3294938066,4011595847,840292616,3712170807,616741398,312560963,711312465,1351876610,322626781,1910503582,271666773,2175563734,1594956187,70604529,3617834859,1007753275,1495573769,4069517037,2549218298,2663038764,504708206,2263041392,3941167025,2249088522,1514023603,1998579484,1312622330,694541497,2582060303,2151582166,1382467621,776784248,2618340202,3323268794,2497899128,2784771155,503983604,4076293799,907881277,423175695,432175456,1378068232,4145222326,3954048622,3938656102,3820766613,2793130115,2977904593,26017576,3274890735,3194772133,1700274565,1756076034,4006520079,3677328699,720338349,1533947780,354530856,688349552,3973924725,1637815568,332179504,3949051286,53804574,2852348879,3044236432,1282449977,3583942155,3416972820,4006381244,1617046695,2628476075,3002303598,1686838959,431878346,2686675385,1700445008,1080580658,1009431731,832498133,3223435511,2605976345,2271191193,2516031870,1648197032,4164389018,2548247927,300782431,375919233,238389289,3353747414,2531188641,2019080857,1475708069,455242339,2609103871,448939670,3451063019,1395535956,2413381860,1841049896,1491858159,885456874,4264095073,4001119347,1565136089,3898914787,1108368660,540939232,1173283510,2745871338,3681308437,4207628240,3343053890,4016749493,1699691293,1103962373,3625875870,2256883143,3830138730,1031889488,3479347698,1535977030,4236805024,3251091107,2132092099,1774941330,1199868427,1452454533,157007616,2904115357,342012276,595725824,1480756522,206960106,497939518,591360097,863170706,2375253569,3596610801,1814182875,2094937945,3421402208,1082520231,3463918190,2785509508,435703966,3908032597,1641649973,2842273706,3305899714,1510255612,2148256476,2655287854,3276092548,4258621189,236887753,3681803219,274041037,1734335097,3815195456,3317970021,1899903192,1026095262,4050517792,356393447,2410691914,3873677099,3682840055],[3913112168,2491498743,4132185628,2489919796,1091903735,1979897079,3170134830,3567386728,3557303409,857797738,1136121015,1342202287,507115054,2535736646,337727348,3213592640,1301675037,2528481711,1895095763,1721773893,3216771564,62756741,2142006736,835421444,2531993523,1442658625,3659876326,2882144922,676362277,1392781812,170690266,3921047035,1759253602,3611846912,1745797284,664899054,1329594018,3901205900,3045908486,2062866102,2865634940,3543621612,3464012697,1080764994,553557557,3656615353,3996768171,991055499,499776247,1265440854,648242737,3940784050,980351604,3713745714,1749149687,3396870395,4211799374,3640570775,1161844396,3125318951,1431517754,545492359,4268468663,3499529547,1437099964,2702547544,3433638243,2581715763,2787789398,1060185593,1593081372,2418618748,4260947970,69676912,2159744348,86519011,2512459080,3838209314,1220612927,3339683548,133810670,1090789135,1078426020,1569222167,845107691,3583754449,4072456591,1091646820,628848692,1613405280,3757631651,526609435,236106946,48312990,2942717905,3402727701,1797494240,859738849,992217954,4005476642,2243076622,3870952857,3732016268,765654824,3490871365,2511836413,1685915746,3888969200,1414112111,2273134842,3281911079,4080962846,172450625,2569994100,980381355,4109958455,2819808352,2716589560,2568741196,3681446669,3329971472,1835478071,660984891,3704678404,4045999559,3422617507,3040415634,1762651403,1719377915,3470491036,2693910283,3642056355,3138596744,1364962596,2073328063,1983633131,926494387,3423689081,2150032023,4096667949,1749200295,3328846651,309677260,2016342300,1779581495,3079819751,111262694,1274766160,443224088,298511866,1025883608,3806446537,1145181785,168956806,3641502830,3584813610,1689216846,3666258015,3200248200,1692713982,2646376535,4042768518,1618508792,1610833997,3523052358,4130873264,2001055236,3610705100,2202168115,4028541809,2961195399,1006657119,2006996926,3186142756,1430667929,3210227297,1314452623,4074634658,4101304120,2273951170,1399257539,3367210612,3027628629,1190975929,2062231137,2333990788,2221543033,2438960610,1181637006,548689776,2362791313,3372408396,3104550113,3145860560,296247880,1970579870,3078560182,3769228297,1714227617,3291629107,3898220290,166772364,1251581989,493813264,448347421,195405023,2709975567,677966185,3703036547,1463355134,2715995803,1338867538,1343315457,2802222074,2684532164,233230375,2599980071,2000651841,3277868038,1638401717,4028070440,3237316320,6314154,819756386,300326615,590932579,1405279636,3267499572,3150704214,2428286686,3959192993,3461946742,1862657033,1266418056,963775037,2089974820,2263052895,1917689273,448879540,3550394620,3981727096,150775221,3627908307,1303187396,508620638,2975983352,2726630617,1817252668,1876281319,1457606340,908771278,3720792119,3617206836,2455994898,1729034894,1080033504],[976866871,3556439503,2881648439,1522871579,1555064734,1336096578,3548522304,2579274686,3574697629,3205460757,3593280638,3338716283,3079412587,564236357,2993598910,1781952180,1464380207,3163844217,3332601554,1699332808,1393555694,1183702653,3581086237,1288719814,691649499,2847557200,2895455976,3193889540,2717570544,1781354906,1676643554,2592534050,3230253752,1126444790,2770207658,2633158820,2210423226,2615765581,2414155088,3127139286,673620729,2805611233,1269405062,4015350505,3341807571,4149409754,1057255273,2012875353,2162469141,2276492801,2601117357,993977747,3918593370,2654263191,753973209,36408145,2530585658,25011837,3520020182,2088578344,530523599,2918365339,1524020338,1518925132,3760827505,3759777254,1202760957,3985898139,3906192525,674977740,4174734889,2031300136,2019492241,3983892565,4153806404,3822280332,352677332,2297720250,60907813,90501309,3286998549,1016092578,2535922412,2839152426,457141659,509813237,4120667899,652014361,1966332200,2975202805,55981186,2327461051,676427537,3255491064,2882294119,3433927263,1307055953,942726286,933058658,2468411793,3933900994,4215176142,1361170020,2001714738,2830558078,3274259782,1222529897,1679025792,2729314320,3714953764,1770335741,151462246,3013232138,1682292957,1483529935,471910574,1539241949,458788160,3436315007,1807016891,3718408830,978976581,1043663428,3165965781,1927990952,4200891579,2372276910,3208408903,3533431907,1412390302,2931980059,4132332400,1947078029,3881505623,4168226417,2941484381,1077988104,1320477388,886195818,18198404,3786409e3,2509781533,112762804,3463356488,1866414978,891333506,18488651,661792760,1628790961,3885187036,3141171499,876946877,2693282273,1372485963,791857591,2686433993,3759982718,3167212022,3472953795,2716379847,445679433,3561995674,3504004811,3574258232,54117162,3331405415,2381918588,3769707343,4154350007,1140177722,4074052095,668550556,3214352940,367459370,261225585,2610173221,4209349473,3468074219,3265815641,314222801,3066103646,3808782860,282218597,3406013506,3773591054,379116347,1285071038,846784868,2669647154,3771962079,3550491691,2305946142,453669953,1268987020,3317592352,3279303384,3744833421,2610507566,3859509063,266596637,3847019092,517658769,3462560207,3443424879,370717030,4247526661,2224018117,4143653529,4112773975,2788324899,2477274417,1456262402,2901442914,1517677493,1846949527,2295493580,3734397586,2176403920,1280348187,1908823572,3871786941,846861322,1172426758,3287448474,3383383037,1655181056,3139813346,901632758,1897031941,2986607138,3066810236,3447102507,1393639104,373351379,950779232,625454576,3124240540,4148612726,2007998917,544563296,2244738638,2330496472,2058025392,1291430526,424198748,50039436,29584100,3605783033,2429876329,2791104160,1057563949,3255363231,3075367218,3463963227,1469046755,985887462]];var x={pbox:[],sbox:[]};function w(g,u){let l=u>>24&255,c=u>>16&255,m=u>>8&255,v=u&255,E=g.sbox[0][l]+g.sbox[1][c];return E=E^g.sbox[2][m],E=E+g.sbox[3][v],E}function o(g,u,l){let c=u,m=l,v;for(let E=0;E<d;++E)c=c^g.pbox[E],m=w(g,c)^m,v=c,c=m,m=v;return v=c,c=m,m=v,m=m^g.pbox[d],c=c^g.pbox[d+1],{left:c,right:m}}function p(g,u,l){let c=u,m=l,v;for(let E=d+1;E>1;--E)c=c^g.pbox[E],m=w(g,c)^m,v=c,c=m,m=v;return v=c,c=m,m=v,m=m^g.pbox[1],c=c^g.pbox[0],{left:c,right:m}}function f(g,u,l){for(let C=0;C<4;C++){g.sbox[C]=[];for(let B=0;B<256;B++)g.sbox[C][B]=i[C][B]}let c=0;for(let C=0;C<d+2;C++)g.pbox[C]=h[C]^u[c],c++,c>=l&&(c=0);let m=0,v=0,E=0;for(let C=0;C<d+2;C+=2)E=o(g,m,v),m=E.left,v=E.right,g.pbox[C]=m,g.pbox[C+1]=v;for(let C=0;C<4;C++)for(let B=0;B<256;B+=2)E=o(g,m,v),m=E.left,v=E.right,g.sbox[C][B]=m,g.sbox[C][B+1]=v;return!0}var y=b.Blowfish=s.extend({_doReset:function(){if(this._keyPriorReset!==this._key){var g=this._keyPriorReset=this._key,u=g.words,l=g.sigBytes/4;f(x,u,l)}},encryptBlock:function(g,u){var l=o(x,g[u],g[u+1]);g[u]=l.left,g[u+1]=l.right},decryptBlock:function(g,u){var l=p(x,g[u],g[u+1]);g[u]=l.left,g[u+1]=l.right},blockSize:64/32,keySize:128/32,ivSize:64/32});r.Blowfish=s._createHelper(y)})(),a.Blowfish})})(bt)),bt.exports}var bn=Ne.exports,jr;function wn(){return jr||(jr=1,(function(e,t){(function(a,r,n){e.exports=r(I(),Bt(),va(),ga(),ve(),wa(),me(),s0(),Nt(),_a(),o0(),Fa(),La(),Pa(),Mt(),Ta(),fe(),V(),Ma(),Oa(),Ua(),Ka(),Va(),Ya(),Za(),en(),rn(),nn(),on(),ln(),xn(),un(),hn(),mn(),yn())})(bn,function(a){return a})})(Ne)),Ne.exports}var En=wn();const Ee=oa(En),ne=Et.isNativePlatform(),Cn="38346591",Ur={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",Accept:"*/*","Accept-Language":"en-US,en;q=0.9,hi;q=0.8",Referer:"https://www.jiosaavn.com/"};async function ae(e){if(ne){const t=await ea.get({url:e,headers:Ur});if(t.status!==200)throw new Error(`HTTP ${t.status}`);return typeof t.data=="string"?t.data:JSON.stringify(t.data)}else{const t=await fetch(e,{headers:Ur});if(!t.ok)throw new Error(`HTTP ${t.status}`);return await t.text()}}function Wr(e){if(!e)return"";try{const t=Ee.enc.Utf8.parse(Cn),a=Ee.enc.Base64.parse(e.trim());let n=Ee.DES.decrypt({ciphertext:a},t,{mode:Ee.mode.ECB,padding:Ee.pad.Pkcs7}).toString(Ee.enc.Utf8);return n?(n=n.replace("_96.mp4","_320.mp4"),n):""}catch(t){return console.error("Decrypt error:",t),""}}function oe(e){if(!e)return"";const t=document.createElement("textarea");return t.innerHTML=e,t.value}function It(e){var t,a,r,n;if(!e)return null;try{let s="";if(e.encrypted_media_url?(s=Wr(e.encrypted_media_url),e["320kbps"]!=="true"&&(s=s.replace("_320.mp4","_160.mp4"))):(t=e.more_info)!=null&&t.encrypted_media_url?(s=Wr(e.more_info.encrypted_media_url),e.more_info["320kbps"]!=="true"&&(s=s.replace("_320.mp4","_160.mp4"))):e.media_preview_url&&(s=e.media_preview_url.replace("preview.saavncdn.com","aac.saavncdn.com"),s=e["320kbps"]==="true"?s.replace("_96_p.mp4","_320.mp4"):s.replace("_96_p.mp4","_160.mp4")),!s)return null;let b=(e.image||"").replace(/150x150/g,"500x500").replace(/50x50/g,"500x500"),d=(e.image||"").replace(/500x500/g,"150x150").replace(/50x50/g,"150x150");return{id:e.id||"",title:oe(e.song||e.title||""),artist:oe(e.primary_artists||((a=e.more_info)==null?void 0:a.primary_artists)||e.singers||e.music||e.subtitle||""),album:oe(e.album||((r=e.more_info)==null?void 0:r.album)||""),duration:parseInt(e.duration||((n=e.more_info)==null?void 0:n.duration)||"0"),cover:b,coverSmall:d,url:s}}catch(s){return console.error("Format error:",s),null}}function wt(e){const t=new Set,a=new Set;return e.filter(r=>{if(!r)return!1;const n=(r.cover||"").replace(/\d+x\d+/g,"SIZE").toLowerCase(),s=(r.title||"").toLowerCase().trim();return n&&t.has(n)&&a.has(s)?!1:(n&&t.add(n),s&&a.add(s),!0)})}const Bn=(e,t,a)=>`https://www.jiosaavn.com/api.php?__call=search.getResults&_format=json&_marker=0&cc=in&p=${t}&n=${a}&q=${encodeURIComponent(e)}`,An="https://www.jiosaavn.com/api.php?__call=search.getAll&_format=json&_marker=0&cc=in&query=",_n="https://www.jiosaavn.com/api.php?__call=autocomplete.get&_format=json&_marker=0&cc=in&includeMetaTags=1&query=",c0="https://www.jiosaavn.com/api.php?__call=song.getDetails&cc=in&_marker=0&_format=json&pids=",Dn="https://www.jiosaavn.com/api.php?__call=playlist.getDetails&_format=json&_marker=0&cc=in&listid=";async function ce(e,t=1,a=10){var r;try{if(console.log(`[${ne?"NATIVE":"WEB"}] Searching for: ${e} (Page ${t})`),ne){try{const w=(await ae(Bn(e,t,a))).replace(/\(From "([^"]+)"\)/g,"(From '$1')"),o=JSON.parse(w),p=(o==null?void 0:o.results)||[];if(console.log(`search.getResults: ${p.length} results`),p.length>0){const f=p.map(y=>y.id).filter(Boolean).join(",");if(f){const y=await ae(c0+f),g=JSON.parse(y),u=Object.values(g).map(l=>It(l)).filter(l=>l&&l.url);if(u.length>0)return console.log(`Formatted ${u.length} full songs from IDs`),wt(u)}}}catch(x){console.warn("search.getResults failed, trying autocomplete:",x.message)}const s=(await ae(_n+encodeURIComponent(e))).replace(/\(From "([^"]+)"\)/g,"(From '$1')"),b=JSON.parse(s),d=((r=b==null?void 0:b.songs)==null?void 0:r.data)||[];console.log(`Autocomplete fallback: ${d.length} IDs`);const h=d.map(x=>x0(x.id)),i=await Promise.all(h);return wt(i.filter(x=>x&&x.url))}else{const n=await fetch(`/api/search?q=${encodeURIComponent(e)}&page=${t}&limit=${a}`);if(!n.ok)return[];const s=await n.json();return Array.isArray(s)?wt(s):[]}}catch(n){return console.error("Search failed:",n),[]}}async function l0(e){var t,a,r;try{if(!ne)return{songs:await ce(e),playlists:[],albums:[]};const s=(await ae(An+encodeURIComponent(e))).replace(/\(From "([^"]+)"\)/g,"(From '$1')"),b=JSON.parse(s);let d=[];const h=((t=b==null?void 0:b.songs)==null?void 0:t.data)||[];h.length>0&&(d=h.map(p=>{var f;return{id:p.id||"",title:oe(p.title||""),artist:oe(p.description||((f=p.more_info)==null?void 0:f.primary_artists)||""),cover:(p.image||"").replace(/150x150/g,"500x500").replace(/50x50/g,"500x500"),coverSmall:(p.image||"").replace(/500x500/g,"150x150"),_needsDetail:!0}}).filter(p=>p.id));let i=[];const x=((a=b==null?void 0:b.playlists)==null?void 0:a.data)||[];x.length>0&&(i=x.map(p=>{var f;return{id:p.id||"",title:oe(p.title||""),description:oe(p.description||p.subtitle||""),cover:(p.image||"").replace(/150x150/g,"500x500").replace(/50x50/g,"500x500"),coverSmall:(p.image||"").replace(/500x500/g,"150x150"),songCount:((f=p.more_info)==null?void 0:f.song_count)||p.count||0,type:"playlist"}}).filter(p=>p.id));let w=[];const o=((r=b==null?void 0:b.albums)==null?void 0:r.data)||[];return o.length>0&&(w=o.map(p=>{var f;return{id:p.id||"",title:oe(p.title||""),artist:oe(p.description||p.music||((f=p.more_info)==null?void 0:f.music)||""),cover:(p.image||"").replace(/150x150/g,"500x500").replace(/50x50/g,"500x500"),coverSmall:(p.image||"").replace(/500x500/g,"150x150"),type:"album"}}).filter(p=>p.id)),{songs:d,playlists:i,albums:w}}catch(n){return console.error("searchAll failed:",n),{songs:[],playlists:[],albums:[]}}}async function d0(e){try{if(!ne)return[];const a=(await ae(Dn+e)).replace(/\(From "([^"]+)"\)/g,"(From '$1')"),r=JSON.parse(a),s=((r==null?void 0:r.songs)||(r==null?void 0:r.list)||[]).map(b=>It(b)).filter(b=>b&&b.url);return wt(s)}catch(t){return console.error("Playlist fetch failed:",t),[]}}async function x0(e){try{if(ne){const t=await ae(c0+e),r=JSON.parse(t)[e];return It(r)}else{const t=await fetch(`/api/song?id=${e}`);return t.ok?await t.json():null}}catch(t){return console.error("Get song failed:",t,e),null}}const kn="https://api.lyrics.ovh/v1/";async function p0(e,t){if(!e||!t)return null;try{const a=e.split(",")[0].trim(),r=t.replace(/\s*\(.*?\)\s*/g,"").replace(/\s*\[.*?\]\s*/g,"").replace(/\s*-\s*.*$/,"").trim(),n=kn+encodeURIComponent(a)+"/"+encodeURIComponent(r);let s="";if(ne){const b=await ae(n),d=JSON.parse(b);s=(d==null?void 0:d.lyrics)||""}else{const b=await fetch(n);if(!b.ok)return null;const d=await b.json();s=(d==null?void 0:d.lyrics)||""}return s.trim()||null}catch(a){return console.warn("Lyrics not found:",a.message),null}}const Fn="https://www.theaudiodb.com/api/v1/json/2/search.php?s=";async function u0(e){if(!e)return null;const t=e.split(",")[0].trim(),a=Fn+encodeURIComponent(t);try{let r;if(ne){const n=await ae(a);r=JSON.parse(n)}else{const n=await fetch(a);if(!n.ok)return null;r=await n.json()}if(r&&r.artists&&r.artists.length>0){const n=r.artists[0];return{name:n.strArtist||t,biography:n.strBiographyEN||"",thumbnail:n.strArtistThumb||"",logo:n.strArtistLogo||"",banner:n.strArtistBanner||n.strArtistThumb||"",genre:n.strGenre||"",country:n.strCountry||"",yearFormed:n.intFormedYear||""}}}catch(r){console.warn("Artist info fetch failed:",r.message)}return null}const Sn="https://itunes.apple.com/search?media=podcast&limit=15&term=";async function f0(e){if(!e)return[];try{const t=Sn+encodeURIComponent(e);let a;if(ne){const r=await ae(t);a=JSON.parse(r)}else{const r=await fetch(t);if(!r.ok)return[];a=await r.json()}if(a&&a.results)return a.results.map(r=>({id:r.collectionId,title:r.collectionName,artist:r.artistName,cover:r.artworkUrl600||r.artworkUrl100,feedUrl:r.feedUrl,genre:r.primaryGenreName,type:"podcast"})).filter(r=>r.feedUrl)}catch(t){console.error("Podcast search failed:",t)}return[]}async function h0(e,t,a){if(!e)return[];try{let r="";if(ne)r=await ae(e);else{const d=await fetch(e);if(!d.ok)return[];r=await d.text()}const s=new DOMParser().parseFromString(r,"text/xml");return Array.from(s.querySelectorAll("item")).slice(0,50).map((d,h)=>{var y,g,u;const i=((y=d.querySelector("title"))==null?void 0:y.textContent)||`Episode ${h+1}`,x=d.querySelector("enclosure"),w=x?x.getAttribute("url"):"",o=((g=d.querySelector("pubDate"))==null?void 0:g.textContent)||"",f=(((u=d.querySelector("description"))==null?void 0:u.textContent)||"").replace(/<[^>]+>/g," ").substring(0,150)+"...";return w?{id:`podcast_${btoa(w).substring(0,10)}_${h}`,title:oe(i),artist:a||"Podcast",cover:t,url:w,duration:0,type:"podcast_episode",date:o,description:f}:null}).filter(Boolean)}catch(r){console.error("Podcast feed fetch failed:",r)}return[]}const Ln="https://musicbrainz.org/ws/2/artist/?fmt=json&query=";async function qn(e){if(!e)return[];const t=e.split(",")[0].trim(),a=Ln+encodeURIComponent(t);try{const r={"User-Agent":"MeloMusicPlayer/1.0 (mahesh@example.com)"};let n=null;if(ne){const d=await ae(a),h=JSON.parse(d);h.artists&&h.artists.length>0&&(n=h.artists[0].id)}else{const d=await fetch(a,{headers:r});if(!d.ok)return[];const h=await d.json();h.artists&&h.artists.length>0&&(n=h.artists[0].id)}if(!n)return[];const s=`https://musicbrainz.org/ws/2/release-group?artist=${n}&fmt=json&limit=50`;let b;if(ne){const d=await ae(s);b=JSON.parse(d)}else{const d=await fetch(s,{headers:r});if(!d.ok)return[];b=await d.json()}if(b&&b["release-groups"]){const d=b["release-groups"],h=new Map;return d.forEach(i=>{if(!i.title||!i["first-release-date"])return;const x=i["first-release-date"].substring(0,4),w=i.title.toLowerCase().replace(/\\(.*\\)|\[.*\]/g,"").trim();h.has(w)||h.set(w,{id:i.id,title:i.title,type:i["primary-type"]||"Single",year:x,cover:`https://coverartarchive.org/release-group/${i.id}/front-250`})}),Array.from(h.values()).sort((i,x)=>parseInt(x.year)-parseInt(i.year))}}catch(r){console.error("MusicBrainz discography failed:",r)}return[]}const v0=Object.freeze(Object.defineProperty({__proto__:null,getArtistDiscography:qn,getArtistInfo:u0,getLyrics:p0,getPlaylistSongs:d0,getPodcastEpisodes:h0,getSongById:x0,searchAll:l0,searchPodcasts:f0,searchSongs:ce},Symbol.toStringTag,{value:"Module"})),Pn={pop:"latest pop hits",hiphop:"hip hop trending",rock:"rock hits",lofi:"lofi chill beats",electronic:"electronic dance",rnb:"r&b soul",jazz:"jazz classics",classical:"classical music",indie:"indie music",kpop:"kpop trending",bollywood:"bollywood latest songs",ambient:"ambient relax"};function Hn(){const e=document.createElement("div");e.className="page";const t=M.get(),a=new Date().getHours();let r="Good evening";a<12?r="Good morning":a<17&&(r="Good afternoon"),e.innerHTML=`
    <div class="home-header">
      <h1 class="text-greeting">${r} <span style="font-size: 14px; color: var(--accent); vertical-align: middle; margin-left: 10px;">v1.0.10</span></h1>
    </div>
    <div class="section" style="margin-top: var(--space-xl);">
      <div class="horizontal-scroll" id="home-chips"></div>
    </div>
    <div id="home-sections">
      <div class="home-loading">
        <div class="loading-spinner"></div>
        <p class="text-subtitle">Loading your music...</p>
      </div>
    </div>
  `;const n=e.querySelector("#home-chips"),s=document.createElement("button");s.className="chip active",s.textContent="For You",n.appendChild(s),(t.interests.length>0?t.interests:["bollywood","pop","lofi","hiphop"]).forEach(o=>{const p=Ht.find(f=>f.id===o);if(p){const f=document.createElement("button");f.className="chip",f.textContent=p.name,f.dataset.genre=o,n.appendChild(f)}});let d=null;n.addEventListener("click",o=>{const p=o.target.closest(".chip");p&&(n.querySelectorAll(".chip").forEach(f=>f.classList.remove("active")),p.classList.add("active"),d=p.dataset.genre||null,i())});const h=e.querySelector("#home-sections");async function i(){var o;h.innerHTML=`
      <div class="home-loading">
        <div class="loading-spinner"></div>
        <p class="text-subtitle">Loading...</p>
      </div>
    `;try{if(d){const p=Pn[d]||d,f=await ce(p);if(h.innerHTML="",f.length>0){const y=((o=Ht.find(g=>g.id===d))==null?void 0:o.name)||d;h.appendChild(x(`${y} Hits`,f,p))}else h.innerHTML='<div class="empty-state"><span class="material-symbols-rounded">music_off</span><p>No tracks found</p></div>'}else{if(h.innerHTML="",t.recentlyPlayed.length>0){const C=t.recentlyPlayed.map(B=>z.getCachedTrack(B)).filter(Boolean).slice(0,10);C.length>0&&h.appendChild(x("Recently played",C))}const p=await he.getAllDownloads();p.length>0&&h.appendChild(x("Downloaded · Offline",p.slice(0,20)));const f=[],y={pop:[{title:"Pop Hits 🎵",query:"latest pop songs new 2025"},{title:"International Pop",query:"top english pop songs trending"}],hiphop:[{title:"Hip Hop Fire 🔥",query:"hindi rap songs trending 2025"},{title:"Underground Beats",query:"indian hip hop rapper tracks"}],rock:[{title:"Rock Anthems 🎸",query:"rock songs hindi best"},{title:"Alt Rock Picks",query:"alternative rock band songs"}],lofi:[{title:"Lo-Fi Chill 🌙",query:"lofi hindi chill beats study"},{title:"Late Night Vibes",query:"slowed reverb songs hindi aesthetic"}],electronic:[{title:"EDM Drops ⚡",query:"edm electronic dance songs"},{title:"Bass & Beats",query:"electronic bass music remix"}],rnb:[{title:"R&B Smooth 🎤",query:"rnb soul music smooth"},{title:"Soulful Vibes",query:"soul music relaxing"}],jazz:[{title:"Jazz Sessions 🎷",query:"jazz songs instrumental smooth"},{title:"Jazz Classics",query:"jazz classic legends vocals"}],classical:[{title:"Classical Ragas 🎻",query:"indian classical music raga"},{title:"Timeless Melodies",query:"classical instrumental piano soothing"}],indie:[{title:"Indie Picks 🌿",query:"indie music hindi artist"},{title:"Fresh Indie",query:"independent artist songs new"}],kpop:[{title:"K-Pop Faves 💜",query:"kpop trending songs BTS"},{title:"K-Pop New Releases",query:"kpop latest songs 2025"}],bollywood:[{title:"Bollywood Hits 🎬",query:"bollywood songs latest trending 2025"},{title:"Filmi Favorites",query:"best bollywood movie songs romantic"}],ambient:[{title:"Ambient Escape 🧘",query:"ambient meditation music calm"},{title:"Nature & Peace",query:"relaxing music nature sounds sleep"}]};(t.interests.length>0?t.interests:["bollywood","pop","lofi"]).forEach(C=>{(y[C]||[]).forEach(D=>f.push(D))});const u=new Set;if(t.recentlyPlayed.length>0)for(const C of t.recentlyPlayed.slice(0,10)){const B=z.getCachedTrack(C);if(B!=null&&B.artist){const D=B.artist.split(",")[0].trim();!u.has(D.toLowerCase())&&u.size<2&&(u.add(D.toLowerCase()),f.splice(2+u.size,0,{title:`Because you listened to ${D}`,query:`${D} best songs more`}))}}const l=f.slice(0,8),c=await Promise.allSettled(l.map(C=>ce(C.query).then(B=>({...C,songs:B})))),m=h.querySelector(".home-loading");m&&m.remove();let v=0;async function E(){if(v>=c.length||h.parentElement!==e)return;const C=c[v];C.status==="fulfilled"&&C.value.songs.length>0&&h.appendChild(x(C.value.title,C.value.songs,C.value.query)),v++,setTimeout(E,30)}E().then(()=>{h.parentElement===e&&h.appendChild(w())}),c.length===0&&(h.innerHTML=`
            <div class="empty-state">
              <span class="material-symbols-rounded">wifi_off</span>
              <p>Couldn't load music</p>
              <p class="text-subtitle" style="margin-top: var(--space-sm);">Check your internet and try again</p>
            </div>
          `)}}catch(p){console.error("Failed to load home content:",p),h.innerHTML=`
        <div class="empty-state">
          <span class="material-symbols-rounded">error</span>
          <p>Something went wrong</p>
        </div>
      `}}function x(o,p,f=null){const y=document.createElement("div");y.className="section";let g=1;y.innerHTML=`
      <div class="section-header">
        <h2 class="text-section-title">${o}</h2>
        <span class="text-subtitle">${p.length} songs</span>
      </div>
    `;const u=document.createElement("div");if(u.className="horizontal-scroll",p.slice(0,10).forEach(l=>{u.appendChild(ue(l,p))}),p.length>=10&&f){const l=document.createElement("div");l.className="view-more-card";let c=!1;l.innerHTML=`
        <div class="view-more-inner">
          <span class="material-symbols-rounded">arrow_forward</span>
          <span>Load More</span>
        </div>
      `,l.addEventListener("click",async()=>{if(!c){c=!0,l.innerHTML='<div class="loading-spinner" style="width:24px;height:24px;border-width:2px;"></div>',g++;try{const m=await ce(f,g,10);m&&m.length>0?(m.forEach(v=>{p.push(v),u.insertBefore(ue(v,p),l)}),y.querySelector(".text-subtitle").textContent=`${p.length} songs`,l.innerHTML=`
              <div class="view-more-inner">
                <span class="material-symbols-rounded">arrow_forward</span>
                <span>Load More</span>
              </div>
            `):l.remove()}catch{l.innerHTML='<div class="view-more-inner"><span>Error</span></div>'}c=!1}}),u.appendChild(l)}return y.appendChild(u),y}function w(){const o=document.createElement("div");o.className="section",o.innerHTML=`
      <div class="section-header">
        <h2 class="text-section-title">Popular Artists</h2>
      </div>
    `;const p=document.createElement("div");return p.className="horizontal-scroll artist-scroll",sa.forEach(f=>{const y=document.createElement("div");y.className="artist-card";const g=f.name.split(" ").map(u=>u[0]).join("").slice(0,2);y.innerHTML=`
        <div class="artist-avatar" style="background: ${f.gradient};">
          ${f.image?`<img class="artist-img" src="${f.image}" alt="${f.name}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';" /><span class="artist-initials" style="display:none;">${g}</span>`:`<span class="artist-initials">${g}</span>`}
        </div>
        <div class="artist-name">${f.name}</div>
      `,y.addEventListener("click",async()=>{var c;h.innerHTML=`
          <div class="home-loading">
            <div class="loading-spinner"></div>
            <p class="text-subtitle">Loading ${f.name} songs...</p>
          </div>
        `;const u=await ce(f.query);h.innerHTML="";const l=document.createElement("div");l.style.cssText="display:flex;align-items:center;gap:var(--space-md);margin-bottom:var(--space-xl);",l.innerHTML=`
          <button class="btn-icon" id="artist-back"><span class="material-symbols-rounded">arrow_back</span></button>
          <div class="artist-avatar" style="background:${f.gradient};width:48px;height:48px;"><span class="material-symbols-rounded" style="font-size:24px;">person</span></div>
          <div>
            <h2 class="text-section-title">${f.name}</h2>
            <span class="text-subtitle">${u.length} songs</span>
          </div>
          ${u.length>0?'<button class="btn-play" id="artist-play-all" style="margin-left:auto;width:44px;height:44px;"><span class="material-symbols-rounded" style="font-size:22px;">play_arrow</span></button>':""}
        `,l.querySelector("#artist-back").addEventListener("click",()=>{d=null,i()}),h.appendChild(l),u.length>0?((c=l.querySelector("#artist-play-all"))==null||c.addEventListener("click",()=>{z.playAll(u,u[0])}),h.appendChild(x(`${f.name} Songs`,u,f.query))):h.innerHTML+='<div class="empty-state"><span class="material-symbols-rounded">music_off</span><p>No songs found</p></div>'}),p.appendChild(y)}),o.appendChild(p),o}return i(),e}const m0=document.createElement("style");m0.textContent=`
  .home-header {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    margin-bottom: var(--space-sm);
  }
  .home-logo {
    width: 32px;
    height: 32px;
    filter: drop-shadow(0 0 8px var(--accent-glow));
    cursor: pointer;
    transition: transform var(--transition-fast);
  }
  .home-logo:active {
    transform: scale(0.9);
  }

  .home-loading {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: var(--space-3xl);
    gap: var(--space-lg);
  }

  .loading-spinner {
    width: 36px;
    height: 36px;
    border: 3px solid var(--bg-active);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }

  /* View More card at end of row */
  .view-more-card {
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 100px;
    height: 130px;
    cursor: pointer;
    -webkit-tap-highlight-color: transparent;
    flex-shrink: 0;
  }

  .view-more-inner {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: var(--space-sm);
    color: var(--text-secondary);
    font-size: var(--font-sm);
    font-weight: 500;
    text-align: center;
    transition: color var(--transition-fast), transform var(--transition-fast);
  }

  .view-more-inner .material-symbols-rounded {
    font-size: 32px;
    width: 56px;
    height: 56px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--radius-full);
    background: var(--surface-glass);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid var(--surface-border);
    transition: background var(--transition-fast), transform var(--transition-fast);
  }

  .view-more-card:hover .view-more-inner {
    color: var(--accent);
  }

  .view-more-card:hover .material-symbols-rounded {
    background: var(--accent-dim);
    transform: scale(1.05);
  }

  .view-more-card:active .view-more-inner {
    transform: scale(0.95);
  }

  .view-more-inner small {
    font-size: var(--font-xs);
    color: var(--text-tertiary);
  }

  /* Artist cards */
  .artist-scroll {
    gap: var(--space-xl);
  }

  .artist-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: var(--space-sm);
    cursor: pointer;
    transition: transform var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
    width: 90px;
  }

  .artist-card:active {
    transform: scale(0.95);
  }

  .artist-avatar {
    width: 72px;
    height: 72px;
    border-radius: var(--radius-full);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: var(--shadow-md);
    transition: transform var(--transition-normal), box-shadow var(--transition-normal);
    overflow: hidden;
  }

  .artist-card:hover .artist-avatar {
    transform: scale(1.05);
    box-shadow: var(--shadow-lg);
  }

  .artist-avatar .material-symbols-rounded {
    font-size: 32px;
    opacity: 0.9;
  }

  .artist-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: var(--radius-full);
  }

  .artist-initials {
    font-size: 24px;
    font-weight: 700;
    color: rgba(255,255,255,0.85);
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
  }

  .artist-name {
    font-size: var(--font-xs);
    font-weight: 500;
    color: var(--text-primary);
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
  }

  /* Tablet: bigger artist cards */
  @media (min-width: 768px) {
    .artist-card {
      width: 110px;
    }
    .artist-avatar {
      width: 88px;
      height: 88px;
    }
    .artist-name {
      font-size: var(--font-sm);
    }
    .artist-initials {
      font-size: 30px;
    }
  }

  @media (min-width: 1024px) {
    .artist-card {
      width: 130px;
    }
    .artist-avatar {
      width: 100px;
      height: 100px;
    }
    .artist-avatar .material-symbols-rounded {
      font-size: 40px;
    }
    .artist-initials {
      font-size: 36px;
    }
  }
`;document.head.appendChild(m0);function $n(){const e=document.createElement("div");e.className="page",e.innerHTML=`
    <h1 class="text-greeting">Search</h1>
    <div class="search-input-wrapper" style="margin-top: var(--space-xl);">
      <span class="material-symbols-rounded">search</span>
      <input type="text" class="search-input" placeholder="Search songs, artists, playlists..." id="search-input" autocomplete="off" />
    </div>
    <div id="search-loading" class="home-loading" style="display:none;">
      <div class="loading-spinner"></div>
      <p class="text-subtitle">Searching...</p>
    </div>
    <div id="search-results" style="display: none;"></div>
    <div id="browse-section"></div>
  `;const t=e.querySelector("#search-input"),a=e.querySelector("#search-results"),r=e.querySelector("#search-loading"),n=e.querySelector("#browse-section");function s(){const u=M.get();if(n.innerHTML="",u.recentlyPlayed.length>0){const c=document.createElement("div");c.className="section",c.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Recently Played</h2>
          <span class="text-subtitle">${u.recentlyPlayed.length} songs</span>
        </div>
      `;const m=document.createElement("div");m.className="search-history-list",u.recentlyPlayed.slice(0,10).forEach(v=>{const E=u.trackMetadata[v];E&&m.appendChild(ue(E,u.recentlyPlayed.map(C=>u.trackMetadata[C]).filter(Boolean),"horizontal"))}),c.appendChild(m),n.appendChild(c)}if(u.likedSongs.length>0){const c=document.createElement("div");c.className="section",c.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Your Liked Songs</h2>
          <span class="text-subtitle">${u.likedSongs.length} songs</span>
        </div>
      `;const m=document.createElement("div");m.className="search-history-list",u.likedSongs.slice(0,10).forEach(v=>{const E=u.trackMetadata[v];E&&m.appendChild(ue(E,u.likedSongs.map(C=>u.trackMetadata[C]).filter(Boolean),"horizontal"))}),c.appendChild(m),n.appendChild(c)}const l=b(u);if(l.length>0){const c=document.createElement("div");c.className="section",c.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Try Searching</h2>
        </div>
      `;const m=document.createElement("div");m.className="suggestion-chips",l.forEach(v=>{const E=document.createElement("button");E.className="chip suggestion-chip",E.innerHTML=`<span class="material-symbols-rounded" style="font-size:16px;">${v.icon}</span> ${v.label}`,E.addEventListener("click",()=>{t.value=v.query,y(v.query)}),m.appendChild(E)}),c.appendChild(m),n.appendChild(c)}if(u.recentlyPlayed.length===0&&u.likedSongs.length===0){const c=document.createElement("div");c.className="section",c.innerHTML=`
        <div class="empty-state" style="padding: var(--space-2xl) 0;">
          <span class="material-symbols-rounded" style="font-size:48px;color:var(--text-tertiary);">search</span>
          <p style="margin-top:var(--space-md);color:var(--text-secondary);">Search for any song, artist, or playlist</p>
          <p class="text-subtitle" style="margin-top:var(--space-sm);">Your listening history will appear here</p>
        </div>
      `,n.appendChild(c);const m=document.createElement("div");m.className="section",m.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Popular Searches</h2>
        </div>
      `;const v=document.createElement("div");v.className="suggestion-chips",[{label:"Arijit Singh",icon:"person",query:"Arijit Singh"},{label:"Bollywood Hits",icon:"music_note",query:"bollywood hits 2025"},{label:"Party Songs",icon:"celebration",query:"party songs hindi"},{label:"Romantic",icon:"favorite",query:"romantic hindi songs"},{label:"Punjabi",icon:"queue_music",query:"punjabi hits 2025"},{label:"Sad Songs",icon:"sentiment_sad",query:"sad hindi songs broken heart"},{label:"Lo-fi Chill",icon:"headphones",query:"lofi chill hindi"},{label:"Top Playlists",icon:"playlist_play",query:"top hindi playlist trending"}].forEach(C=>{const B=document.createElement("button");B.className="chip suggestion-chip",B.innerHTML=`<span class="material-symbols-rounded" style="font-size:16px;">${C.icon}</span> ${C.label}`,B.addEventListener("click",()=>{t.value=C.query,y(C.query)}),v.appendChild(B)}),m.appendChild(v),n.appendChild(m)}}function b(u){const l=[],c=new Set;return u.recentlyPlayed.slice(0,15).forEach(v=>{const E=u.trackMetadata[v];if(E&&E.artist){const C=E.artist.split(",")[0].trim();c.has(C.toLowerCase())||(c.add(C.toLowerCase()),l.push({label:C,icon:"person",query:C}))}}),[{label:"New Releases",icon:"new_releases",query:"new hindi songs 2025"},{label:"Trending Now",icon:"trending_up",query:"trending songs india"},{label:"Workout Mix",icon:"fitness_center",query:"workout hindi songs"},{label:"Chill Vibes",icon:"spa",query:"chill hindi lofi"}].forEach(v=>{c.has(v.label.toLowerCase())||(c.add(v.label.toLowerCase()),l.push(v))}),l.slice(0,12)}let d=null,h=0,i="",x=1,w=!1,o=!0,p=[];function f(u,l){new IntersectionObserver(async m=>{if(m[0].isIntersecting&&!w&&o){w=!0,x++,u.innerHTML='<div class="loading-spinner" style="width: 24px; height: 24px; border-width: 2px;"></div>',u.style.display="flex",u.style.justifyContent="center";try{const v=await ce(i,x,10);!v||v.length===0?(o=!1,u.innerHTML=""):(v.forEach(E=>p.push(E)),v.forEach(E=>{l.appendChild(ue(E,p,"horizontal"))}),u.innerHTML="")}catch{u.innerHTML=""}w=!1}},{rootMargin:"150px"}).observe(u)}async function y(u){const l=++h;if(!u.trim()){a.style.display="none",r.style.display="none",n.style.display="block";return}n.style.display="none",a.style.display="none",r.style.display="flex",i=u,x=1,w=!1,o=!0,p=[];try{const[c,m]=await Promise.allSettled([l0(u),f0(u)]),v=c.status==="fulfilled"?c.value:{},E=m.status==="fulfilled"?m.value:[];if(l!==h)return;const C=v.songs||[],B=v.playlists||[];if(C.length>0&&C[0]._needsDetail)try{p=await ce(u,1,10)}catch{p=C}else if(C.length===0)try{p=await ce(u,1,10)}catch{p=[]}else p=C;if(l!==h)return;if(r.style.display="none",a.style.display="block",a.innerHTML="",p.length===0&&B.length===0&&E.length===0){a.innerHTML=`
          <div class="empty-state">
            <span class="material-symbols-rounded">search_off</span>
            <p>No results found for "${u}"</p>
            <p class="text-subtitle" style="margin-top: var(--space-sm);">Try a different search</p>
          </div>
        `;return}if(E.length>0){const D=document.createElement("div");D.className="section",D.innerHTML=`
          <div class="section-header">
            <h2 class="text-section-title">Podcasts</h2>
            <span class="text-subtitle">from Apple Podcasts</span>
          </div>
        `;const A=document.createElement("div");A.className="horizontal-scroll",E.slice(0,10).forEach(_=>{const k=document.createElement("div");k.className="playlist-card",k.style.width="160px",k.innerHTML=`
            <div class="playlist-card-art-wrapper" style="border-radius: var(--radius-lg);">
              <img class="playlist-card-art" src="${_.cover}" alt="${_.title}" loading="lazy" />
              <div class="playlist-card-overlay">
                <span class="material-symbols-rounded">podcasts</span>
              </div>
            </div>
            <div class="playlist-card-title">${_.title}</div>
            <div class="playlist-card-info">${_.artist}</div>
          `,k.addEventListener("click",()=>{window.location.hash=`podcast?feed=${encodeURIComponent(_.feedUrl)}&title=${encodeURIComponent(_.title)}&artist=${encodeURIComponent(_.artist)}&cover=${encodeURIComponent(_.cover)}`}),A.appendChild(k)}),D.appendChild(A),a.appendChild(D)}if(B.length>0){const D=document.createElement("div");D.className="section",D.innerHTML=`
          <div class="section-header">
            <h2 class="text-section-title">Playlists</h2>
            <span class="text-subtitle">${B.length} found</span>
          </div>
        `;const A=document.createElement("div");A.className="horizontal-scroll",B.slice(0,10).forEach(_=>{const k=document.createElement("div");k.className="playlist-card",k.innerHTML=`
            <div class="playlist-card-art-wrapper">
              <img class="playlist-card-art" src="${_.coverSmall||_.cover||""}" alt="${_.title}" loading="lazy" />
              <div class="playlist-card-overlay">
                <span class="material-symbols-rounded">playlist_play</span>
              </div>
            </div>
            <div class="playlist-card-title">${_.title}</div>
            <div class="playlist-card-info">${_.songCount?_.songCount+" songs":_.description||""}</div>
          `,k.addEventListener("click",()=>g(_)),A.appendChild(k)}),D.appendChild(A),a.appendChild(D)}if(p.length>0){const D=document.createElement("div");D.innerHTML=`
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:var(--space-lg);margin-top:var(--space-lg);">
            <span class="text-section-title">Songs</span>
            <button class="chip" id="play-all-results">
              <span class="material-symbols-rounded" style="font-size:16px;">play_arrow</span>
              Play All
            </button>
          </div>
        `,D.querySelector("#play-all-results").addEventListener("click",()=>{z.playAll(p,p[0])});const A=document.createElement("div");A.id="search-song-container",p.forEach(k=>{A.appendChild(ue(k,p,"horizontal"))}),D.appendChild(A);const _=document.createElement("div");_.id="infinite-scroll-trigger",_.style.height="40px",_.style.marginTop="var(--space-md)",D.appendChild(_),a.appendChild(D),f(_,A)}}catch{r.style.display="none",a.style.display="block",a.innerHTML=`
        <div class="empty-state">
          <span class="material-symbols-rounded">error</span>
          <p>Search failed. Check your internet connection.</p>
        </div>
      `}}async function g(u){var m;a.innerHTML=`
      <div class="home-loading">
        <div class="loading-spinner"></div>
        <p class="text-subtitle">Loading playlist...</p>
      </div>
    `;const l=await d0(u.id);a.innerHTML="";const c=document.createElement("div");c.className="playlist-header",c.innerHTML=`
      <button class="btn-icon" id="playlist-back"><span class="material-symbols-rounded">arrow_back</span></button>
      <img class="playlist-header-art" src="${u.cover||u.coverSmall||""}" alt="${u.title}" />
      <div class="playlist-header-info">
        <h2 class="text-section-title">${u.title}</h2>
        <span class="text-subtitle">${l.length} songs</span>
      </div>
      ${l.length>0?'<button class="btn-play" id="playlist-play-all" style="margin-left:auto;"><span class="material-symbols-rounded">play_arrow</span></button>':""}
    `,c.querySelector("#playlist-back").addEventListener("click",()=>{y(t.value)}),a.appendChild(c),l.length>0?((m=c.querySelector("#playlist-play-all"))==null||m.addEventListener("click",()=>{z.playAll(l,l[0])}),l.forEach(v=>{a.appendChild(ue(v,l,"horizontal"))})):a.innerHTML+=`
        <div class="empty-state">
          <span class="material-symbols-rounded">music_off</span>
          <p>No songs found in this playlist</p>
        </div>
      `}return t.addEventListener("input",()=>{clearTimeout(d);const u=t.value;if(!u.trim()){a.style.display="none",r.style.display="none",n.style.display="block";return}d=setTimeout(()=>y(u),400)}),s(),setTimeout(()=>t.focus(),100),e}const g0=document.createElement("style");g0.textContent=`
  .search-history-list {
    display: flex;
    flex-direction: column;
    gap: var(--space-xs);
  }

  .suggestion-chips {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-sm);
  }

  .suggestion-chip {
    animation: fadeInUp 0.3s ease both;
  }

  @keyframes fadeInUp {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }

  /* Playlist cards */
  .playlist-card {
    width: 140px;
    cursor: pointer;
    transition: transform var(--transition-fast);
    -webkit-tap-highlight-color: transparent;
    flex-shrink: 0;
  }

  .playlist-card:active {
    transform: scale(0.97);
  }

  .playlist-card-art-wrapper {
    position: relative;
    border-radius: var(--radius-md);
    overflow: hidden;
    aspect-ratio: 1;
    background: var(--bg-tertiary);
  }

  .playlist-card-art {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .playlist-card-overlay {
    position: absolute;
    inset: 0;
    background: rgba(0,0,0,0.35);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity var(--transition-normal);
  }

  .playlist-card:hover .playlist-card-overlay {
    opacity: 1;
  }

  .playlist-card-overlay .material-symbols-rounded {
    font-size: 36px;
    color: white;
  }

  .playlist-card-title {
    margin-top: var(--space-sm);
    font-size: var(--font-sm);
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: var(--text-primary);
  }

  .playlist-card-info {
    font-size: var(--font-xs);
    color: var(--text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  /* Playlist detail header */
  .playlist-header {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    margin-bottom: var(--space-xl);
    padding: var(--space-md) 0;
  }

  .playlist-header-art {
    width: 56px;
    height: 56px;
    border-radius: var(--radius-md);
    object-fit: cover;
  }
`;document.head.appendChild(g0);function Tn(){const e=document.createElement("div");e.className="page",e.innerHTML=`
    <div class="lib-header">
      <h1 class="lib-title">Your Library</h1>
    </div>
    <div id="library-content"></div>
  `;const t=e.querySelector("#library-content");async function a(){var g,u,l;const s=M.get();t.innerHTML="";const b=document.createElement("div");b.className="lib-section",b.innerHTML='<div class="lib-section-title">Quick Access</div>';const d=document.createElement("div");d.className="lib-quick-grid";const h=await he.getAllDownloads();d.innerHTML+=`
      <div class="lib-quick-chip" id="lib-chip-downloads">
        <div class="lib-chip-icon downloads-gradient">
          <span class="material-symbols-rounded">download_done</span>
        </div>
        <span class="lib-chip-label">Downloads</span>
        <span class="lib-chip-count">${h.length}</span>
      </div>
    `;const i=s.likedSongs.length;d.innerHTML+=`
      <div class="lib-quick-chip" id="lib-chip-liked">
        <div class="lib-chip-icon liked-gradient">
          <span class="material-symbols-rounded">favorite</span>
        </div>
        <span class="lib-chip-label">Liked Songs</span>
        <span class="lib-chip-count">${i}</span>
      </div>
    `,s.recentlyPlayed.length>0&&(d.innerHTML+=`
        <div class="lib-quick-chip" id="lib-chip-recent">
          <div class="lib-chip-icon recent-gradient">
            <span class="material-symbols-rounded">history</span>
          </div>
          <span class="lib-chip-label">Recent</span>
          <span class="lib-chip-count">${s.recentlyPlayed.length}</span>
        </div>
      `),b.appendChild(d),t.appendChild(b),(g=b.querySelector("#lib-chip-downloads"))==null||g.addEventListener("click",()=>r(h,t)),(u=b.querySelector("#lib-chip-liked"))==null||u.addEventListener("click",()=>{i>0&&n("Liked Songs",s.likedSongs,t)}),(l=b.querySelector("#lib-chip-recent"))==null||l.addEventListener("click",()=>{n("Recently Played",s.recentlyPlayed,t)});const x=document.createElement("div");x.className="lib-section",x.innerHTML=`
      <div style="display:flex;align-items:center;justify-content:space-between;">
        <div class="lib-section-title">Playlists</div>
        <button class="lib-create-btn" id="lib-create-pl">
          <span class="material-symbols-rounded">add</span>
          <span>New</span>
        </button>
      </div>
    `;const w=document.createElement("div");w.className="lib-playlist-list",s.playlists.length===0?w.innerHTML=`
        <div class="lib-empty">
          <span class="material-symbols-rounded">queue_music</span>
          <p>No playlists yet</p>
          <p class="lib-empty-sub">Tap + New to create one</p>
        </div>
      `:s.playlists.forEach((c,m)=>{const v=c.trackIds.length>0?z.getCachedTrack(c.trackIds[0]):null,E=(v==null?void 0:v.coverSmall)||(v==null?void 0:v.cover)||"",C=document.createElement("div");C.className="lib-playlist-card",C.innerHTML=`
          <div class="lib-pl-art">
            ${E?`<img src="${E}" alt="" loading="lazy" />`:'<span class="material-symbols-rounded">queue_music</span>'}
          </div>
          <div class="lib-pl-info">
            <div class="lib-pl-name">${c.name}</div>
            <div class="lib-pl-meta">${c.trackIds.length} song${c.trackIds.length!==1?"s":""}</div>
          </div>
          <span class="material-symbols-rounded lib-chevron">chevron_right</span>
        `,C.addEventListener("click",()=>n(c.name,c.trackIds,t)),w.appendChild(C)}),x.appendChild(w),t.appendChild(x),x.querySelector("#lib-create-pl").addEventListener("click",()=>{const c=prompt("Enter playlist name:");c!=null&&c.trim()&&(M.createPlaylist(c.trim()),a())});const o=localStorage.getItem("melo-zoom")||"1.0",p=document.createElement("div");p.className="lib-section",p.innerHTML=`
      <div class="lib-section-title">Display</div>
      <div class="lib-scale-card">
        <div class="lib-scale-header">
          <span class="material-symbols-rounded">zoom_in</span>
          <span class="lib-scale-label">Scaling</span>
          <span class="lib-scale-value">${Math.round(o*100)}%</span>
        </div>
        <input type="range" id="zoom-slider" min="0.8" max="1.5" step="0.05" value="${o}" class="lib-zoom-slider">
        <div class="lib-zoom-labels">
          <span>Small</span>
          <span>Default</span>
          <span>Large</span>
        </div>
      </div>
    `;const f=p.querySelector("#zoom-slider"),y=p.querySelector(".lib-scale-value");f.addEventListener("input",c=>{const m=c.target.value;y.textContent=Math.round(m*100)+"%",localStorage.setItem("melo-zoom",m),document.documentElement.style.setProperty("--zoom",m),document.body.style.zoom=m}),t.appendChild(p)}function r(s,b){var h;b.innerHTML="";const d=document.createElement("div");if(d.className="lib-view-header",d.innerHTML=`
      <button class="btn-icon" id="dl-back"><span class="material-symbols-rounded">arrow_back</span></button>
      <h2 class="lib-view-title">Downloads</h2>
      <span class="lib-view-count">${s.length} song${s.length!==1?"s":""}</span>
      ${s.length>0?`
        <button class="lib-play-btn" id="dl-play-all">
          <span class="material-symbols-rounded">play_arrow</span>
        </button>
      `:""}
    `,d.querySelector("#dl-back").addEventListener("click",()=>a()),b.appendChild(d),s.length>0&&((h=d.querySelector("#dl-play-all"))==null||h.addEventListener("click",()=>z.playAll(s,s[0]))),s.length===0){b.innerHTML+=`
        <div class="lib-empty">
          <span class="material-symbols-rounded">download</span>
          <p>No downloads yet</p>
          <p class="lib-empty-sub">Download songs to play offline</p>
        </div>
      `;return}s.forEach(i=>{const x=document.createElement("div");x.className="track-item",x.innerHTML=`
        <img class="track-item-art" src="${i.coverSmall||i.cover}" alt="" loading="lazy" />
        <div class="track-item-info">
          <div class="track-item-title">${i.title}</div>
          <div class="track-item-artist">${i.artist}</div>
        </div>
        <span class="track-item-duration">${Rn(i.size||0)}</span>
        <button class="btn-icon dl-delete-btn" data-id="${i.id}" title="Delete">
          <span class="material-symbols-rounded" style="font-size:20px;color:var(--text-tertiary);">delete</span>
        </button>
      `,x.addEventListener("click",w=>{if(w.target.closest(".dl-delete-btn")){w.stopPropagation(),he.deleteDownload(w.target.closest(".dl-delete-btn").dataset.id).then(()=>{te.show("Download removed","info"),he.getAllDownloads().then(o=>r(o,b))});return}z.playAll(s,i)}),b.appendChild(x)})}function n(s,b,d){d.innerHTML="";const h=document.createElement("div");h.className="lib-view-header",h.innerHTML=`
      <button class="btn-icon" id="lib-back"><span class="material-symbols-rounded">arrow_back</span></button>
      <h2 class="lib-view-title">${s}</h2>
      <button class="lib-play-btn" id="lib-play-all">
        <span class="material-symbols-rounded">play_arrow</span>
      </button>
    `,h.querySelector("#lib-back").addEventListener("click",()=>a()),d.appendChild(h);const i=b.map(x=>z.getCachedTrack(x)).filter(Boolean);if(h.querySelector("#lib-play-all").addEventListener("click",()=>{i.length>0&&z.playAll(i,i[0])}),i.length===0){d.innerHTML+=`
        <div class="lib-empty">
          <span class="material-symbols-rounded">library_music</span>
          <p>No songs yet</p>
          <p class="lib-empty-sub">Search and play songs to see them here</p>
        </div>
      `;return}i.forEach(x=>{const w=document.createElement("div");w.className="track-item",w.innerHTML=`
        <img class="track-item-art" src="${x.coverSmall||x.cover}" alt="" loading="lazy" />
        <div class="track-item-info">
          <div class="track-item-title">${x.title}</div>
          <div class="track-item-artist">${x.artist}</div>
        </div>
        <span class="track-item-duration">${zn(x.duration)}</span>
      `,w.addEventListener("click",()=>z.playAll(i,x)),d.appendChild(w)})}return a(),M.subscribe(s=>{["likedSongs","playlists","recentlyPlayed","downloads"].includes(s)&&a()}),e}function zn(e){if(!e||!isFinite(e))return"";const t=Math.floor(e/60),a=Math.floor(e%60);return`${t}:${a.toString().padStart(2,"0")}`}function Rn(e){return e?e<1024?e+" B":e<1024*1024?(e/1024).toFixed(0)+" KB":(e/1024/1024).toFixed(1)+" MB":"0 B"}const y0=document.createElement("style");y0.textContent=`
  /* ── Header ── */
  .lib-header { padding: 20px 0 10px; }
  .lib-title { font-size: 28px; font-weight: 700; color: var(--text-primary); }

  /* ── Sections ── */
  .lib-section { margin-bottom: 28px; }
  .lib-section-title {
    font-size: 13px; font-weight: 600; color: var(--accent);
    text-transform: uppercase; letter-spacing: 0.08em;
    margin-bottom: 12px; padding-left: 4px;
  }

  /* ── Quick Access Grid ── */
  .lib-quick-grid {
    display: flex; flex-wrap: wrap; gap: 10px;
  }
  .lib-quick-chip {
    display: flex; align-items: center; gap: 10px;
    background: var(--surface); border: 1px solid var(--surface-border);
    border-radius: 14px; padding: 10px 14px;
    flex: 1; min-width: calc(50% - 5px);
    cursor: pointer; transition: all 0.2s ease;
    -webkit-tap-highlight-color: transparent;
  }
  .lib-quick-chip:active { transform: scale(0.97); opacity: 0.9; }
  .lib-chip-icon {
    width: 36px; height: 36px; border-radius: 10px;
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
  }
  .lib-chip-icon .material-symbols-rounded { font-size: 20px; color: #fff; }
  .downloads-gradient { background: linear-gradient(135deg, #1ed760, #0ea5e9); }
  .liked-gradient { background: linear-gradient(135deg, #7c4dff, #e040fb); }
  .recent-gradient { background: linear-gradient(135deg, #ff6b6b, #ffa726); }
  .lib-chip-label {
    font-size: 14px; font-weight: 600; color: var(--text-primary);
    flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  }
  .lib-chip-count {
    font-size: 12px; font-weight: 700; color: var(--accent);
    background: var(--accent-dim); padding: 2px 8px;
    border-radius: 20px; min-width: 22px; text-align: center;
  }

  /* ── Playlist Cards ── */
  .lib-playlist-list { display: flex; flex-direction: column; gap: 2px; }
  .lib-playlist-card {
    display: flex; align-items: center; gap: 14px;
    padding: 12px 14px; border-radius: 14px;
    background: var(--surface); border: 1px solid var(--surface-border);
    cursor: pointer; transition: all 0.2s ease;
    -webkit-tap-highlight-color: transparent;
    margin-bottom: 8px;
  }
  .lib-playlist-card:active { transform: scale(0.98); opacity: 0.9; }
  .lib-pl-art {
    width: 52px; height: 52px; border-radius: 12px;
    background: var(--bg-tertiary); display: flex;
    align-items: center; justify-content: center;
    flex-shrink: 0; overflow: hidden;
  }
  .lib-pl-art img { width: 100%; height: 100%; object-fit: cover; }
  .lib-pl-art .material-symbols-rounded { font-size: 24px; color: var(--text-tertiary); }
  .lib-pl-info { flex: 1; min-width: 0; }
  .lib-pl-name {
    font-size: 15px; font-weight: 600; color: var(--text-primary);
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  }
  .lib-pl-meta { font-size: 13px; color: var(--text-secondary); margin-top: 2px; }
  .lib-chevron { font-size: 20px; color: var(--text-tertiary); flex-shrink: 0; }

  /* ── Create Button ── */
  .lib-create-btn {
    display: flex; align-items: center; gap: 6px;
    padding: 6px 14px; border-radius: 20px;
    border: 1px solid var(--accent); background: transparent;
    color: var(--accent); font-weight: 600; font-size: 13px;
    cursor: pointer; font-family: var(--font-family);
    transition: all 0.2s ease;
  }
  .lib-create-btn:active { background: var(--accent-dim); }
  .lib-create-btn .material-symbols-rounded { font-size: 18px; }

  /* ── Scale Card ── */
  .lib-scale-card {
    background: var(--surface); border: 1px solid var(--surface-border);
    border-radius: 16px; padding: 16px;
  }
  .lib-scale-header {
    display: flex; align-items: center; gap: 10px; margin-bottom: 12px;
  }
  .lib-scale-header .material-symbols-rounded {
    font-size: 22px; color: var(--accent);
  }
  .lib-scale-label { flex: 1; font-size: 15px; font-weight: 500; color: var(--text-primary); }
  .lib-scale-value {
    font-size: 13px; font-weight: 700; color: var(--accent);
    background: var(--accent-dim); padding: 3px 10px; border-radius: 8px;
  }
  .lib-zoom-slider { width: 100%; accent-color: var(--accent); cursor: pointer; }
  .lib-zoom-labels {
    display: flex; justify-content: space-between;
    font-size: 10px; color: var(--text-tertiary);
    text-transform: uppercase; letter-spacing: 0.05em; margin-top: 4px;
  }

  /* ── View Header (Downloads/Playlist) ── */
  .lib-view-header {
    display: flex; align-items: center; gap: 12px;
    margin-bottom: 20px; padding: 4px 0;
  }
  .lib-view-title { flex: 1; font-size: 22px; font-weight: 700; color: var(--text-primary); }
  .lib-view-count { font-size: 13px; color: var(--text-secondary); }
  .lib-play-btn {
    width: 44px; height: 44px; border-radius: 50%;
    background: var(--accent); border: none;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; flex-shrink: 0;
  }
  .lib-play-btn .material-symbols-rounded { font-size: 22px; color: #000; }
  .lib-play-btn:active { transform: scale(0.93); }

  /* ── Empty State ── */
  .lib-empty {
    text-align: center; padding: 40px 20px; color: var(--text-secondary);
  }
  .lib-empty .material-symbols-rounded {
    font-size: 48px; color: var(--text-tertiary);
    margin-bottom: 12px; display: block;
  }
  .lib-empty p { margin: 0; font-size: 16px; font-weight: 500; }
  .lib-empty-sub { font-size: 13px; color: var(--text-tertiary); margin-top: 6px !important; }
`;document.head.appendChild(y0);async function Nn(e,t){try{return await p0(t,e)}catch(a){console.warn("Lyrics fetch failed:",a)}return null}function Mn(){const e=document.createElement("div");e.className="page nowplaying-page";const t=z.currentTrack;if(!t)return e.innerHTML=`
      <div class="empty-state" style="padding-top: 30vh;">
        <span class="material-symbols-rounded">music_off</span>
        <p>No track playing</p>
        <p class="text-subtitle" style="margin-top: var(--space-sm);">Choose a song to get started</p>
      </div>
    `,e;const a=M.get(),r=M.isLiked(t.id);e.innerHTML=`
    <div class="np-bg" id="np-bg"></div>
    <div class="np-header">
      <button class="btn-icon" id="np-back">
        <span class="material-symbols-rounded">keyboard_arrow_down</span>
      </button>
      <div class="np-header-title">
        <span class="text-tiny" style="text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600;">Now Playing</span>
      </div>
      <button class="btn-icon" id="np-queue">
        <span class="material-symbols-rounded">queue_music</span>
      </button>
    </div>

    <div class="np-body">
      <div class="np-art-container ${z.isPlaying?"playing":""}">
        <img class="np-art" id="np-art" src="${t.cover}" alt="${t.title}" />
      </div>

      <div class="np-info">
        <div class="np-title-row">
          <div class="np-title-wrap">
            <h2 class="np-title" id="np-title">${t.title}</h2>
            <p class="np-artist" id="np-artist" style="pointer-events: auto;">${t.artist}</p>
          </div>
          <button class="btn-icon np-like ${r?"liked":""}" id="np-like">
            <span class="material-symbols-rounded">${r?"favorite":"favorite_border"}</span>
          </button>
        </div>

        <div class="np-progress">
          <div class="np-progress-bar" id="np-progress-bar">
            <div class="np-progress-fill" id="np-progress-fill"></div>
            <div class="np-progress-thumb" id="np-progress-thumb"></div>
          </div>
          <div class="np-time">
            <span id="np-time-current">0:00</span>
            <span id="np-time-total">${Re(t.duration)}</span>
          </div>
        </div>

        <div class="np-controls">
          <button class="btn-icon np-ctrl-btn ${a.shuffle?"active":""}" id="np-shuffle">
            <span class="material-symbols-rounded">shuffle</span>
          </button>
          <button class="btn-icon np-ctrl-btn np-ctrl-lg" id="np-prev">
            <span class="material-symbols-rounded">skip_previous</span>
          </button>
          <button class="btn-play np-play-btn" id="np-play">
            <span class="material-symbols-rounded">${z.isPlaying?"pause":"play_arrow"}</span>
          </button>
          <button class="btn-icon np-ctrl-btn np-ctrl-lg" id="np-next">
            <span class="material-symbols-rounded">skip_next</span>
          </button>
          <button class="btn-icon np-ctrl-btn ${M.isDownloadComplete(t.id)?"active":""}" id="np-download">
             <span class="material-symbols-rounded">${M.isDownloadComplete(t.id)?"download_done":"download"}</span>
          </button>
        </div>

        <!-- Caption / Lyrics Section -->
        <div class="np-caption" id="np-caption">
          <div class="np-caption-toggle" id="np-caption-toggle">
            <span class="material-symbols-rounded" style="font-size:18px;">lyrics</span>
            <span>Lyrics</span>
            <span class="material-symbols-rounded np-caption-arrow" id="np-caption-arrow">expand_more</span>
          </div>
          <div class="np-caption-body" id="np-caption-body" style="display:none;">
            <div class="np-caption-loading" id="np-caption-loading">
              <div class="loading-spinner" style="width:20px;height:20px;border-width:2px;"></div>
              <span>Finding lyrics...</span>
            </div>
            <pre class="np-caption-text" id="np-caption-text" style="display:none;"></pre>
          </div>
        </div>
      </div>
    </div>
  `;const n=e.querySelector("#np-bg");n.style.backgroundImage=`url(${t.cover})`,e.querySelector("#np-back").addEventListener("click",()=>{Y.navigate("home")}),e.querySelector("#np-artist").addEventListener("click",()=>{const u=t.artist.split(",")[0].trim();Y.navigate(`artist?name=${encodeURIComponent(u)}`)}),e.querySelector("#np-download").addEventListener("click",async()=>{const u=e.querySelector("#np-download");if(M.isDownloadComplete(t.id)){te.show("Already downloaded!","info");return}te.show(`Downloading ${t.title}...`,"info"),u.querySelector(".material-symbols-rounded").textContent="hourglass_top",await he.downloadTrack(t)?(u.classList.add("active"),u.querySelector(".material-symbols-rounded").textContent="download_done",te.show(`Downloaded: ${t.title}`,"success")):(u.querySelector(".material-symbols-rounded").textContent="download",te.show("Download failed","error"))}),e.querySelector("#np-play").addEventListener("click",()=>z.togglePlay()),e.querySelector("#np-prev").addEventListener("click",()=>z.prev()),e.querySelector("#np-next").addEventListener("click",()=>z.next()),e.querySelector("#np-shuffle").addEventListener("click",()=>{M.toggleShuffle(),e.querySelector("#np-shuffle").classList.toggle("active")}),e.querySelector("#np-like").addEventListener("click",()=>{M.toggleLike(t);const u=M.isLiked(t.id),l=e.querySelector("#np-like");l.classList.toggle("liked",u),l.querySelector(".material-symbols-rounded").textContent=u?"favorite":"favorite_border"});let s=!1;const b=e.querySelector("#np-caption-toggle"),d=e.querySelector("#np-caption-body"),h=e.querySelector("#np-caption-arrow"),i=e.querySelector("#np-caption-text"),x=e.querySelector("#np-caption-loading");b.addEventListener("click",async()=>{const u=d.style.display!=="none";if(d.style.display=u?"none":"block",h.textContent=u?"expand_more":"expand_less",!u&&!s){s=!0;const l=await Nn(t.title,t.artist);x.style.display="none",i.style.display="block",l?i.textContent=l.replace(/\r\n/g,`
`).replace(/\n{3,}/g,`

`).trim():(i.textContent="Lyrics not available for this song.",i.style.textAlign="center",i.style.color="var(--text-tertiary)")}});const w=e.querySelector("#np-progress-bar");let o=!1,p=0;function f(u){const l=w.getBoundingClientRect();let c=l.left;u.touches&&u.touches.length>0?c=u.touches[0].clientX:u.clientX!==void 0?c=u.clientX:u.changedTouches&&u.changedTouches.length>0&&(c=u.changedTouches[0].clientX);const m=c-l.left;p=Math.max(0,Math.min(1,m/l.width));const v=z.currentTrack?z.currentTrack.duration:parseInt(z.audio.duration||0);v&&g(p*v,v)}function y(){if(!o)return;o=!1;const u=z.currentTrack?z.currentTrack.duration:parseInt(z.audio.duration||0);if(!u)return;const l=Math.floor(u*p);z.seek(l)}w.addEventListener("mousedown",u=>{o=!0,f(u)}),w.addEventListener("touchstart",u=>{o=!0,f(u)},{passive:!0}),document.addEventListener("mousemove",u=>{o&&f(u)}),document.addEventListener("touchmove",u=>{o&&f(u)},{passive:!0}),document.addEventListener("mouseup",()=>{o&&y()}),document.addEventListener("touchend",()=>{o&&y()}),z.on("statechange",({isPlaying:u})=>{const l=e.querySelector("#np-play .material-symbols-rounded");l&&(l.textContent=u?"pause":"play_arrow");const c=e.querySelector(".np-art-container");c&&c.classList.toggle("playing",u)}),z.on("timeupdate",({currentTime:u,duration:l})=>{o||g(u,l)}),z.on("trackchange",u=>{const l=e.querySelector("#np-art"),c=e.querySelector("#np-title"),m=e.querySelector("#np-artist"),v=e.querySelector("#np-time-total"),E=e.querySelector("#np-bg");l&&(l.src=u.cover),c&&(c.textContent=u.title),m&&(m.textContent=u.artist),v&&(u.duration?v.textContent=Re(u.duration):v.textContent="Live"),E&&(E.style.backgroundImage=`url(${u.cover})`);const C=M.isLiked(u.id),B=e.querySelector("#np-like");B&&(B.classList.toggle("liked",C),B.querySelector(".material-symbols-rounded").textContent=C?"favorite":"favorite_border"),s=!1,d.style.display="none",h.textContent="expand_more",x.style.display="flex",i.style.display="none",i.textContent=""});function g(u,l){const c=e.querySelector("#np-time-current"),m=e.querySelector("#np-time-total");if(c&&(c.textContent=Re(u)),!l||!isFinite(l)||l===0){m&&m.textContent!=="Live"&&(m.textContent="Live");return}if(m){const B=Re(l);m.textContent!==B&&(m.textContent=B)}const v=u/l*100,E=e.querySelector("#np-progress-fill"),C=e.querySelector("#np-progress-thumb");E&&(E.style.width=`${v}%`),C&&(C.style.left=`${v}%`)}return e}function Re(e){if(!e||!isFinite(e))return"0:00";const t=Math.floor(e/60),a=Math.floor(e%60);return`${t}:${a.toString().padStart(2,"0")}`}const b0=document.createElement("style");b0.textContent=`
  .nowplaying-page {
    position: relative;
    display: flex;
    flex-direction: column;
    min-height: 100dvh;
    padding: 0 !important;
    padding-bottom: 0 !important;
    overflow-y: auto;
    overflow-x: hidden;
  }

  .np-bg {
    position: fixed;
    inset: 0;
    background-size: cover;
    background-position: center;
    filter: blur(80px) brightness(0.2) saturate(1.5);
    transform: scale(1.5);
    z-index: 0;
    transition: background-image 0.8s ease;
  }

  .np-header {
    position: sticky;
    top: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: var(--space-md) var(--space-lg);
    z-index: 2;
  }

  .np-body {
    position: relative;
    z-index: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 1;
    padding: 0 var(--space-xl);
    padding-bottom: calc(var(--nav-height) + var(--safe-bottom) + 24px);
  }

  .np-art-container {
    position: relative;
    width: min(260px, 55vw);
    aspect-ratio: 1;
    margin-bottom: var(--space-xl);
    border-radius: var(--radius-xl);
    box-shadow: 0 20px 50px rgba(0,0,0,0.6);
    transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    overflow: hidden;
  }

  .np-art-container.playing {
    transform: scale(1.02);
  }

  .np-art {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: inherit;
  }

  .np-info {
    position: relative;
    z-index: 1;
    width: min(380px, 90vw);
  }

  .np-title-row {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: var(--space-md);
  }

  .np-title-wrap {
    flex: 1;
    min-width: 0;
  }

  .np-title {
    font-size: var(--font-lg);
    font-weight: 700;
    letter-spacing: -0.02em;
    margin: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .np-artist {
    font-size: var(--font-sm);
    color: var(--text-secondary);
    margin-top: 2px;
    margin-bottom: var(--space-lg);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .np-progress-bar {
    height: 4px;
    background: rgba(255,255,255,0.1);
    border-radius: var(--radius-full);
    cursor: pointer;
    position: relative;
  }

  .np-progress-fill {
    height: 100%;
    background: var(--accent);
    box-shadow: 0 0 10px var(--accent-glow);
    border-radius: inherit;
  }

  .np-progress-thumb {
    position: absolute;
    top: 50%;
    width: 14px;
    height: 14px;
    background: var(--accent);
    border-radius: 50%;
    transform: translate(-50%, -50%);
    box-shadow: 0 0 6px var(--accent-glow);
  }

  .np-time {
    display: flex;
    justify-content: space-between;
    font-size: var(--font-xs);
    color: var(--text-tertiary);
    margin-top: var(--space-xs);
  }

  .np-controls {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: var(--space-lg);
  }

  .np-play-btn {
    width: 56px;
    height: 56px;
    background: var(--text-primary);
    color: var(--bg-primary);
  }

  .np-play-btn:hover {
    transform: scale(1.08);
  }

  .np-ctrl-lg .material-symbols-rounded {
    font-size: 36px !important;
  }

  .np-ctrl-btn.active {
    color: var(--accent);
  }

  .np-like.liked {
    color: var(--accent);
  }

  /* Caption / Lyrics */
  .np-caption {
    margin-top: var(--space-xl);
    border-radius: var(--radius-lg);
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(255,255,255,0.08);
    overflow: hidden;
  }

  .np-caption-toggle {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    padding: var(--space-md) var(--space-lg);
    cursor: pointer;
    color: var(--text-secondary);
    font-size: var(--font-sm);
    font-weight: 600;
    -webkit-tap-highlight-color: transparent;
    transition: color var(--transition-fast);
  }

  .np-caption-toggle:hover {
    color: var(--text-primary);
  }

  .np-caption-arrow {
    margin-left: auto;
    transition: transform 0.3s ease;
  }

  .np-caption-body {
    padding: 0 var(--space-lg) var(--space-lg);
    max-height: 200px;
    overflow-y: auto;
  }

  .np-caption-loading {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    color: var(--text-tertiary);
    font-size: var(--font-sm);
  }

  .np-caption-text {
    font-family: inherit;
    font-size: var(--font-sm);
    color: var(--text-secondary);
    line-height: 1.8;
    white-space: pre-wrap;
    word-wrap: break-word;
    margin: 0;
  }

  /* Scrollbar for lyrics */
  .np-caption-body::-webkit-scrollbar { width: 3px; }
  .np-caption-body::-webkit-scrollbar-thumb { background: var(--accent-dim); border-radius: 3px; }

  /* Tablet landscape split view */
  @media (min-width: 1024px) {
    .np-body {
      flex-direction: row;
      align-items: center;
      justify-content: center;
      gap: var(--space-3xl);
      padding-top: var(--space-xl);
    }
    .np-art-container {
      width: min(320px, 35vw);
      margin-bottom: 0;
    }
    .np-info {
      width: min(400px, 40vw);
    }
  }
`;document.head.appendChild(b0);function In(){const e=document.createElement("div");e.className="page onboarding-page";const t=new Set;e.innerHTML=`
    <div class="onboarding-content">
      <div class="onboarding-logo">
        <span class="material-symbols-rounded" style="font-size: 48px; color: var(--accent);">music_note</span>
      </div>
      <h1 class="text-greeting" style="text-align: center;">Welcome to Melo</h1>
      <p class="text-subtitle" style="text-align: center; margin-top: var(--space-sm); margin-bottom: var(--space-2xl);">
        What kind of music do you like?<br/>Pick at least 3 to personalize your experience
      </p>
      <div class="onboarding-genres" id="onboarding-genres"></div>
      <button class="onboarding-continue" id="onboarding-continue" disabled>
        Let's Go
      </button>
    </div>
  `;const a=e.querySelector("#onboarding-genres"),r=e.querySelector("#onboarding-continue");return Ht.forEach(n=>{const s=document.createElement("button");s.className="onboarding-genre-chip",s.innerHTML=`
      <span class="material-symbols-rounded">${n.icon}</span>
      <span>${n.name}</span>
    `,s.style.setProperty("--genre-gradient",n.gradient),s.addEventListener("click",()=>{t.has(n.id)?(t.delete(n.id),s.classList.remove("selected")):(t.add(n.id),s.classList.add("selected")),r.disabled=t.size<3}),a.appendChild(s)}),r.addEventListener("click",()=>{M.setInterests([...t]),Y.navigate("home")}),e}const w0=document.createElement("style");w0.textContent=`
  .onboarding-page {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100dvh;
    padding-bottom: var(--space-2xl) !important;
  }

  .onboarding-content {
    max-width: 500px;
    width: 100%;
  }

  .onboarding-logo {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 80px;
    height: 80px;
    margin: 0 auto var(--space-xl);
    border-radius: var(--radius-xl);
    background: var(--accent-dim);
    animation: logoPulse 2s ease-in-out infinite;
  }

  @keyframes logoPulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
  }

  .onboarding-genres {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-md);
    justify-content: center;
    margin-bottom: var(--space-2xl);
  }

  .onboarding-genre-chip {
    display: inline-flex;
    align-items: center;
    gap: var(--space-sm);
    padding: var(--space-md) var(--space-xl);
    border-radius: var(--radius-full);
    border: 2px solid var(--surface-border);
    background: var(--bg-tertiary);
    color: var(--text-primary);
    font-family: var(--font-family);
    font-size: var(--font-base);
    font-weight: 500;
    cursor: pointer;
    transition: all var(--transition-normal);
    -webkit-tap-highlight-color: transparent;
  }

  .onboarding-genre-chip:active {
    transform: scale(0.95);
  }

  .onboarding-genre-chip.selected {
    background: var(--genre-gradient, var(--accent));
    border-color: transparent;
    box-shadow: var(--shadow-md);
    transform: scale(1.05);
  }

  .onboarding-genre-chip .material-symbols-rounded {
    font-size: 20px;
  }

  .onboarding-continue {
    display: block;
    width: 100%;
    padding: var(--space-lg);
    border: none;
    border-radius: var(--radius-full);
    background: var(--accent);
    color: var(--text-on-accent);
    font-family: var(--font-family);
    font-size: var(--font-md);
    font-weight: 600;
    cursor: pointer;
    transition: all var(--transition-normal);
    letter-spacing: 0.02em;
  }

  .onboarding-continue:disabled {
    opacity: 0.3;
    cursor: not-allowed;
  }

  .onboarding-continue:not(:disabled):hover {
    box-shadow: var(--shadow-glow);
    transform: translateY(-1px);
  }

  .onboarding-continue:not(:disabled):active {
    transform: scale(0.98);
  }
`;document.head.appendChild(w0);function On(){const e=document.createElement("div");e.className="page artist-page";const t=Y.getParams().get("name");return t?(e.innerHTML=`
    <div class="home-loading" id="artist-loading">
      <div class="loading-spinner"></div>
      <p class="text-subtitle">Loading ${t}...</p>
    </div>
    <div id="artist-content" style="display:none; padding-bottom: 120px;"></div>
  `,jn(t,e),e):(e.innerHTML='<div class="empty-state"><p>Artist not found.</p></div>',e)}async function jn(e,t){var a;try{const r=t.querySelector("#artist-loading"),n=t.querySelector("#artist-content"),[s,b]=await Promise.allSettled([u0(e),ce(`${e} best songs`)]),d=s.status==="fulfilled"?s.value:null,h=b.status==="fulfilled"?b.value||[]:[];r.style.display="none",n.style.display="block";const i=d?d.name:e,x=(d==null?void 0:d.banner)||(d==null?void 0:d.thumbnail)||((a=h[0])==null?void 0:a.cover)||"",w=d!=null&&d.genre?`<span class="chip" style="pointer-events:none;">${d.genre}</span>`:"",o=d!=null&&d.biography?d.biography:`Explore the top hits and popular songs by ${i}.`,p=document.createElement("div");p.className="artist-header",p.innerHTML=`
      <img class="artist-header-bg" src="${x}" alt="Banner" onerror="this.src=''" />
      <div class="artist-header-overlay"></div>
      <button class="btn-icon artist-back-btn"><span class="material-symbols-rounded">arrow_back</span></button>
      
      <div class="artist-header-content">
        <h1 class="artist-title">${i}</h1>
        <div class="artist-meta">
          ${w}
          <span class="text-subtitle" style="color:#fff;">${h.length} top songs</span>
        </div>
      </div>
      ${h.length>0?'<button class="btn-play artist-play-all"><span class="material-symbols-rounded">play_arrow</span></button>':""}
    `,p.querySelector(".artist-back-btn").addEventListener("click",()=>{window.history.back()}),h.length>0&&p.querySelector(".artist-play-all").addEventListener("click",()=>{z.playAll(h,h[0])}),n.appendChild(p);const f=document.createElement("div");f.className="section",f.innerHTML=`
      <div class="section-header">
        <h2 class="text-section-title">About</h2>
      </div>
      <div class="artist-bio-box">
        <p class="artist-bio-text">${o.replace(/\n\n/g,"<br><br>")}</p>
        <button class="artist-bio-more">Read More</button>
      </div>
    `;const y=f.querySelector(".artist-bio-text"),g=f.querySelector(".artist-bio-more");if(g.addEventListener("click",()=>{y.classList.contains("expanded")?(y.classList.remove("expanded"),g.textContent="Read More"):(y.classList.add("expanded"),g.textContent="Show Less")}),o.length<200&&(g.style.display="none",y.classList.add("expanded")),n.appendChild(f),h.length>0){const l=document.createElement("div");l.className="section",l.innerHTML=`
        <div class="section-header">
          <h2 class="text-section-title">Popular Tracks</h2>
        </div>
      `;const c=document.createElement("div");c.style.display="flex",c.style.flexDirection="column",c.style.gap="var(--space-xs)",h.forEach((m,v)=>{const E=ue(m,h,"horizontal");c.appendChild(E)}),l.appendChild(c),n.appendChild(l)}const u=document.createElement("div");u.className="section",u.innerHTML=`
          <div class="section-header">
            <h2 class="text-section-title">Full Discography</h2>
            <div class="loading-spinner" id="disco-loading" style="width:20px;height:20px;border-width:2px;"></div>
          </div>
          <div id="disco-content" class="horizontal-scroll" style="display:none;"></div>
        `,n.appendChild(u),Be(()=>Promise.resolve().then(()=>v0),void 0).then(async({getArtistDiscography:l})=>{const c=await l(e),m=u.querySelector("#disco-loading"),v=u.querySelector("#disco-content");m.style.display="none",c&&c.length>0?(v.style.display="flex",c.forEach(E=>{const C=document.createElement("div");C.className="album-card",C.innerHTML=`
                      <img class="album-card-art" src="${E.cover}" alt="${E.title}" loading="lazy" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\\'http://www.w3.org/2000/svg\\' viewBox=\\'0 0 100 100\\'%3E%3Crect width=\\'100\\' height=\\'100\\' fill=\\'%232a2a2a\\'/%3E%3Ctext x=\\'50\\' y=\\'55\\' font-family=\\'sans-serif\\' font-size=\\'14\\' fill=\\'%23666\\' text-anchor=\\'middle\\'%3EAlbum%3C/text%3E%3C/svg%3E'" />
                      <div class="album-card-title">${E.title}</div>
                      <div class="album-card-info">${E.year} • ${E.type}</div>
                    `,v.appendChild(C)})):u.style.display="none"})}catch{t.innerHTML='<div class="empty-state"><p>Error loading artist.</p></div>'}}const E0=document.createElement("style");E0.textContent=`
  .artist-page {
    /* Override standard page padding so banner touches the top */
    padding-top: 0 !important;
  }

  .artist-header {
    position: relative;
    width: 100%;
    height: 35vh;
    min-height: 280px;
    margin-bottom: var(--space-2xl);
    border-radius: 0 0 var(--radius-2xl) var(--radius-2xl);
    overflow: hidden;
    box-shadow: var(--shadow-md);
  }

  .artist-header-bg {
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    object-fit: cover;
  }

  .artist-header-overlay {
    position: absolute;
    inset: 0;
    /* Dark gradient overlay so text is legible and fades beautifully into the app */
    background: linear-gradient(to bottom, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.8) 100%);
  }

  .artist-back-btn {
    position: absolute;
    top: max(var(--space-md), env(safe-area-inset-top));
    left: var(--space-md);
    z-index: 10;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(8px);
    color: white;
  }

  .artist-header-content {
    position: absolute;
    bottom: var(--space-xl);
    left: var(--space-xl);
    right: var(--space-xl);
    z-index: 2;
  }

  .artist-title {
    font-size: clamp(28px, 6vw, 42px);
    font-weight: 800;
    color: #ffffff;
    margin: 0 0 var(--space-sm) 0;
    line-height: 1.1;
    text-shadow: 0 2px 8px rgba(0,0,0,0.5);
  }

  .artist-meta {
    display: flex;
    align-items: center;
    gap: var(--space-md);
  }

  .artist-play-all {
    position: absolute;
    bottom: calc(var(--space-xl) - 28px);
    right: var(--space-xl);
    z-index: 10;
    transform: scale(1.1);
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  }

  .artist-bio-box {
    background: var(--surface-glass);
    border: 1px solid var(--surface-border);
    border-radius: var(--radius-xl);
    padding: var(--space-lg);
  }

  .artist-bio-text {
    font-size: var(--font-sm);
    color: var(--text-secondary);
    line-height: 1.6;
    margin: 0;
    
    /* Clamp lines by default */
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
    transition: all 0.3s ease;
  }

  .artist-bio-text.expanded {
    display: block;
    -webkit-line-clamp: unset;
  }

  .artist-bio-more {
    background: none;
    border: none;
    color: var(--accent);
    font-weight: 600;
    font-size: var(--font-sm);
    padding: var(--space-md) 0 0 0;
    cursor: pointer;
  }

  .album-card {
    width: 140px;
    flex-shrink: 0;
  }

  .album-card-art {
    width: 100%;
    aspect-ratio: 1;
    object-fit: cover;
    border-radius: var(--radius-md);
    background: var(--bg-tertiary);
    margin-bottom: var(--space-sm);
    box-shadow: var(--shadow-sm);
  }

  .album-card-title {
    font-size: var(--font-sm);
    font-weight: 500;
    color: var(--text-primary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .album-card-info {
    font-size: var(--font-xs);
    color: var(--text-tertiary);
    margin-top: 2px;
  }
`;document.head.appendChild(E0);function Un(){const e=document.createElement("div");e.className="page podcast-page";const t=Y.getParams(),a=t.get("feed"),r=t.get("title")||"Podcast",n=t.get("artist")||"",s=t.get("cover")||"";return a?(e.innerHTML=`
    <div class="header-nav" style="display:flex; align-items:center; gap:var(--space-md); padding:var(--space-md) 0; margin-bottom:var(--space-lg);">
      <button class="btn-icon" id="podcast-back"><span class="material-symbols-rounded">arrow_back</span></button>
      <h2 class="text-greeting" style="margin:0; font-size:var(--font-lg);">Podcast</h2>
    </div>

    <!-- Header Section -->
    <div style="display:flex; flex-direction:column; align-items:center; text-align:center; margin-bottom:var(--space-2xl);">
      <img src="${s}" alt="${r}" style="width:200px; height:200px; border-radius:var(--radius-xl); object-fit:cover; margin-bottom:var(--space-lg); box-shadow:var(--shadow-lg);" />
      <h1 class="text-section-title" style="margin-bottom:var(--space-xs); font-size:24px;">${r}</h1>
      <p class="text-subtitle" style="font-size:var(--font-md);">${n}</p>
    </div>

    <div class="home-loading" id="podcast-loading">
      <div class="loading-spinner"></div>
      <p class="text-subtitle" style="margin-top:var(--space-sm);">Loading latest episodes...</p>
    </div>
    
    <div id="podcast-content" style="display:none; padding-bottom: 120px;"></div>
  `,e.querySelector("#podcast-back").addEventListener("click",()=>{window.history.back()}),Wn(a,s,n,e),e):(e.innerHTML='<div class="empty-state"><p>Podcast not found.</p></div>',e)}async function Wn(e,t,a,r){try{const n=r.querySelector("#podcast-loading"),s=r.querySelector("#podcast-content"),b=await h0(e,t,a);if(n.style.display="none",s.style.display="block",b.length===0){s.innerHTML=`
        <div class="empty-state">
          <span class="material-symbols-rounded">podcasts</span>
          <p>No episodes found or feed is unsupported.</p>
        </div>
      `;return}const d=document.createElement("div");d.innerHTML=`
      <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:var(--space-lg);">
        <h2 class="text-section-title">Latest Episodes</h2>
        <button class="chip" id="podcast-play-all">
          <span class="material-symbols-rounded" style="font-size:16px;">play_arrow</span> Play Latest
        </button>
      </div>
    `,d.querySelector("#podcast-play-all").addEventListener("click",()=>{z.playAll(b,b[0])}),s.appendChild(d);const h=document.createElement("div");h.style.display="flex",h.style.flexDirection="column",h.style.gap="var(--space-md)",b.forEach(i=>{const x=document.createElement("div");x.className="podcast-ep-card",x.innerHTML=`
        <div class="podcast-ep-meta">
          <span class="text-subtitle" style="font-size:12px;">${Kn(i.date)}</span>
        </div>
        <div class="podcast-ep-main">
          <div class="podcast-ep-info">
            <h3 class="podcast-ep-title">${i.title}</h3>
            <p class="podcast-ep-desc">${i.description}</p>
          </div>
          <button class="btn-play podcast-ep-play"><span class="material-symbols-rounded">play_arrow</span></button>
        </div>
      `,x.querySelector(".podcast-ep-play").addEventListener("click",()=>{z.playAll(b,i)}),h.appendChild(x)}),s.appendChild(h)}catch{r.querySelector("#podcast-loading").innerHTML=`
      <div class="empty-state">
        <span class="material-symbols-rounded">error</span>
        <p>Could not load episodes.</p>
      </div>
    `}}function Kn(e){if(!e)return"Recent";try{const t=new Date(e);return isNaN(t.getTime())?e:t.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}catch{return e}}const C0=document.createElement("style");C0.textContent=`
  .podcast-ep-card {
    background: var(--surface-glass);
    border: 1px solid var(--surface-border);
    border-radius: var(--radius-lg);
    padding: var(--space-md);
  }

  .podcast-ep-meta {
    margin-bottom: var(--space-xs);
  }

  .podcast-ep-main {
    display: flex;
    align-items: center;
    gap: var(--space-md);
  }

  .podcast-ep-info {
    flex: 1;
    min-width: 0;
  }

  .podcast-ep-title {
    font-size: var(--font-md);
    font-weight: 600;
    color: var(--text-primary);
    margin: 0 0 var(--space-xs) 0;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  .podcast-ep-desc {
    font-size: 13px;
    color: var(--text-secondary);
    margin: 0;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  .podcast-ep-play {
    width: 44px;
    height: 44px;
    flex-shrink: 0;
  }
`;document.head.appendChild(C0);const Gn="__capgo_keep_url_path_after_reload",St="__capgo_history_stack__",Kr=100,Vn=typeof window<"u"&&typeof document<"u"&&typeof history<"u";if(Vn){const e=window;if(!e.__capgoHistoryPatched){e.__capgoHistoryPatched=!0;const t=()=>{try{if(e.__capgoKeepUrlPathAfterReload)return!0}catch{}try{return window.localStorage.getItem(Gn)==="1"}catch{return!1}},a=()=>{try{const v=window.sessionStorage.getItem(St);if(!v)return{stack:[],index:-1};const E=JSON.parse(v);return!E||!Array.isArray(E.stack)||typeof E.index!="number"?{stack:[],index:-1}:E}catch{return{stack:[],index:-1}}},r=(v,E)=>{try{window.sessionStorage.setItem(St,JSON.stringify({stack:v,index:E}))}catch{}},n=()=>{try{window.sessionStorage.removeItem(St)}catch{}},s=v=>{try{const E=v??window.location.href,C=new URL(E instanceof URL?E.toString():E,window.location.href);return`${C.pathname}${C.search}${C.hash}`}catch{return null}},b=(v,E)=>{if(v.length<=Kr)return{stack:v,index:E};const C=v.length-Kr,B=v.slice(C),D=Math.max(0,E-C);return{stack:B,index:D}},d=v=>{document.readyState==="complete"||document.readyState==="interactive"?v():window.addEventListener("DOMContentLoaded",v,{once:!0})};let h=!1,i=!1,x=!1;const w=()=>{if(!h)return;const v=a(),E=s();if(E){if(v.stack.length===0){v.stack.push(E),v.index=0,r(v.stack,v.index);return}(v.index<0||v.index>=v.stack.length)&&(v.index=v.stack.length-1),v.stack[v.index]!==E&&(v.stack[v.index]=E,r(v.stack,v.index))}},o=(v,E)=>{if(!h||i)return;const C=s(v);if(!C)return;let{stack:B,index:D}=a();B.length===0?(B.push(C),D=B.length-1):E?((D<0||D>=B.length)&&(D=B.length-1),B[D]=C):D>=B.length-1?(B.push(C),D=B.length-1):(B=B.slice(0,D+1),B.push(C),D=B.length-1),{stack:B,index:D}=b(B,D),r(B,D)},p=()=>{if(!h||i)return;const v=a();if(v.stack.length===0){w();return}const E=v.index>=0&&v.index<v.stack.length?v.index:v.stack.length-1,C=s();if(v.stack.length===1&&C===v.stack[0])return;const B=v.stack[0];if(!B)return;i=!0;try{history.replaceState(history.state,document.title,B);for(let _=1;_<v.stack.length;_+=1)history.pushState(history.state,document.title,v.stack[_])}catch{i=!1;return}i=!1;const D=v.stack.length-1,A=E-D;A!==0?history.go(A):(history.replaceState(history.state,document.title,v.stack[E]),window.dispatchEvent(new PopStateEvent("popstate")))},f=()=>{!h||x||(x=!0,d(()=>{x=!1,p()}))};let y=null,g=null;const u=()=>{if(!h||i)return;const v=s();if(!v)return;const E=a(),C=E.stack.lastIndexOf(v);C>=0?E.index=C:(E.stack.push(v),E.index=E.stack.length-1);const B=b(E.stack,E.index);r(B.stack,B.index)},l=()=>{y&&g||(y=history.pushState,g=history.replaceState,history.pushState=function(E,C,B){const D=y==null?void 0:y.call(history,E,C,B);return o(B,!1),D},history.replaceState=function(E,C,B){const D=g==null?void 0:g.call(history,E,C,B);return o(B,!0),D},window.addEventListener("popstate",u))},c=()=>{y&&(history.pushState=y,y=null),g&&(history.replaceState=g,g=null),window.removeEventListener("popstate",u)},m=v=>{if(h===v){h&&(w(),f());return}h=v,h?(l(),w(),f()):(c(),n())};window.addEventListener("CapacitorUpdaterKeepUrlPathAfterReload",v=>{var E;const C=v,B=(E=C==null?void 0:C.detail)===null||E===void 0?void 0:E.enabled;typeof B=="boolean"?(e.__capgoKeepUrlPathAfterReload=B,m(B)):(e.__capgoKeepUrlPathAfterReload=!0,m(!0))}),m(t())}}var Gr;(function(e){e[e.UNKNOWN=0]="UNKNOWN",e[e.UPDATE_NOT_AVAILABLE=1]="UPDATE_NOT_AVAILABLE",e[e.UPDATE_AVAILABLE=2]="UPDATE_AVAILABLE",e[e.UPDATE_IN_PROGRESS=3]="UPDATE_IN_PROGRESS"})(Gr||(Gr={}));var Vr;(function(e){e[e.UNKNOWN=0]="UNKNOWN",e[e.PENDING=1]="PENDING",e[e.DOWNLOADING=2]="DOWNLOADING",e[e.INSTALLING=3]="INSTALLING",e[e.INSTALLED=4]="INSTALLED",e[e.FAILED=5]="FAILED",e[e.CANCELED=6]="CANCELED",e[e.DOWNLOADED=11]="DOWNLOADED"})(Vr||(Vr={}));var Xr;(function(e){e[e.OK=0]="OK",e[e.CANCELED=1]="CANCELED",e[e.FAILED=2]="FAILED",e[e.NOT_AVAILABLE=3]="NOT_AVAILABLE",e[e.NOT_ALLOWED=4]="NOT_ALLOWED",e[e.INFO_MISSING=5]="INFO_MISSING"})(Xr||(Xr={}));const $t=de("CapacitorUpdater",{web:()=>Be(()=>import("./web-Bj5_3swu.js"),[]).then(e=>new e.CapacitorUpdaterWeb)}),Tt=de("App",{web:()=>Be(()=>import("./web-COrXD_1V.js"),[]).then(e=>new e.AppWeb)}),B0="1.0.10",Xn="https://api.github.com/repos/maheshwarkibehan-hub/MElo-music-player/contents/version.json";function Yn(e,t){const a=e.split(".").map(Number),r=t.split(".").map(Number);for(let n=0;n<Math.max(a.length,r.length);n++){const s=a[n]||0,b=r[n]||0;if(s>b)return!0;if(s<b)return!1}return!1}function Qn(){const e=document.createElement("div");return e.className="page settings-page",e.innerHTML=`
    <div class="settings-header">
      <h1 class="settings-title">Settings</h1>
    </div>

    <div class="settings-section">
      <div class="settings-section-title">App Info</div>
      <div class="settings-card">
        <div class="settings-row">
          <span class="material-symbols-rounded" style="color: var(--accent);">info</span>
          <div class="settings-row-text">
            <span class="settings-label">Current Version</span>
            <span class="settings-value" id="settings-version">${B0}</span>
          </div>
        </div>
        <div class="settings-divider"></div>
        <div class="settings-row">
          <span class="material-symbols-rounded" style="color: var(--accent);">cloud_done</span>
          <div class="settings-row-text">
            <span class="settings-label">Update Status</span>
            <span class="settings-value" id="settings-status">Tap below to check</span>
          </div>
        </div>
        <div class="settings-divider"></div>
        <div class="settings-row">
          <span class="material-symbols-rounded" style="color: var(--accent);">new_releases</span>
          <div class="settings-row-text">
            <span class="settings-label">Latest Version</span>
            <span class="settings-value" id="settings-latest">--</span>
          </div>
        </div>
      </div>
    </div>

    <div class="settings-section">
      <div class="settings-section-title">Updates</div>
      <div class="settings-card">
        <button class="settings-btn" id="settings-check-update">
          <span class="material-symbols-rounded">system_update</span>
          <span>Check for Updates</span>
        </button>
        <div id="settings-update-area"></div>
      </div>
    </div>

    <div class="settings-section">
      <div class="settings-section-title">About</div>
      <div class="settings-card">
        <div class="settings-row">
          <span class="material-symbols-rounded" style="color: var(--text-secondary);">code</span>
          <div class="settings-row-text">
            <span class="settings-label">Developer</span>
            <span class="settings-value">Maheshwar</span>
          </div>
        </div>
        <div class="settings-divider"></div>
        <div class="settings-row">
          <span class="material-symbols-rounded" style="color: var(--text-secondary);">music_note</span>
          <div class="settings-row-text">
            <span class="settings-label">App Name</span>
            <span class="settings-value">Melo Music Player</span>
          </div>
        </div>
      </div>
    </div>
  `,e.querySelector("#settings-check-update").addEventListener("click",()=>Zn(e)),e}async function Zn(e){const t=e.querySelector("#settings-status"),a=e.querySelector("#settings-latest"),r=e.querySelector("#settings-update-area"),n=e.querySelector("#settings-check-update");n.disabled=!0,n.querySelector("span:last-child").textContent="Checking...",t.textContent="Checking...",t.style.color="var(--text-secondary)";try{const s=await fetch(Xn+"?t="+Date.now(),{headers:{Accept:"application/vnd.github.v3.raw"},cache:"no-store"});if(!s.ok)throw new Error("Failed: "+s.status);const b=await s.json();a.textContent=b.version||"--",Yn(b.version,B0)?(t.textContent="Update available!",t.style.color="#ff9800",r.innerHTML=`
        <div class="settings-divider"></div>
        <button class="settings-btn settings-btn-accent" id="settings-do-update">
          <span class="material-symbols-rounded">download</span>
          <span>Download & Install v${b.version}</span>
        </button>
        <p class="settings-hint" id="settings-progress">App will restart to apply</p>
      `,e.querySelector("#settings-do-update").addEventListener("click",()=>Jn(e,b))):(t.textContent="Up to date ✓",t.style.color="#4caf50",r.innerHTML="")}catch{t.textContent="Check failed",t.style.color="#e53935",a.textContent="--"}n.disabled=!1,n.querySelector("span:last-child").textContent="Check for Updates"}async function Jn(e,t){const a=e.querySelector("#settings-do-update"),r=e.querySelector("#settings-progress");a.disabled=!0,a.querySelector("span:last-child").textContent="Downloading...",r.textContent="Downloading update...",r.style.color="var(--text-secondary)";try{const n=await $t.download({url:t.url,version:t.version});r.textContent="Installing...",a.querySelector("span:last-child").textContent="Installing...",await $t.set(n),a.querySelector("span:last-child").textContent="Restarting...",r.textContent="Restarting app...",setTimeout(()=>Tt.exitApp(),500)}catch(n){r.textContent="Failed: "+(n.message||n),r.style.color="#e53935",a.disabled=!1,a.querySelector("span:last-child").textContent="Retry"}}const A0=document.createElement("style");A0.textContent=`
  .settings-page { padding: 20px 16px 120px; }
  .settings-header { padding: 20px 0 10px; }
  .settings-title { font-size: 28px; font-weight: 700; color: var(--text-primary); }
  .settings-section { margin-bottom: 24px; }
  .settings-section-title { font-size: 13px; font-weight: 600; color: var(--accent); text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 10px; padding-left: 4px; }
  .settings-card { background: var(--surface); border-radius: 16px; padding: 4px 0; border: 1px solid var(--surface-border); }
  .settings-row { display: flex; align-items: center; gap: 14px; padding: 14px 18px; }
  .settings-row .material-symbols-rounded { font-size: 22px; flex-shrink: 0; }
  .settings-row-text { display: flex; flex-direction: column; flex: 1; min-width: 0; }
  .settings-label { font-size: 15px; font-weight: 500; color: var(--text-primary); }
  .settings-value { font-size: 13px; color: var(--text-secondary); margin-top: 2px; }
  .settings-divider { height: 1px; background: var(--surface-border); margin: 0 18px; }
  .settings-btn { display: flex; align-items: center; justify-content: center; gap: 10px; width: calc(100% - 24px); margin: 10px 12px; padding: 14px; border-radius: 12px; border: none; background: rgba(255,255,255,0.05); color: var(--text-primary); font-weight: 600; font-size: 15px; cursor: pointer; font-family: var(--font-family); transition: all 0.2s ease; }
  .settings-btn:active { transform: scale(0.97); }
  .settings-btn:disabled { opacity: 0.5; pointer-events: none; }
  .settings-btn-accent { background: var(--accent); color: black; }
  .settings-btn-accent:active { filter: brightness(0.9); }
  .settings-hint { text-align: center; font-size: 12px; color: var(--text-secondary); margin: 4px 0 10px; padding: 0; }
`;document.head.appendChild(A0);var zt;(function(e){e.Dark="DARK",e.Light="LIGHT",e.Default="DEFAULT"})(zt||(zt={}));var Yr;(function(e){e.None="NONE",e.Slide="SLIDE",e.Fade="FADE"})(Yr||(Yr={}));const Qr=de("StatusBar");var Zr;(function(e){e[e.Sunday=1]="Sunday",e[e.Monday=2]="Monday",e[e.Tuesday=3]="Tuesday",e[e.Wednesday=4]="Wednesday",e[e.Thursday=5]="Thursday",e[e.Friday=6]="Friday",e[e.Saturday=7]="Saturday"})(Zr||(Zr={}));const Lt=de("LocalNotifications",{web:()=>Be(()=>import("./web-mFoM3R3p.js"),[]).then(e=>new e.LocalNotificationsWeb)});async function ei(){try{try{await Qr.setOverlaysWebView({overlay:!0})}catch{}try{await Qr.setStyle({style:zt.Dark})}catch{}try{(await Lt.checkPermissions()).display!=="granted"&&await Lt.requestPermissions()}catch{}try{await Lt.createChannel({id:"media_playback",name:"Music Controls",description:"Music playback controls",importance:5,visibility:1,sound:null,vibration:!1})}catch{}try{$t.notifyAppReady()}catch{}}catch(e){console.warn("Native APIs not available:",e)}}const ti=async()=>{try{await a0.impact({style:Ct.Light})}catch{}},ri=()=>{const e=localStorage.getItem("melo-zoom")||"1.0";document.documentElement.style.setProperty("--zoom",e),document.body.style.zoom=e};ri();ei();Tt.addListener("backButton",({canGoBack:e})=>{window.location.hash&&window.location.hash!=="#/home"?window.history.back():Tt.exitApp()});function ai(){const e=document.getElementById("app");if(!M.get().onboarded){e.innerHTML="",e.appendChild(In());const a=M.subscribe(r=>{r==="interests"&&(a(),Jr())});return}Jr()}function Jr(){const e=document.getElementById("app");e.innerHTML="";const t=document.createElement("main");t.id="page-content",e.appendChild(t),e.appendChild(ia()),e.appendChild(O0()),Y.register("home",Hn),Y.register("search",$n),Y.register("library",Tn),Y.register("nowplaying",Mn),Y.register("artist",On),Y.register("podcast",Un),Y.register("settings",Qn),Y.init(t),(!window.location.hash||window.location.hash==="#")&&Y.navigate("home"),window.addEventListener("routechange",()=>{ti()})}window.onerror=(e,t,a,r,n)=>{const s=document.createElement("div");s.style.cssText="position:fixed;top:0;left:0;right:0;padding:20px;background:#e53935;color:#fff;z-index:99999;font-size:14px;white-space:pre-wrap;font-family:monospace;",s.textContent=`ERROR: ${e}
File: ${t}
Line: ${a}:${r}
${(n==null?void 0:n.stack)||""}`,document.body.appendChild(s)};window.addEventListener("unhandledrejection",e=>{var a,r;const t=document.createElement("div");t.style.cssText="position:fixed;top:0;left:0;right:0;padding:20px;background:#e53935;color:#fff;z-index:99999;font-size:14px;white-space:pre-wrap;font-family:monospace;",t.textContent=`PROMISE ERROR: ${((a=e.reason)==null?void 0:a.message)||e.reason}
${((r=e.reason)==null?void 0:r.stack)||""}`,document.body.appendChild(t)});try{ai()}catch(e){document.body.innerHTML=`<div style="padding:20px;color:#e53935;font-family:monospace;"><h2>App Crash</h2><pre>${e.message}
${e.stack}</pre></div>`}export{Gr as A,Ct as I,sr as N,Rt as W};
